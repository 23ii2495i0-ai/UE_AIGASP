# GASP Animation UE 插件

本目录是可移植插件，示例工程在上两级 `GaspNative.uproject`。已在 UE 5.8.3 编译验证；其他引擎版本需要自行重编译验证。

## 安装

把整个 `GaspAnimation` 目录复制到目标 C++ 工程的 `Plugins/`，生成项目文件并编译编辑器，启用 GASP Animation。运行时依赖 PoseSearch、BlendStack、AnimationWarping、MotionWarping、Chooser；编辑器依赖 PythonScriptPlugin。保留模块名 GaspNative/GaspNativeEditor，以兼容已有 `/Script/GaspNative` 资产。

项目设置 → Plugins → GASP Animation：配置默认 Animation Set、训练 Python、外部 AI 工作目录和模型服务地址。Tools → GASP → 动画配置工具。AI 默认关闭，手工配置和 MM 运行时不要求安装训练依赖。

插件不包含本工程的 Epic 示例角色、动画、MM 数据库或模型权重。请在目标工程创建 Animation Set，并配置自己的骨骼、动画资源和角色绑定；也可通过 UE 的迁移功能迁移有使用权的示例资产及依赖。角色继续可用已有 Animation Set 显式绑定。

## 目录

- `Source/GaspNative`：运行时、MM、动作、原生动画链。
- `Source/GaspNativeEditor`：配置工具、数据库和动画蓝图模板导出。
- `Resources/Python/gasp_ai`：公开模型 SDK、命令行、训练与扩展契约。
- `Resources/Python/anim_config`：原有协议与模型实现，供 SDK 和编辑器调用。
- `Tests/Python`：无模型依赖的接口检查。

动画模板继续使用 Motion Matching，公开动画组变量供子级动画蓝图修改；本次插件迁移不升级状态机协议。

训练、替换模型与扩展接口见 [AI_INTERFACES.md](AI_INTERFACES.md)。权重、训练数据和审核记录放在插件外。源码发布与独立宿主编译可使用仓库 `tools/build/package_plugin.ps1`。
