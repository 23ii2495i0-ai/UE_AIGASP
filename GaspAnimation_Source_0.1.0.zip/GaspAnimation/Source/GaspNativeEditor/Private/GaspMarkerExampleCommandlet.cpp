#include "GaspMarkerExampleCommandlet.h"
#include "GaspAnimationSet.h"
#include "GaspNativeCharacter.h"
#include "GaspNativeGameMode.h"
#include "GaspChooserMigration.h"
#include "Chooser.h"
#include "Animation/AnimSequence.h"
#include "Animation/AnimMontage.h"
#include "Engine/SkeletalMesh.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchFeatureChannel_Position.h"
#include "Engine/World.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/DirectionalLight.h"
#include "Components/StaticMeshComponent.h"
#include "Components/LightComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/WorldSettings.h"
#include "Misc/PackageName.h"
#include "UObject/SavePackage.h"
#include "UObject/UnrealType.h"
#include "AssetRegistry/AssetRegistryModule.h"

namespace {
bool SaveMarker(UObject* Object)
{
    Object->SetFlags(RF_Public|RF_Standalone);
    FSavePackageArgs Args; Args.TopLevelFlags=RF_Public|RF_Standalone;
    FAssetRegistryModule::AssetCreated(Object);
    const FString File=FPackageName::LongPackageNameToFilename(Object->GetOutermost()->GetName(),Object->IsA<UWorld>() ? TEXT(".umap") : TEXT(".uasset"));
    return UPackage::SavePackage(Object->GetOutermost(),Object,*File,Args);
}
template<typename T> T* Asset(const TCHAR* Name)
{
    const FString Path=FString(TEXT("/Game/Native/MarkerExample/"))+Name;
    if (auto* Existing=LoadObject<T>(nullptr,*Path,nullptr,LOAD_NoWarn)) return Existing;
    return NewObject<T>(CreatePackage(*Path),Name,RF_Public|RF_Standalone);
}
}
int32 UGaspMarkerExampleCommandlet::Main(const FString& Params)
{
    auto* Mesh=LoadObject<USkeletalMesh>(nullptr,TEXT("/Game/Native/MarkerExample/SK_Marker.SK_Marker"));
    auto* Run=LoadObject<UAnimSequence>(nullptr,TEXT("/Game/Native/MarkerExample/A_FastRun.A_FastRun"));
    if (!Mesh || !Run || Mesh->GetSkeleton()!=Run->GetSkeleton()) return 1;
    const auto& Ref=Mesh->GetRefSkeleton();
    auto Bone=[&](const TCHAR* Suffix) -> FName { for (int32 I=0;I<Ref.GetNum();++I) if (Ref.GetBoneName(I).ToString().EndsWith(Suffix)) return Ref.GetBoneName(I); return NAME_None; };
    auto* Set=Asset<UGaspAnimationSet>(TEXT("DA_Marker_Run"));
    Set->Mesh=Mesh; Set->Bones.Root=Ref.GetBoneName(0); Set->Bones.Pelvis=Bone(TEXT("Hips"));
    Set->Bones.Feet={Bone(TEXT("LeftFoot")),Bone(TEXT("RightFoot"))};
    Set->Bones.Thighs={Bone(TEXT("LeftUpLeg")),Bone(TEXT("RightUpLeg"))};
    Set->Bones.Spine={Bone(TEXT("Spine")),Bone(TEXT("Spine1")),Bone(TEXT("Spine2"))};
    Set->Bones.IKRoot=NAME_None; Set->Bones.IKFeet={NAME_None,NAME_None}; Set->Bones.Balls={Bone(TEXT("LeftToeBase")),Bone(TEXT("RightToeBase"))};
    Set->Bones.MeshYawOffset=-90; Set->Lean=nullptr; Set->Aim=nullptr;
    Set->bEnableFootIK=false; Set->bEnableSampleWarping=false; Set->bEnableRootOffset=false; Set->bReferencePoseWhenStopped=true;
    Set->PlayRateRange=FVector2D(1,1);
    Run->bLoop=true; Run->bEnableRootMotion=false; if (!SaveMarker(Run)) return 2;
    auto* Schema=Asset<UPoseSearchSchema>(TEXT("PSS_Marker_Run"));
    for (const TCHAR* Field : {TEXT("Skeletons"),TEXT("Channels")}) { auto* Property=FindFProperty<FArrayProperty>(Schema->GetClass(),Field); FScriptArrayHelper(Property,Property->ContainerPtrToValuePtr<void>(Schema)).EmptyValues(); }
    Schema->AddSkeleton(Mesh->GetSkeleton());
    for (FName Foot:Set->Bones.Feet)
    {
        auto* Channel=NewObject<UPoseSearchFeatureChannel_Position>(Schema);
        Channel->Bone.BoneName=Foot; Channel->OriginBone.BoneName=Set->Bones.Pelvis;
        Schema->AddChannel(Channel);
    }
    Schema->PostEditChange(); if (!SaveMarker(Schema)) return 3;
    auto* DB=Asset<UPoseSearchDatabase>(TEXT("PSD_Marker_Run")); DB->Schema=Schema;
    while (DB->GetNumAnimationAssets()) DB->RemoveAnimationAssetAt(0);
    FPoseSearchDatabaseAnimationAsset Entry; Entry.AnimAsset=Run; DB->AddAnimationAsset(Entry);
    DB->PoseSearchMode=EPoseSearchMode::BruteForce;
    DB->PostEditChange(); if (!SaveMarker(DB)) return 4;
    const FString Rules=FString::Printf(TEXT(R"({"root":"Run","tables":{"Run":{"results":[{"asset":"%s"}],"columns":[],"disabled":[false]}}})"),*DB->GetPathName());
    Set->DenseTable=BuildGaspChooserTable(Rules,TEXT("/Game/Native/MarkerExample/CHT_Marker_Run"),UPoseSearchDatabase::StaticClass());
    Set->SparseTable=Set->DenseTable;
    Set->TraversalTable=Asset<UChooserTable>(TEXT("CHT_Marker_NoTraversal")); Set->TraversalTable->OutputObjectType=UAnimMontage::StaticClass(); Set->TraversalTable->ResultsStructs.Reset();
    if (!SaveMarker(Set->DenseTable) || !SaveMarker(Set->TraversalTable)) return 5;
    FString Error; if (!Set->ValidateForMesh(Mesh,Error)) { UE_LOG(LogTemp,Error,TEXT("MARKER_INVALID %s"),*Error); return 6; }
    if (!SaveMarker(Set)) return 7;
    for (int32 I=0; I<Ref.GetNum();++I) UE_LOG(LogTemp,Display,TEXT("MARKER_BONE %s"),*Ref.GetBoneName(I).ToString());
    if (!FPackageName::DoesPackageExist(TEXT("/Game/Native/MarkerExample/L_MarkerExample")))
    {
        const auto Init=UWorld::InitializationValues().AllowAudioPlayback(false).CreatePhysicsScene(true).CreateNavigation(false).ShouldSimulatePhysics(false).SetTransactional(false);
        auto* World=UWorld::CreateWorld(EWorldType::Editor,false,TEXT("L_MarkerExample"),CreatePackage(TEXT("/Game/Native/MarkerExample/L_MarkerExample")),true,ERHIFeatureLevel::Num,&Init);
        auto* Floor=World->SpawnActor<AStaticMeshActor>(); Floor->GetStaticMeshComponent()->SetStaticMesh(LoadObject<UStaticMesh>(nullptr,TEXT("/Engine/BasicShapes/Cube.Cube")));
        Floor->SetActorLocation(FVector(500,0,-25)); Floor->SetActorScale3D(FVector(60,40,.5)); Floor->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAll"));
        auto* Character=World->SpawnActor<AGaspNativeCharacter>(FVector(0,0,90),FRotator::ZeroRotator);
        Character->AnimationSetOverride=Set; Character->AutoPossessPlayer=EAutoReceiveInput::Player0;
        Character->GetMesh()->SetSkeletalMesh(Mesh); Character->SetActorLabel(TEXT("Marker - native C++ resource example"));
        auto* Light=World->SpawnActor<ADirectionalLight>(); Light->SetActorRotation(FRotator(-45,-30,0)); Light->GetLightComponent()->SetIntensity(5);
        World->GetWorldSettings()->DefaultGameMode=AGaspNativeGameMode::StaticClass();
        if (!SaveMarker(World)) return 8; World->DestroyWorld(false);
    }
    UE_LOG(LogTemp,Display,TEXT("MARKER_EXAMPLE_READY bones=%d length=%f"),Ref.GetNum(),Run->GetPlayLength());
    return 0;
}


