#include "GaspConfigTool.h"
#include "GaspAnimationSettings.h"
#include "Interfaces/IPluginManager.h"
#include "GaspAnimationSet.h"
#include "GaspChooserMigration.h"
#include "Chooser.h"
#include "Animation/AnimSequence.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimBlueprint.h"
#include "AnimGraphNode_Root.h"
#include "AnimGraphNode_LinkedAnimGraph.h"
#include "AnimGraphNode_Base.h"
#include "AnimGraphNode_StateMachine.h"
#include "AnimGraphNode_SaveCachedPose.h"
#include "AnimGraphNode_UseCachedPose.h"
#include "AnimGraphNode_TransitionResult.h"
#include "AnimGraphNode_StateResult.h"
#include "AnimStateNode.h"
#include "AnimStateEntryNode.h"
#include "AnimStateTransitionNode.h"
#include "AnimationStateMachineGraph.h"
#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphPin.h"
#include "EdGraphSchema_K2.h"
#include "AnimationGraphSchema.h"
#include "K2Node_VariableGet.h"
#include "Factories/AnimBlueprintFactory.h"
#include "GaspBehaviorComponent.h"
#include "Animation/AnimMontage.h"
#include "Engine/SkeletalMesh.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "PoseSearch/PoseSearchFeatureChannel_Position.h"
#include "PoseSearch/PoseSearchFeatureChannel_Trajectory.h"
#include "PoseSearch/PoseSearchFeatureChannel_Pose.h"
#include "UObject/UnrealType.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "HAL/PlatformProcess.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "Misc/PackageName.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "UObject/SavePackage.h"
#include "Engine/Blueprint.h"
#include "GaspNativeCharacter.h"
#include "GaspCppAnimInstance.h"
#include "GaspNativeAnimInstance.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Animation/AnimInstance.h"
#include "ScopedTransaction.h"

namespace GaspConfigTool {
FString BackendDirectory()
{
    const auto Plugin=IPluginManager::Get().FindPlugin(TEXT("GaspAnimation"));
    return Plugin ? FPaths::ConvertRelativePathToFull(Plugin->GetBaseDir()/TEXT("Resources/Python/anim_config")):FString();
}
FString Backend() { FPlatformMisc::SetEnvironmentVar(TEXT("GASP_AI_WORKSPACE"),*Workspace()); return BackendDirectory()/TEXT("config_tool.py"); }
FString Workspace()
{
    FString Value=FPlatformMisc::GetEnvironmentVariable(TEXT("GASP_AI_WORKSPACE"));
    if(Value.IsEmpty())Value=GetDefault<UGaspAnimationSettings>()->AIWorkspace.Path;
    if(!Value.IsEmpty())return FPaths::ConvertRelativePathToFull(Value);
    const FString Development=FPaths::ConvertRelativePathToFull(FPaths::ProjectDir()/TEXT(".."));
    return FPaths::DirectoryExists(Development/TEXT("artifacts/anim_config/models")) ? Development:FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir()/TEXT("GaspAnimationAI"));
}
FString Python() { FString Value=FPlatformMisc::GetEnvironmentVariable(TEXT("GASP_CONFIG_PYTHON")); if(Value.IsEmpty())Value=GetDefault<UGaspAnimationSettings>()->PythonExecutable; if (!Value.IsEmpty()) return Value; const FString Bundled=FPaths::ConvertRelativePathToFull(FPaths::EngineDir()/TEXT("Binaries/ThirdParty/Python3/Win64/python.exe")); return FPaths::FileExists(Bundled) ? Bundled : TEXT("python"); }
static FString Encode(const TSharedPtr<FJsonObject>& Object) { FString Text; FJsonSerializer::Serialize(Object.ToSharedRef(),TJsonWriterFactory<>::Create(&Text)); return Text; }
static TSharedPtr<FJsonObject> Read(const FString& File) { FString Text; TSharedPtr<FJsonObject> Object; if (FFileHelper::LoadFileToString(Text,*File)) FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),Object); return Object; }
static bool Save(UObject* Object,bool bNewAsset=true);
static UAnimBlueprint* CreateAnimBlueprint(const FString& Path,const FString& Name,UClass* ParentClass,USkeleton* Skeleton,USkeletalMesh* PreviewMesh,bool bTemplate)
{
    auto* Factory=NewObject<UAnimBlueprintFactory>();
    Factory->ParentClass=ParentClass;
    Factory->bTemplate=bTemplate;
    Factory->TargetSkeleton=bTemplate ? nullptr : Skeleton;
    Factory->PreviewSkeletalMesh=bTemplate ? nullptr : PreviewMesh;
    auto* BP=Cast<UAnimBlueprint>(Factory->FactoryCreateNew(UAnimBlueprint::StaticClass(),CreatePackage(*Path),FName(*Name),RF_Public|RF_Standalone,nullptr,GWarn));
    if(!BP)return nullptr;
    FKismetEditorUtilities::CompileBlueprint(BP);
    if(BP->Status==BS_Error || !BP->GeneratedClass)return nullptr;
    BP->TargetSkeleton=bTemplate ? nullptr : Skeleton;
    if(!Save(BP))return nullptr;
    return BP;
}
static bool AddBehaviorBlueprintVariables(UAnimBlueprint* BP,const TSharedPtr<FJsonObject>& BehaviorGraph,FString& Error)
{
    if(!BP || !BehaviorGraph)return true;
    const TSharedPtr<FJsonObject>* Variables=nullptr;
    BehaviorGraph->TryGetObjectField(TEXT("variables"),Variables);
    TMap<FString,TSharedPtr<FJsonValue>> VariableDefaults;
    if(Variables)for(const auto& Pair:(*Variables)->Values)VariableDefaults.Add(FString(Pair.Key.ToView()),Pair.Value);
    TFunction<void(const TSharedPtr<FJsonObject>&)> CollectCondition;
    CollectCondition=[&](const TSharedPtr<FJsonObject>& Condition)
    {
        if(!Condition)return;
        FString Name;
        if(Condition->TryGetStringField(TEXT("var"),Name) && !Name.IsEmpty() && !VariableDefaults.Contains(Name))
            VariableDefaults.Add(Name,Condition->TryGetField(TEXT("value")) ? Condition->TryGetField(TEXT("value")) : MakeShared<FJsonValueNumber>(0.0));
        const TArray<TSharedPtr<FJsonValue>>* Children=nullptr;
        for(const TCHAR* Key:{TEXT("all"),TEXT("any")})
            if(Condition->TryGetArrayField(Key,Children))for(const auto& Child:*Children)CollectCondition(Child->AsObject());
        const TSharedPtr<FJsonObject>* Not=nullptr;
        if(Condition->TryGetObjectField(TEXT("not"),Not))CollectCondition(*Not);
    };
    for(const TCHAR* Collection:{TEXT("transitions"),TEXT("handlers")})
    {
        const TArray<TSharedPtr<FJsonValue>>* Entries=nullptr;
        if(!BehaviorGraph->TryGetArrayField(Collection,Entries))continue;
        for(const auto& Entry:*Entries)
        {
            const auto Object=Entry->AsObject();
            const TArray<TSharedPtr<FJsonValue>>* All=nullptr;
            if(Object->TryGetArrayField(TEXT("all"),All))for(const auto& Condition:*All)CollectCondition(Condition->AsObject());
            const TSharedPtr<FJsonObject>* Condition=nullptr;
            if(Object->TryGetObjectField(TEXT("condition"),Condition))CollectCondition(*Condition);
        }
    }
    for(const auto& Pair:VariableDefaults)
    {
        FEdGraphPinType PinType;
        if(Pair.Value && Pair.Value->Type==EJson::Boolean)
        {
            PinType.PinCategory=UEdGraphSchema_K2::PC_Boolean;
        }
        else
        {
            PinType.PinCategory=UEdGraphSchema_K2::PC_Float;
        }
        if(FProperty* Existing=FindFProperty<FProperty>(BP->ParentClass,FName(*Pair.Key)))
        {
            const bool bCompatible=Pair.Value && Pair.Value->Type==EJson::Boolean ? CastField<FBoolProperty>(Existing)!=nullptr : CastField<FNumericProperty>(Existing)!=nullptr;
            if(!bCompatible)
            {
                Error=FString(TEXT("状态机条件变量与 C++ 动画模板属性类型不兼容："))+FString(*Pair.Key);
                return false;
            }
            continue; // Reuse a same-name native property such as Gait.
        }
        if(!FBlueprintEditorUtils::AddMemberVariable(BP,FName(*Pair.Key),PinType))
        {
            Error=FString(TEXT("无法将状态机条件变量添加到动画蓝图："))+FString(*Pair.Key);
            return false;
        }
    }
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(BP);
    FKismetEditorUtilities::CompileBlueprint(BP);
    if(BP->Status==BS_Error || !BP->GeneratedClass)
    {
        Error=TEXT("状态机变量蓝图编译失败。");
        return false;
    }
    UObject* DefaultObject=BP->GeneratedClass->GetDefaultObject();
    if(Variables)for(const auto& Pair:(*Variables)->Values)
    {
        FProperty* Property=FindFProperty<FProperty>(BP->GeneratedClass,FName(*Pair.Key));
        if(auto* BoolProperty=CastField<FBoolProperty>(Property))BoolProperty->SetPropertyValue_InContainer(DefaultObject,Pair.Value->AsBool());
        else if(auto* NumericProperty=CastField<FNumericProperty>(Property))
        {
            void* ValuePtr=NumericProperty->ContainerPtrToValuePtr<void>(DefaultObject);
            if(NumericProperty->IsFloatingPoint())NumericProperty->SetFloatingPointPropertyValue(ValuePtr,Pair.Value->AsNumber());
            else if(NumericProperty->IsInteger())NumericProperty->SetIntPropertyValue(ValuePtr,int64(Pair.Value->AsNumber()));
            else {Error=TEXT("状态机蓝图变量类型不受支持：")+FString(*Pair.Key);return false;}
        }
        else {Error=TEXT("状态机蓝图变量未生成：")+FString(*Pair.Key);return false;}
    }
    DefaultObject->Modify();
    BP->Modify();
    return true;
}
static int32 HidePublicMMGroupInputs(UAnimGraphNode_LinkedAnimGraph* Linked)
{
    int32 Count=0;
    if(auto* Property=FindFProperty<FArrayProperty>(Linked->GetClass(),TEXT("CustomPinProperties")))
        for(auto& Pin:*Property->ContainerPtrToValuePtr<TArray<FOptionalPinFromProperty>>(Linked))if(Pin.PropertyName.ToString().StartsWith(TEXT("MMGroup_")))
        {if(Pin.bShowPin)++Count;Pin.bShowPin=false;}
    Linked->ReconstructNode();
    return Count;
}
bool RefreshLinkedAnimationInputs(const FString& BlueprintPath,FString& Message)
{
    auto* Host=LoadObject<UAnimBlueprint>(nullptr,*BlueprintPath);
    if(!Host){Message=TEXT("无法加载 Linked Anim Graph 宿主。");return false;}
    TArray<UEdGraph*> Graphs;Host->GetAllGraphs(Graphs);int32 LinkedCount=0,Hidden=0;Host->Modify();
    for(UEdGraph* Graph:Graphs)for(UEdGraphNode* Node:Graph->Nodes)if(auto* Linked=Cast<UAnimGraphNode_LinkedAnimGraph>(Node))
    {++LinkedCount;Hidden+=HidePublicMMGroupInputs(Linked);}
    if(!LinkedCount){Message=TEXT("蓝图没有 Linked Anim Graph 节点。");return false;}
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Host);FKismetEditorUtilities::CompileBlueprint(Host);
    if(Host->Status==BS_Error || !Save(Host,false)){Message=TEXT("宿主更新或保存失败。");return false;}
    Message=FString::Printf(TEXT("已隐藏 %d 个自动公开的 MM 数组输入，保留子类默认值。"),Hidden);return true;
}
static bool AddLinkedAnimGraphHost(UAnimBlueprint* Host,UClass* ChildClass)
{
    TArray<UEdGraph*> Graphs; Host->GetAllGraphs(Graphs);
    UEdGraph* AnimGraph=nullptr;
    for(UEdGraph* Graph:Graphs)if(Graph && Graph->GetFName()==TEXT("AnimGraph")){AnimGraph=Graph;break;}
    if(!AnimGraph)return false;
    UAnimGraphNode_Root* Root=nullptr;
    for(UEdGraphNode* Node:AnimGraph->Nodes)if(auto* Candidate=Cast<UAnimGraphNode_Root>(Node)){Root=Candidate;break;}
    if(!Root)return false;
    auto* Linked=NewObject<UAnimGraphNode_LinkedAnimGraph>(AnimGraph);
    AnimGraph->AddNode(Linked,true,false);
    Linked->CreateNewGuid();
    Linked->PostPlacedNewNode();
    Linked->Node.InstanceClass=ChildClass;
    Linked->Node.bPropagateNotifiesToLinkedInstances=true;
    Linked->SetTag(TEXT("GaspCore"));
    Linked->ReconstructNode();
    HidePublicMMGroupInputs(Linked);
    UEdGraphPin* PoseOutput=nullptr;
    for(UEdGraphPin* Pin:Linked->Pins)if(Pin && Pin->Direction==EGPD_Output && Pin->PinType.PinCategory==UEdGraphSchema_K2::PC_Struct){PoseOutput=Pin;break;}
    UEdGraphPin* RootInput=Root->FindPin(TEXT("Result"),EGPD_Input);
    if(!PoseOutput || !RootInput || !GetDefault<UEdGraphSchema_K2>()->TryCreateConnection(PoseOutput,RootInput))return false;
    AnimGraph->NotifyGraphChanged();
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Host);
    FKismetEditorUtilities::CompileBlueprint(Host);
    return Host->Status!=BS_Error && Host->GeneratedClass;
}
static UAnimGraphNode_Base* AddTemplateNode(UEdGraph* Graph,const TCHAR* ClassPath,const TCHAR* Settings=TEXT("()"))
{
    UClass* NodeClass=LoadClass<UAnimGraphNode_Base>(nullptr,ClassPath);
    if(!NodeClass)return nullptr;
    auto* Node=NewObject<UAnimGraphNode_Base>(Graph,NodeClass,NAME_None,RF_Transactional);
    Graph->AddNode(Node,false,false);Node->CreateNewGuid();
    if(auto* Property=FindFProperty<FStructProperty>(NodeClass,TEXT("Node")))
        if(!Property->ImportText_Direct(Settings,Property->ContainerPtrToValuePtr<void>(Node),Node,PPF_None))return nullptr;
    Node->PostPlacedNewNode();Node->AllocateDefaultPins();Node->NodePosX=Graph->Nodes.Num()*240;
    return Node;
}
static bool ConnectTemplateNodes(UEdGraphNode* From,UEdGraphNode* To,const TCHAR* Input=nullptr)
{
    UEdGraphPin* Out=nullptr;UEdGraphPin* In=nullptr;
    for(UEdGraphPin* Pin:From->Pins)if(Pin->Direction==EGPD_Output && Pin->PinType.PinCategory==UEdGraphSchema_K2::PC_Struct){Out=Pin;break;}
    for(UEdGraphPin* Pin:To->Pins)if(Pin->Direction==EGPD_Input && (Input ? Pin->PinName==Input : Pin->PinType.PinCategory==UEdGraphSchema_K2::PC_Struct)){In=Pin;break;}
    return Out && In && To->GetGraph()->GetSchema()->TryCreateConnection(Out,In);
}
static bool BindTemplateNode(UAnimGraphNode_Base* Node,const TCHAR* PinName,const TCHAR* PropertyName)
{
    for(int32 I=0;I<Node->ShowPinForProperties.Num();++I)
        if(Node->ShowPinForProperties[I].PropertyName==PinName && !Node->ShowPinForProperties[I].bShowPin){Node->SetPinVisibility(true,I);break;}
    Node->ReconstructNode();
    auto* Get=NewObject<UK2Node_VariableGet>(Node->GetGraph());Get->VariableReference.SetSelfMember(PropertyName);
    Node->GetGraph()->AddNode(Get,false,false);Get->CreateNewGuid();Get->AllocateDefaultPins();
    UEdGraphPin* Out=Get->FindPin(PropertyName,EGPD_Output);UEdGraphPin* In=Node->FindPin(PinName,EGPD_Input);
    return Out && In && Node->GetGraph()->GetSchema()->TryCreateConnection(Out,In);
}
static bool BuildNativeTemplateGraph(UAnimBlueprint* Blueprint,FString& Error)
{
    TArray<UEdGraph*> Graphs;Blueprint->GetAllGraphs(Graphs);UEdGraph* Graph=nullptr;
    for(UEdGraph* Candidate:Graphs)if(Candidate && Candidate->GetFName()==TEXT("AnimGraph")){Graph=Candidate;break;}
    if(!Graph){Error=TEXT("C++ 动画模板缺少 AnimGraph。");return false;}
    UAnimGraphNode_Root* Root=nullptr;
    for(UEdGraphNode* Node:Graph->Nodes)if(auto* Candidate=Cast<UAnimGraphNode_Root>(Node)){Root=Candidate;break;}
    if(!Root){Error=TEXT("C++ 动画模板缺少 AnimGraph Root。");return false;}
    auto* MM=AddTemplateNode(Graph,TEXT("/Script/PoseSearchEditor.AnimGraphNode_MotionMatching"),TEXT("(BlendTime=0.2,PlayRate=(Min=0.85,Max=1.15),MaxActiveBlends=4,MaxBlendInTimeToOverrideAnimation=0.03,PlayerDepthBlendInTimeMultiplier=1.1,PoseJumpThresholdTime=(Min=0,Max=0),PoseReselectHistory=0.3,SearchThrottleTime=0)"));
    if(!MM || !BindTemplateNode(MM,TEXT("BlendTime"),TEXT("MotionBlendTime")) || !BindTemplateNode(MM,TEXT("NotifyRecencyTimeOut"),TEXT("NotifyRecencyTimeOut")))
    {Error=TEXT("无法创建并绑定模板 Motion Matching 节点。");return false;}
    const TArray<UEdGraph*> SampleGraphs=MM->GetSubGraphs();
    if(SampleGraphs.Num()!=1){Error=TEXT("Motion Matching BlendStack 样本图数量异常。");return false;}
    UEdGraph* Sample=SampleGraphs[0];UEdGraphNode* SampleInput=nullptr;UEdGraphNode* SampleOutput=nullptr;
    for(UEdGraphNode* Node:Sample->Nodes){if(Node->GetClass()->GetName()==TEXT("AnimGraphNode_BlendStackInput"))SampleInput=Node;if(Node->IsA<UAnimGraphNode_Root>())SampleOutput=Node;}
    auto* Warp=AddTemplateNode(Sample,TEXT("/Script/GaspNativeEditor.AnimGraphNode_GaspSampleWarp"));
    if(!SampleInput || !SampleOutput || !Warp || !ConnectTemplateNodes(SampleInput,Warp,TEXT("Source")) || !ConnectTemplateNodes(Warp,SampleOutput,TEXT("Result")))
    {Error=TEXT("无法创建模板 Motion Matching 样本 Warping 图。");return false;}
    auto* Lean=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_BlendSpacePlayer"));
    auto* ApplyLean=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_ApplyMeshSpaceAdditive"));
    auto* Aim=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_BlendSpacePlayer"));
    auto* ApplyAim=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_ApplyMeshSpaceAdditive"));
    auto* Slot=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_Slot"),TEXT("(SlotName=DefaultSlot,bAlwaysUpdateSourcePose=False)"));
    auto* Offset=AddTemplateNode(Graph,TEXT("/Script/AnimationWarpingEditor.AnimGraphNode_OffsetRootBone"),TEXT("(TranslationHalflife=0.2,RotationHalfLife=0.1,MaxTranslationError=30,TranslationMode=Interpolate,RotationMode=Accumulate,bResetOnTeleport=False)"));
    auto* ToComponent=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_LocalToComponentSpace"));
    auto* Feet=AddTemplateNode(Graph,TEXT("/Script/AnimationWarpingEditor.AnimGraphNode_FootPlacement"));
    auto* Legs=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_LegIK"),TEXT("(SoftPercentLength=0.99)"));
    auto* ToLocal=AddTemplateNode(Graph,TEXT("/Script/AnimGraph.AnimGraphNode_ComponentToLocalSpace"));
    auto* History=AddTemplateNode(Graph,TEXT("/Script/PoseSearchEditor.AnimGraphNode_PoseSearchHistoryCollector"),TEXT("(PoseCount=2,SamplingInterval=0.04,CollectedCurves=(Phase))"));
    if(!Lean||!ApplyLean||!Aim||!ApplyAim||!Slot||!Offset||!ToComponent||!Feet||!Legs||!ToLocal||!History)
    {Error=TEXT("无法创建 C++ 动画模板的 Lean/Aim/Slot/IK/PoseHistory 节点。");return false;}
    auto Bind=[&](UAnimGraphNode_Base* Node,const TCHAR* Pin,const TCHAR* Variable){return BindTemplateNode(Node,Pin,Variable);};
    if(!Bind(Lean,TEXT("BlendSpace"),TEXT("LeanAsset")) || !Bind(Lean,TEXT("X"),TEXT("LeanAmount")) ||
       !Bind(ApplyLean,TEXT("Alpha"),TEXT("LeanAlpha")) || !Bind(Aim,TEXT("BlendSpace"),TEXT("AimAsset")) ||
       !Bind(Aim,TEXT("X"),TEXT("AimYaw")) || !Bind(Aim,TEXT("Y"),TEXT("AimPitch")) || !Bind(ApplyAim,TEXT("Alpha"),TEXT("AimAlpha")) ||
       !Bind(Offset,TEXT("TranslationMode"),TEXT("TranslationMode")) || !Bind(Offset,TEXT("RotationMode"),TEXT("RotationMode")) ||
       !Bind(Offset,TEXT("TranslationHalflife"),TEXT("TranslationHalflife")) || !Bind(Offset,TEXT("bClampToTranslationVelocity"),TEXT("bClampTranslation")) ||
       !Bind(Feet,TEXT("Alpha"),TEXT("FootPlacementAlpha")))
    {Error=TEXT("无法将 GASP AnimGraph 输入绑定到 C++ 动画变量。");return false;}
    History->SetTag(TEXT("PoseHistory"));
    const bool bConnected=ConnectTemplateNodes(MM,ApplyLean,TEXT("Base")) && ConnectTemplateNodes(Lean,ApplyLean,TEXT("Additive")) &&
        ConnectTemplateNodes(ApplyLean,ApplyAim,TEXT("Base")) && ConnectTemplateNodes(Aim,ApplyAim,TEXT("Additive")) &&
        ConnectTemplateNodes(ApplyAim,Slot,TEXT("Source")) && ConnectTemplateNodes(Slot,Offset,TEXT("Source")) &&
        ConnectTemplateNodes(Offset,ToComponent,TEXT("LocalPose")) && ConnectTemplateNodes(ToComponent,Feet,TEXT("ComponentPose")) &&
        ConnectTemplateNodes(Feet,Legs,TEXT("ComponentPose")) && ConnectTemplateNodes(Legs,ToLocal,TEXT("ComponentPose")) &&
        ConnectTemplateNodes(ToLocal,History,TEXT("Source")) && ConnectTemplateNodes(History,Root,TEXT("Result"));
    if(!bConnected){Error=TEXT("无法连接 C++ 动画模板姿势链。");return false;}
    Sample->NotifyGraphChanged();Graph->NotifyGraphChanged();
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
    FKismetEditorUtilities::CompileBlueprint(Blueprint);
    if(Blueprint->Status==BS_Error || !Blueprint->GeneratedClass || !Blueprint->GeneratedClass->IsChildOf(UGaspNativeAnimInstance::StaticClass()))
    {Error=TEXT("C++ 动画模板编译失败。");return false;}
    return true;
}
static bool BuildSemanticTemplateGraph(UAnimBlueprint* Blueprint,const TSharedPtr<FJsonObject>& Definition,FString& Error)
{
    if(!Definition)return true;
    TMap<FString,TSharedPtr<FJsonObject>> States;
    for(const auto& Value:Definition->GetArrayField(TEXT("states")))
        States.Add(Value->AsObject()->GetStringField(TEXT("id")),Value->AsObject());
    auto Text=[](const TSharedPtr<FJsonObject>& Object,const TCHAR* Key){FString Value;Object->TryGetStringField(Key,Value);return Value;};
    TArray<UEdGraph*> Graphs;Blueprint->GetAllGraphs(Graphs);UEdGraph* AnimGraph=nullptr;
    for(UEdGraph* Graph:Graphs)if(Graph->GetFName()==TEXT("AnimGraph")){AnimGraph=Graph;break;}
    if(!AnimGraph){Error=TEXT("语义状态机缺少模板 AnimGraph。");return false;}
    UAnimGraphNode_Root* Root=nullptr;
    for(UEdGraphNode* Node:AnimGraph->Nodes)if(auto* Candidate=Cast<UAnimGraphNode_Root>(Node)){Root=Candidate;break;}
    UEdGraphPin* Result=Root ? Root->FindPin(TEXT("Result"),EGPD_Input) : nullptr;
    if(!Result || Result->LinkedTo.Num()!=1){Error=TEXT("语义状态机缺少完整的 GASP 源姿势。");return false;}
    UEdGraphNode* Source=Result->LinkedTo[0]->GetOwningNode();
    Result->BreakAllPinLinks();
    auto* Cache=Cast<UAnimGraphNode_SaveCachedPose>(AddTemplateNode(AnimGraph,TEXT("/Script/AnimGraph.AnimGraphNode_SaveCachedPose")));
    if(!Cache || !ConnectTemplateNodes(Source,Cache)){Error=TEXT("无法缓存 GASP 语义状态机源姿势。");return false;}
    Cache->CacheName=TEXT("GaspSemanticPose");Cache->NodePosX=Source->NodePosX+240;Cache->ReconstructNode();
    TMap<FString,UAnimStateNode*> StateNodes;
    TMap<FString,UAnimationStateMachineGraph*> Machines;
    TFunction<UAnimGraphNode_StateMachine*(UEdGraph*,const FString&,const FString&)> BuildMachine;
    BuildMachine=[&](UEdGraph* Parent,const FString& Group,const FString& Initial)->UAnimGraphNode_StateMachine*
    {
        auto* Machine=Cast<UAnimGraphNode_StateMachine>(AddTemplateNode(Parent,TEXT("/Script/AnimGraph.AnimGraphNode_StateMachine")));
        if(!Machine || !Machine->EditorStateMachineGraph)return nullptr;
        Machine->OnRenameNode(Group.IsEmpty() ? TEXT("SemanticStateMachine") : Group+TEXT("_States"));
        Machine->Node.MaxTransitionsPerFrame=8;
        auto* MachineGraph=Machine->EditorStateMachineGraph.Get();Machines.Add(Group,MachineGraph);
        int32 Index=0;
        for(const auto& Value:Definition->GetArrayField(TEXT("states")))
        {
            const auto State=Value->AsObject();const FString Id=Text(State,TEXT("id"));
            if(Text(State,TEXT("parent"))!=Group)continue;
            auto* Node=NewObject<UAnimStateNode>(MachineGraph,NAME_None,RF_Transactional);
            MachineGraph->AddNode(Node,false,false);Node->CreateNewGuid();Node->PostPlacedNewNode();Node->AllocateDefaultPins();
            if(!Node->BoundGraph)return nullptr;
            FBlueprintEditorUtils::RenameGraph(Node->BoundGraph,Id);
            Node->NodePosX=(Index%3)*380;Node->NodePosY=(Index/3)*260;++Index;
            Node->NodeComment=Encode(State);Node->bCommentBubbleVisible=false;StateNodes.Add(Id,Node);
            UEdGraphNode* Pose=nullptr;
            if(Text(State,TEXT("player"))==TEXT("group"))Pose=BuildMachine(Node->BoundGraph,Id,Text(State,TEXT("initial")));
            else
            {
                auto* Use=Cast<UAnimGraphNode_UseCachedPose>(AddTemplateNode(Node->BoundGraph,TEXT("/Script/AnimGraph.AnimGraphNode_UseCachedPose")));
                if(!Use)return nullptr;
                Use->SaveCachedPoseNode=Cache;Use->ReconstructNode();Use->NodeComment=TEXT("GASP MM/Slot pose; database and actions follow this semantic state.");Pose=Use;
            }
            if(!Pose || !ConnectTemplateNodes(Pose,Node->GetResultNodeInsideState(),TEXT("Result")))return nullptr;
        }
        auto* InitialNode=StateNodes.FindRef(Initial);
        if(!InitialNode || InitialNode->GetGraph()!=MachineGraph || !MachineGraph->EntryNode ||
           !MachineGraph->GetSchema()->TryCreateConnection(MachineGraph->EntryNode->GetOutputPin(),InitialNode->GetInputPin()))return nullptr;
        MachineGraph->EntryNode->NodePosX=-300;MachineGraph->NotifyGraphChanged();return Machine;
    };
    auto* Top=BuildMachine(AnimGraph,TEXT(""),Text(Definition,TEXT("entry")));
    if(!Top || !ConnectTemplateNodes(Top,Root,TEXT("Result"))){Error=TEXT("无法生成语义状态机层级、入口或状态姿势图。");return false;}
    Top->NodePosX=Cache->NodePosX+400;Root->NodePosX=Top->NodePosX+300;
    auto Path=[&](FString Id){TArray<FString> ResultPath;while(!Id.IsEmpty() && States.Contains(Id)){ResultPath.Insert(Id,0);Id=Text(States[Id],TEXT("parent"));}return ResultPath;};
    const auto& Edges=Definition->GetArrayField(TEXT("transitions"));
    for(int32 Index=0;Index<Edges.Num();++Index)
    {
        const auto Edge=Edges[Index]->AsObject();const FString From=Text(Edge,TEXT("from")),To=Text(Edge,TEXT("to"));
        const FName Variable(*FString::Printf(TEXT("SemanticTransition_%03d"),Index));
        FEdGraphPinType Type;Type.PinCategory=UEdGraphSchema_K2::PC_Boolean;
        if(!FBlueprintEditorUtils::AddMemberVariable(Blueprint,Variable,Type)){Error=TEXT("无法创建模板转换条件变量：")+Variable.ToString();return false;}
        for(auto& Description:Blueprint->NewVariables)if(Description.VarName==Variable){Description.Category=FText::FromString(TEXT("GASP|Semantic Transitions"));Description.FriendlyName=From+TEXT(" to ")+To;}
        FBlueprintEditorUtils::SetBlueprintVariableMetaData(Blueprint,Variable,nullptr,TEXT("Tooltip"),TEXT("Native semantic arbitration synchronizes this transition. Definition: ")+Encode(Edge));
        auto AddEdge=[&](const FString& SourceId)->bool
        {
            const auto SourcePath=Path(SourceId),TargetPath=Path(To);int32 Common=0;
            while(Common<SourcePath.Num() && Common<TargetPath.Num() && SourcePath[Common]==TargetPath[Common])++Common;
            if(Common>=SourcePath.Num() || Common>=TargetPath.Num())return false;
            auto* Previous=StateNodes.FindRef(SourcePath[Common]);auto* Next=StateNodes.FindRef(TargetPath[Common]);
            if(!Previous || !Next || Previous->GetGraph()!=Next->GetGraph())return false;
            auto* Transition=NewObject<UAnimStateTransitionNode>(Previous->GetGraph(),NAME_None,RF_Transactional);
            Previous->GetGraph()->AddNode(Transition,false,false);Transition->CreateNewGuid();Transition->PostPlacedNewNode();Transition->AllocateDefaultPins();Transition->CreateConnections(Previous,Next);
            Transition->CrossfadeDuration=0; // MM/Slot already apply the authored blend; avoid a second pose blend.
            double Priority=0;Edge->TryGetNumberField(TEXT("priority"),Priority);Transition->PriorityOrder=1000-int32(Priority);
            Transition->NodeComment=Encode(Edge);Transition->NodePosX=(Previous->NodePosX+Next->NodePosX)/2;Transition->NodePosY=(Previous->NodePosY+Next->NodePosY)/2-70;
            if(!Transition->BoundGraph)return false;
            UAnimGraphNode_TransitionResult* Sink=nullptr;
            for(UEdGraphNode* Node:Transition->BoundGraph->Nodes)if(auto* Candidate=Cast<UAnimGraphNode_TransitionResult>(Node)){Sink=Candidate;break;}
            if(!Sink)return false;
            auto* Get=NewObject<UK2Node_VariableGet>(Transition->BoundGraph);Get->VariableReference.SetSelfMember(Variable);
            Transition->BoundGraph->AddNode(Get,false,false);Get->CreateNewGuid();Get->AllocateDefaultPins();Get->NodePosX=-300;
            UEdGraphPin* Input=nullptr;for(UEdGraphPin* Pin:Sink->Pins)if(Pin->Direction==EGPD_Input && Pin->PinType.PinCategory==UEdGraphSchema_K2::PC_Boolean){Input=Pin;break;}
            return Input && Transition->BoundGraph->GetSchema()->TryCreateConnection(Get->FindPin(Variable,EGPD_Output),Input);
        };
        if(From==TEXT("*"))
        {
            for(const auto& State:States)if(State.Key!=To && Text(State.Value,TEXT("player"))!=TEXT("group") && !Path(To).Contains(State.Key))
                if(!AddEdge(State.Key)){Error=TEXT("无法生成通配语义转换：")+Encode(Edge);return false;}
        }
        else if(!AddEdge(From)){Error=TEXT("无法生成语义转换（不支持状态到自身或其祖先/后代的直接转换）：")+Encode(Edge);return false;}
    }
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);FKismetEditorUtilities::CompileBlueprint(Blueprint);
    if(Blueprint->Status==BS_Error){Error=TEXT("语义状态机模板编译失败。");return false;}
    return true;
}
TSharedPtr<FJsonObject> Scan(const TArray<FString>& Paths,FString& Error)
{
    auto Catalog=MakeShared<FJsonObject>(); TArray<TSharedPtr<FJsonValue>> Entries; TSet<FString> Seen;
    for (const FString& Path:Paths)
    {
        if (Seen.Contains(Path)) continue; Seen.Add(Path);
        UObject* Object=LoadObject<UObject>(nullptr,*Path);
        if (!Object) { Error=TEXT("Cannot load selected asset: ")+Path; return nullptr; }
        auto Row=MakeShared<FJsonObject>(); USkeleton* Skeleton=nullptr; FString Kind;
        if (auto* Mesh=Cast<USkeletalMesh>(Object)) {
            Kind=TEXT("mesh"); Skeleton=Mesh->GetSkeleton(); TArray<TSharedPtr<FJsonValue>> Bones;
            for (int32 I=0;I<Mesh->GetRefSkeleton().GetNum();++I) Bones.Add(MakeShared<FJsonValueString>(Mesh->GetRefSkeleton().GetBoneName(I).ToString()));
            Row->SetArrayField(TEXT("bones"),Bones);
        } else if (auto* Sequence=Cast<UAnimSequence>(Object)) {
            Kind=TEXT("sequence"); Skeleton=Sequence->GetSkeleton(); Row->SetNumberField(TEXT("length"),Sequence->GetPlayLength());
            Row->SetBoolField(TEXT("loop"),Sequence->bLoop); Row->SetBoolField(TEXT("root_motion"),Sequence->bEnableRootMotion);
            Row->SetBoolField(TEXT("additive"),Sequence->IsValidAdditive());
            Row->SetNumberField(TEXT("num_frames"),Sequence->GetNumberOfSampledKeys());
        } else if (auto* Montage=Cast<UAnimMontage>(Object)) {
            Kind=TEXT("montage");Skeleton=Montage->GetSkeleton();Row->SetNumberField(TEXT("length"),Montage->GetPlayLength());Row->SetBoolField(TEXT("loop"),false);
        } else if (auto* DB=Cast<UPoseSearchDatabase>(Object)) {
            Kind=TEXT("database"); if (DB->Schema) Skeleton=DB->Schema->GetSkeleton(DB->Schema->GetDefaultRole());
        } else { Kind=TEXT("unsupported"); }
        Row->SetStringField(TEXT("id"),Object->GetPathName()); Row->SetStringField(TEXT("name"),Object->GetName()); Row->SetStringField(TEXT("kind"),Kind);
        Row->SetStringField(TEXT("skeleton"),Skeleton ? Skeleton->GetPathName() : TEXT("")); Entries.Add(MakeShared<FJsonValueObject>(Row));
    }
    Catalog->SetNumberField(TEXT("version"),1); Catalog->SetArrayField(TEXT("assets"),Entries); return Catalog;
}
static bool Save(UObject* Object,bool bNewAsset)
{
    const FString File=FPackageName::LongPackageNameToFilename(Object->GetOutermost()->GetName(),TEXT(".uasset"));
    FSavePackageArgs Args; Args.TopLevelFlags=RF_Public|RF_Standalone;
    IFileManager::Get().MakeDirectory(*FPaths::GetPath(File),true);
    if (!UPackage::SavePackage(Object->GetOutermost(),Object,*File,Args)) return false;
    if (bNewAsset) FAssetRegistryModule::AssetCreated(Object); return true;
}
bool CheckBlueprint(const FString& BlueprintPath,FString& Error)
{
    auto* BP=LoadObject<UBlueprint>(nullptr,*BlueprintPath);
    if (!BP || !BP->GeneratedClass || !BP->GeneratedClass->IsChildOf(AGaspNativeCharacter::StaticClass()) || BP->BlueprintType!=BPTYPE_Normal) {
        Error=TEXT("目标必须是继承 GaspNativeCharacter 的普通角色蓝图，例如 BP_CusGaspNativeCharacter。"); return false;
    }
    if (BP->Status==BS_Error) { Error=TEXT("目标蓝图存在编译错误，请先修复。"); return false; }
    return true;
}
static bool PopulateMotionMatchingGroups(UGaspNativeAnimInstance* Defaults,UGaspAnimationSet* Set,const USkeletalMesh* Mesh,FString& Error)
{
    auto& Groups=Defaults->MotionMatchingAnimationGroups;
    for(auto& Pair:Groups)Pair.Value.SemanticStates.Reset();
    for(const auto& Pair:Set->ConfiguredLocomotion)if(Pair.Value)
    {
        const bool bNew=!Groups.Contains(Pair.Key);auto& Group=Groups.FindOrAdd(Pair.Key);
        Group.SourceDatabase=Pair.Value;if(bNew)Group.Databases.Add(Pair.Value);
    }
    for(const auto& Reference:Set->Databases)
    {
        auto* Database=Cast<UPoseSearchDatabase>(Set->ResolveDatabase(Reference.ToSoftObjectPath()).TryLoad());
        if(!Database)continue;
        bool bMapped=false;for(const auto& Pair:Groups)if(Pair.Value.SourceDatabase==Database){bMapped=true;break;}
        if(bMapped)continue;
        FName Key=Database->GetFName();int32 Suffix=0;
        while(Groups.Contains(Key))Key=FName(*FString::Printf(TEXT("%s_%d"),*Database->GetName(),++Suffix));
        auto& Group=Groups.Add(Key);Group.SourceDatabase=Database;Group.Databases.Add(Database);
    }
    TSharedPtr<FJsonObject> Graph;
    if(!Set->BehaviorGraphJson.IsEmpty())FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Set->BehaviorGraphJson),Graph);
    if(Graph)for(const auto& Value:Graph->GetArrayField(TEXT("states")))
    {
        const auto State=Value->AsObject();FString Id,Role,Player;
        State->TryGetStringField(TEXT("id"),Id);State->TryGetStringField(TEXT("database_role"),Role);State->TryGetStringField(TEXT("player"),Player);
        if(Player==TEXT("mm"))
        {
            const FName Key(*(Role.IsEmpty() ? Id:Role));const bool bNew=!Groups.Contains(Key);
            auto& Group=Groups.FindOrAdd(Key);Group.SemanticStates.AddUnique(FName(*Id));
            if(Role.IsEmpty() && bNew)for(const auto& Resource:State->GetArrayField(TEXT("resources")))
                if(auto* DB=LoadObject<UPoseSearchDatabase>(nullptr,*Resource->AsString()))Group.Databases.AddUnique(DB);
        }
        else if(Player==TEXT("locomotion"))for(auto& Pair:Groups)Pair.Value.SemanticStates.AddUnique(FName(*Id));
    }
    return Defaults->ValidateMotionMatchingAnimationGroups(Mesh,Error);
}
static bool ExposeTemplateMotionMatchingVariables(UAnimBlueprint* Blueprint,UGaspAnimationSet* Set,const USkeletalMesh* Mesh,FString& Error)
{
    auto* Defaults=Cast<UGaspNativeAnimInstance>(Blueprint->GeneratedClass->GetDefaultObject());
    if(!Defaults || !PopulateMotionMatchingGroups(Defaults,Set,Mesh,Error))return false;
    auto Groups=Defaults->MotionMatchingAnimationGroups;
    for(auto& Pair:Groups)
    {
        FString Identifier=TEXT("MMGroup_");
        for(TCHAR Character:Pair.Key.ToString())
            Identifier+=FChar::IsAlnum(Character) && Character<128 || Character==TEXT('_') ? FString::Chr(Character):FString::Printf(TEXT("_%04X"),uint32(Character));
        Pair.Value.PublicVariableName=FName(*Identifier);
        FEdGraphPinType Type;Type.PinCategory=UEdGraphSchema_K2::PC_Object;Type.PinSubCategoryObject=UPoseSearchDatabase::StaticClass();Type.ContainerType=EPinContainerType::Array;
        if(!FBlueprintEditorUtils::AddMemberVariable(Blueprint,Pair.Value.PublicVariableName,Type))
        {Error=TEXT("无法创建公开 MM 动画变量：")+Identifier;return false;}
        for(auto& Variable:Blueprint->NewVariables)if(Variable.VarName==Pair.Value.PublicVariableName)
        {
            Variable.Category=FText::FromString(TEXT("GASP|Motion Matching|Animation Groups"));
            Variable.PropertyFlags|=CPF_Edit|CPF_BlueprintVisible;
            Variable.PropertyFlags&=~(CPF_BlueprintReadOnly|CPF_DisableEditOnInstance);
        }
        FBlueprintEditorUtils::SetBlueprintVariableMetaData(Blueprint,Pair.Value.PublicVariableName,nullptr,TEXT("Tooltip"),TEXT("Public Motion Matching database array for chooser group ")+Pair.Key.ToString()+TEXT(". Child AnimBPs override this variable. Edit clips inside a compatible Pose Search Database."));
    }
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);FKismetEditorUtilities::CompileBlueprint(Blueprint);
    if(Blueprint->Status==BS_Error || !Blueprint->GeneratedClass){Error=TEXT("公开 MM 动画变量模板编译失败。");return false;}
    Defaults=Cast<UGaspNativeAnimInstance>(Blueprint->GeneratedClass->GetDefaultObject());Defaults->MotionMatchingAnimationGroups=Groups;
    for(const auto& Pair:Groups)
    {
        auto* Array=FindFProperty<FArrayProperty>(Blueprint->GeneratedClass,Pair.Value.PublicVariableName);
        auto* Object=Array ? CastField<FObjectPropertyBase>(Array->Inner):nullptr;
        if(!Array || !Object){Error=TEXT("公开 MM 数组未生成：")+Pair.Key.ToString();return false;}
        void* Address=Array->ContainerPtrToValuePtr<void>(Defaults);FScriptArrayHelper Values(Array,Address);
        Values.EmptyAndAddValues(Pair.Value.Databases.Num());
        for(int32 Index=0;Index<Pair.Value.Databases.Num();++Index)Object->SetObjectPropertyValue(Values.GetRawPtr(Index),Pair.Value.Databases[Index]);
        FString DefaultValue;Array->ExportTextItem_Direct(DefaultValue,Address,nullptr,Defaults,PPF_None);
        for(auto& Variable:Blueprint->NewVariables)if(Variable.VarName==Pair.Value.PublicVariableName)Variable.DefaultValue=DefaultValue;
    }
    FBlueprintEditorUtils::MarkBlueprintAsModified(Blueprint);FKismetEditorUtilities::CompileBlueprint(Blueprint);
    Defaults=Blueprint->GeneratedClass ? Cast<UGaspNativeAnimInstance>(Blueprint->GeneratedClass->GetDefaultObject()):nullptr;
    if(!Defaults || Blueprint->Status==BS_Error){Error=TEXT("公开 MM 变量默认值编译失败。");return false;}
    Defaults->MotionMatchingAnimationGroups=Groups;Defaults->Modify();Blueprint->Modify();
    return Defaults->ValidateMotionMatchingAnimationGroups(Mesh,Error);
}
bool MapAnimationGroups(const FString& BlueprintPath,FString& Message)
{
    auto* BP=LoadObject<UAnimBlueprint>(nullptr,*BlueprintPath);
    auto* Defaults=BP && BP->GeneratedClass ? Cast<UGaspNativeAnimInstance>(BP->GeneratedClass->GetDefaultObject()):nullptr;
    if(!BP || BP->bIsTemplate || !Defaults || !Defaults->AnimationSet){Message=TEXT("请选择带有 AnimationSet 的 GASP 状态机子蓝图。");return false;}
    auto* Set=Defaults->AnimationSet.Get();auto* Mesh=Set->Mesh.LoadSynchronous();
    Defaults->Modify();BP->Modify();
    if(!PopulateMotionMatchingGroups(Defaults,Set,Mesh,Message))return false;
    const auto ExpectedGroups=Defaults->MotionMatchingAnimationGroups;
    FBlueprintEditorUtils::MarkBlueprintAsModified(BP);
    FKismetEditorUtilities::CompileBlueprint(BP);
    Defaults=BP->GeneratedClass ? Cast<UGaspNativeAnimInstance>(BP->GeneratedClass->GetDefaultObject()):nullptr;
    if(BP->Status==BS_Error || !Defaults || Defaults->MotionMatchingAnimationGroups.Num()!=ExpectedGroups.Num())
    {Message=TEXT("动画组映射在蓝图重编译后校验失败，未保存。");return false;}
    for(const auto& Pair:ExpectedGroups)
    {
        const auto* Saved=Defaults->MotionMatchingAnimationGroups.Find(Pair.Key);
        if(!Saved || Saved->Databases!=Pair.Value.Databases || Saved->SourceDatabase!=Pair.Value.SourceDatabase)
        {Message=TEXT("蓝图重编译未能保留动画组：")+Pair.Key.ToString();return false;}
    }
    if(!Save(BP,false)){Message=TEXT("动画组映射保存失败。");return false;}
    Message=FString::Printf(TEXT("已保存 %d 个 Motion Matching 动画组到 %s 的类默认值。"),Defaults->MotionMatchingAnimationGroups.Num(),*BlueprintPath);return true;
}
bool ApplyToBlueprint(const FString& CatalogFile,const FString& PlanFile,const FString& BlueprintPath,FString& Message,bool bExportAnimBlueprint,const FString& AnimBlueprintDirectory,const FString& AnimBlueprintName)
{
    if (!CheckBlueprint(BlueprintPath,Message)) return false;
    auto* BP=LoadObject<UBlueprint>(nullptr,*BlueprintPath);
    auto Plan=Read(PlanFile);
    if(!Plan){Message=TEXT("无法读取已审核计划；未创建配置资产。");return false;}
    const FString Destination=Plan->GetStringField(TEXT("destination"));
    const FString ExportDirectory=AnimBlueprintDirectory.IsEmpty() ? Destination : AnimBlueprintDirectory;
    const FString ExportName=AnimBlueprintName.IsEmpty() ? TEXT("ABP_StateMachine") : AnimBlueprintName;
    const FString AnimBlueprintPath=ExportDirectory/ExportName;
    const FString TemplateName=ExportName+TEXT("_Template"),HostName=ExportName+TEXT("_Host");
    const FString TemplatePath=ExportDirectory/TemplateName,HostPath=ExportDirectory/HostName;
    if(bExportAnimBlueprint && (FPaths::GetCleanFilename(ExportName)!=ExportName || !FPackageName::IsValidLongPackageName(AnimBlueprintPath) || !FPackageName::IsValidLongPackageName(TemplatePath) || !FPackageName::IsValidLongPackageName(HostPath)))
    {Message=TEXT("动画蓝图路径或名称无效，请使用 /Game/... 目录及合法资产名称。");return false;}
    for(const FString& OutputPath:{TemplatePath,AnimBlueprintPath,HostPath})
        if(bExportAnimBlueprint && (FPackageName::DoesPackageExist(OutputPath) || FindPackage(nullptr,*OutputPath)))
        {Message=TEXT("目标动画蓝图资产已存在，未覆盖，也未创建配置资产：")+OutputPath;return false;}
    UGaspAnimationSet* Set=nullptr;
    const FString ConfigAssetPath=Destination/TEXT("DA_Config.DA_Config");
    if(bExportAnimBlueprint && (FPackageName::DoesPackageExist(Destination/TEXT("DA_Config")) || FindPackage(nullptr,*(Destination/TEXT("DA_Config")))))
    {
        FString CurrentPlanText,AppliedPlanText;
        const FString ApprovedPlanFile=FPackageName::LongPackageNameToFilename(Destination/TEXT("approved_plan"),TEXT(".json"));
        if(!FFileHelper::LoadFileToString(CurrentPlanText,*PlanFile) || !FFileHelper::LoadFileToString(AppliedPlanText,*ApprovedPlanFile) || CurrentPlanText!=AppliedPlanText)
        {Message=TEXT("配置目录已存在，但没有与当前草案完全一致的已应用记录；未覆盖。请恢复原草案或选择新的配置目录。");return false;}
        Set=LoadObject<UGaspAnimationSet>(nullptr,*ConfigAssetPath);
        auto* PlanMesh=LoadObject<USkeletalMesh>(nullptr,*Plan->GetStringField(TEXT("target_mesh")));
        FString ValidationError;
        if(!Set || !PlanMesh || Set->Mesh.LoadSynchronous()!=PlanMesh || !Set->ValidateForMesh(PlanMesh,ValidationError))
        {Message=TEXT("配置目录存在，但 DA_Config 与当前网格不匹配或验证失败：")+ValidationError;return false;}
    }
    else
    {
        for(const TCHAR* Name:{TEXT("PSS_Config"),TEXT("CHT_Config"),TEXT("CHT_NoTraversal")})
            if(FPackageName::DoesPackageExist(Destination/Name) || FindPackage(nullptr,*(Destination/Name)))
            {Message=TEXT("配置目录只包含部分生成资产，不能安全复用或覆盖：")+Destination/Name;return false;}
        if(!Apply(CatalogFile,PlanFile,Message))return false;
        Set=LoadObject<UGaspAnimationSet>(nullptr,*ConfigAssetPath);
    }
    auto* Mesh=Set ? Set->Mesh.LoadSynchronous() : nullptr;
    if (!Set || !Mesh) { Message=TEXT("配置已生成，但无法加载资源，未绑定蓝图。"); return false; }
    UClass* TargetAnimClass=UGaspCppAnimInstance::StaticClass();
    UAnimBlueprint* ExportedAnimBlueprint=nullptr;
    UAnimBlueprint* TemplateAnimBlueprint=nullptr;
    UAnimBlueprint* HostAnimBlueprint=nullptr;
    if(bExportAnimBlueprint)
    {
        TSharedPtr<FJsonObject> ExportGraph;
        if(!Set->BehaviorGraphJson.IsEmpty())FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Set->BehaviorGraphJson),ExportGraph);
        TemplateAnimBlueprint=CreateAnimBlueprint(TemplatePath,TemplateName,UGaspNativeAnimInstance::StaticClass(),nullptr,nullptr,true);
        FString TemplateError;
        if(!TemplateAnimBlueprint || !TemplateAnimBlueprint->bIsTemplate || TemplateAnimBlueprint->TargetSkeleton ||
           !TemplateAnimBlueprint->GeneratedClass->IsChildOf(UGaspNativeAnimInstance::StaticClass()) ||
           !AddBehaviorBlueprintVariables(TemplateAnimBlueprint,ExportGraph,TemplateError) ||
           !BuildNativeTemplateGraph(TemplateAnimBlueprint,TemplateError) ||
           !BuildSemanticTemplateGraph(TemplateAnimBlueprint,ExportGraph,TemplateError) ||
           !ExposeTemplateMotionMatchingVariables(TemplateAnimBlueprint,Set,Mesh,TemplateError) || !Save(TemplateAnimBlueprint,false))
        {Message=TEXT("配置已生成，但无法创建 GASP C++ AnimBP 模板：")+TemplatePath+TEXT("；")+TemplateError;return false;}
        ExportedAnimBlueprint=CreateAnimBlueprint(AnimBlueprintPath,ExportName,TemplateAnimBlueprint->GeneratedClass,Mesh->GetSkeleton(),Mesh,false);
        if(!ExportedAnimBlueprint)
        {Message=TEXT("动画蓝图模板已生成，但无法创建模板子类：")+AnimBlueprintPath;return false;}
        auto* AnimDefaults=ExportedAnimBlueprint->GeneratedClass ? Cast<UGaspNativeAnimInstance>(ExportedAnimBlueprint->GeneratedClass->GetDefaultObject()) : nullptr;
        if(ExportedAnimBlueprint->Status==BS_Error || !AnimDefaults || !ExportedAnimBlueprint->GeneratedClass->IsChildOf(UGaspNativeAnimInstance::StaticClass()))
        {Message=TEXT("状态机动画蓝图未能编译为 UGaspNativeAnimInstance 模板子类。");return false;}
        AnimDefaults->AnimationSet=Set;
        FString GroupError;
        if(!PopulateMotionMatchingGroups(AnimDefaults,Set,Mesh,GroupError))
        {Message=TEXT("状态机子蓝图动画组校验失败：")+GroupError;return false;}
        AnimDefaults->Modify();
        ExportedAnimBlueprint->Modify();
        ExportedAnimBlueprint->TargetSkeleton=Mesh->GetSkeleton();
        if(!Save(ExportedAnimBlueprint,false))
        {Message=TEXT("状态机子蓝图保存失败；配置资产仍保留在：")+Destination;return false;}
        HostAnimBlueprint=CreateAnimBlueprint(HostPath,HostName,UAnimInstance::StaticClass(),Mesh->GetSkeleton(),Mesh,false);
        if(!HostAnimBlueprint || !AddLinkedAnimGraphHost(HostAnimBlueprint,ExportedAnimBlueprint->GeneratedClass) || !Save(HostAnimBlueprint,false))
        {Message=TEXT("状态机子蓝图已生成，但无法创建 Linked Anim Graph 宿主：")+HostPath;return false;}
        TargetAnimClass=HostAnimBlueprint->GeneratedClass;
    }
    const FScopedTransaction Transaction(FText::FromString(TEXT("应用 GASP 动画配置到角色蓝图")));
    BP->Modify();
    auto* Defaults=CastChecked<AGaspNativeCharacter>(BP->GeneratedClass->GetDefaultObject());
    Defaults->Modify(); Defaults->GetMesh()->Modify();
    Defaults->AnimationSetOverride=Set;
    Defaults->AnimationClass=TargetAnimClass;
    Defaults->GetMesh()->SetSkeletalMesh(Mesh);
    Defaults->GetMesh()->SetRelativeRotation(FRotator(0,Set->Bones.MeshYawOffset,0));
    Defaults->GetMesh()->SetAnimInstanceClass(TargetAnimClass);
    FBlueprintEditorUtils::MarkBlueprintAsModified(BP);
    FKismetEditorUtilities::CompileBlueprint(BP);
    Defaults=Cast<AGaspNativeCharacter>(BP->GeneratedClass->GetDefaultObject());
    if (BP->Status==BS_Error || !Defaults || Defaults->AnimationSetOverride!=Set || Defaults->AnimationClass.LoadSynchronous()!=TargetAnimClass) {
        Message=TEXT("配置已生成，但蓝图编译或绑定检查失败；请检查目标蓝图，未确认应用成功。"); return false;
    }
    if (!Save(BP,false)) { Message=TEXT("配置已绑定但蓝图保存失败，请在编辑器中保存目标蓝图。"); return false; }
    auto Manifest=Read(PlanFile+TEXT(".applied.json"));
    if (Manifest)
    {
        Manifest->SetStringField(TEXT("target_blueprint"),BlueprintPath);
        if(ExportedAnimBlueprint)
        {
            Manifest->SetStringField(TEXT("animation_blueprint"),ExportedAnimBlueprint->GetPathName());
            Manifest->SetStringField(TEXT("animation_blueprint_template"),TemplateAnimBlueprint->GetPathName());
            Manifest->SetStringField(TEXT("animation_blueprint_host"),HostAnimBlueprint->GetPathName());
            Manifest->SetStringField(TEXT("animation_blueprint_parent"),UGaspNativeAnimInstance::StaticClass()->GetPathName());
            if(Manifest->HasField(TEXT("assets")))
            {
                TArray<TSharedPtr<FJsonValue>> AssetPaths=Manifest->GetArrayField(TEXT("assets"));
                AssetPaths.Add(MakeShared<FJsonValueString>(ExportedAnimBlueprint->GetPathName()));
                AssetPaths.Add(MakeShared<FJsonValueString>(TemplateAnimBlueprint->GetPathName()));
                AssetPaths.Add(MakeShared<FJsonValueString>(HostAnimBlueprint->GetPathName()));
                Manifest->SetArrayField(TEXT("assets"),AssetPaths);
            }
        }
        FFileHelper::SaveStringToFile(Encode(Manifest),*(PlanFile+TEXT(".applied.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    }
    Message=TEXT("已生成配置并绑定、编译、保存目标蓝图：\n")+BlueprintPath+TEXT("\n配置：")+Set->GetPathName()+
        (ExportedAnimBlueprint ? TEXT("\nC++ 动画模板：")+TemplateAnimBlueprint->GetPathName()+TEXT("（UGaspNativeAnimInstance + GASP MM/姿势链 + SemanticStateMachine）\n状态机子蓝图：")+ExportedAnimBlueprint->GetPathName()+TEXT("\n角色 Linked Anim Graph 宿主：")+HostAnimBlueprint->GetPathName()+TEXT("\n语义状态、层级和转换节点已生成到模板；条件变量位于模板，子蓝图继承。") : TEXT("\n动画类：GaspCppAnimInstance。"))+
        TEXT("\n已有实例若覆盖了这些属性，需清除实例覆盖后 Play 检查。");
    return true;
}
bool Apply(const FString& CatalogFile,const FString& PlanFile,FString& Message)
{
    // The same validator gates both edited drafts and model-produced drafts.
    const FString Validation=PlanFile+TEXT(".validation.json"); int32 Exit=-1; FString Out,Err;
    FPlatformProcess::ExecProcess(*Python(),*FString::Printf(TEXT("\"%s\" validate --catalog \"%s\" --plan \"%s\" --output \"%s\""),*Backend(),*CatalogFile,*PlanFile,*Validation),&Exit,&Out,&Err);
    if (Exit!=0) { FFileHelper::LoadFileToString(Message,*Validation); Message=TEXT("Validation failed: ")+Message+Err; return false; }
    auto Plan=Read(PlanFile); auto Catalog=Read(CatalogFile); if (!Plan || !Catalog) { Message=TEXT("Unreadable JSON"); return false; }
    TSet<FString> Allowed; TMap<FString,FString> CatalogSkeletons;
    for (const auto& Value:Catalog->GetArrayField(TEXT("assets"))) { auto Row=Value->AsObject(); const FString Id=Row->GetStringField(TEXT("id")); Allowed.Add(Id); CatalogSkeletons.Add(Id,Row->GetStringField(TEXT("skeleton"))); }
    const FString MeshPath=Plan->GetStringField(TEXT("target_mesh"));
    auto* Mesh=Allowed.Contains(MeshPath) ? LoadObject<USkeletalMesh>(nullptr,*MeshPath) : nullptr;
    if (!Mesh || !Mesh->GetSkeleton() || Mesh->GetSkeleton()->GetPathName()!=CatalogSkeletons.FindRef(MeshPath)) { Message=TEXT("Mesh changed since scan"); return false; }
    const FString Destination=Plan->GetStringField(TEXT("destination"));
    TMap<FString,UObject*> Resources; TArray<FString> Packages={Destination/TEXT("PSS_Config"),Destination/TEXT("DA_Config"),Destination/TEXT("CHT_Config"),Destination/TEXT("CHT_NoTraversal")};
    TSet<FName> DatabaseNames; TMap<FString,TArray<UObject*>> CandidateResources;
    for (const auto& Value:Plan->GetArrayField(TEXT("states")))
    {
        const auto State=Value->AsObject(); const FString Id=State->GetStringField(TEXT("id")), Path=State->GetStringField(TEXT("resource"));
        UObject* Resource=Allowed.Contains(Path) ? LoadObject<UObject>(nullptr,*Path) : nullptr; USkeleton* Skeleton=nullptr;
        bool BehaviorOnly=false;State->TryGetBoolField(TEXT("behavior_only"),BehaviorOnly);
        if (auto* Sequence=Cast<UAnimSequence>(Resource)) { Skeleton=Sequence->GetSkeleton(); if (Id!=TEXT("jump") && !BehaviorOnly && !Sequence->bLoop) { Message=TEXT("Locomotion sequence is not marked Loop: ")+Path; return false; } Packages.Add(Destination/(TEXT("PSD_")+Id)); }
        if (auto* DB=Cast<UPoseSearchDatabase>(Resource)) if (DB->Schema) Skeleton=DB->Schema->GetSkeleton(DB->Schema->GetDefaultRole());
        if (!Skeleton || Skeleton!=Mesh->GetSkeleton() || Skeleton->GetPathName()!=CatalogSkeletons.FindRef(Path)) { Message=TEXT("Resource changed or incompatible skeleton: ")+Path; return false; }
        const FName DatabaseName=Resource->IsA<UPoseSearchDatabase>() ? Resource->GetFName() : FName(*(TEXT("PSD_")+Id));
        if (DatabaseNames.Contains(DatabaseName)) { Message=TEXT("Transition states require databases with distinct asset names"); return false; } DatabaseNames.Add(DatabaseName);
        Resources.Add(Id,Resource);
        TArray<UObject*>& Candidates=CandidateResources.FindOrAdd(Id); Candidates.Add(Resource);
        const TArray<TSharedPtr<FJsonValue>>* PathsToAdd=nullptr;
        if (State->TryGetArrayField(TEXT("resources"),PathsToAdd)) for (const auto& Candidate:*PathsToAdd)
        {
            const FString CandidatePath=Candidate->AsString(); if (CandidatePath==Path) continue;
            auto* Sequence=Allowed.Contains(CandidatePath) ? LoadObject<UAnimSequence>(nullptr,*CandidatePath) : nullptr;
            if (!Sequence || Resource->IsA<UPoseSearchDatabase>() || Sequence->GetSkeleton()!=Mesh->GetSkeleton() || Sequence->GetSkeleton()->GetPathName()!=CatalogSkeletons.FindRef(CandidatePath)) {Message=TEXT("Invalid MM candidate: ")+CandidatePath; return false;}
            Candidates.Add(Sequence);
        }
    }
    TMap<FName,UAnimSequence*> ActionResources;
    const TSharedPtr<FJsonObject>* BehaviorGraph=nullptr;TArray<UObject*> BehaviorAssets;
    if(Plan->HasField(TEXT("behavior_graph")) && !Plan->TryGetObjectField(TEXT("behavior_graph"),BehaviorGraph)){Message=TEXT("behavior_graph must be an object");return false;}
    if(BehaviorGraph)
    {
        const TArray<TSharedPtr<FJsonValue>>* BehaviorStates=nullptr;
        if(!(*BehaviorGraph)->TryGetArrayField(TEXT("states"),BehaviorStates)){Message=TEXT("behavior_graph.states must be an array");return false;}
        for(const auto& Node:*BehaviorStates)
        {
            const TArray<TSharedPtr<FJsonValue>>* Paths=nullptr;
            if(!Node.IsValid() || Node->Type!=EJson::Object || !Node->AsObject()->TryGetArrayField(TEXT("resources"),Paths)){Message=TEXT("Each behavior state requires a resources array (groups use [])");return false;}
            for(const auto& Value:*Paths)
            {
                FString Path;if(!Value.IsValid() || !Value->TryGetString(Path)){Message=TEXT("Behavior resource must be an asset path string");return false;}
                UObject* Asset=Allowed.Contains(Path)?LoadObject<UObject>(nullptr,*Path):nullptr;
                if(!Asset || CatalogSkeletons.FindRef(Path)!=Mesh->GetSkeleton()->GetPathName()){Message=TEXT("Invalid behavior resource: ")+Path;return false;}
                BehaviorAssets.AddUnique(Asset);
            }
        }
    }
    TMap<FName,FGaspActionCandidates> ActionCandidates;
    const TSharedPtr<FJsonObject>* Flow=nullptr;
    if (Plan->TryGetObjectField(TEXT("runtime_flow"),Flow))
        for (const auto& Pair:(*Flow)->GetObjectField(TEXT("actions"))->Values)
        {
            const FString Path=Pair.Value->AsString();
            auto* Sequence=Allowed.Contains(Path) ? LoadObject<UAnimSequence>(nullptr,*Path) : nullptr;
            if (!Sequence || Sequence->bLoop || Sequence->GetSkeleton()!=Mesh->GetSkeleton() || Sequence->GetSkeleton()->GetPathName()!=CatalogSkeletons.FindRef(Path))
            { Message=TEXT("Action changed or incompatible: ")+Path; return false; }
            ActionResources.Add(FName(*Pair.Key),Sequence);
        }
    const TSharedPtr<FJsonObject>* CandidateMap=nullptr;
    if (Flow && (*Flow)->TryGetObjectField(TEXT("action_candidates"),CandidateMap)) for (const auto& Pair:(*CandidateMap)->Values)
    {
        auto& Candidates=ActionCandidates.FindOrAdd(FName(*Pair.Key));
        for (const auto& Value:Pair.Value->AsArray())
        {
            const FString Path=Value->AsString(); auto* Sequence=Allowed.Contains(Path) ? LoadObject<UAnimSequence>(nullptr,*Path) : nullptr;
            if (!Sequence || Sequence->bLoop || Sequence->GetSkeleton()!=Mesh->GetSkeleton() || Sequence->GetSkeleton()->GetPathName()!=CatalogSkeletons.FindRef(Path)) {Message=TEXT("Invalid action candidate: ")+Path;return false;}
            Candidates.Sequences.Add(Sequence);
        }
    }
    // No mutation occurs until every reference, bone and destination has passed preflight.
    for (const FString& Package:Packages) if (FPackageName::DoesPackageExist(Package) || FindPackage(nullptr,*Package)) { Message=TEXT("Destination already exists; choose a fresh directory: ")+Package; return false; }
    FGaspBoneLayout Bones; const auto& Ref=Mesh->GetRefSkeleton();
    if (Ref.GetNum()==0) { Message=TEXT("Mesh has no reference bones"); return false; }
    auto Find=[&](const TCHAR* UEName,const TCHAR* Mixamo)->FName { if (Ref.FindBoneIndex(UEName)!=INDEX_NONE) return FName(UEName); for (int32 I=0;I<Ref.GetNum();++I) if (Ref.GetBoneName(I).ToString().EndsWith(Mixamo)) return Ref.GetBoneName(I); return NAME_None; };
    Bones.Root=Ref.GetBoneName(0); Bones.Pelvis=Find(TEXT("pelvis"),TEXT("Hips"));
    Bones.Feet={Find(TEXT("foot_l"),TEXT("LeftFoot")),Find(TEXT("foot_r"),TEXT("RightFoot"))}; Bones.Thighs={Find(TEXT("thigh_l"),TEXT("LeftUpLeg")),Find(TEXT("thigh_r"),TEXT("RightUpLeg"))}; Bones.Spine={Find(TEXT("spine_03"),TEXT("Spine2"))};
    if(Ref.FindBoneIndex(TEXT("spine_01"))!=INDEX_NONE)
    {
        Bones.Spine.Reset();
        for(const TCHAR* Name:{TEXT("spine_01"),TEXT("spine_02"),TEXT("spine_03"),TEXT("spine_04"),TEXT("spine_05")})
            if(Ref.FindBoneIndex(Name)!=INDEX_NONE)Bones.Spine.Add(FName(Name));
    }
    for (FName Bone:{Bones.Pelvis,Bones.Feet[0],Bones.Feet[1],Bones.Thighs[0],Bones.Thighs[1],Bones.Spine[0]}) if (Bone.IsNone()) { Message=TEXT("Unsupported bone layout: v1 supports mannequin / Mixamo aliases"); return false; }
    TArray<UObject*> Created;
    auto New=[&](UClass* Class,const FString& Name)->UObject* { const FString Path=Destination/Name; UObject* Result=NewObject<UObject>(CreatePackage(*Path),Class,*Name,RF_Public|RF_Standalone); Created.Add(Result); return Result; };
    auto* Schema=CastChecked<UPoseSearchSchema>(New(UPoseSearchSchema::StaticClass(),TEXT("PSS_Config"))); Schema->AddSkeleton(Mesh->GetSkeleton());
    // Define the actual indexed query vector, rather than a pair of foot positions.
    // Reset this NEW schema's defaults so engine-version defaults cannot duplicate channels.
    if (auto* Property=FindFProperty<FArrayProperty>(UPoseSearchSchema::StaticClass(),TEXT("Channels")))
        FScriptArrayHelper(Property,Property->ContainerPtrToValuePtr<void>(Schema)).EmptyValues();
    auto* Trajectory=NewObject<UPoseSearchFeatureChannel_Trajectory>(Schema);
    Trajectory->Samples.Reset();
    for (float Time:{-.2f,0.f,.2f,.4f,.6f})
    {
        auto& Sample=Trajectory->Samples.AddDefaulted_GetRef();Sample.Offset=Time;
        Sample.Flags=int32(EPoseSearchTrajectoryFlags::PositionXY)|int32(EPoseSearchTrajectoryFlags::VelocityXY)|int32(EPoseSearchTrajectoryFlags::FacingDirectionXY);
    }
    Schema->AddChannel(Trajectory);
    auto* Pose=NewObject<UPoseSearchFeatureChannel_Pose>(Schema);Pose->SampledBones.Reset();
    for (FName Bone:{Bones.Pelvis,Bones.Feet[0],Bones.Feet[1]})
    {
        auto& Sample=Pose->SampledBones.AddDefaulted_GetRef();Sample.Reference.BoneName=Bone;
        Sample.Flags=int32(EPoseSearchBoneFlags::Position)|int32(EPoseSearchBoneFlags::Velocity);
    }
    Schema->AddChannel(Pose);Schema->SampleRate=30;Schema->PostEditChange();
    auto* Set=CastChecked<UGaspAnimationSet>(New(UGaspAnimationSet::StaticClass(),TEXT("DA_Config"))); Set->Mesh=Mesh; Set->Bones=Bones;
    if(BehaviorGraph){Set->BehaviorGraphJson=Encode(*BehaviorGraph);for(auto* Asset:BehaviorAssets)Set->BehaviorResources.Add(Asset);}
    Set->Bones.MeshYawOffset=Plan->GetObjectField(TEXT("parameters"))->GetNumberField(TEXT("mesh_yaw"));
    Set->bEnableFootIK=false;
    // Keep the native MM sample graph for rigs that provide its IK chains.
    // Other rigs retain the sequence-only path until an IK layout is supplied.
    Set->bEnableSampleWarping=Ref.FindBoneIndex(Bones.IKRoot)!=INDEX_NONE;
    for(FName Bone:Bones.IKFeet)Set->bEnableSampleWarping &= Ref.FindBoneIndex(Bone)!=INDEX_NONE;
    for(FName Bone:Bones.Balls)Set->bEnableSampleWarping &= Ref.FindBoneIndex(Bone)!=INDEX_NONE;
    Set->bEnableRootOffset=Bones.Root!=Bones.Pelvis;
    Set->bReferencePoseWhenStopped=Plan->GetObjectField(TEXT("parameters"))->GetBoolField(TEXT("reference_idle"));
    for (const auto& Pair:ActionResources) Set->ConfiguredActions.Add(Pair.Key,Pair.Value);
    Set->ActionCandidates=ActionCandidates;
    if (Flow)
    {
        const auto Policy=(*Flow)->GetObjectField(TEXT("policy"));
        Set->ActionPolicy.bHitInterruptsAll=Policy->HasField(TEXT("hit_interrupts"));
        Set->ActionPolicy.bAttackMustFinish=Policy->HasField(TEXT("attack_exit"));
        FString AfterHit; Policy->TryGetStringField(TEXT("after_hit"),AfterHit);
        Set->ActionPolicy.bResumePreviousAfterHit=AfterHit==TEXT("previous");
        Set->ActionPolicy.bBlockAimWhenSprinting=Policy->HasField(TEXT("sprint_aim"));
        Set->ActionPolicy.BlendSeconds=(*Flow)->GetNumberField(TEXT("blend_seconds"));
        for (const auto& Pair:(*Flow)->GetObjectField(TEXT("filters"))->Values)
            Set->ConfiguredVariants.Add(FName(*(Pair.Key==TEXT("weapon") ? Pair.Value->AsString() : FString(Pair.Key.ToView()))));
    }
    const float Rate=Plan->GetObjectField(TEXT("parameters"))->GetNumberField(TEXT("play_rate")); Set->PlayRateRange=FVector2D(Rate,Rate);
    TMap<FString,UPoseSearchDatabase*> Databases; TArray<TSharedPtr<FJsonValue>> Results,Disabled,NativeStates;
    for (const auto& Value:Plan->GetArrayField(TEXT("states"))) {
        const auto State=Value->AsObject(); const FString Id=State->GetStringField(TEXT("id"));
        auto* DB=Cast<UPoseSearchDatabase>(Resources[Id]);
        if (!DB) { DB=CastChecked<UPoseSearchDatabase>(New(UPoseSearchDatabase::StaticClass(),TEXT("PSD_")+Id)); DB->Schema=Schema; DB->PoseSearchMode=EPoseSearchMode::BruteForce; for (UObject* Candidate:CandidateResources[Id]) {FPoseSearchDatabaseAnimationAsset Entry; Entry.AnimAsset=Candidate; DB->AddAnimationAsset(Entry);} DB->PostEditChange(); }
        Databases.Add(Id,DB); Set->Databases.Add(DB);Set->ConfiguredLocomotion.Add(FName(*Id),DB);
        bool BehaviorOnly=false;State->TryGetBoolField(TEXT("behavior_only"),BehaviorOnly);if(BehaviorOnly)continue;
        NativeStates.Add(Value);auto Row=MakeShared<FJsonObject>(); Row->SetStringField(TEXT("asset"),DB->GetPathName()); Results.Add(MakeShared<FJsonValueObject>(Row)); Disabled.Add(MakeShared<FJsonValueBoolean>(false));
    }
    TArray<TSharedPtr<FJsonValue>> Columns;
    for (const TCHAR* Binding:{TEXT("MovementMode"),TEXT("MovementState"),TEXT("Gait"),TEXT("Stance")}) {
        auto Column=MakeShared<FJsonObject>(); Column->SetStringField(TEXT("type"),TEXT("FloatRangeColumn")); Column->SetStringField(TEXT("binding"),Binding); TArray<TSharedPtr<FJsonValue>> Rows;
        for (const auto& Value:NativeStates) { auto When=Value->AsObject()->GetObjectField(TEXT("when")); double Number=0; const bool Has=When->TryGetNumberField(Binding,Number); auto Cell=MakeShared<FJsonObject>(); Cell->SetNumberField(TEXT("min"),Number); Cell->SetNumberField(TEXT("max"),Number); Cell->SetBoolField(TEXT("no_min"),!Has); Cell->SetBoolField(TEXT("no_max"),!Has); Rows.Add(MakeShared<FJsonValueObject>(Cell)); }
        Column->SetArrayField(TEXT("rows"),Rows); Columns.Add(MakeShared<FJsonValueObject>(Column));
    }
    auto Table=MakeShared<FJsonObject>(); Table->SetArrayField(TEXT("results"),Results); Table->SetArrayField(TEXT("disabled"),Disabled); Table->SetArrayField(TEXT("columns"),Columns);
    auto Tables=MakeShared<FJsonObject>(); Tables->SetObjectField(TEXT("Main"),Table); auto Rules=MakeShared<FJsonObject>(); Rules->SetStringField(TEXT("root"),TEXT("Main")); Rules->SetObjectField(TEXT("tables"),Tables);
    Set->DenseTable=BuildGaspChooserTable(Encode(Rules),Destination/TEXT("CHT_Config"),UPoseSearchDatabase::StaticClass()); Set->SparseTable=Set->DenseTable; Created.Add(Set->DenseTable);
    Set->TraversalTable=CastChecked<UChooserTable>(New(UChooserTable::StaticClass(),TEXT("CHT_NoTraversal"))); Set->TraversalTable->OutputObjectType=UAnimMontage::StaticClass();
    for (const auto& Value:Plan->GetArrayField(TEXT("transitions"))) { auto Edge=Value->AsObject(); auto& Rule=Set->ConfiguredTransitions.AddDefaulted_GetRef(); Rule.FromDatabase=Databases[Edge->GetStringField(TEXT("from"))]->GetFName(); Rule.ToDatabase=Databases[Edge->GetStringField(TEXT("to"))]->GetFName(); Rule.BlendSeconds=Edge->GetNumberField(TEXT("blend_seconds")); }
    FString ValidationError; if (!Set->ValidateForMesh(Mesh,ValidationError)) { Message=ValidationError; return false; }
    for (UObject* Object:Created) if (!Object || !Save(Object)) { Message=TEXT("Asset save failed. Partial new assets may remain under ")+Destination; return false; }
    FString PlanText; FFileHelper::LoadFileToString(PlanText,*PlanFile); FFileHelper::SaveStringToFile(PlanText,*FPackageName::LongPackageNameToFilename(Destination/TEXT("approved_plan"),TEXT(".json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    auto Manifest=MakeShared<FJsonObject>(); Manifest->SetStringField(TEXT("plan_text"),PlanText); TArray<TSharedPtr<FJsonValue>> Paths; for (auto* Object:Created) Paths.Add(MakeShared<FJsonValueString>(Object->GetPathName())); Manifest->SetArrayField(TEXT("assets"),Paths);
    FFileHelper::SaveStringToFile(Encode(Manifest),*(PlanFile+TEXT(".applied.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    Message=TEXT("Applied: ")+Set->GetPathName()+TEXT("\nSaved approved_plan.json; original assets were not changed."); return true;
}
}
