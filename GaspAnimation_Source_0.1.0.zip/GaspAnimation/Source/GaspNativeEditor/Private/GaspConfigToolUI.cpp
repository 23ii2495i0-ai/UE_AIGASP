#include "GaspConfigTool.h"
#include "GaspAnimationSettings.h"
#include "IPythonScriptPlugin.h"
#include "ContentBrowserModule.h"
#include "IContentBrowserSingleton.h"
#include "ToolMenus.h"
#include "Framework/Docking/TabManager.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Input/SSpinBox.h"
#include "PropertyCustomizationHelpers.h"
#include "Serialization/JsonReader.h"
#include "Containers/Ticker.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/SWindow.h"
#include "ImageUtils.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/PlatformProcess.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/Blueprint.h"
#include "Animation/AnimSequence.h"
#include "Animation/AnimMontage.h"
#include "SGaspBehaviorEditor.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "GaspNativeCharacter.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Widgets/Views/SListView.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Notifications/SProgressBar.h"
#include "HAL/FileManager.h"
#include "SGaspRequirementReview.h"
#include "SGaspUnifiedRequirementReview.h"

namespace GaspConfigTool {
static const FName TabName(TEXT("GaspAnimationConfigurator"));
static FDelegateHandle StartupHandle;
class SConfigurator : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SConfigurator) {} SLATE_END_ARGS()
    void Construct(const FArguments& Args)
    {
        bUseModel=GetDefault<UGaspAnimationSettings>()->bEnableAIByDefault || FParse::Param(FCommandLine::Get(),TEXT("AnimationConfigModel")) || FPaths::FileExists(Workspace()/TEXT("artifacts/anim_config/active_model.json"));
        Session=FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir()/TEXT("AnimationConfigurator")/FGuid::NewGuid().ToString(EGuidFormats::Digits));
        IFileManager::Get().MakeDirectory(*Session,true);
        ChildSlot[SNew(SVerticalBox)
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("指定网格、候选资源与目标蓝图 → 描述 Motion Matching 配置流 → 检查草案 → 应用\n生成器规划资源槽位，选择器绑定已选资源。原生支持攻击播放锁定、受击打断与恢复、冲刺禁瞄准；规则模式仅支持基础移动。")))]
            +SVerticalBox::Slot().AutoHeight().Padding(8,0)[SAssignNew(InputsArea,SExpandableArea).InitiallyCollapsed(false)
                .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("资源、目标角色与提示词（生成后折叠，展开可修改）")))]
                .BodyContent()[SNew(SVerticalBox)
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth()[SNew(STextBlock).Text(FText::FromString(TEXT("1  骨骼网格体   ")))]
                +SHorizontalBox::Slot().FillWidth(1)[SNew(SObjectPropertyEntryBox).AllowedClass(USkeletalMesh::StaticClass()).ObjectPath_Lambda([this](){return MeshPath;}).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnObjectChanged_Lambda([this](const FAssetData& A){MeshPath=A.GetSoftObjectPath().ToString(); AnimationPaths.Reset(); AnimationPaths.Add(FString()); InvalidateInputs(); RebuildAnimationInputs();})]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).Text(FText::FromString(TEXT("2  对应骨架的候选动画 / PoseSearch 数据库（可添加多个）")))]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SBox).MaxDesiredHeight(150)[SNew(SScrollBox)+SScrollBox::Slot()[SAssignNew(AnimationInputs,SVerticalBox)]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[SNew(SButton).Text(FText::FromString(TEXT("批量选择 / 添加文件夹…"))).IsEnabled_Lambda([this](){return Pending.IsEmpty() && !MeshPath.IsEmpty();}).OnClicked(this,&SConfigurator::OpenBatchPicker)]
                +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("+ 添加单个候选"))).IsEnabled_Lambda([this](){return Pending.IsEmpty() && !MeshPath.IsEmpty();}).OnClicked_Lambda([this](){AnimationPaths.Add(FString()); RebuildAnimationInputs(); return FReply::Handled();})]
                +SHorizontalBox::Slot().AutoWidth().Padding(8,0)[SNew(STextBlock).Text_Lambda([this](){return FText::FromString(FString::Printf(TEXT("已选 %d 项"),AnimationPaths.FilterByPredicate([](const FString& P){return !P.IsEmpty();}).Num()));})]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth()[SNew(STextBlock).Text(FText::FromString(TEXT("3  应用到角色蓝图   ")))]
                +SHorizontalBox::Slot().FillWidth(1)[SNew(SObjectPropertyEntryBox).AllowedClass(UBlueprint::StaticClass()).ObjectPath_Lambda([this](){return BlueprintPath;}).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnShouldFilterAsset_Lambda([](const FAssetData& A){auto* BP=Cast<UBlueprint>(A.GetAsset()); return !BP || !BP->ParentClass || !BP->ParentClass->IsChildOf(AGaspNativeCharacter::StaticClass());}).OnObjectChanged_Lambda([this](const FAssetData& A){BlueprintPath=A.GetSoftObjectPath().ToString();})]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth()[SNew(SCheckBox).IsChecked_Lambda([this](){ return bUseModel ? ECheckBoxState::Checked : ECheckBoxState::Unchecked; }).OnCheckStateChanged_Lambda([this](ECheckBoxState State){ if (!Idle()) return; bUseModel=State==ECheckBoxState::Checked; Say(bUseModel ? TEXT("已选择本地模型；请先启动服务。连接失败会报错，不会回退规则。") : TEXT("已选择规则模式。")); })[SNew(STextBlock).Text(FText::FromString(TEXT("使用本地训练模型  ")))]]
                +SHorizontalBox::Slot().FillWidth(1)[SAssignNew(Endpoint,SEditableTextBox).Text(FText::FromString(GetDefault<UGaspAnimationSettings>()->ModelServiceEndpoint)).IsEnabled_Lambda([this](){return bUseModel && Pending.IsEmpty();})]]
            +SVerticalBox::Slot().AutoHeight().Padding(8,2)[SNew(STextBlock).Text(FText::FromString(TEXT("4  动作描述与 Motion Matching 配置流要求")))]
            +SVerticalBox::Slot().AutoHeight().Padding(8,2)[SNew(SCheckBox).IsEnabled_Lambda([this](){return Pending.IsEmpty() && bUseModel;}).IsChecked(ECheckBoxState::Unchecked).OnCheckStateChanged_Lambda([this](ECheckBoxState S){bBehaviorMode=S==ECheckBoxState::Checked;InvalidateInputs();})[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("生成可编辑嵌套状态机（原固定策略）")))]]
            +SVerticalBox::Slot().AutoHeight().Padding(8,2)[SNew(SCheckBox).IsEnabled_Lambda([this](){return Pending.IsEmpty() && bUseModel;}).IsChecked(ECheckBoxState::Unchecked).OnCheckStateChanged_Lambda([this](ECheckBoxState S){bUnifiedMode=S==ECheckBoxState::Checked;InvalidateInputs();})[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("统一状态/条件/自定义动作（实验；草案需审阅，不支持的规则会阻断应用）")))]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SBox).MinDesiredHeight(60).MaxDesiredHeight(180)[SAssignNew(Request,SMultiLineEditableTextBox).Text(FText::FromString(TEXT("配置跑步，停止移动时使用参考姿势"))).HintText(FText::FromString(TEXT("描述需要的动作和切换"))).IsReadOnly_Lambda([this](){return !Pending.IsEmpty();}).OnTextChanged_Lambda([this](const FText& Text) { if (Draft && Draft->GetStringField(TEXT("request"))!=Text.ToString()) { InvalidateInputs(); Say(TEXT("动作描述已变更，请重新生成，避免应用旧逻辑。")); } })]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SAssignNew(Destination,SEditableTextBox).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).Text(FText::FromString(TEXT("/Game/Native/Generated/Setup_")+FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(8))).OnTextCommitted_Lambda([this](const FText& Text,ETextCommit::Type) { if (Draft) { Draft->SetStringField(TEXT("destination"),Text.ToString()); CommitStructured(); } })]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[SNew(STextBlock).Text(FText::FromString(TEXT("动画蓝图保存目录")))]
                +SHorizontalBox::Slot().FillWidth(2)[SAssignNew(AnimBlueprintDirectory,SEditableTextBox).Text(FText::FromString(TEXT("/Game/Native/Generated"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();})]
                +SHorizontalBox::Slot().AutoWidth().Padding(12,0,8,0)[SNew(STextBlock).Text(FText::FromString(TEXT("资产名称")))]
                +SHorizontalBox::Slot().FillWidth(1)[SAssignNew(AnimBlueprintName,SEditableTextBox).Text(FText::FromString(TEXT("ABP_StateMachine"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();})]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("模型/规则生成草案"))).IsEnabled_Lambda([this](){return Pending.IsEmpty() && !MeshPath.IsEmpty() && !BlueprintPath.IsEmpty() && AnimationPaths.ContainsByPredicate([](const FString& P){return !P.IsEmpty();});}).OnClicked(this,&SConfigurator::Generate)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("检查草案"))).OnClicked(this,&SConfigurator::Validate)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("重新编译审阅需求"))).OnClicked(this,&SConfigurator::CompileRequirements)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("保存审阅草案"))).OnClicked(this,&SConfigurator::SaveReviewedDraft)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("重开已保存草案"))).OnClicked(this,&SConfigurator::ReopenReviewedDraft)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("应用到指定角色蓝图"))).OnClicked(this,&SConfigurator::ApplyDraft)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("应用并导出状态机动画蓝图"))).OnClicked(this,&SConfigurator::ApplyAndExportAnimBlueprint)]
                +SHorizontalBox::Slot().AutoWidth().Padding(3)[SNew(SButton).Text(FText::FromString(TEXT("保存已应用样本"))).OnClicked(this,&SConfigurator::Record)]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SExpandableArea).InitiallyCollapsed(false)
                .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("人工创建：从空白建立单个叶子状态（不调用模型）")))]
                .BodyContent()[SNew(SVerticalBox)
                    +SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)
                        +SHorizontalBox::Slot().AutoWidth().Padding(4)[SNew(STextBlock).Text(FText::FromString(TEXT("状态名称")))]
                        +SHorizontalBox::Slot().FillWidth(1)[SAssignNew(ManualLeafName,SEditableTextBox).IsEnabled_Lambda([this](){return Pending.IsEmpty();})
                            .HintText(FText::FromString(TEXT("英文或下划线开头，可含数字，最多64字符")))
                            .OnTextChanged_Lambda([this](const FText&){bManualLeafConfirmed=false;})]]
                    +SVerticalBox::Slot().AutoHeight()[SNew(SCheckBox).IsEnabled_Lambda([this](){return Pending.IsEmpty();})
                        .IsChecked_Lambda([this](){return bManualLeafGround ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;})
                        .OnCheckStateChanged_Lambda([this](ECheckBoxState S){bManualLeafGround=S==ECheckBoxState::Checked;bManualLeafConfirmed=false;})
                        [SNew(STextBlock).Text(FText::FromString(TEXT("使用现有地面Motion Matching选择逻辑（待机、行走、跑步资源须另行检查）")))]]
                    +SVerticalBox::Slot().AutoHeight()[SNew(SCheckBox).IsEnabled_Lambda([this](){return Pending.IsEmpty() && bManualLeafGround && !ManualLeafName->GetText().IsEmpty();})
                        .IsChecked_Lambda([this](){return bManualLeafConfirmed ? ECheckBoxState::Checked : ECheckBoxState::Unchecked;})
                        .OnCheckStateChanged_Lambda([this](ECheckBoxState S){bManualLeafConfirmed=S==ECheckBoxState::Checked;})
                        [SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("我确认：仅创建上述一个叶子状态并设为入口，无父组、子状态或转换；这是人工创建，资源不足继续阻断应用。")))]]
                    +SVerticalBox::Slot().AutoHeight()[SNew(SButton).Text(FText::FromString(TEXT("确认并人工创建草案"))).IsEnabled_Lambda([this](){return Pending.IsEmpty() && bManualLeafConfirmed;}).OnClicked(this,&SConfigurator::CreateManualLeaf)]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SExpandableArea).InitiallyCollapsed(true)
                .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("生成失败后恢复：导入人工补全的需求IR（高级）")))]
                .BodyContent()[SNew(SVerticalBox)
                    +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("粘贴完整需求IR；可从失败审阅日志补全，不能粘贴错误JSON。此入口不调用模型，不自动补跳跃规则。导入后逐项确认，缺素材与外部接入继续阻断。")))]
                    +SVerticalBox::Slot().AutoHeight()[SNew(SBox).HeightOverride(120)[SAssignNew(ManualIR,SMultiLineEditableTextBox).IsReadOnly_Lambda([this](){return !Pending.IsEmpty();})]]
                    +SVerticalBox::Slot().AutoHeight()[SNew(SButton).Text(FText::FromString(TEXT("以人工IR建立待确认草案"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnClicked(this,&SConfigurator::ImportManualRequirements)]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SAssignNew(Status,STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("规则和本地模型独立选择；模型输出仍须校验与人工审阅。生成期间操作会被拒绝，不改写原资源。")))]
            +SVerticalBox::Slot().AutoHeight().Padding(8,0)[SNew(SProgressBar).Visibility_Lambda([this](){return Pending.IsEmpty()?EVisibility::Collapsed:EVisibility::Visible;}).Percent(TOptional<float>())]
            +SVerticalBox::Slot().AutoHeight().Padding(8,0)[SNew(SExpandableArea).InitiallyCollapsed(true)
                .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("完整处理详情（展开查看，可滚动）")))]
                .BodyContent()[SNew(SBox).HeightOverride(110)[SAssignNew(StatusDetails,SMultiLineEditableTextBox).IsReadOnly(true).AutoWrapText(true)]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8,0)[SNew(SButton).Text(FText::FromString(TEXT("结束本次隔离预览并退出UE")))
                .Visibility_Lambda([](){return FParse::Param(FCommandLine::Get(),TEXT("GaspReviewAcceptance")) ? EVisibility::Visible : EVisibility::Collapsed;})
                .OnClicked_Lambda([](){FPlatformMisc::RequestExit(false);return FReply::Handled();})]
            +SVerticalBox::Slot().FillHeight(1).Padding(8)[SAssignNew(Structured,SScrollBox)]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SExpandableArea).InitiallyCollapsed(true).HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("高级：JSON 配置（编辑后失去焦点刷新预览）")))].BodyContent()[SNew(SBox).HeightOverride(200)[SAssignNew(Preview,SMultiLineEditableTextBox).IsReadOnly_Lambda([this](){return !Pending.IsEmpty();}).OnTextCommitted(this,&SConfigurator::RawCommitted)]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SExpandableArea).InitiallyCollapsed(true).HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("已选资源元数据")))].BodyContent()[SNew(SBox).HeightOverride(130)[SAssignNew(CatalogView,SMultiLineEditableTextBox).IsReadOnly(true)]]]];
        RegisterActiveTimer(.2f,FWidgetActiveTimerDelegate::CreateSP(this,&SConfigurator::Poll));
        AnimationPaths.Add(FString()); RebuildAnimationInputs();
        if (FParse::Param(FCommandLine::Get(),TEXT("GaspConfigToolPreview"))) {
            FString CatalogText,PlanText,PreviewDir=FPaths::ProjectSavedDir()/TEXT("AnimationConfigurator/Integration");
            FParse::Value(FCommandLine::Get(),TEXT("ConfigToolPreviewDir="),PreviewDir);
            FFileHelper::LoadFileToString(CatalogText,*(PreviewDir/TEXT("catalog.json")));
            FFileHelper::LoadFileToString(PlanText,*(PreviewDir/TEXT("plan.json")));
            CatalogView->SetText(FText::FromString(CatalogText)); Preview->SetText(FText::FromString(PlanText)); Rebuild();
            TSharedPtr<FJsonObject> Catalog;
            if (FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(CatalogText),Catalog)) {
                AnimationPaths.Reset(); for (const auto& V:Catalog->GetArrayField(TEXT("assets"))) {auto A=V->AsObject(); if(A->GetStringField(TEXT("kind"))==TEXT("mesh")) MeshPath=A->GetStringField(TEXT("id")); else AnimationPaths.Add(A->GetStringField(TEXT("id")));} RebuildAnimationInputs();
                FFileHelper::SaveStringToFile(CatalogText,*File(TEXT("catalog.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
                FFileHelper::SaveStringToFile(Draft->GetStringField(TEXT("request")),*File(TEXT("request.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
                HasCatalog=true;
                if(FParse::Param(FCommandLine::Get(),TEXT("ConfigToolGeneratePreview")))
                {
                    bUseModel=true;bBehaviorMode=true;bUnifiedMode=true;
                    RegisterActiveTimer(1.f,FWidgetActiveTimerDelegate::CreateLambda([this](double,float){Launch(TEXT("generate"));return EActiveTimerReturnType::Stop;}));
                }
                if(FParse::Param(FCommandLine::Get(),TEXT("GaspReviewAcceptance")))
                    FFileHelper::SaveStringToFile(Session,*(PreviewDir/TEXT("ui_session.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
            }
            FParse::Value(FCommandLine::Get(),TEXT("ConfigToolTargetBlueprint="),BlueprintPath);
            if(InputsArea.IsValid())InputsArea->SetExpanded(false);
            Say(TEXT("集成验证预览：所示配置由选定资源生成；条件表和混合衔接参数可独立编辑。"));
            if (FParse::Param(FCommandLine::Get(),TEXT("GaspConfigBatchPreview")))
                RegisterActiveTimer(.5f,FWidgetActiveTimerDelegate::CreateLambda([this](double,float){OpenBatchPicker(); return EActiveTimerReturnType::Stop;}));
        }
    }
    ~SConfigurator() { if (Process.IsValid()) FPlatformProcess::CloseProc(Process); }
private:
    TSharedPtr<SEditableTextBox> ManualLeafName;
    double TaskStarted=0;
    bool bProgressPreviewSaved=false;
    bool bManualLeafGround=false,bManualLeafConfirmed=false;
    TSharedPtr<SMultiLineEditableTextBox> ManualIR;
    TSharedPtr<SExpandableArea> InputsArea;
    FString MeshPath,BlueprintPath; TArray<FString> AnimationPaths; TSharedPtr<SVerticalBox> AnimationInputs;
    TSet<FString> SelectedInputPaths;
    TMap<FString,TSet<FString>> CandidateSelections;
    void InvalidateInputs() { HasCatalog=false; Draft.Reset(); Structured->ClearChildren(); Preview->SetText(FText::GetEmpty()); Say(TEXT("资源已更新，点击生成会自动检查网格与候选动画。")); }
    bool FilterAnimation(const FAssetData& Asset) const
    {
        auto* Mesh=LoadObject<USkeletalMesh>(nullptr,*MeshPath); if(!Mesh || !Mesh->GetSkeleton()) return true;
        if (Asset.IsInstanceOf<UAnimSequence>()) { auto* A=Cast<UAnimSequence>(Asset.GetAsset()); return !A || A->GetSkeleton()!=Mesh->GetSkeleton(); }
        if (Asset.IsInstanceOf<UAnimMontage>()) {auto* A=Cast<UAnimMontage>(Asset.GetAsset());return !A || A->GetSkeleton()!=Mesh->GetSkeleton();}
        if (Asset.IsInstanceOf<UPoseSearchDatabase>()) { auto* A=Cast<UPoseSearchDatabase>(Asset.GetAsset()); return !A || !A->Schema || A->Schema->GetSkeleton(A->Schema->GetDefaultRole())!=Mesh->GetSkeleton(); }
        return true;
    }
    FARFilter BatchFilter(const FString& Folder,bool Recursive) const
    {
        FARFilter Filter;
        Filter.ClassPaths.Add(UAnimSequence::StaticClass()->GetClassPathName());
        Filter.ClassPaths.Add(UAnimMontage::StaticClass()->GetClassPathName());
        Filter.ClassPaths.Add(UPoseSearchDatabase::StaticClass()->GetClassPathName());
        Filter.bRecursiveClasses=true;
        Filter.PackagePaths.Add(FName(*Folder)); Filter.bRecursivePaths=Recursive;
        return Filter;
    }
    void AddAnimationCandidates(const TArray<FAssetData>& Assets)
    {
        if (!Idle()) return;
        int32 Added=0,Duplicates=0,Skipped=0;
        for (const FAssetData& Asset:Assets)
        {
            if (FilterAnimation(Asset)) { ++Skipped; continue; }
            const FString Path=Asset.GetSoftObjectPath().ToString();
            if (AnimationPaths.Contains(Path)) { ++Duplicates; continue; }
            AnimationPaths.Add(Path); ++Added;
        }
        if (Added) { AnimationPaths.RemoveAll([](const FString& P){return P.IsEmpty();}); InvalidateInputs(); RebuildAnimationInputs(); }
        Say(FString::Printf(TEXT("新增 %d 项，跳过 %d 个重复资源、%d 个不兼容或不支持的资源。候选过多超出模型输入预算时，请缩小文件夹或选择范围。"),Added,Duplicates,Skipped));
    }
    FReply OpenBatchPicker()
    {
        if (!Idle() || MeshPath.IsEmpty()) return FReply::Handled();
        auto& Browser=FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser")).Get();
        auto Folder=MakeShared<FString>(TEXT("/Game"));
        auto Recursive=MakeShared<bool>(true);
        auto Items=MakeShared<TArray<TSharedPtr<FAssetData>>>();
        auto Search=MakeShared<FString>();
        if (FParse::Param(FCommandLine::Get(),TEXT("GaspConfigBatchPreview")))
        {
            auto& Registry=FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
            Registry.SearchAllAssets(true);
            TArray<FAssetData> Found; Registry.GetAssets(BatchFilter(*Folder,*Recursive),Found);
            Found.RemoveAll([this](const FAssetData& A){return FilterAnimation(A);});
            const TArray<FString> Before=AnimationPaths;
            AddAnimationCandidates(Found); const int32 UniqueCount=AnimationPaths.Num();
            AddAnimationCandidates(Found);
            UE_LOG(LogTemp,Display,TEXT("GASP_BATCH_PICKER_CHECK compatible=%d duplicate_stable=%d"),Found.Num(),AnimationPaths.Num()==UniqueCount);
            AnimationPaths=Before; RebuildAnimationInputs();
        }
        auto AssetList=SNew(SListView<TSharedPtr<FAssetData>>).ListItemsSource(&Items.Get()).SelectionMode(ESelectionMode::Multi)
            .OnGenerateRow_Lambda([](TSharedPtr<FAssetData> Item,const TSharedRef<STableViewBase>& Owner){return SNew(STableRow<TSharedPtr<FAssetData>>,Owner)[SNew(STextBlock).Text(FText::FromString(Item->AssetName.ToString()+TEXT("  |  ")+Item->PackagePath.ToString())).ToolTipText(FText::FromString(Item->GetSoftObjectPath().ToString()))];});
        auto Refresh=[this,Folder,Recursive,Search,Items,WeakList=TWeakPtr<SListView<TSharedPtr<FAssetData>>>(AssetList)]()
        {
            TArray<FAssetData> Found;
            FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get().GetAssets(BatchFilter(*Folder,*Recursive),Found);
            Found.Sort([](const FAssetData& A,const FAssetData& B){return A.GetSoftObjectPath().ToString()<B.GetSoftObjectPath().ToString();});
            Items->Reset();
            for(const FAssetData& A:Found) if ((Search->IsEmpty() || A.GetSoftObjectPath().ToString().Contains(*Search)) && !FilterAnimation(A)) Items->Add(MakeShared<FAssetData>(A));
            if(auto List=WeakList.Pin()) {List->ClearSelection(); List->RequestListRefresh();}
        };
        Refresh();
        FPathPickerConfig Paths; Paths.DefaultPath=*Folder; Paths.bAllowContextMenu=false;
        Paths.OnPathSelected=FOnPathSelected::CreateLambda([Folder,Refresh](const FString& Path){*Folder=Path; Refresh();});
        auto Window=SNew(SWindow).Title(FText::FromString(TEXT("批量添加同骨架候选资源"))).ClientSize(FVector2D(1050,650)).SupportsMinimize(false).SupportsMaximize(true);
        Window->SetContent(SNew(SVerticalBox)
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).Text(FText::FromString(TEXT("左侧选择内容文件夹；右侧 Ctrl 点击多选、Shift 点击连续选择。仅显示当前网格同骨架的动画序列和 PoseSearch 数据库。"))).AutoWrapText(true)]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SCheckBox).IsChecked(ECheckBoxState::Checked).OnCheckStateChanged_Lambda([Recursive,Refresh](ECheckBoxState State){*Recursive=State==ECheckBoxState::Checked; Refresh();})[SNew(STextBlock).Text(FText::FromString(TEXT("包含子文件夹")))]]
            +SVerticalBox::Slot().FillHeight(1).Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().FillWidth(.28f)[Browser.CreatePathPicker(Paths)]
                +SHorizontalBox::Slot().FillWidth(.72f).Padding(8,0)[SNew(SVerticalBox)
                    +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,6)[SNew(SSearchBox).OnTextChanged_Lambda([Search,Refresh](const FText& Text){*Search=Text.ToString(); Refresh();})]
                    +SVerticalBox::Slot().FillHeight(1)[AssetList]
                    +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text_Lambda([Items,WeakList=TWeakPtr<SListView<TSharedPtr<FAssetData>>>(AssetList)](){auto List=WeakList.Pin(); return FText::FromString(FString::Printf(TEXT("显示 %d 项，选中 %d 项"),Items->Num(),List ? List->GetSelectedItems().Num() : 0));})]]]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).Text_Lambda([Folder](){return FText::FromString(TEXT("当前文件夹：")+*Folder);})]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(STextBlock).AutoWrapText(true).Text_Lambda([this](){return Status->GetText();})]
            +SVerticalBox::Slot().AutoHeight().Padding(8)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[SNew(SButton).Text(FText::FromString(TEXT("添加所选资源"))).OnClicked_Lambda([this,AssetList](){TArray<FAssetData> Selected; for(const auto& Item:AssetList->GetSelectedItems()) Selected.Add(*Item); AddAnimationCandidates(Selected); return FReply::Handled();})]
                +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[SNew(SButton).Text(FText::FromString(TEXT("添加当前文件夹全部兼容资源"))).ToolTipText(FText::FromString(TEXT("按左侧文件夹和子文件夹选项添加，不受右侧搜索词影响。"))).OnClicked_Lambda([this,Folder,Recursive](){TArray<FAssetData> Found; FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get().GetAssets(BatchFilter(*Folder,*Recursive),Found); Found.Sort([](const FAssetData& A,const FAssetData& B){return A.GetSoftObjectPath().ToString()<B.GetSoftObjectPath().ToString();}); AddAnimationCandidates(Found); return FReply::Handled();})]
                +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("完成"))).OnClicked_Lambda([WeakWindow=TWeakPtr<SWindow>(Window)](){if(auto W=WeakWindow.Pin()) W->RequestDestroyWindow(); return FReply::Handled();})]]);
        if (FParse::Param(FCommandLine::Get(),TEXT("GaspConfigBatchPreview"))) FSlateApplication::Get().AddWindow(Window);
        else FSlateApplication::Get().AddModalWindow(Window,FSlateApplication::Get().FindWidgetWindow(AsShared()));
        return FReply::Handled();
    }
    void RebuildAnimationInputs()
    {
        AnimationInputs->ClearChildren();
        for(auto It=SelectedInputPaths.CreateIterator();It;++It)if(!AnimationPaths.Contains(*It))It.RemoveCurrent();
        AnimationInputs->AddSlot().AutoHeight()[SNew(SHorizontalBox)
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("全选 / 取消全选输入资源"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnClicked_Lambda([this](){if(SelectedInputPaths.Num()==AnimationPaths.Num())SelectedInputPaths.Reset();else{SelectedInputPaths.Reset();for(const auto& Path:AnimationPaths)if(!Path.IsEmpty())SelectedInputPaths.Add(Path);}return FReply::Handled();})]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("删除选中输入资源"))).IsEnabled_Lambda([this](){return Pending.IsEmpty() && !SelectedInputPaths.IsEmpty();}).OnClicked_Lambda([this](){AnimationPaths.RemoveAll([this](const FString& Path){return SelectedInputPaths.Contains(Path);});SelectedInputPaths.Reset();InvalidateInputs();RebuildAnimationInputs();return FReply::Handled();})]];
        for(int32 I=0;I<AnimationPaths.Num();++I) AnimationInputs->AddSlot().AutoHeight().Padding(0,2)[SNew(SHorizontalBox)
            +SHorizontalBox::Slot().AutoWidth()[SNew(SCheckBox).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).IsChecked_Lambda([this,I](){return AnimationPaths.IsValidIndex(I) && SelectedInputPaths.Contains(AnimationPaths[I])?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([this,I](ECheckBoxState State){if(!AnimationPaths.IsValidIndex(I))return;if(State==ECheckBoxState::Checked)SelectedInputPaths.Add(AnimationPaths[I]);else SelectedInputPaths.Remove(AnimationPaths[I]);})]
            +SHorizontalBox::Slot().FillWidth(1)[SNew(SObjectPropertyEntryBox).AllowedClass(UObject::StaticClass()).ObjectPath_Lambda([this,I](){return AnimationPaths.IsValidIndex(I)?AnimationPaths[I]:FString();}).IsEnabled_Lambda([this](){return Pending.IsEmpty() && !MeshPath.IsEmpty();}).OnShouldFilterAsset(this,&SConfigurator::FilterAnimation).OnObjectChanged_Lambda([this,I](const FAssetData& A){ if(AnimationPaths.IsValidIndex(I)){AnimationPaths[I]=A.GetSoftObjectPath().ToString(); InvalidateInputs();} })]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("移除"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnClicked_Lambda([this,I](){AnimationPaths.RemoveAt(I); InvalidateInputs(); RebuildAnimationInputs(); return FReply::Handled();})]];
    }
    FString Session; bool bUseModel=true,bBehaviorMode=false,bUnifiedMode=false; FProcHandle Process; FString Pending; bool HasCatalog=false, bRefresh=false;
    TSharedPtr<SMultiLineEditableTextBox> Request,Preview,CatalogView;
    TSharedPtr<SEditableTextBox> Destination,Endpoint,AnimBlueprintDirectory,AnimBlueprintName; TSharedPtr<STextBlock> Status; TSharedPtr<SMultiLineEditableTextBox> StatusDetails;
    TSharedPtr<SScrollBox> Structured; TSharedPtr<FJsonObject> Draft; TSet<FString> AllowedResources;
    FString File(const TCHAR* Name) const { return Session/Name; }
    void Say(const FString& Text)
    {
        if(StatusDetails.IsValid())StatusDetails->SetText(FText::FromString(Text));
        FString Summary=Text;int32 Start=INDEX_NONE;
        if(Text.FindChar(TCHAR('{'),Start))
        {
            TSharedPtr<FJsonObject> Error;FString Message;const TArray<TSharedPtr<FJsonValue>>* Errors=nullptr;
            if(FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text.Mid(Start)),Error) && Error)
            {
                if(Error->TryGetStringField(TEXT("error"),Message))Summary=TEXT("处理失败：")+Message;
                else if(Error->TryGetArrayField(TEXT("errors"),Errors) && !Errors->IsEmpty())Summary=FString::Printf(TEXT("检查未通过（%d项）："),Errors->Num())+(*Errors)[0]->AsString();
            }
        }
        int32 Newline=INDEX_NONE;if(Summary.FindChar(TCHAR('\n'),Newline))Summary=Summary.Left(Newline);
        if(Summary.Len()>130)Summary=Summary.Left(127)+TEXT("…");
        Status->SetText(FText::FromString(Summary));
    }
    bool Idle() { if (!Pending.IsEmpty()) { Say(TEXT("后台任务仍在运行，请稍候。")); return false; } return true; }
    void SaveDraft() { FFileHelper::SaveStringToFile(Preview->GetText().ToString(),*File(TEXT("plan.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM); }
    bool HasUsableDraft()
    {
        TSharedPtr<FJsonObject> Parsed;
        if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Preview->GetText().ToString()),Parsed) || !Parsed || Parsed->HasField(TEXT("error")) || !Parsed->HasField(TEXT("states")))
        {
            Say(TEXT("没有可检查或应用的有效草案。请先生成成功；生成错误保留在当前会话 plan.json 中。"));
            return false;
        }
        return true;
    }
    bool Launch(const FString& Action)
    {
        if (!HasCatalog || !Idle()) { Say(TEXT("请先指定网格、候选动画和目标蓝图并生成草案，等待当前任务完成。")); return false; }
        const FString Output=File(Action==TEXT("generate") || Action==TEXT("compile-behavior") || Action==TEXT("review-draft") || Action==TEXT("create-leaf") ? TEXT("plan.json") : TEXT("result.json"));
        const FString Samples=FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir()/TEXT("AnimationConfigurator/approved_samples.jsonl"));
        FString Args=FString::Printf(TEXT("\"%s\" %s --catalog \"%s\" --plan \"%s\" --request \"%s\" --destination \"%s\" --output \"%s\" --samples \"%s\" --applied-manifest \"%s\""),
            *Backend(),*Action,*File(TEXT("catalog.json")),*File(TEXT("plan.json")),*File(TEXT("request.txt")),*Destination->GetText().ToString(),*Output,*Samples,*File(TEXT("plan.json.applied.json")));
        if (Action==TEXT("generate") && bUseModel) Args+=TEXT(" --provider local --endpoint \"")+Endpoint->GetText().ToString()+TEXT("\"");
        if(Action==TEXT("create-leaf")) Args+=TEXT(" --form-file \"")+File(TEXT("manual_leaf_form.json"))+TEXT("\"");
        if(Action==TEXT("review-draft")) Args+=TEXT(" --ir-file \"")+File(TEXT("manual_ir.json"))+TEXT("\"");
        if(Action==TEXT("generate") && bUseModel && bBehaviorMode)Args+=TEXT(" --behavior");
        if(Action==TEXT("generate") && bUseModel && bUnifiedMode)Args+=TEXT(" --unified-behavior");
        IFileManager::Get().Delete(*File(TEXT("progress.json")));
        TaskStarted=FPlatformTime::Seconds();
        Process=FPlatformProcess::CreateProc(*Python(),*Args,false,true,true,nullptr,0,nullptr,nullptr);
        if (!Process.IsValid()) { Say(TEXT("无法启动 Python。用环境变量 GASP_CONFIG_PYTHON 指定 Python 3。")); return false; }
        Pending=Action; Say(TEXT("正在后台处理：")+Action); return true;
    }
    EActiveTimerReturnType Poll(double,float)
    {
        if(!Pending.IsEmpty() && FPlatformProcess::IsProcRunning(Process))
        {
            FString Text,Stage=TEXT("准备或发送请求"),Phase;TSharedPtr<FJsonObject> Progress;
            double Attempt=1,Tokens=0;
            if(FFileHelper::LoadFileToString(Text,*File(TEXT("progress.json"))) && FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),Progress) && Progress)
            {
                Progress->TryGetStringField(TEXT("stage"),Stage);Progress->TryGetStringField(TEXT("phase"),Phase);
                Progress->TryGetNumberField(TEXT("attempt"),Attempt);Progress->TryGetNumberField(TEXT("tokens"),Tokens);
                Stage.ReplaceInline(TEXT("state_"),TEXT("配置节点："));
                Stage.ReplaceInline(TEXT("layout"),TEXT("提取状态布局"));Stage.ReplaceInline(TEXT("hierarchy"),TEXT("建立父子层级"));
                Stage.ReplaceInline(TEXT("declarations"),TEXT("提取变量与输入"));
                Phase=Phase==TEXT("prefill")?TEXT("处理输入"):Phase==TEXT("decode")?TEXT("生成内容"):TEXT("准备约束");
            }
            Status->SetText(FText::FromString(FString::Printf(TEXT("%s · %s · 第%d次 · 已用 %.0f 秒 · 已生成 %d token"),*Stage,*Phase,int32(Attempt),FPlatformTime::Seconds()-TaskStarted,int32(Tokens))));
            if(!bProgressPreviewSaved && FPlatformTime::Seconds()-TaskStarted>15 && FParse::Param(FCommandLine::Get(),TEXT("ConfigToolGeneratePreview")))
            {
                auto Window=FSlateApplication::Get().FindWidgetWindow(AsShared());
                TArray<FColor> Pixels;FIntVector Size=FIntVector::ZeroValue;
                if(Window && FSlateApplication::Get().TakeScreenshot(Window.ToSharedRef(),Pixels,Size))
                {
                    TArray64<uint8> PNG;FImageUtils::PNGCompressImageArray(Size.X,Size.Y,TArrayView64<const FColor>(Pixels),PNG);
                    bProgressPreviewSaved=FFileHelper::SaveArrayToFile(PNG,*(FPaths::ProjectSavedDir()/TEXT("AnimationConfigurator/GenerationProgress.png")));
                }
            }
        }
        if (bRefresh && Pending.IsEmpty()) { bRefresh=false; Rebuild(); }
        if (!Pending.IsEmpty() && !FPlatformProcess::IsProcRunning(Process)) {
            int32 Code=-1; FPlatformProcess::GetProcReturnCode(Process,&Code); FPlatformProcess::CloseProc(Process); Process.Reset();
            FString Text; FFileHelper::LoadFileToString(Text,*File(Pending==TEXT("generate") || Pending==TEXT("compile-behavior") || Pending==TEXT("review-draft") || Pending==TEXT("create-leaf") ? TEXT("plan.json") : TEXT("result.json")));
            if ((Pending==TEXT("generate") || Pending==TEXT("compile-behavior") || Pending==TEXT("review-draft") || Pending==TEXT("create-leaf")) && Code==0) { Preview->SetText(FText::FromString(Text)); Rebuild(); Say(Pending==TEXT("create-leaf") ? TEXT("人工创建并确定性编译完成，未调用模型。请检查资源缺口；这不是模型生成成功。") : TEXT("草案已生成/重新编译。请检查资源、条件和 issues；校验通过后再应用。")); }
            else if(Pending==TEXT("validate") && Code==0) Say(TEXT("结构与资源约束检查通过。尚未验证实际播放、Pose 索引和衔接效果，请在 Play 中检查。"));
            else Say(FString::Printf(TEXT("%s (exit %d)\n%s"),*Pending,Code,*Text));
            Pending.Reset();
        }
        return EActiveTimerReturnType::Continue;
    }
    void CommitStructured()
    {
        FString Text; FJsonSerializer::Serialize(Draft.ToSharedRef(),TJsonWriterFactory<>::Create(&Text)); Preview->SetText(FText::FromString(Text));
        if(FParse::Param(FCommandLine::Get(),TEXT("GaspReviewAcceptance")))
            FFileHelper::SaveStringToFile(Text,*File(TEXT("ui_live_plan.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
    }
    bool FilterBinding(const FAssetData& Asset,bool Action,const FString& Role=FString()) const
    {
        if (!AllowedResources.Contains(Asset.GetSoftObjectPath().ToString()) || FilterAnimation(Asset)) return true;
        if(auto* Sequence=Cast<UAnimSequence>(Asset.GetAsset())) return Role==TEXT("jump") ? false : Action ? Sequence->bLoop : !Sequence->bLoop;
        return Action || !Asset.IsInstanceOf<UPoseSearchDatabase>();
    }
    void UpdateBinding(const FString& Role,const FString& Path,bool Action)
    {
        if (Draft)
        {
            if (Action) {const TSharedPtr<FJsonObject>* Flow=nullptr; const TSharedPtr<FJsonObject>* Candidates=nullptr; if(Draft->TryGetObjectField(TEXT("runtime_flow"),Flow) && (*Flow)->TryGetObjectField(TEXT("action_candidates"),Candidates)) (*Candidates)->SetArrayField(Role,{MakeShared<FJsonValueString>(Path)});}
            else for (const auto& Value:Draft->GetArrayField(TEXT("states"))) if (Value->AsObject()->GetStringField(TEXT("id"))==Role) Value->AsObject()->SetArrayField(TEXT("resources"),{MakeShared<FJsonValueString>(Path)});
        }
        TSharedPtr<FJsonObject> Catalog; FString Alias;
        if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(CatalogView->GetText().ToString()),Catalog)) return;
        const auto& Assets=Catalog->GetArrayField(TEXT("assets"));
        for(int32 I=0;I<Assets.Num();++I) if(Assets[I]->AsObject()->GetStringField(TEXT("id"))==Path) {Alias=FString::Printf(TEXT("a%d"),I); break;}
        if(Alias.IsEmpty()) return;
        const TSharedPtr<FJsonObject>* Info=nullptr; const TSharedPtr<FJsonObject>* IR=nullptr;
        if(Draft->TryGetObjectField(TEXT("model_info"),Info) && (*Info)->TryGetObjectField(TEXT("flow_ir"),IR))
        {
            const TSharedPtr<FJsonObject>* Bindings=nullptr;
            if(!(*IR)->TryGetObjectField(Action ? TEXT("actions") : TEXT("bindings"),Bindings)) {Say(TEXT("模型绑定记录无效，请重新生成。")); return;}
            (*Bindings)->SetStringField(Role,Alias);
            bool Complete=true;
            for(const TCHAR* Field:{TEXT("bindings"),TEXT("actions")})
            {
                const TSharedPtr<FJsonObject>* Map=nullptr;
                if(!(*IR)->TryGetObjectField(Field,Map)) {Complete=false; continue;}
                for(const auto& Pair:(*Map)->Values) {FString Value; if(!Pair.Value->TryGetString(Value) || Value.IsEmpty()) Complete=false;}
            }
            // Only selection rejection can be cleared; semantic rejection stays blocking.
            if(Complete && (*Info)->HasField(TEXT("generator_reject")) && (*Info)->TryGetField(TEXT("generator_reject"))->IsNull()) (*IR)->SetField(TEXT("reject"),MakeShared<FJsonValueNull>());
        }
        const TArray<TSharedPtr<FJsonValue>>* Current=nullptr;
        if(Draft->TryGetArrayField(TEXT("issues"),Current))
        {
            TArray<TSharedPtr<FJsonValue>> Kept;
            for(const auto& Value:*Current)
            {
                const auto Issue=Value->AsObject(); FString IssueRole,Code,Message;
                if(!Issue) {Kept.Add(Value); continue;}
                Issue->TryGetStringField(TEXT("role"),IssueRole); Issue->TryGetStringField(TEXT("code"),Code); Issue->TryGetStringField(TEXT("message"),Message);
                if(IssueRole==Role) continue;
                if(Action && Code==TEXT("runtime_binding_invalid") && Message==TEXT("Action must be selected compatible nonloop sequence: ")+Role) continue;
                if(Code==TEXT("model_rejected") && IR && (*IR)->HasField(TEXT("reject")) && (*IR)->TryGetField(TEXT("reject"))->IsNull()) continue;
                Kept.Add(Value);
            }
            Draft->SetArrayField(TEXT("issues"),Kept);
        }
        CommitStructured(); bRefresh=true; Say(TEXT("已更新资源绑定，请重新检查草案。"));
    }
    void RawCommitted(const FText&,ETextCommit::Type) { Rebuild(); }
    void ChangeCandidates(const FString& Role,bool Action,const TSharedPtr<FJsonObject>& Owner,const FString& Key,TArray<TSharedPtr<FJsonValue>> Copy)
    {
        if (!Idle()) return;
        // Removing a primary promotes another compatible looping clip, never a stop-only clip.
        if (!Action && !Copy.IsEmpty())
        {
            const int32 Primary=Copy.IndexOfByPredicate([Role](const TSharedPtr<FJsonValue>& V){UObject* A=LoadObject<UObject>(nullptr,*V->AsString());const auto* S=Cast<UAnimSequence>(A);return (S && (S->bLoop || Role==TEXT("jump"))) || Cast<UPoseSearchDatabase>(A);});
            if (Primary!=INDEX_NONE) Copy.Swap(0,Primary);
        }
        const TSharedPtr<FJsonObject>* Flow=nullptr;
        TSharedPtr<FJsonObject> Bindings=Owner;
        if(Action && Draft->TryGetObjectField(TEXT("runtime_flow"),Flow)) Bindings=(*Flow)->GetObjectField(TEXT("actions"));
        if (!Copy.IsEmpty())
        {
            const FString Path=Copy[0]->AsString(); Bindings->SetStringField(Action ? Role : TEXT("resource"),Path);
            UpdateBinding(Role,Path,Action);
        }
        else
        {
            Bindings->SetField(Action ? Role : TEXT("resource"),MakeShared<FJsonValueNull>());
            const TSharedPtr<FJsonObject>* Info=nullptr;const TSharedPtr<FJsonObject>* IR=nullptr;
            if(Draft->TryGetObjectField(TEXT("model_info"),Info) && (*Info)->TryGetObjectField(TEXT("flow_ir"),IR))
                (*IR)->GetObjectField(Action ? TEXT("actions") : TEXT("bindings"))->SetField(Role,MakeShared<FJsonValueNull>());
        }
        Owner->SetArrayField(Key,Copy);CandidateSelections.Remove(Role+(Action ? TEXT("|action") : TEXT("|motion")));
        CommitStructured();bRefresh=true;Say(Copy.IsEmpty() ? TEXT("该类别已清空；重新绑定资源前禁止应用。") : TEXT("候选已更新，主资源及模型绑定已同步；请重新检查草案。"));
    }
    void CandidateRows(const FString& Role,bool Action,const TSharedPtr<FJsonObject>& Owner,const FString& Key)
    {
        const TArray<TSharedPtr<FJsonValue>>* Values=nullptr;
        if (!Owner->TryGetArrayField(Key,Values)) return;
        const FString Group=Role+(Action ? TEXT("|action") : TEXT("|motion"));
        auto& GroupSelection=CandidateSelections.FindOrAdd(Group);
        for(auto It=GroupSelection.CreateIterator();It;++It)if(!Values->ContainsByPredicate([&It](const TSharedPtr<FJsonValue>& V){return V->AsString()==*It;}))It.RemoveCurrent();
        Structured->AddSlot().Padding(4)[SNew(SHorizontalBox)
            +SHorizontalBox::Slot().FillWidth(1)[SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("%s 候选片段：%d（首项为主资源）"),*Role,Values->Num())))]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("全选 / 取消全选"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnClicked_Lambda([this,Owner,Key,Group](){auto& Selected=CandidateSelections.FindOrAdd(Group);const auto& All=Owner->GetArrayField(Key);if(Selected.Num()==All.Num())Selected.Reset();else{Selected.Reset();for(const auto& V:All)Selected.Add(V->AsString());}return FReply::Handled();})]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("删除选中"))).IsEnabled_Lambda([this,Group](){return Pending.IsEmpty() && !CandidateSelections.FindOrAdd(Group).IsEmpty();}).OnClicked_Lambda([this,Role,Action,Owner,Key,Group](){auto Copy=Owner->GetArrayField(Key);const auto Selected=CandidateSelections.FindRef(Group);Copy.RemoveAll([&Selected](const TSharedPtr<FJsonValue>& V){return Selected.Contains(V->AsString());});ChangeCandidates(Role,Action,Owner,Key,Copy);return FReply::Handled();})]];
        for(int32 I=0;I<Values->Num();++I)
        {
            const FString Path=(*Values)[I]->AsString();
            FString Label=Path; const TSharedPtr<FJsonObject>* Info=nullptr; const TSharedPtr<FJsonObject>* Hybrid=nullptr;
            if(Draft->TryGetObjectField(TEXT("model_info"),Info) && (*Info)->TryGetObjectField(TEXT("hybrid_selection"),Hybrid))
            {
                const TArray<TSharedPtr<FJsonValue>>* Evidence=nullptr;
                if((*Hybrid)->TryGetArrayField(TEXT("evidence"),Evidence)) for(const auto& Value:*Evidence) if(Value->AsObject()->GetStringField(TEXT("id"))==Path)
                {
                    const TSharedPtr<FJsonObject>* Scores=nullptr;double Score=0;
                    if(Value->AsObject()->TryGetObjectField(TEXT("pose_scores"),Scores) && (*Scores)->TryGetNumberField(Role,Score)) Label+=FString::Printf(TEXT("\n姿态模型对本类别评分 %.3f（实验分数）"),Score);
                }
            }
            Structured->AddSlot().Padding(8,2)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().AutoWidth()[SNew(SCheckBox).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).IsChecked_Lambda([this,Group,Path](){return CandidateSelections.FindOrAdd(Group).Contains(Path)?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([this,Group,Path](ECheckBoxState State){auto& Selected=CandidateSelections.FindOrAdd(Group);if(State==ECheckBoxState::Checked)Selected.Add(Path);else Selected.Remove(Path);})]
                +SHorizontalBox::Slot().FillWidth(1)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(Label))]
                +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("移除候选"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnClicked_Lambda([this,Role,Action,Owner,Key,I](){auto Copy=Owner->GetArrayField(Key);Copy.RemoveAt(I);ChangeCandidates(Role,Action,Owner,Key,Copy);return FReply::Handled();})]];
        }
        Structured->AddSlot().Padding(4)[SNew(SButton).Text(FText::FromString(TEXT("将内容浏览器中选中的动画加入此候选槽"))).IsEnabled_Lambda([this](){return Pending.IsEmpty();}).OnClicked_Lambda([this,Owner,Key,Action](){
            TArray<FAssetData> Selected; FModuleManager::LoadModuleChecked<FContentBrowserModule>(TEXT("ContentBrowser")).Get().GetSelectedAssets(Selected);
            auto Copy=Owner->GetArrayField(Key);
            if(!Action && !Copy.IsEmpty() && Cast<UPoseSearchDatabase>(LoadObject<UObject>(nullptr,*Copy[0]->AsString()))) {Say(TEXT("主资源已是完整数据库；若要编辑片段候选，请先将主资源改为动画序列。"));return FReply::Handled();}
            TSet<FString> Seen;for(const auto& V:Copy) Seen.Add(V->AsString());
            for(const auto& A:Selected) if(AllowedResources.Contains(A.GetSoftObjectPath().ToString()) && !FilterAnimation(A)) if(auto* Sequence=Cast<UAnimSequence>(A.GetAsset())) if(!Action || !Sequence->bLoop) {const FString Path=A.GetSoftObjectPath().ToString();if(!Seen.Contains(Path)){Seen.Add(Path);Copy.Add(MakeShared<FJsonValueString>(Path));}}
            Owner->SetArrayField(Key,Copy);CommitStructured();bRefresh=true;return FReply::Handled();})];
    }
    void Rebuild()
    {
        TSharedPtr<FJsonObject> Parsed;
        if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Preview->GetText().ToString()),Parsed) || !Parsed) { Say(TEXT("JSON 格式无效；不能刷新预览。")); return; }
        const TArray<TSharedPtr<FJsonValue>>* States=nullptr; const TArray<TSharedPtr<FJsonValue>>* Edges=nullptr; const TSharedPtr<FJsonObject>* Parameters=nullptr;
        if (!Parsed->TryGetArrayField(TEXT("states"),States) || !Parsed->TryGetArrayField(TEXT("transitions"),Edges) || !Parsed->TryGetObjectField(TEXT("parameters"),Parameters)) { Say(TEXT("缺少 states / transitions / parameters")); return; }
        // Validate structure without dereferencing user-edited JSON fields blindly.
        for (const auto& V:*States) { FString Id; const TSharedPtr<FJsonObject>* When=nullptr; if (!V->AsObject() || !V->AsObject()->TryGetStringField(TEXT("id"),Id) || !V->AsObject()->TryGetObjectField(TEXT("when"),When)) { Say(TEXT("状态字段格式错误")); return; } }
        for (const auto& V:*Edges) { FString From,To; double Blend; if (!V->AsObject() || !V->AsObject()->TryGetStringField(TEXT("from"),From) || !V->AsObject()->TryGetStringField(TEXT("to"),To) || !V->AsObject()->TryGetNumberField(TEXT("blend_seconds"),Blend)) { Say(TEXT("衔接字段格式错误")); return; } }
        double Yaw,Rate; if (!(*Parameters)->TryGetNumberField(TEXT("mesh_yaw"),Yaw) || !(*Parameters)->TryGetNumberField(TEXT("play_rate"),Rate)) { Say(TEXT("参数格式错误")); return; }
        Draft=Parsed; FString CurrentDestination,CurrentRequest; if (Draft->TryGetStringField(TEXT("destination"),CurrentDestination)) Destination->SetText(FText::FromString(CurrentDestination)); if (Draft->TryGetStringField(TEXT("request"),CurrentRequest)) Request->SetText(FText::FromString(CurrentRequest)); Structured->ClearChildren();
        const TSharedPtr<FJsonObject>* ReviewInfo=nullptr;const TSharedPtr<FJsonObject>* ReviewIR=nullptr;
        if(Draft->TryGetObjectField(TEXT("model_info"),ReviewInfo) && (*ReviewInfo)->HasTypedField<EJson::Object>(TEXT("unified_requirements")))
        {
            Structured->AddSlot().Padding(4)[SNew(SExpandableArea).InitiallyCollapsed(false)
                .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("统一状态、条件与内容：含自定义动作")))]
                .BodyContent()[SNew(SBox).MaxDesiredHeight(460)[SNew(SScrollBox)+SScrollBox::Slot()[MakeGaspUnifiedRequirementReview(*ReviewInfo,Draft->GetStringField(TEXT("request")),[this](){CommitStructured();},[this](){return Pending.IsEmpty();})]]]];
        }
        if(Draft->TryGetObjectField(TEXT("model_info"),ReviewInfo) && (*ReviewInfo)->TryGetObjectField(TEXT("behavior_requirements"),ReviewIR))
        {
            Structured->AddSlot().Padding(4)[SNew(SExpandableArea).InitiallyCollapsed(false)
                .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("跳跃规则与原文依据：人工确认")))]
                .BodyContent()[SNew(SBox).MaxDesiredHeight(420)[SNew(SScrollBox)+SScrollBox::Slot()[MakeGaspRequirementReview(*ReviewInfo,Draft->GetStringField(TEXT("request")),[this](){CommitStructured();},[this](){return Pending.IsEmpty();})]]]];
        }
        const TSharedPtr<FJsonObject>* Behavior=nullptr;
        if(Draft->HasField(TEXT("behavior_graph")) && !Draft->TryGetObjectField(TEXT("behavior_graph"),Behavior))
            Structured->AddSlot().Padding(4)[SNew(STextBlock).AutoWrapText(true).ColorAndOpacity(FLinearColor(1,.3,.2)).Text(FText::FromString(TEXT("behavior_graph必须是对象；请在高级JSON中修正，当前草案不能应用。")))];
        if(Behavior)
        {
            InputsArea->SetExpanded(false);
            TSet<FString> GraphAllowed;TSharedPtr<FJsonObject> InputCatalog;
            const TArray<TSharedPtr<FJsonValue>>* InputAssets=nullptr;
            if(FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(CatalogView->GetText().ToString()),InputCatalog) && InputCatalog && InputCatalog->TryGetArrayField(TEXT("assets"),InputAssets))
                for(const auto& V:*InputAssets){FString Id;if(V.IsValid() && V->Type==EJson::Object && V->AsObject()->TryGetStringField(TEXT("id"),Id))GraphAllowed.Add(Id);}
            Structured->AddSlot().Padding(4)[SNew(SGaspBehaviorEditor).Definition(*Behavior).AllowedResources(GraphAllowed).OnChanged(FSimpleDelegate::CreateSP(this,&SConfigurator::CommitStructured))];
        }
        const TSharedPtr<FJsonObject>* SelectionInfo=nullptr;const TSharedPtr<FJsonObject>* Hybrid=nullptr;const TSharedPtr<FJsonObject>* Constraints=nullptr;
        if(Draft->TryGetObjectField(TEXT("model_info"),SelectionInfo))
        {
            const TSharedPtr<FJsonObject>* Requirements=nullptr;
            if((*SelectionInfo)->TryGetObjectField(TEXT("behavior_requirements"),Requirements))
            {
                FString RequirementText;FJsonSerializer::Serialize((*Requirements).ToSharedRef(),TJsonWriterFactory<>::Create(&RequirementText));
                Structured->AddSlot().Padding(4)[SNew(SExpandableArea).InitiallyCollapsed(true)
                    .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("高级需求IR：可选查看或编辑；人工表单创建与模型抽取的来源分别记录。编辑后须重新确认和编译。"))).AutoWrapText(true)]
                    .BodyContent()[SNew(SBox).MaxDesiredHeight(260)[SNew(SMultiLineEditableTextBox).IsReadOnly_Lambda([this](){return !Pending.IsEmpty();}).Text(FText::FromString(RequirementText)).OnTextChanged_Lambda([this,Info=*SelectionInfo](const FText&){const TSharedPtr<FJsonObject>* Review=nullptr;if(Info->TryGetObjectField(TEXT("behavior_human_review"),Review)){(*Review)->SetBoolField(TEXT("ir_edit_uncommitted"),true);(*Review)->SetBoolField(TEXT("all_ir_confirmed"),false);(*Review)->RemoveField(TEXT("compiled_signature"));CommitStructured();}}).OnTextCommitted_Lambda([this,Info=*SelectionInfo](const FText& T,ETextCommit::Type){TSharedPtr<FJsonObject> Edited;if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(T.ToString()),Edited) || !Edited){Say(TEXT("需求IR JSON无效，未修改。"));return;}Info->SetObjectField(TEXT("behavior_requirements"),Edited);const TSharedPtr<FJsonObject>* Review=nullptr;if(Info->TryGetObjectField(TEXT("behavior_human_review"),Review)){(*Review)->RemoveField(TEXT("ir_edit_uncommitted"));(*Review)->SetBoolField(TEXT("all_ir_confirmed"),false);(*Review)->RemoveField(TEXT("compiled_signature"));}CommitStructured();bRefresh=true;Say(TEXT("需求IR已修改；请重新编译审阅需求并检查草案，旧语义审阅不可沿用。"));})]]];
            }
            double Limit=0;
            if((*SelectionInfo)->TryGetObjectField(TEXT("selection_constraints"),Constraints) && (*Constraints)->TryGetNumberField(TEXT("max_candidates_per_role"),Limit))
                Structured->AddSlot().Padding(4)[SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("文本数量约束：每类最多 %d 段候选动画。动作类别不是蒙太奇 Slot。"),int32(Limit))))];
            const TSharedPtr<FJsonObject>* RoleLimits=nullptr;
            if(Constraints && (*Constraints)->TryGetObjectField(TEXT("max_candidates_by_role"),RoleLimits))for(const auto& Pair:(*RoleLimits)->Values)
                Structured->AddSlot().Padding(4)[SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("单独数量要求：%s 最多 %d 段"),*Pair.Key,int32(Pair.Value->AsNumber()))))];
            if((*SelectionInfo)->TryGetObjectField(TEXT("hybrid_selection"),Hybrid))
            {
                const TArray<TSharedPtr<FJsonValue>>* Evidence=nullptr;FString Review;int32 Count=0;
                if((*Hybrid)->TryGetArrayField(TEXT("evidence"),Evidence)) for(const auto& V:*Evidence)
                {
                    FString Reason,Path;if(V->AsObject()->TryGetStringField(TEXT("review_reason"),Reason) && V->AsObject()->TryGetStringField(TEXT("id"),Path))
                    {++Count;if(Count<=80) Review+=Path+TEXT("\n  ")+Reason+TEXT("\n");}
                }
                if(Count>80)Review+=TEXT("其余项目见高级 JSON 中的完整 evidence。\n");
                if(Count)Structured->AddSlot().Padding(4)[SNew(SExpandableArea).InitiallyCollapsed(true).HeaderContent()[SNew(STextBlock).Text(FText::FromString(FString::Printf(TEXT("未绑定 / 待人工检查：%d 项"),Count)))].BodyContent()[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(Review))]];
            }
        }
        const TArray<TSharedPtr<FJsonValue>>* Issues=nullptr;
        if (Draft->TryGetArrayField(TEXT("issues"),Issues)) for (const auto& V:*Issues) { FString Message,Severity; if (V->AsObject() && V->AsObject()->TryGetStringField(TEXT("message"),Message)) { V->AsObject()->TryGetStringField(TEXT("severity"),Severity); Structured->AddSlot().Padding(4)[SNew(STextBlock).AutoWrapText(true).ColorAndOpacity(Severity==TEXT("error") ? FLinearColor(1,.3,.2) : FLinearColor(1,.8,.3)).Text(FText::FromString(Severity+TEXT(": ")+Message))]; } }
        const TSharedPtr<FJsonObject>* Flow=nullptr;
        if (Draft->TryGetObjectField(TEXT("runtime_flow"),Flow))
        {
            FString Summary=TEXT("原生动作配置流（生成器规划，选择器绑定）\n");
            const TSharedPtr<FJsonObject>* Fields=nullptr;
            if ((*Flow)->TryGetObjectField(TEXT("actions"),Fields))
                for (const auto& Pair:(*Fields)->Values) { FString Path; if (Pair.Value->TryGetString(Path)) Summary+=FString(Pair.Key.ToView())+TEXT(" → ")+Path+TEXT("\n"); }
            if ((*Flow)->TryGetObjectField(TEXT("policy"),Fields))
            {
                if ((*Fields)->HasField(TEXT("attack_exit"))) Summary+=TEXT("攻击完整播放后才允许普通切换\n");
                if ((*Fields)->HasField(TEXT("hit_interrupts"))) Summary+=TEXT("受击优先打断当前蒙太奇\n");
                FString After; if ((*Fields)->TryGetStringField(TEXT("after_hit"),After)) Summary+=After==TEXT("previous") ? TEXT("受击后从原位置续播被打断动作\n") : TEXT("受击后返回 Motion Matching\n");
                if ((*Fields)->HasField(TEXT("sprint_aim"))) Summary+=TEXT("冲刺期间禁止瞄准\n");
            }
            if ((*Flow)->TryGetObjectField(TEXT("filters"),Fields) && !(*Fields)->Values.IsEmpty()) Summary+=TEXT("资源变体过滤已在选配阶段生效；不自动模拟装备/受伤状态。\n");
            Structured->AddSlot().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(Summary))];
            if((*Flow)->TryGetObjectField(TEXT("actions"),Fields)) for(const auto& Pair:(*Fields)->Values)
            {
                const FString Role(Pair.Key.ToView()); const auto Actions=*Fields;
                Structured->AddSlot().Padding(4)[SNew(SVerticalBox)
                    +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(FText::FromString(FString(Role==TEXT("hit") ? TEXT("受击") : Role==TEXT("jump") ? TEXT("跳跃") : Role==TEXT("dodge") ? TEXT("闪避翻滚") : TEXT("攻击"))+TEXT("：选择同骨架的非循环动画；没有对应资源时需添加资源并重新生成。")))]
                    +SVerticalBox::Slot().AutoHeight()[SNew(SObjectPropertyEntryBox).AllowedClass(UAnimSequence::StaticClass()).IsEnabled_Lambda([this](){return Pending.IsEmpty();})
                        .ObjectPath_Lambda([Actions,Role](){FString Path; Actions->TryGetStringField(Role,Path); return Path;})
                        .OnShouldFilterAsset_Lambda([this](const FAssetData& A){return FilterBinding(A,true);})
                        .OnObjectChanged_Lambda([this,Actions,Role](const FAssetData& A){if(FilterBinding(A,true)) return; const FString Path=A.GetSoftObjectPath().ToString(); Actions->SetStringField(Role,Path); UpdateBinding(Role,Path,true);})]];
                const TSharedPtr<FJsonObject>* Candidates=nullptr; if((*Flow)->TryGetObjectField(TEXT("action_candidates"),Candidates)) CandidateRows(Role,true,*Candidates,Role);
            }
        }
        for (const auto& V:*States) {
            auto State=V->AsObject(); const FString Id=State->GetStringField(TEXT("id")); FString Condition;
            for (const auto& Pair:State->GetObjectField(TEXT("when"))->Values) { double Number; if (Pair.Value->TryGetNumber(Number)) Condition+=FString(Pair.Key.ToView())+TEXT("=")+FString::SanitizeFloat(Number)+TEXT("  "); }
            Structured->AddSlot().Padding(4)[SNew(SVerticalBox)
                +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(FText::FromString(Id+TEXT("  |  ")+Condition))]
                +SVerticalBox::Slot().AutoHeight()[SNew(SObjectPropertyEntryBox).AllowedClass(UObject::StaticClass())
                    .ObjectPath_Lambda([State]() { FString Path; State->TryGetStringField(TEXT("resource"),Path); return Path; })
                    .IsEnabled_Lambda([this](){return Pending.IsEmpty();})
                    .OnShouldFilterAsset_Lambda([this,Id](const FAssetData& Asset) { return FilterBinding(Asset,false,Id); })
                    .OnObjectChanged_Lambda([this,State,Id](const FAssetData& Asset) {
                        if (FilterBinding(Asset,false,Id)) return;
                        State->SetStringField(TEXT("resource"),Asset.GetSoftObjectPath().ToString());
                        const TArray<TSharedPtr<FJsonValue>>* Current=nullptr; if (Draft->TryGetArrayField(TEXT("issues"),Current)) {
                            TArray<TSharedPtr<FJsonValue>> Kept; for (const auto& I:*Current) { FString Role; if (!I->AsObject() || !I->AsObject()->TryGetStringField(TEXT("role"),Role) || Role!=Id) Kept.Add(I); } Draft->SetArrayField(TEXT("issues"),Kept);
                        }
                        UpdateBinding(Id,Asset.GetSoftObjectPath().ToString(),false);
                    })]];
            CandidateRows(Id,false,State,TEXT("resources"));
        }
        for (const auto& V:*Edges) {
            auto Edge=V->AsObject();
            Structured->AddSlot().Padding(4)[SNew(SHorizontalBox)
                +SHorizontalBox::Slot().FillWidth(1)[SNew(STextBlock).Text(FText::FromString(Edge->GetStringField(TEXT("from"))+TEXT(" → ")+Edge->GetStringField(TEXT("to"))+TEXT("  混合秒数")))]
                +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[SNew(SSpinBox<float>).MinValue(0).MaxValue(2).Value_Lambda([Edge](){ return float(Edge->GetNumberField(TEXT("blend_seconds"))); }).OnValueChanged_Lambda([this,Edge](float Value){ Edge->SetNumberField(TEXT("blend_seconds"),Value); CommitStructured(); })]]];
        }
        auto P=*Parameters;
        Structured->AddSlot().Padding(4)[SNew(SHorizontalBox)
            +SHorizontalBox::Slot().AutoWidth()[SNew(STextBlock).Text(FText::FromString(TEXT("网格 Yaw  ")))]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[SNew(SSpinBox<float>).MinValue(-360).MaxValue(360).Value(float(Yaw)).OnValueChanged_Lambda([this,P](float Value){ P->SetNumberField(TEXT("mesh_yaw"),Value); CommitStructured(); })]]
            +SHorizontalBox::Slot().AutoWidth()[SNew(STextBlock).Text(FText::FromString(TEXT("  固定播放倍率  ")))]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[SNew(SSpinBox<float>).MinValue(.1f).MaxValue(3).Value(float(Rate)).OnValueChanged_Lambda([this,P](float Value){ P->SetNumberField(TEXT("play_rate"),Value); CommitStructured(); })]]];
        // Persist newly created review gates even before the first user edit.
        CommitStructured();
    }
    FReply ScanSelection(bool AllowMissing=false)
    {
        if (!Idle()) return FReply::Handled();
        TArray<FString> Paths; if(!MeshPath.IsEmpty()) Paths.Add(MeshPath);
        for(const FString& Path:AnimationPaths) if(!Path.IsEmpty()) {FAssetData A(LoadObject<UObject>(nullptr,*Path)); if(!(AllowMissing && MeshPath.IsEmpty()) && FilterAnimation(A)){Say(TEXT("候选动画与网格骨架不匹配，请重新选择。"));return FReply::Handled();} Paths.AddUnique(Path);}
        if(!AllowMissing && (MeshPath.IsEmpty() || Paths.Num()<2)) {HasCatalog=false; Say(TEXT("请先指定一个骨骼网格和至少一个兼容动画。"));return FReply::Handled();} FString Error;
        const auto Catalog=Scan(Paths,Error); if (!Catalog || (!AllowMissing && Paths.IsEmpty())) { Say(TEXT("请选择资源。")+Error); return FReply::Handled(); }
        FString Text; FJsonSerializer::Serialize(Catalog.ToSharedRef(),TJsonWriterFactory<>::Create(&Text)); FFileHelper::SaveStringToFile(Text,*File(TEXT("catalog.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        if (bUseModel)
        {
            Say(TEXT("正在稀疏采样候选动画，供名称与姿态混合选择使用……"));
            const FString Repo=Workspace();
            const FString SampleScript=BackendDirectory()/TEXT("extract_motion_samples.py");
            const FString SampleFile=File(TEXT("catalog_motion.json"));
            FPlatformMisc::SetEnvironmentVar(TEXT("GASP_REPO"),*Repo);
            FPlatformMisc::SetEnvironmentVar(TEXT("GASP_MOTION_CATALOG"),*File(TEXT("catalog.json")));
            FPlatformMisc::SetEnvironmentVar(TEXT("GASP_MOTION_OUTPUT"),*SampleFile);
            FPlatformMisc::SetEnvironmentVar(TEXT("GASP_MOTION_WINDOWED"),TEXT("1"));
            FPlatformMisc::SetEnvironmentVar(TEXT("GASP_MOTION_LIMIT"),TEXT("0"));
            FString Normal=SampleScript; Normal.ReplaceInline(TEXT("\\"),TEXT("/")); Normal.ReplaceInline(TEXT("'"),TEXT("\\'"));
            auto Environment=MakeShared<FJsonObject>();
            Environment->SetStringField(TEXT("GASP_REPO"),Repo);Environment->SetStringField(TEXT("GASP_MOTION_CATALOG"),File(TEXT("catalog.json")));Environment->SetStringField(TEXT("GASP_MOTION_OUTPUT"),SampleFile);Environment->SetStringField(TEXT("GASP_MOTION_WINDOWED"),TEXT("1"));Environment->SetStringField(TEXT("GASP_MOTION_LIMIT"),TEXT("0"));
            FString EnvText; FJsonSerializer::Serialize(Environment,TJsonWriterFactory<>::Create(&EnvText));
            FString EnvFile=File(TEXT("sampling_env.json"));FFileHelper::SaveStringToFile(EnvText,*EnvFile,FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);EnvFile.ReplaceInline(TEXT("\\"),TEXT("/"));EnvFile.ReplaceInline(TEXT("'"),TEXT("\\'"));
            const FString Command=FString::Printf(TEXT("import os,json; os.environ.update(json.load(open('%s',encoding='utf-8'))); exec(compile(open('%s', encoding='utf-8').read(), '%s', 'exec'), {'__file__':'%s','__name__':'__main__'})"),*EnvFile,*Normal,*Normal,*Normal);
            if (!IPythonScriptPlugin::Get()->ExecPythonCommand(*Command) || !FFileHelper::LoadFileToString(Text,*SampleFile)) {HasCatalog=false;Say(TEXT("姿态采样失败，请检查输出日志后重试。"));return FReply::Handled();}
            FFileHelper::SaveStringToFile(Text,*File(TEXT("catalog.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
            FJsonSerializer::Serialize(Catalog.ToSharedRef(),TJsonWriterFactory<>::Create(&Text)); // Keep large numeric samples out of the text widget.
        }
        AllowedResources.Reset(); for (const auto& V:Catalog->GetArrayField(TEXT("assets"))) { const auto R=V->AsObject(); if (R->GetStringField(TEXT("kind"))==TEXT("sequence") || R->GetStringField(TEXT("kind"))==TEXT("database") || R->GetStringField(TEXT("kind"))==TEXT("montage")) AllowedResources.Add(R->GetStringField(TEXT("id"))); }
        CatalogView->SetText(FText::FromString(Text)); Structured->ClearChildren(); Draft.Reset(); HasCatalog=true; Preview->SetText(FText::GetEmpty());
        Say(FString::Printf(TEXT("已扫描 %d 个选中资源。只匹配这份清单，不搜索或编造其他路径。"),Paths.Num())); return FReply::Handled();
    }
    FReply CreateManualLeaf()
    {
        if(!Idle() || !bManualLeafConfirmed || !bManualLeafGround)return FReply::Handled();
        const FString Name=ManualLeafName->GetText().ToString();
        bool Valid=!Name.IsEmpty() && Name.Len()<=64;
        for(int32 I=0;I<Name.Len();++I){const TCHAR C=Name[I];Valid &= (C>=TCHAR('a') && C<=TCHAR('z')) || (C>=TCHAR('A') && C<=TCHAR('Z')) || C==TCHAR('_') || (I>0 && C>=TCHAR('0') && C<=TCHAR('9'));}
        if(!Valid){Say(TEXT("状态名须以英文或下划线开头，仅含英文、数字、下划线，最多64字符。"));return FReply::Handled();}
        if(Draft)SaveDraft();
        const bool UseModel=bUseModel;bUseModel=false;ScanSelection(true);bUseModel=UseModel;
        if(!HasCatalog)return FReply::Handled();
        auto Form=MakeShared<FJsonObject>();Form->SetStringField(TEXT("state_name"),Name);Form->SetStringField(TEXT("selection"),TEXT("native_ground"));Form->SetBoolField(TEXT("confirmed"),true);
        FString Text;FJsonSerializer::Serialize(Form,TJsonWriterFactory<>::Create(&Text));
        FFileHelper::SaveStringToFile(Text,*File(TEXT("manual_leaf_form.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        Launch(TEXT("create-leaf"));return FReply::Handled();
    }
    FReply ImportManualRequirements()
    {
        if(!Idle()) return FReply::Handled();
        TSharedPtr<FJsonObject> IR;
        if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(ManualIR->GetText().ToString()),IR) || !IR || (!IR->HasField(TEXT("topology")) && !IR->HasField(TEXT("protocol"))))
        {Say(TEXT("请输入完整需求IR对象；未导入，也未修改旧草案。"));return FReply::Handled();}
        // Preserve the current in-memory draft before scanning clears the view.
        if(Draft) SaveDraft();
        const bool UseModel=bUseModel;bUseModel=false;ScanSelection();bUseModel=UseModel;
        if(!HasCatalog)return FReply::Handled();
        FFileHelper::SaveStringToFile(ManualIR->GetText().ToString(),*File(TEXT("manual_ir.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        FFileHelper::SaveStringToFile(Request->GetText().ToString(),*File(TEXT("request.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
        Launch(TEXT("review-draft"));return FReply::Handled();
    }
    FReply Generate() { if (!Idle()) return FReply::Handled(); FString Error; if(!CheckBlueprint(BlueprintPath,Error)){Say(Error);return FReply::Handled();} ScanSelection(); if(!HasCatalog)return FReply::Handled(); FFileHelper::SaveStringToFile(Request->GetText().ToString(),*File(TEXT("request.txt")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM); Launch(TEXT("generate")); return FReply::Handled(); }
    FReply Validate() { if (!Idle() || !HasUsableDraft()) return FReply::Handled(); SaveDraft(); Launch(TEXT("validate")); return FReply::Handled(); }
    FReply CompileRequirements() { if (!Idle() || !HasUsableDraft()) return FReply::Handled(); SaveDraft(); Launch(TEXT("compile-behavior")); return FReply::Handled(); }
    FReply SaveReviewedDraft()
    {
        if(!Idle() || !HasUsableDraft())return FReply::Handled();
        const TSharedPtr<FJsonObject>* UnifiedInfo=nullptr;const TSharedPtr<FJsonObject>* UnifiedReview=nullptr;
        if(Draft->TryGetObjectField(TEXT("model_info"),UnifiedInfo) && (*UnifiedInfo)->TryGetObjectField(TEXT("unified_review"),UnifiedReview))
        {bool Dirty=false;(*UnifiedReview)->TryGetBoolField(TEXT("uncommitted"),Dirty);if(Dirty){Say(TEXT("统一需求IR尚有未提交修改，请先提交再保存。"));return FReply::Handled();}}
        const TSharedPtr<FJsonObject>* Info=nullptr;const TSharedPtr<FJsonObject>* Review=nullptr;const TSharedPtr<FJsonObject>* Fields=nullptr;
        if(Draft && Draft->TryGetObjectField(TEXT("model_info"),Info) && (*Info)->TryGetObjectField(TEXT("behavior_human_review"),Review))
        {
            bool Dirty=false;(*Review)->TryGetBoolField(TEXT("ir_edit_uncommitted"),Dirty);
            if((*Review)->TryGetObjectField(TEXT("fields"),Fields))for(const auto& Pair:(*Fields)->Values)
            {bool FieldDirty=false;if(Pair.Value->Type==EJson::Object)Pair.Value->AsObject()->TryGetBoolField(TEXT("uncommitted"),FieldDirty);Dirty|=FieldDirty;}
            if(Dirty){Say(TEXT("尚有未提交修改，未保存旧值；请先提交并重新确认。"));return FReply::Handled();}
        }
        const FString Path=File(TEXT("reviewed_draft.json"));
        if(FPaths::FileExists(Path))IFileManager::Get().Copy(*(Path+TEXT(".before_save_")+FGuid::NewGuid().ToString(EGuidFormats::Digits)+TEXT(".json")),*Path);
        if(FFileHelper::SaveStringToFile(Preview->GetText().ToString(),*Path,FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM))
            Say(TEXT("审阅草案已保存；确认随文件保存，内容变化后必须重新确认。\n文件：")+Path);
        else Say(TEXT("审阅草案保存失败。"));
        return FReply::Handled();
    }
    FReply ReopenReviewedDraft()
    {
        if(!Idle())return FReply::Handled();FString Text;
        if(!FFileHelper::LoadFileToString(Text,*File(TEXT("reviewed_draft.json")))){Say(TEXT("本会话没有已保存的审阅草案。"));return FReply::Handled();}
        Preview->SetText(FText::FromString(Text));Rebuild();
        Say(TEXT("已重开本会话审阅草案；保留文件中的确认记录，应用前仍检查内容、确认与编译是否一致。"));
        return FReply::Handled();
    }
    FReply ApplyDraft() { if (!HasCatalog || !Idle() || !HasUsableDraft()) return FReply::Handled(); SaveDraft();
        // Explicit acceptance mode exercises the identical Python application gate,
        // but cannot enter any asset creation or Blueprint binding code.
        if(FParse::Param(FCommandLine::Get(),TEXT("GaspReviewAcceptance"))){Launch(TEXT("validate"));return FReply::Handled();}
        FString Message; ApplyToBlueprint(File(TEXT("catalog.json")),File(TEXT("plan.json")),BlueprintPath,Message); Say(Message); return FReply::Handled(); }
    FReply ApplyAndExportAnimBlueprint()
    {
        if(!HasCatalog || !Idle() || !HasUsableDraft())return FReply::Handled();
        SaveDraft();
        // Acceptance mode remains read-only and exercises the same draft validation gate.
        if(FParse::Param(FCommandLine::Get(),TEXT("GaspReviewAcceptance"))){Launch(TEXT("validate"));return FReply::Handled();}
        FString Message;
        ApplyToBlueprint(File(TEXT("catalog.json")),File(TEXT("plan.json")),BlueprintPath,Message,true,AnimBlueprintDirectory->GetText().ToString(),AnimBlueprintName->GetText().ToString());
        Say(Message);
        return FReply::Handled();
    }
    FReply Record() { if (!Idle() || !HasUsableDraft()) return FReply::Handled(); SaveDraft(); Launch(TEXT("record")); return FReply::Handled(); }
};
void Register()
{
    FGlobalTabmanager::Get()->RegisterNomadTabSpawner(TabName,FOnSpawnTab::CreateLambda([](const FSpawnTabArgs&) { return SNew(SDockTab).TabRole(ETabRole::NomadTab)[SNew(SConfigurator)]; })).SetDisplayName(FText::FromString(TEXT("GASP 动画配置工具")));
    StartupHandle=UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateLambda([]() {
        if (FParse::Param(FCommandLine::Get(),TEXT("GaspConfigToolPreview"))) {
            FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([](float) {
                auto Window=SNew(SWindow).Title(FText::FromString(TEXT("GASP 动画配置工具"))).ClientSize(FVector2D(1400,900))[SNew(SConfigurator)];
                FSlateApplication::Get().AddWindow(Window);
                float PreviewSeconds=FParse::Param(FCommandLine::Get(),TEXT("GaspConfigBatchPreview")) ? 12.f : 3.f;
                if(FParse::Param(FCommandLine::Get(),TEXT("GaspReviewAcceptance")))
                {
                    PreviewSeconds=1800.f;
                    FParse::Value(FCommandLine::Get(),TEXT("ConfigToolPreviewSeconds="),PreviewSeconds);
                    PreviewSeconds=FMath::Clamp(PreviewSeconds,10.f,1800.f);
                }
                FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([Window](float) {
                    TArray<FColor> Pixels; FIntVector Size; bool Saved=false;
                    const bool Batch=FParse::Param(FCommandLine::Get(),TEXT("GaspConfigBatchPreview"));
                    const TSharedPtr<SWindow> CaptureWindow=Batch ? FSlateApplication::Get().GetActiveTopLevelWindow() : Window;
                    if (CaptureWindow && FSlateApplication::Get().TakeScreenshot(CaptureWindow.ToSharedRef(),Pixels,Size)) { TArray<uint8> PNG; FImageUtils::CompressImageArray(Size.X,Size.Y,Pixels,PNG); Saved=FFileHelper::SaveArrayToFile(PNG,*(FPaths::ProjectSavedDir()/(Batch ? TEXT("AnimationConfigurator/BatchPickerPreview.png") : TEXT("AnimationConfigurator/ToolPreview.png")))); }
                    FPlatformMisc::RequestExitWithStatus(false,Saved ? 0 : 1); return false;
                }),PreviewSeconds); return false;
            }),2.f);
        }
        if (FParse::Param(FCommandLine::Get(),TEXT("OpenGaspConfigTool"))) FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda([](float) { FGlobalTabmanager::Get()->TryInvokeTab(TabName); return false; }),1.f);
        FToolMenuOwnerScoped Owner(TEXT("GaspConfigTool")); auto* Menu=UToolMenus::Get()->ExtendMenu(TEXT("LevelEditor.MainMenu.Tools"));
        Menu->AddSection(TEXT("GaspConfig"),FText::FromString(TEXT("GASP"))).AddMenuEntry(TEXT("OpenGaspConfig"),FText::FromString(TEXT("动画配置工具")),FText::FromString(TEXT("扫描选中资源，生成并预览原生动画配置")),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([](){ FGlobalTabmanager::Get()->TryInvokeTab(TabName); })));
    }));
}
void Unregister() { UToolMenus::UnRegisterStartupCallback(StartupHandle); UToolMenus::UnregisterOwner(TEXT("GaspConfigTool")); FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(TabName); }
}


