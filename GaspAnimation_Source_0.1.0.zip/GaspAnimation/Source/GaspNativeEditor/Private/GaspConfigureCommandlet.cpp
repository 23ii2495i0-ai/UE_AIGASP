#include "GaspConfigureCommandlet.h"
#include "GaspConfigTool.h"
#include "GaspAnimationSet.h"
#include "GaspChooser.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "Serialization/JsonReader.h"
#include "Misc/Parse.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "Animation/AnimBlueprint.h"
#include "AnimStateNode.h"
#include "AnimStateTransitionNode.h"
#include "AnimGraphNode_StateMachine.h"
#include "GaspNativeAnimInstance.h"
#include "UObject/UnrealType.h"
#include "EdGraph/EdGraph.h"
#include "Engine/SkeletalMesh.h"
int32 UGaspConfigureCommandlet::Main(const FString& Params)
{
    FString Action,Catalog,Plan,Selection; FParse::Value(*Params,TEXT("Action="),Action); FParse::Value(*Params,TEXT("Catalog="),Catalog);
    FParse::Value(*Params,TEXT("Plan="),Plan); FParse::Value(*Params,TEXT("Selection="),Selection);
    if(Action==TEXT("RefreshLinkedAnimationInputs"))
    {
        FString Blueprint,Message;FParse::Value(*Params,TEXT("AnimationBlueprint="),Blueprint);
        const bool Passed=GaspConfigTool::RefreshLinkedAnimationInputs(Blueprint,Message);
        UE_LOG(LogTemp,Display,TEXT("PUBLIC_MM_HOST_INPUTS %s: %s"),Passed ? TEXT("PASS"):TEXT("FAIL"),*Message);return Passed ? 0:18;
    }
    if(Action==TEXT("MapAnimationGroups"))
    {
        FString Blueprint;FParse::Value(*Params,TEXT("AnimationBlueprint="),Blueprint);
        if(Blueprint.IsEmpty() && !Plan.IsEmpty())
        {
            FString Text;TSharedPtr<FJsonObject> Manifest;
            if(FFileHelper::LoadFileToString(Text,*(Plan+TEXT(".applied.json"))) && FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),Manifest))Manifest->TryGetStringField(TEXT("animation_blueprint"),Blueprint);
        }
        FString Message;const bool Passed=!Blueprint.IsEmpty() && GaspConfigTool::MapAnimationGroups(Blueprint,Message);
        UE_LOG(LogTemp,Display,TEXT("MM_GROUPS_MAP %s: %s"),Passed ? TEXT("PASS"):TEXT("FAIL"),*Message);return Passed ? 0:17;
    }
    if(Action==TEXT("VerifyTemplate") && !Plan.IsEmpty())
    {
        FString Text;TSharedPtr<FJsonObject> Manifest,Definition;
        if(!FFileHelper::LoadFileToString(Text,*(Plan+TEXT(".applied.json"))) || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),Manifest))return 13;
        auto* Template=LoadObject<UAnimBlueprint>(nullptr,*Manifest->GetStringField(TEXT("animation_blueprint_template")));
        auto* Child=LoadObject<UAnimBlueprint>(nullptr,*Manifest->GetStringField(TEXT("animation_blueprint")));
        if(!Template || !Child || !Template->GeneratedClass || !Child->GeneratedClass)return 14;
        auto* Defaults=Cast<UGaspNativeAnimInstance>(Child->GeneratedClass->GetDefaultObject());
        if(!Defaults || !Defaults->AnimationSet || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Defaults->AnimationSet->BehaviorGraphJson),Definition))return 15;
        auto Report=MakeShared<FJsonObject>();TArray<TSharedPtr<FJsonValue>> StateNames,MachineNames,VariableNames;
        TSet<FString> SeenStates;int32 Transitions=0,RuleVariables=0;bool Passed=Template->bIsTemplate && !Template->TargetSkeleton && Child->ParentClass==Template->GeneratedClass;
        TArray<UEdGraph*> Graphs;Template->GetAllGraphs(Graphs);
        TSet<UEdGraphNode*> SeenNodes;
        for(UEdGraph* Graph:Graphs)for(UEdGraphNode* Node:Graph->Nodes)
        {
            if(SeenNodes.Contains(Node))continue;SeenNodes.Add(Node);
            if(auto* State=Cast<UAnimStateNode>(Node)){SeenStates.Add(State->GetStateName());StateNames.Add(MakeShared<FJsonValueString>(State->GetStateName()));}
            if(auto* Machine=Cast<UAnimGraphNode_StateMachine>(Node))MachineNames.Add(MakeShared<FJsonValueString>(Machine->GetStateMachineName()));
            if(auto* Transition=Cast<UAnimStateTransitionNode>(Node)){++Transitions;Passed &= Transition->BoundGraph!=nullptr && Transition->GetPreviousState()!=nullptr && Transition->GetNextState()!=nullptr;}
        }
        for(const auto& State:Definition->GetArrayField(TEXT("states")))Passed &= SeenStates.Contains(State->AsObject()->GetStringField(TEXT("id")));
        const int32 EdgeCount=Definition->GetArrayField(TEXT("transitions")).Num();
        for(int32 Index=0;Index<EdgeCount;++Index)
        {
            const FName Name(*FString::Printf(TEXT("SemanticTransition_%03d"),Index));
            const auto* Property=FindFProperty<FBoolProperty>(Template->GeneratedClass,Name);
            bool Declared=false;for(const auto& Variable:Template->NewVariables)if(Variable.VarName==Name)Declared=true;
            if(Property && Declared)++RuleVariables;else Passed=false;
        }
        for(const auto& Variable:Template->NewVariables)VariableNames.Add(MakeShared<FJsonValueString>(Variable.VarName.ToString()));
        Passed &= Transitions>=EdgeCount && MachineNames.Num()>=1;
        FString GroupError;
        const bool bGroupsValid=Defaults->ValidateMotionMatchingAnimationGroups(Defaults->AnimationSet->Mesh.LoadSynchronous(),GroupError);
        const auto* TemplateDefaults=Cast<UGaspNativeAnimInstance>(Template->GeneratedClass->GetDefaultObject());
        Passed &= bGroupsValid && TemplateDefaults;
        TArray<TSharedPtr<FJsonValue>> Groups,PublicVariables;
        for(const auto& Pair:Defaults->MotionMatchingAnimationGroups)
        {
            auto Group=MakeShared<FJsonObject>();Group->SetStringField(TEXT("name"),Pair.Key.ToString());
            TArray<TSharedPtr<FJsonValue>> Databases,States;
            TArray<UPoseSearchDatabase*> Effective;Defaults->GetMotionMatchingAnimationGroup(Pair.Key,Effective);
            for(const auto* DB:Effective)Databases.Add(MakeShared<FJsonValueString>(DB ? DB->GetPathName():TEXT("null")));
            for(FName State:Pair.Value.SemanticStates)States.Add(MakeShared<FJsonValueString>(State.ToString()));
            Group->SetArrayField(TEXT("databases"),Databases);Group->SetArrayField(TEXT("states"),States);Groups.Add(MakeShared<FJsonValueObject>(Group));
            if(!Pair.Value.PublicVariableName.IsNone())
            {
                const auto* Property=FindFProperty<FArrayProperty>(Template->GeneratedClass,Pair.Value.PublicVariableName);
                const auto* Inner=Property ? CastField<FObjectPropertyBase>(Property->Inner):nullptr;
                const bool Public=Property && Property->GetOwnerClass()==Template->GeneratedClass && Property->HasAllPropertyFlags(CPF_Edit|CPF_BlueprintVisible) && !Property->HasAnyPropertyFlags(CPF_BlueprintReadOnly) && Inner && Inner->PropertyClass==UPoseSearchDatabase::StaticClass();
                Passed &= Public;
                auto Entry=MakeShared<FJsonObject>();Entry->SetStringField(TEXT("name"),Pair.Value.PublicVariableName.ToString());Entry->SetBoolField(TEXT("public_editable_on_template"),Public);Entry->SetStringField(TEXT("owner"),Property ? Property->GetOwnerClass()->GetPathName():TEXT("missing"));PublicVariables.Add(MakeShared<FJsonValueObject>(Entry));
            }
        }
        for(const auto& Value:Definition->GetArrayField(TEXT("states")))
        {
            const auto State=Value->AsObject();FString Player,Id,Role;
            State->TryGetStringField(TEXT("player"),Player);State->TryGetStringField(TEXT("id"),Id);State->TryGetStringField(TEXT("database_role"),Role);
            if(Player==TEXT("mm"))Passed &= Defaults->MotionMatchingAnimationGroups.Contains(FName(*(Role.IsEmpty() ? Id:Role)));
        }
        Report->SetArrayField(TEXT("motion_matching_animation_groups"),Groups);Report->SetBoolField(TEXT("motion_matching_groups_valid"),bGroupsValid);Report->SetStringField(TEXT("motion_matching_groups_error"),GroupError);
        if(FParse::Param(*Params,TEXT("RequirePublicGroups")))Passed &= PublicVariables.Num()==Groups.Num() && !PublicVariables.IsEmpty();
        Report->SetArrayField(TEXT("public_animation_variables"),PublicVariables);
        Report->SetStringField(TEXT("template"),Template->GetPathName());Report->SetBoolField(TEXT("passed"),Passed);
        Report->SetArrayField(TEXT("states"),StateNames);Report->SetArrayField(TEXT("state_machines"),MachineNames);Report->SetArrayField(TEXT("template_variables"),VariableNames);
        Report->SetNumberField(TEXT("transitions"),Transitions);Report->SetNumberField(TEXT("transition_variables"),RuleVariables);Report->SetNumberField(TEXT("child_local_variables"),Child->NewVariables.Num());
        FJsonSerializer::Serialize(Report,TJsonWriterFactory<>::Create(&Text));FFileHelper::SaveStringToFile(Text,*(Plan+TEXT(".template_verification.json")));
        UE_LOG(LogTemp,Display,TEXT("SEMANTIC_TEMPLATE_VERIFY %s states=%d machines=%d transitions=%d rule_variables=%d child_local_variables=%d"),Passed ? TEXT("PASS"):TEXT("FAIL"),SeenStates.Num(),MachineNames.Num(),Transitions,RuleVariables,Child->NewVariables.Num());
        return Passed ? 0:16;
    }
    if (Action==TEXT("Scan") && !Catalog.IsEmpty()) {
        TArray<FString> Paths; Selection.ParseIntoArray(Paths,TEXT("+"),true); FString Error;
        if (Paths.IsEmpty()) return 2; const auto Data=GaspConfigTool::Scan(Paths,Error); if (!Data) { UE_LOG(LogTemp,Error,TEXT("%s"),*Error); return 3; }
        FString Text; FJsonSerializer::Serialize(Data.ToSharedRef(),TJsonWriterFactory<>::Create(&Text));
        IFileManager::Get().MakeDirectory(*FPaths::GetPath(Catalog),true);
        return FFileHelper::SaveStringToFile(Text,*Catalog,FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM) ? 0 : 4;
    }
    if (Action==TEXT("Apply") && !Catalog.IsEmpty() && !Plan.IsEmpty()) {
        FString Blueprint,AnimBlueprintDirectory,AnimBlueprintName; FParse::Value(*Params,TEXT("TargetBlueprint="),Blueprint);
        FParse::Value(*Params,TEXT("AnimBlueprintDirectory="),AnimBlueprintDirectory); FParse::Value(*Params,TEXT("AnimBlueprintName="),AnimBlueprintName);
        const bool bExportAnimBlueprint=FParse::Param(*Params,TEXT("ExportAnimBlueprint"));
        FString Message; const bool Success=Blueprint.IsEmpty() ? GaspConfigTool::Apply(Catalog,Plan,Message) :
            GaspConfigTool::ApplyToBlueprint(Catalog,Plan,Blueprint,Message,bExportAnimBlueprint,AnimBlueprintDirectory,AnimBlueprintName);
        UE_LOG(LogTemp,Display,TEXT("CONFIG_APPLY %s: %s"),Success ? TEXT("PASS") : TEXT("FAIL"),*Message); return Success ? 0 : 5;
    }
    if (Action==TEXT("Verify") && !Plan.IsEmpty()) {
        FString Text; TSharedPtr<FJsonObject> Data;
        if (!FFileHelper::LoadFileToString(Text,*Plan) || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),Data)) return 6;
        auto* Set=LoadObject<UGaspAnimationSet>(nullptr,*(Data->GetStringField(TEXT("destination"))/TEXT("DA_Config.DA_Config")));
        if (!Set) return 7; FGaspChooser Chooser; Chooser.LoadTable(Set->DenseTable);
        int32 Checks=0;
        for (const auto& Value:Data->GetArrayField(TEXT("states"))) {
            auto State=Value->AsObject(); TMap<FString,double> Context={{TEXT("MovementState"),0},{TEXT("Stance"),0},{TEXT("Gait"),0}},Outputs;
            for (const auto& Pair:State->GetObjectField(TEXT("when"))->Values) Context.Add(FString(Pair.Key.ToView()),Pair.Value->AsNumber());
            bool BehaviorOnly=false;State->TryGetBoolField(TEXT("behavior_only"),BehaviorOnly);
            const auto Results=Chooser.Evaluate(Context,Outputs);
            if (!BehaviorOnly && Results.Num()!=1) return 8;
            UPoseSearchDatabase* DB=BehaviorOnly ? Set->ConfiguredLocomotion.FindRef(FName(*State->GetStringField(TEXT("id")))).Get() : Cast<UPoseSearchDatabase>(Results[0].TryLoad());
            UObject* Resource=LoadObject<UObject>(nullptr,*State->GetStringField(TEXT("resource")));
            const TArray<TSharedPtr<FJsonValue>>* Candidates=nullptr; State->TryGetArrayField(TEXT("resources"),Candidates);
            if (!DB) return 9;
            if (DB!=Resource) {
                const int32 Count=Candidates ? Candidates->Num() : 1;
                if (DB->GetNumAnimationAssets()!=Count) return 9;
                for(int32 I=0;I<Count;++I) if(DB->GetAnimationAsset(I)!=LoadObject<UObject>(nullptr,*(Candidates ? (*Candidates)[I]->AsString() : State->GetStringField(TEXT("resource"))))) return 9;
            }
            ++Checks;
        }
        const auto& Edges=Data->GetArrayField(TEXT("transitions")); if (Set->ConfiguredTransitions.Num()!=Edges.Num()) return 10;
        const TSharedPtr<FJsonObject>* Flow=nullptr; const TSharedPtr<FJsonObject>* Candidates=nullptr;
        if (Data->TryGetObjectField(TEXT("runtime_flow"),Flow) && (*Flow)->TryGetObjectField(TEXT("action_candidates"),Candidates)) for(const auto& Pair:(*Candidates)->Values)
        {
            const auto* Saved=Set->ActionCandidates.Find(FName(*Pair.Key)); if(!Saved || Saved->Sequences.Num()!=Pair.Value->AsArray().Num()) return 12;
            for(int32 I=0;I<Saved->Sequences.Num();++I) if(Saved->Sequences[I]->GetPathName()!=Pair.Value->AsArray()[I]->AsString()) return 12;
            ++Checks;
        }
        for (int32 I=0; I<Edges.Num();++I) if (!FMath::IsNearlyEqual(Set->ConfiguredTransitions[I].BlendSeconds,float(Edges[I]->AsObject()->GetNumberField(TEXT("blend_seconds"))))) return 11; else ++Checks;
        UE_LOG(LogTemp,Display,TEXT("CONFIG_VERIFY PASS checks=%d"),Checks); return 0;
    }
    UE_LOG(LogTemp,Error,TEXT("Use -Action=Scan -Catalog=<file> -Selection=<path+path> or -Action=Apply -Catalog=<file> -Plan=<file>")); return 1;
}
