#include "GaspBuildContentCommandlet.h"
#include "GaspNativeAnimInstance.h"
#include "GaspAnimationSet.h"
#include "GaspFoleyMigration.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "GaspChooserMigration.h"
#include "Chooser.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "Serialization/JsonSerializer.h"
#include "GaspNativeCharacter.h"
#include "GaspNativeGameMode.h"
#include "GaspTraversableBlock.h"
#include "GaspTraversalChannels.h"
#include "GaspMontageBlendOutNotifyState.h"
#include "Animation/AnimMontage.h"
#include "Animation/BlendSpace.h"
#include "AnimGraphNode_LinkedAnimGraph.h"
#include "Misc/FileHelper.h"
#include "Internationalization/Regex.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "PoseSearch/PoseSearchFeatureChannel_Group.h"
#include "AnimGraphNode_GaspSampleWarp.h"
#include "AnimGraphNode_Base.h"
#include "AnimGraphNode_Root.h"
#include "AnimationGraph.h"
#include "AnimationGraphSchema.h"
#include "Animation/AnimBlueprint.h"
#include "Animation/AnimBlueprintGeneratedClass.h"
#include "Animation/AnimClassInterface.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "Components/StaticMeshComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "EdGraph/EdGraph.h"
#include "Editor.h"
#include "Engine/DirectionalLight.h"
#include "Engine/SkyLight.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/World.h"
#include "Factories/AnimBlueprintFactory.h"
#include "GameFramework/PlayerStart.h"
#include "K2Node_VariableGet.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Misc/PackageName.h"
#include "HAL/FileManager.h"
#include "Misc/Paths.h"
#include "UObject/SavePackage.h"
#include "UObject/UnrealType.h"

namespace
{
bool SaveAsset(UObject* Asset)
{
    Asset->SetFlags(RF_Public | RF_Standalone);
    UPackage* Package = Asset->GetOutermost();
    const FString Extension = Asset->IsA<UWorld>() ? FPackageName::GetMapPackageExtension() : FPackageName::GetAssetPackageExtension();
    const FString File = FPackageName::LongPackageNameToFilename(Package->GetName(), Extension);
    FSavePackageArgs Args;
    Args.TopLevelFlags = RF_Public | RF_Standalone;
    Args.SaveFlags = SAVE_None;
    IFileManager::Get().MakeDirectory(*FPaths::GetPath(File), true);
    return UPackage::SavePackage(Package, Asset, *File, Args);
}

void ReplaceTraversalChannels(TArray<TObjectPtr<UPoseSearchFeatureChannel>>& Channels)
{
    for (auto& Channel : Channels)
    {
        UClass* Replacement = nullptr;
        if (Channel->GetClass()->GetName() == TEXT("PSC_Traversal_Pos_C")) Replacement = UGaspTraversalPositionChannel::StaticClass();
        if (Channel->GetClass()->GetName() == TEXT("PSC_Traversal_Head_C")) Replacement = UGaspTraversalHeadingChannel::StaticClass();
        if (Replacement)
        {
            auto* Native = NewObject<UPoseSearchFeatureChannel>(Channel->GetOuter(), Replacement);
            // Preserve authored weights, sampled bones, timing, component stripping and filters.
            for (TFieldIterator<FProperty> P(Replacement->GetSuperClass()); P; ++P)
                P->CopyCompleteValue(P->ContainerPtrToValuePtr<void>(Native), P->ContainerPtrToValuePtr<void>(Channel.Get()));
            Channel = Native;
        }
        if (auto* Group = Cast<UPoseSearchFeatureChannel_Group>(Channel)) ReplaceTraversalChannels(Group->SubChannels);
    }
}

UAnimGraphNode_Base* AddNode(UEdGraph* Graph, const TCHAR* ClassPath, const TCHAR* Settings = TEXT("()"))
{
    UClass* Class = LoadClass<UAnimGraphNode_Base>(nullptr, ClassPath);
    checkf(Class, TEXT("Missing anim graph node %s"), ClassPath);
    auto* Node = NewObject<UAnimGraphNode_Base>(Graph, Class, NAME_None, RF_Transactional);
    Graph->AddNode(Node, false, false);
    Node->CreateNewGuid();
    if (auto* Property = FindFProperty<FStructProperty>(Class, TEXT("Node")))
        checkf(Property->ImportText_Direct(Settings, Property->ContainerPtrToValuePtr<void>(Node), Node, PPF_None), TEXT("Invalid node config %s"), Settings);
    Node->PostPlacedNewNode();
    Node->AllocateDefaultPins();
    Node->NodePosX = Graph->Nodes.Num()*240;
    return Node;
}

void Connect(UEdGraphNode* From, UEdGraphNode* To, const TCHAR* Input = nullptr)
{
    UEdGraphPin* Out = nullptr;
    UEdGraphPin* In = nullptr;
    for (auto* Pin : From->Pins) if (Pin->Direction == EGPD_Output && Pin->PinType.PinCategory == TEXT("struct")) { Out = Pin; break; }
    for (auto* Pin : To->Pins)
        if (Pin->Direction == EGPD_Input && (Input ? Pin->PinName == Input : Pin->PinType.PinCategory == TEXT("struct"))) { In = Pin; break; }
    checkf(Out && In && To->GetGraph()->GetSchema()->TryCreateConnection(Out, In), TEXT("Cannot connect %s -> %s (%s)"), *From->GetClass()->GetName(), *To->GetClass()->GetName(), Input ? Input : TEXT("pose"));
}

void Bind(UAnimGraphNode_Base* Node, const TCHAR* PinName, const TCHAR* PropertyName)
{
    for (int32 I = 0; I < Node->ShowPinForProperties.Num(); ++I)
        if (Node->ShowPinForProperties[I].PropertyName == PinName && !Node->ShowPinForProperties[I].bShowPin)
        { Node->SetPinVisibility(true, I); break; }
    Node->ReconstructNode();
    auto* Get = NewObject<UK2Node_VariableGet>(Node->GetGraph());
    Get->VariableReference.SetSelfMember(PropertyName);
    Node->GetGraph()->AddNode(Get, false, false);
    Get->CreateNewGuid();
    Get->AllocateDefaultPins();
    UEdGraphPin* Out = Get->FindPin(PropertyName, EGPD_Output);
    UEdGraphPin* In = Node->FindPin(PinName, EGPD_Input);
    checkf(Out && In && Node->GetGraph()->GetSchema()->TryCreateConnection(Out, In), TEXT("Cannot bind %s.%s to %s"), *Node->GetClass()->GetName(), PinName, PropertyName);
}
}

UGaspBuildContentCommandlet::UGaspBuildContentCommandlet() { IsClient = false; IsEditor = true; IsServer = false; LogToConsole = true; }

int32 UGaspBuildContentCommandlet::Main(const FString& Params)
{
    auto& Registry = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
    Registry.SearchAllAssets(true);
    if (!MigrateGaspFoleyNotifies()) return 28;
    const bool bLegacyGraphs=FParse::Param(FCommandLine::Get(),TEXT("GenerateLegacyGraphs"));
    TArray<FAssetData> Assets;
    Registry.GetAssetsByPath(TEXT("/Game/Characters/UEFN_Mannequin/Animations/Traversal"), Assets, true);
    for (const FAssetData& Asset : Assets)
    {
        if (Asset.AssetClassPath.GetAssetName() != TEXT("AnimMontage")) continue;
        auto* Montage = Cast<UAnimMontage>(Asset.GetAsset());
        bool bChanged = false;
        for (auto& Notify : Montage->Notifies)
        {
            UObject* Old = Notify.NotifyStateClass.Get();
            if (!Old || Old->GetClass()->GetName() != TEXT("BP_NotifyState_MontageBlendOut_C")) continue;
            auto* Native = NewObject<UGaspMontageBlendOutNotifyState>(Montage);
            if (auto* Time = FindFProperty<FFloatProperty>(Old->GetClass(), TEXT("BlendOutTime"))) Native->BlendOutTime = Time->GetPropertyValue_InContainer(Old);
            if (auto* Profile = FindFProperty<FNameProperty>(Old->GetClass(), TEXT("BlendProfile"))) Native->BlendProfile = Profile->GetPropertyValue_InContainer(Old);
            auto* Condition = FindFProperty<FByteProperty>(Old->GetClass(), TEXT("BlendOutCondition"));
            check(Condition && Condition->Enum);
            const FString Display = Condition->Enum->GetDisplayNameTextByValue(Condition->GetPropertyValue_InContainer(Old)).ToString();
            if (Display.Contains(TEXT("Always")) || Display.Contains(TEXT("Force"))) Native->Condition = EGaspBlendOutCondition::Always;
            else if (Display.Contains(TEXT("Input"))) Native->Condition = EGaspBlendOutCondition::WithInput;
            else if (Display.Contains(TEXT("Falling")) || Display.Contains(TEXT("Air"))) Native->Condition = EGaspBlendOutCondition::Falling;
            else { UE_LOG(LogTemp, Error, TEXT("Unknown montage blend-out condition: %s"), *Display); return 9; }
            Notify.NotifyStateClass = Native;
            bChanged = true;
        }
        if (bChanged && !SaveAsset(Montage)) return 10;
    }
    for (const TCHAR* SchemaName : { TEXT("PSS_Traversal"), TEXT("PSS_Traversal_Chooser") })
    {
        const FString Path = FString(TEXT("/Game/Characters/UEFN_Mannequin/Animations/MotionMatchingData/Schemas/")) + SchemaName;
        if (!FPackageName::DoesPackageExist(Path)) continue;
        if (auto* Schema = LoadObject<UPoseSearchSchema>(nullptr, *Path))
        {
            FArrayProperty* Channels = FindFProperty<FArrayProperty>(Schema->GetClass(), TEXT("Channels"));
            check(Channels);
            ReplaceTraversalChannels(*Channels->ContainerPtrToValuePtr<TArray<TObjectPtr<UPoseSearchFeatureChannel>>>(Schema));
            Schema->PostEditChange();
            if (!SaveAsset(Schema)) return 8;
        }
    }
    if (bLegacyGraphs)
    {
    const TCHAR* PackageName = TEXT("/Game/Native/ABPT_GaspCore");
    if (FPackageName::DoesPackageExist(PackageName))
    {
        UE_LOG(LogTemp, Display, TEXT("Reusing existing animation graph; custom edits are preserved."));
    }
    else
    {
    auto* Mesh = LoadObject<USkeletalMesh>(nullptr, TEXT("/Game/Characters/UEFN_Mannequin/Meshes/SKM_UEFN_Mannequin.SKM_UEFN_Mannequin"));
    if (!Mesh) return 2;
    auto* Factory = NewObject<UAnimBlueprintFactory>();
    Factory->ParentClass = UGaspNativeAnimInstance::StaticClass();
    Factory->bTemplate = true;
    UPackage* Package = CreatePackage(PackageName);
    auto* Blueprint = CastChecked<UAnimBlueprint>(Factory->FactoryCreateNew(UAnimBlueprint::StaticClass(), Package,
        TEXT("ABPT_GaspCore"), RF_Public | RF_Standalone, nullptr, GWarn));
    TArray<UEdGraph*> Graphs;
    Blueprint->GetAllGraphs(Graphs);
    UEdGraph* Graph = nullptr;
    for (auto* Candidate : Graphs) if (Candidate->GetFName() == TEXT("AnimGraph")) { Graph = Candidate; break; }
    if (!Graph) return 3;
    UAnimGraphNode_Root* Root = nullptr;
    for (UEdGraphNode* Node : Graph->Nodes) if (auto* Candidate = Cast<UAnimGraphNode_Root>(Node)) { Root = Candidate; break; }
    if (!Root) return 4;
    auto* MM = AddNode(Graph, TEXT("/Script/PoseSearchEditor.AnimGraphNode_MotionMatching"),
        TEXT("(BlendTime=0.2,PlayRate=(Min=0.85,Max=1.15),MaxActiveBlends=4,MaxBlendInTimeToOverrideAnimation=0.03,PlayerDepthBlendInTimeMultiplier=1.1,PoseJumpThresholdTime=(Min=0,Max=0),PoseReselectHistory=0.3,SearchThrottleTime=0)"));
    Bind(MM, TEXT("BlendTime"), TEXT("MotionBlendTime"));
    Bind(MM, TEXT("NotifyRecencyTimeOut"), TEXT("NotifyRecencyTimeOut"));
    // BlendStack owns a separate graph instance for every player.
    const TArray<UEdGraph*> SampleGraphs = MM->GetSubGraphs();
    checkf(SampleGraphs.Num() == 1, TEXT("MotionMatching must expose one BlendStack sample graph"));
    {
            UEdGraph* Sample = SampleGraphs[0];
            UEdGraphNode* SampleInput = nullptr;
            UEdGraphNode* SampleOutput = nullptr;
            for (UEdGraphNode* N : Sample->Nodes)
            {
                if (N->GetClass()->GetName() == TEXT("AnimGraphNode_BlendStackInput")) SampleInput = N;
                if (N->IsA<UAnimGraphNode_Root>()) SampleOutput = N;
            }
            if (SampleInput && SampleOutput)
            {
                SampleOutput->BreakAllNodeLinks();
                auto* Warp = AddNode(Sample, TEXT("/Script/GaspNativeEditor.AnimGraphNode_GaspSampleWarp"));
                Connect(SampleInput, Warp, TEXT("Source"));
                Connect(Warp, SampleOutput, TEXT("Result"));
            }
            else return 5;
    }
    auto* Lean = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_BlendSpacePlayer"));
    Bind(Lean, TEXT("BlendSpace"), TEXT("LeanAsset"));
    Bind(Lean, TEXT("X"), TEXT("LeanAmount"));
    auto* ApplyLean = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_ApplyMeshSpaceAdditive"));
    Connect(MM, ApplyLean, TEXT("Base"));
    Connect(Lean, ApplyLean, TEXT("Additive"));
    Bind(ApplyLean, TEXT("Alpha"), TEXT("LeanAlpha"));
    auto* AO = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_BlendSpacePlayer"));
    Bind(AO, TEXT("BlendSpace"), TEXT("AimAsset"));
    Bind(AO, TEXT("X"), TEXT("AimYaw"));
    Bind(AO, TEXT("Y"), TEXT("AimPitch"));
    auto* ApplyAO = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_ApplyMeshSpaceAdditive"));
    Connect(ApplyLean, ApplyAO, TEXT("Base"));
    Connect(AO, ApplyAO, TEXT("Additive"));
    Bind(ApplyAO, TEXT("Alpha"), TEXT("AimAlpha"));
    auto* Slot = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_Slot"), TEXT("(SlotName=DefaultSlot,bAlwaysUpdateSourcePose=False)"));
    Connect(ApplyAO, Slot, TEXT("Source"));
    auto* Offset = AddNode(Graph, TEXT("/Script/AnimationWarpingEditor.AnimGraphNode_OffsetRootBone"),
        TEXT("(TranslationHalflife=0.2,RotationHalfLife=0.1,MaxTranslationError=30,TranslationMode=Interpolate,RotationMode=Accumulate,bResetOnTeleport=False)"));
    Connect(Slot, Offset, TEXT("Source"));
    Bind(Offset, TEXT("TranslationMode"), TEXT("TranslationMode"));
    Bind(Offset, TEXT("RotationMode"), TEXT("RotationMode"));
    Bind(Offset, TEXT("TranslationHalflife"), TEXT("TranslationHalflife"));
    Bind(Offset, TEXT("bClampToTranslationVelocity"), TEXT("bClampTranslation"));
    auto* ToCS = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_LocalToComponentSpace"));
    Connect(Offset, ToCS, TEXT("LocalPose"));
    auto* Feet = AddNode(Graph, TEXT("/Script/AnimationWarpingEditor.AnimGraphNode_FootPlacement"),
        TEXT("()"));
    Connect(ToCS, Feet, TEXT("ComponentPose"));
    Bind(Feet, TEXT("Alpha"), TEXT("FootPlacementAlpha"));
    auto* Legs = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_LegIK"),
        TEXT("(SoftPercentLength=0.99)"));
    Connect(Feet, Legs, TEXT("ComponentPose"));
    auto* ToLocal = AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_ComponentToLocalSpace"));
    Connect(Legs, ToLocal, TEXT("ComponentPose"));
    auto* History = AddNode(Graph, TEXT("/Script/PoseSearchEditor.AnimGraphNode_PoseSearchHistoryCollector"),
        TEXT("(PoseCount=2,SamplingInterval=0.04,CollectedCurves=(Phase))"));
    History->SetTag(TEXT("PoseHistory"));
    Connect(ToLocal, History, TEXT("Source"));
    Connect(History, Root, TEXT("Result"));
    for (UEdGraph* Sample : MM->GetSubGraphs()) Sample->NotifyGraphChanged();
    Graph->NotifyGraphChanged();
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
    FKismetEditorUtilities::CompileBlueprint(Blueprint);
    int32 CompiledSampleGraphs = 0;
    if (const IAnimClassInterface* AnimClass = IAnimClassInterface::GetFromClass(Blueprint->GeneratedClass))
        for (const FStructProperty* Property : AnimClass->GetAnimNodeProperties())
            if (Property->Struct == FAnimNode_GaspSampleWarp::StaticStruct()) ++CompiledSampleGraphs;
    UE_LOG(LogTemp, Display, TEXT("GASP_COMPILED_SAMPLE_GRAPHS=%d"), CompiledSampleGraphs);
    if (CompiledSampleGraphs != 5) return 11;
    if (Blueprint->Status == BS_Error || !Blueprint->GeneratedClass || !SaveAsset(Blueprint)) return 6;
    FAssetRegistryModule::AssetCreated(Blueprint);
    }
    }
    // Concrete assets contain only character resources; all graph logic is inherited.
    UAnimBlueprint* Template = bLegacyGraphs ? LoadObject<UAnimBlueprint>(nullptr, TEXT("/Game/Native/ABPT_GaspCore.ABPT_GaspCore")) : nullptr;
    auto* Mesh = LoadObject<USkeletalMesh>(nullptr, TEXT("/Game/Characters/UEFN_Mannequin/Meshes/SKM_UEFN_Mannequin.SKM_UEFN_Mannequin"));
    if (!Mesh || (bLegacyGraphs && (!Template || !Template->bIsTemplate || Template->TargetSkeleton))) return 20;
    UGaspAnimationSet* Set = LoadObject<UGaspAnimationSet>(nullptr, TEXT("/Game/Native/DA_Gasp_UEFN.DA_Gasp_UEFN"), nullptr, LOAD_NoWarn);
    if (!Set)
    {
        Set = NewObject<UGaspAnimationSet>(CreatePackage(TEXT("/Game/Native/DA_Gasp_UEFN")), TEXT("DA_Gasp_UEFN"), RF_Public|RF_Standalone);
        Set->Mesh = Mesh;
        Set->Lean = LoadObject<UBlendSpace>(nullptr, TEXT("/Game/Characters/UEFN_Mannequin/Animations/Poses/BS1D_Additive_Lean_Run.BS1D_Additive_Lean_Run"));
        Set->Aim = LoadObject<UBlendSpace>(nullptr, TEXT("/Game/Characters/UEFN_Mannequin/Animations/AimOffset/BS_Neutral_AO_Stand.BS_Neutral_AO_Stand"));
        if (!FFileHelper::LoadFileToString(Set->DenseChooser, *(FPaths::ProjectContentDir()/TEXT("NativeData/chooser_dense.json"))) ||
            !FFileHelper::LoadFileToString(Set->SparseChooser, *(FPaths::ProjectContentDir()/TEXT("NativeData/chooser_sparse.json"))) ||
            !FFileHelper::LoadFileToString(Set->TraversalChooser, *(FPaths::ProjectContentDir()/TEXT("NativeData/chooser_traversal.json")))) return 21;
        const FRegexPattern AssetPattern(TEXT("\"asset\"\\s*:\\s*\"([^\"]+)\""));
        for (const FString* Rules : {&Set->DenseChooser, &Set->SparseChooser, &Set->TraversalChooser})
        {
            FRegexMatcher Match(AssetPattern, *Rules);
            while (Match.FindNext())
            {
                const FSoftObjectPath Path(Match.GetCaptureGroup(1));
                if (Rules == &Set->TraversalChooser) Set->TraversalMontages.AddUnique(TSoftObjectPtr<UAnimMontage>(Path));
                else Set->Databases.AddUnique(TSoftObjectPtr<UPoseSearchDatabase>(Path));
            }
        }
        if (!SaveAsset(Set)) return 22;
        FAssetRegistryModule::AssetCreated(Set);
    }
    UGaspAnimationSet* Alternate = LoadObject<UGaspAnimationSet>(nullptr, TEXT("/Game/Native/DA_Gasp_Alternate.DA_Gasp_Alternate"), nullptr, LOAD_NoWarn);
    if (!Alternate)
    {
        Alternate = DuplicateObject<UGaspAnimationSet>(Set, CreatePackage(TEXT("/Game/Native/DA_Gasp_Alternate")), TEXT("DA_Gasp_Alternate"));
        const FString DBRoot = TEXT("/Game/Characters/UEFN_Mannequin/Animations/MotionMatchingData/Databases/");
        Alternate->DatabaseOverrides.Add(TSoftObjectPtr<UPoseSearchDatabase>(FSoftObjectPath(DBRoot+TEXT("Dense/PSD_Dense_Stand_Idles.PSD_Dense_Stand_Idles"))),
            TSoftObjectPtr<UPoseSearchDatabase>(FSoftObjectPath(DBRoot+TEXT("Dense/PSD_Dense_Crouch_Idles.PSD_Dense_Crouch_Idles"))));
        if (!SaveAsset(Alternate)) return 23;
        FAssetRegistryModule::AssetCreated(Alternate);
    }
    // Upgrade legacy configuration in place without overwriting authored native tables.
    for (UGaspAnimationSet* Profile : {Set, Alternate})
    {
        const bool bNeedsProfileUpgrade=!Profile->DenseTable || !Profile->SparseTable || !Profile->TraversalTable;
        auto Migrate = [&](TObjectPtr<UChooserTable>& Table, const FString& Rules, const TCHAR* Suffix, UClass* ResultClass) -> bool
        {
            if (Table) return true;
            const FString Path=TEXT("/Game/Native/Choosers/CHT_")+Profile->GetName().Replace(TEXT("DA_"), TEXT(""))+Suffix;
            const bool bNewTable=!FPackageName::DoesPackageExist(Path);
            Table=BuildGaspChooserTable(Rules, Path, ResultClass);
            if (!Table || (bNewTable && !ValidateGaspChooserMigration(Rules, Table)) || !SaveAsset(Table)) return false;
            FAssetRegistryModule::AssetCreated(Table);
            return true;
        };
        if (Profile==Alternate)
        {
            if (!Profile->DenseTable && Profile->DenseChooser==Set->DenseChooser) Profile->DenseTable=Set->DenseTable;
            if (!Profile->SparseTable && Profile->SparseChooser==Set->SparseChooser) Profile->SparseTable=Set->SparseTable;
            if (!Profile->TraversalTable && Profile->TraversalChooser==Set->TraversalChooser) Profile->TraversalTable=Set->TraversalTable;
        }
        if (!Migrate(Profile->DenseTable, Profile->DenseChooser, TEXT("_Dense"), UPoseSearchDatabase::StaticClass()) ||
            !Migrate(Profile->SparseTable, Profile->SparseChooser, TEXT("_Sparse"), UPoseSearchDatabase::StaticClass()) ||
            !Migrate(Profile->TraversalTable, Profile->TraversalChooser, TEXT("_Traversal"), UAnimMontage::StaticClass())) return 26;
        TSharedPtr<FJsonObject> Legacy;
        if (bNeedsProfileUpgrade && FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Profile->TraversalChooser), Legacy) && Legacy)
            Profile->bTraversalUsesCMC=Legacy->GetBoolField(TEXT("movement_mode_is_cmc"));
        if (!SaveAsset(Profile)) return 27;
    }
    UE_LOG(LogTemp, Display, TEXT("GASP_NATIVE_CHOOSERS_OK: three editable UE Chooser Tables; profile JSON is hidden legacy data"));
    if (bLegacyGraphs)
    {
    auto CreateConcrete = [&](const TCHAR* Name, UGaspAnimationSet* Resources) -> UAnimBlueprint*
    {
        const FString Path = FString(TEXT("/Game/Native/"))+Name;
        if (FPackageName::DoesPackageExist(Path)) return LoadObject<UAnimBlueprint>(nullptr, *Path);
        auto* Factory = NewObject<UAnimBlueprintFactory>();
        Factory->ParentClass = Template->GeneratedClass;
        Factory->TargetSkeleton = Mesh->GetSkeleton();
        Factory->PreviewSkeletalMesh = Mesh;
        auto* BP = CastChecked<UAnimBlueprint>(Factory->FactoryCreateNew(UAnimBlueprint::StaticClass(), CreatePackage(*Path), FName(Name), RF_Public|RF_Standalone, nullptr, GWarn));
        FKismetEditorUtilities::CompileBlueprint(BP);
        CastChecked<UGaspNativeAnimInstance>(BP->GeneratedClass->GetDefaultObject())->AnimationSet = Resources;
        if (BP->Status == BS_Error || !SaveAsset(BP)) return nullptr;
        FAssetRegistryModule::AssetCreated(BP);
        return BP;
    };
    UAnimBlueprint* Concrete = CreateConcrete(TEXT("ABP_Gasp_UEFN"), Set);
    UAnimBlueprint* Other = CreateConcrete(TEXT("ABP_Gasp_Alternate"), Alternate);
    if (!Concrete || !Other) return 24;
    if (!FPackageName::DoesPackageExist(TEXT("/Game/Native/ABP_Gasp_Host")))
    {
        auto* Factory = NewObject<UAnimBlueprintFactory>();
        Factory->ParentClass = UAnimInstance::StaticClass();
        Factory->TargetSkeleton = Mesh->GetSkeleton();
        auto* BP = CastChecked<UAnimBlueprint>(Factory->FactoryCreateNew(UAnimBlueprint::StaticClass(), CreatePackage(TEXT("/Game/Native/ABP_Gasp_Host")), TEXT("ABP_Gasp_Host"), RF_Public|RF_Standalone, nullptr, GWarn));
        TArray<UEdGraph*> Graphs; BP->GetAllGraphs(Graphs);
        for (UEdGraph* Graph : Graphs) if (Graph->GetFName() == TEXT("AnimGraph"))
        {
            UAnimGraphNode_Root* Root = nullptr;
            for (UEdGraphNode* N : Graph->Nodes) if (auto* R = Cast<UAnimGraphNode_Root>(N)) Root=R;
            auto* Linked = CastChecked<UAnimGraphNode_LinkedAnimGraph>(AddNode(Graph, TEXT("/Script/AnimGraph.AnimGraphNode_LinkedAnimGraph")));
            Linked->Node.InstanceClass = Concrete->GeneratedClass;
            Linked->Node.bPropagateNotifiesToLinkedInstances = true;
            Linked->SetTag(TEXT("GaspCore"));
            Linked->ReconstructNode();
            Connect(Linked, Root, TEXT("Result"));
        }
        FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(BP);
        FKismetEditorUtilities::CompileBlueprint(BP);
        if (BP->Status == BS_Error || !SaveAsset(BP)) return 25;
        FAssetRegistryModule::AssetCreated(BP);
    }
    UE_LOG(LogTemp, Display, TEXT("GASP_REUSABLE_CONTENT_OK: skeleton-free template, two resource sets, two inherited ABPs and linked host"));
    }
    UE_LOG(LogTemp,Display,TEXT("GASP_CPP_CONTENT_READY: native animation class plus resource assets"));
    if (FPackageName::DoesPackageExist(TEXT("/Game/Native/L_NativeSandbox"))) return 0;
    const auto Initialization = UWorld::InitializationValues().AllowAudioPlayback(false).CreatePhysicsScene(true).CreateNavigation(false).ShouldSimulatePhysics(false).SetTransactional(false);
    UWorld* World = UWorld::CreateWorld(EWorldType::Editor, false, TEXT("L_NativeSandbox"), CreatePackage(TEXT("/Game/Native/L_NativeSandbox")), true, ERHIFeatureLevel::Num, &Initialization);
    auto* Floor = World->SpawnActor<AStaticMeshActor>();
    Floor->GetStaticMeshComponent()->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube")));
    Floor->SetActorLocation(FVector(500,0,-25));
    Floor->SetActorScale3D(FVector(40,30,.5));
    Floor->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAll"));
    auto* Start = World->SpawnActor<APlayerStart>();
    Start->SetActorLocation(FVector(0,0,90));
    for (int32 I=0; I<3; ++I)
    {
        auto* Block = World->SpawnActor<AGaspTraversableBlock>();
        const float Heights[] = {100, 150, 200};
        Block->SetActorLocation(FVector(450+I*450,0,Heights[I]/2));
        Block->SetActorScale3D(FVector(1.2,3,Heights[I]/100));
    }
    auto* Light = World->SpawnActor<ADirectionalLight>();
    Light->SetActorRotation(FRotator(-45,-30,0));
    Light->GetLightComponent()->SetIntensity(5);
    auto* Sky = World->SpawnActor<ASkyLight>();
    Sky->GetLightComponent()->SetIntensity(1);
    World->GetWorldSettings()->DefaultGameMode = AGaspNativeGameMode::StaticClass();
    const bool bSavedWorld = SaveAsset(World);
    World->DestroyWorld(false);
    if (!bSavedWorld) return 7;
    UE_LOG(LogTemp, Display, TEXT("GASP_NATIVE_CONTENT_OK: native animation graph and sandbox saved"));
    return 0;
}










