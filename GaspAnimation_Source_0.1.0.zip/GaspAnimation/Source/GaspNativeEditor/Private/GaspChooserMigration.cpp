#include "GaspChooserMigration.h"
#include "GaspChooser.h"
#include "GaspTraversalComponent.h"
#include "GaspChooserParameters.h"
#include "Chooser.h"
#include "ObjectChooser_Asset.h"
#include "BoolColumn.h"
#include "FloatRangeColumn.h"
#include "EnumColumn.h"
#include "MultiEnumColumn.h"
#include "OutputEnumColumn.h"
#include "Serialization/JsonSerializer.h"
#include "Misc/PackageName.h"

namespace
{
template<typename T> T& Add(TArray<FInstancedStruct>& Array)
{
    FInstancedStruct& Value=Array.AddDefaulted_GetRef(); Value.InitializeAs<T>(); return Value.GetMutable<T>();
}
FGaspChooserEnum& EnumInput(FInstancedStruct& Value, const TSharedPtr<FJsonObject>& Column)
{
    Value.InitializeAs<FGaspChooserEnum>();
    auto& Input=Value.GetMutable<FGaspChooserEnum>();
    Input.Binding=Column->GetStringField(TEXT("binding"));
    const FString Path=FPackageName::ExportTextPathToObjectPath(Column->GetStringField(TEXT("enum")));
    if (!Path.IsEmpty() && (Path.StartsWith(TEXT("/Script/")) || FPackageName::DoesPackageExist(FPackageName::ObjectPathToPackageName(Path)))) Input.Enumeration=LoadObject<UEnum>(nullptr, *Path);
    if (!Input.Enumeration && Input.Binding==TEXT("MovementState")) Input.Enumeration=StaticEnum<EGaspChooserMovementState>();
    if (!Input.Enumeration && Input.Binding==TEXT("ActionType")) Input.Enumeration=StaticEnum<EGaspTraversalAction>();
    return Input;
}
}

UChooserTable* BuildGaspChooserTable(const FString& Rules, const FString& PackageName, UClass* ResultClass)
{
    if (FPackageName::DoesPackageExist(PackageName)) return LoadObject<UChooserTable>(nullptr, *PackageName);
    TSharedPtr<FJsonObject> Document;
    if (!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Rules), Document) || !Document) return nullptr;
    auto* Root=NewObject<UChooserTable>(CreatePackage(*PackageName), FName(FPackageName::GetShortName(PackageName)), RF_Public|RF_Standalone);
    Root->OutputObjectType=ResultClass;
    const FString RootName=Document->GetStringField(TEXT("root"));
    const auto Tables=Document->GetObjectField(TEXT("tables"));
    TMap<FString, UChooserTable*> Objects; Objects.Add(RootName, Root);
    for (const auto& Pair: Tables->Values) if (FString(Pair.Key.ToView())!=RootName)
    {
        FString Name(Pair.Key.ToView());
        for (TCHAR& C:Name) if (!FChar::IsAlnum(C)) C=TEXT('_');
        auto* Child=NewObject<UChooserTable>(Root, FName(Name), RF_Transactional);
        Child->RootChooser=Root; Child->OutputObjectType=ResultClass;
        Root->AddNestedChooser(Child); Objects.Add(FString(Pair.Key.ToView()), Child);
    }
    for (const auto& Pair: Tables->Values)
    {
        UChooserTable* Table=Objects.FindChecked(FString(Pair.Key.ToView()));
        const auto Data=Pair.Value->AsObject();
        for (const auto& Value:Data->GetArrayField(TEXT("results")))
        {
            const auto Row=Value->AsObject(); FString Nested, Asset;
            if (Row->TryGetStringField(TEXT("nested"), Nested)) Add<FNestedChooser>(Table->ResultsStructs).Chooser=Objects.FindChecked(Nested);
            else if (Row->TryGetStringField(TEXT("asset"), Asset)) Add<FSoftAssetChooser>(Table->ResultsStructs).Asset=TSoftObjectPtr<UObject>(FSoftObjectPath(Asset));
            else Table->ResultsStructs.AddDefaulted();
        }
        for (const auto& Disabled:Data->GetArrayField(TEXT("disabled"))) Table->DisabledRows.Add(Disabled->AsBool());
        for (const auto& Value:Data->GetArrayField(TEXT("columns")))
        {
            const auto Column=Value->AsObject();
            const FString Type=Column->GetStringField(TEXT("type"));
            const auto& Rows=Column->GetArrayField(TEXT("rows"));
            if (Type==TEXT("BoolColumn"))
            {
                auto& C=Add<FBoolColumn>(Table->ColumnsStructs); C.InputValue.InitializeAs<FGaspChooserBool>();
                C.InputValue.GetMutable<FGaspChooserBool>().Binding=Column->GetStringField(TEXT("binding"));
                for (const auto& Row:Rows) C.RowValuesWithAny.Add(Row->AsString()==TEXT("MatchAny") ? EBoolColumnCellValue::MatchAny : Row->AsString()==TEXT("MatchTrue") ? EBoolColumnCellValue::MatchTrue : EBoolColumnCellValue::MatchFalse);
            }
            else if (Type==TEXT("FloatRangeColumn"))
            {
                auto& C=Add<FFloatRangeColumn>(Table->ColumnsStructs); C.InputValue.InitializeAs<FGaspChooserFloat>();
                C.InputValue.GetMutable<FGaspChooserFloat>().Binding=Column->GetStringField(TEXT("binding"));
                for (const auto& Row:Rows)
                {
                    const auto R=Row->AsObject(); auto& Cell=C.RowValues.AddDefaulted_GetRef();
                    Cell.Min=R->GetNumberField(TEXT("min")); Cell.Max=R->GetNumberField(TEXT("max"));
                    Cell.bNoMin=R->GetBoolField(TEXT("no_min")); Cell.bNoMax=R->GetBoolField(TEXT("no_max"));
                }
            }
            else if (Type==TEXT("EnumColumn"))
            {
                auto& C=Add<FEnumColumn>(Table->ColumnsStructs); auto& Input=EnumInput(C.InputValue, Column);
                for (const auto& Row:Rows)
                {
                    const auto R=Row->AsObject(); auto& Cell=C.RowValues.AddDefaulted_GetRef();
                    Cell.Value=R->GetNumberField(TEXT("value"));
                    const FString Comparison=R->GetStringField(TEXT("comparison"));
                    Cell.Comparison=Comparison==TEXT("MatchAny") ? EEnumColumnCellValueComparison::MatchAny : Comparison==TEXT("MatchNotEqual") ? EEnumColumnCellValueComparison::MatchNotEqual : EEnumColumnCellValueComparison::MatchEqual;
                    if (Input.Enumeration) Cell.ValueName=Input.Enumeration->GetNameByValue(Cell.Value);
                }
            }
            else if (Type==TEXT("MultiEnumColumn"))
            {
                auto& C=Add<FMultiEnumColumn>(Table->ColumnsStructs); EnumInput(C.InputValue, Column);
                for (const auto& Row:Rows) C.RowValues.AddDefaulted_GetRef().Value=uint32(Row->AsNumber());
            }
            else if (Type==TEXT("OutputEnumColumn"))
            {
                auto& C=Add<FOutputEnumColumn>(Table->ColumnsStructs); auto& Input=EnumInput(C.InputValue, Column);
                for (const auto& Row:Rows)
                {
                    auto& Cell=C.RowValues.AddDefaulted_GetRef(); Cell.Value=uint8(Row->AsNumber());
                    if (Input.Enumeration) Cell.ValueName=Input.Enumeration->GetNameByValue(Cell.Value);
                }
            }
            else { UE_LOG(LogTemp, Error, TEXT("Unsupported chooser column: %s"), *Type); return nullptr; }
        }
    }
    Root->Compile(true);
    return Root;
}

bool ValidateGaspChooserMigration(const FString& Rules, UChooserTable* Table)
{
    FGaspChooser Legacy, Native; if (!Legacy.LoadText(Rules)) return false;
    Native.LoadTable(Table);
    FRandomStream Random(10202026);
    for (int32 Case=0; Case<512; ++Case)
    {
        TMap<FString,double> Inputs={
            {TEXT("Speed2D"), Random.FRandRange(0,750)}, {TEXT("Speed"), Random.FRandRange(0,750)},
            {TEXT("MovementMode"), double(Random.RandRange(0,1))}, {TEXT("MovementState"), double(Random.RandRange(0,1))},
            {TEXT("Gait"), double(Random.RandRange(0,2))}, {TEXT("Stance"), double(Random.RandRange(0,1))},
            {TEXT("TrajectoryCollision.TimeToLand"), Random.FRandRange(0,1)},
            {TEXT("ObstacleHeight"), Random.FRandRange(40,240)}, {TEXT("ObstacleDepth"), Random.FRandRange(10,150)},
            {TEXT("BackLedgeHeight"), Random.FRandRange(0,240)}
        };
        for (const TCHAR* Key : {TEXT("IsStarting"),TEXT("IsPivoting"),TEXT("ShouldTurnInPlace"),TEXT("ShouldSpinTransition"),
            TEXT("JustLanded_Light"),TEXT("JustLanded_Heavy"),TEXT("JustTraversed"),TEXT("HasFrontLedge"),TEXT("HasBackLedge"),TEXT("HasBackFloor")})
            Inputs.Add(Key, Random.RandRange(0,1));
        TMap<FString,double> OldOutputs, NewOutputs;
        const auto OldResults=Legacy.Evaluate(Inputs, OldOutputs), NewResults=Native.Evaluate(Inputs, NewOutputs);
        bool Equal=OldResults==NewResults;
        if (!OldResults.IsEmpty())
        {
            Equal &= OldOutputs.Num()==NewOutputs.Num();
            for (const auto& Output:OldOutputs)
            { const double* Found=NewOutputs.Find(Output.Key); Equal &= Found && *Found==Output.Value; }
        }
        if (!Equal)
        {
            UE_LOG(LogTemp, Error, TEXT("Chooser migration mismatch %s case=%d legacy=%d native=%d"), *Table->GetName(), Case, OldResults.Num(), NewResults.Num());
            return false;
        }
    }
    UE_LOG(LogTemp, Display, TEXT("GASP_CHOOSER_PARITY %s 512/512"), *Table->GetName());
    return true;
}



