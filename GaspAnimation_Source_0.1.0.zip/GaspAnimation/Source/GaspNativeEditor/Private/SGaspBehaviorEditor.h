#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
#include "Dom/JsonObject.h"
#include "UObject/StrongObjectPtr.h"
class UEdGraph;
class SVerticalBox;
class SBox;
class STextBlock;
struct FEdGraphEditAction;
class SGaspBehaviorEditor : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SGaspBehaviorEditor){}
        SLATE_ARGUMENT(TSharedPtr<FJsonObject>,Definition)
        SLATE_ARGUMENT(TSet<FString>,AllowedResources)
        SLATE_EVENT(FSimpleDelegate,OnChanged)
    SLATE_END_ARGS()
    void Construct(const FArguments& Args);
private:
    TSharedPtr<FJsonObject> Definition;
    TSet<FString> Allowed;
    FSimpleDelegate Changed;
    TSharedPtr<SVerticalBox> Fields;
    TSharedPtr<SBox> Diagram;
    TSharedPtr<STextBlock> Message;
    TStrongObjectPtr<UEdGraph> EdGraph;
    void Refresh();
    void BuildDiagram();
    void SyncConnections(const FEdGraphEditAction& Action);
    void Commit();
    void PromoteVersion();
    void AddState(const FString& Parent,bool bGroup);
    void DeleteState(const TSharedPtr<FJsonObject>& State);
    void DuplicateState(const TSharedPtr<FJsonObject>& State);
    void AddJsonField(const TSharedPtr<FJsonObject>& Owner,const FString& Key,const FString& Label,EJson Expected,bool bOptional=false);
};
