#pragma once

static TSharedRef<SWidget> MakeGaspUnifiedRequirementReview(const TSharedPtr<FJsonObject>& Info,const FString& RequestText,TFunction<void()> Changed,TFunction<bool()> Idle)
{
    const auto IR=Info->GetObjectField(TEXT("unified_requirements"));
    if(!Info->HasTypedField<EJson::Object>(TEXT("unified_review")))Info->SetObjectField(TEXT("unified_review"),MakeShared<FJsonObject>());
    const auto Review=Info->GetObjectField(TEXT("unified_review"));
    FString Text;FJsonSerializer::Serialize(IR.ToSharedRef(),TJsonWriterFactory<>::Create(&Text));
    const auto Box=SNew(SVerticalBox);
    Box->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("所有节点使用同一套结构；动作名称不受训练类别限制。请检查图中条件与资源。未知动作缺素材时会保留空绑定并阻止应用；外部变量保留初始值，等待游戏逻辑传入。")))];
    const TArray<TSharedPtr<FJsonValue>>* Nodes=nullptr;
    if(IR->TryGetArrayField(TEXT("states"),Nodes))for(const auto& V:*Nodes)
    {
        const auto Node=V->AsObject();if(!Node)continue;
        FString Id,Label,Action;Node->TryGetStringField(TEXT("id"),Id);Node->TryGetStringField(TEXT("label"),Label);
        const TSharedPtr<FJsonObject>* Content=nullptr;if(Node->TryGetObjectField(TEXT("content"),Content))(*Content)->TryGetStringField(TEXT("action_name"),Action);
        Box->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(Id+TEXT("：")+Label+(Action.IsEmpty()?TEXT(""):TEXT(" → ")+Action)))];
    }
    Box->AddSlot().AutoHeight().Padding(4)[SNew(SCheckBox)
        .IsEnabled_Lambda([=](){bool Dirty=false;Review->TryGetBoolField(TEXT("uncommitted"),Dirty);return Idle()&&!Dirty;})
        .IsChecked_Lambda([=](){bool Confirmed=false;Review->TryGetBoolField(TEXT("confirmed"),Confirmed);return Confirmed?ECheckBoxState::Checked:ECheckBoxState::Unchecked;})
        .OnCheckStateChanged_Lambda([=](ECheckBoxState S){
            Review->SetBoolField(TEXT("confirmed"),S==ECheckBoxState::Checked);Review->SetStringField(TEXT("request"),RequestText);
            FString Snapshot;FJsonSerializer::Serialize(Info->GetObjectField(TEXT("unified_requirements")).ToSharedRef(),TJsonWriterFactory<>::Create(&Snapshot));TSharedPtr<FJsonObject> Copy;
            FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Snapshot),Copy);Review->SetObjectField(TEXT("reviewed_ir"),Copy);Review->RemoveField(TEXT("compiled_signature"));Changed();})
        [SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("我已审阅状态、条件、动作绑定和外部接入；确认后重新编译，资源或图有变化时仍会重新校验。")))]];
    Box->AddSlot().AutoHeight().Padding(4)[SNew(SExpandableArea).InitiallyCollapsed(true)
        .HeaderContent()[SNew(STextBlock).Text(FText::FromString(TEXT("高级：统一需求IR（编辑后需重新确认、重新编译）")))]
        .BodyContent()[SNew(SBox).MaxDesiredHeight(300)[SNew(SMultiLineEditableTextBox).Text(FText::FromString(Text)).IsReadOnly_Lambda([=](){return !Idle();})
            .OnTextChanged_Lambda([=](const FText&){Review->SetBoolField(TEXT("uncommitted"),true);Review->SetBoolField(TEXT("confirmed"),false);Review->RemoveField(TEXT("compiled_signature"));Changed();})
            .OnTextCommitted_Lambda([=](const FText& T,ETextCommit::Type){TSharedPtr<FJsonObject> Edited;if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(T.ToString()),Edited)||!Edited)return;Info->SetObjectField(TEXT("unified_requirements"),Edited);Review->SetBoolField(TEXT("uncommitted"),false);Review->SetBoolField(TEXT("confirmed"),false);Review->RemoveField(TEXT("compiled_signature"));Changed();})]]];
    return Box;
}
