#pragma once
#include "CoreMinimal.h"
class FJsonObject;
namespace GaspConfigTool {
FString Backend();
FString BackendDirectory();
FString Workspace();
FString Python();
TSharedPtr<FJsonObject> Scan(const TArray<FString>& Paths, FString& Error);
bool Apply(const FString& CatalogFile,const FString& PlanFile,FString& Message);
bool CheckBlueprint(const FString& BlueprintPath,FString& Error);
bool MapAnimationGroups(const FString& BlueprintPath,FString& Message);
bool RefreshLinkedAnimationInputs(const FString& BlueprintPath,FString& Message);
bool ApplyToBlueprint(const FString& CatalogFile,const FString& PlanFile,const FString& BlueprintPath,FString& Message,bool bExportAnimBlueprint=false,const FString& AnimBlueprintDirectory=FString(),const FString& AnimBlueprintName=FString());
void Register();
void Unregister();
}
