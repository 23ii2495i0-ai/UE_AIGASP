#include "SGaspBehaviorEditor.h"
#include "GaspBehaviorEdGraph.h"
#include "EdGraph/EdGraph.h"
#include "GraphEditor.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Input/SSpinBox.h"
#include "PropertyCustomizationHelpers.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonWriter.h"

namespace {
using FValues=TArray<TSharedPtr<FJsonValue>>;
TSharedPtr<FJsonObject> Object(const TSharedPtr<FJsonValue>& V){return V.IsValid() && V->Type==EJson::Object?V->AsObject():nullptr;}
FString Text(const TSharedPtr<FJsonObject>& O,const TCHAR* Key){FString S;if(O)O->TryGetStringField(Key,S);return S;}
const FValues& Array(const TSharedPtr<FJsonObject>& O,const TCHAR* Key){static const FValues Empty;const FValues* A=nullptr;return O && O->TryGetArrayField(Key,A)?*A:Empty;}
bool Flag(const TSharedPtr<FJsonObject>& O,const FString& Key){bool B=false;if(O)O->TryGetBoolField(Key,B);return B;}
double Number(const TSharedPtr<FJsonObject>& O,const FString& Key,double Default=0){double N=Default;if(O)O->TryGetNumberField(Key,N);return FMath::IsFinite(N)?N:Default;}
FString Json(const TSharedPtr<FJsonValue>& V){if(!V.IsValid())return FString();FString S;auto W=TJsonWriterFactory<>::Create(&S);FJsonSerializer::Serialize(V,TEXT(""),W);return S;}
TSharedPtr<FJsonObject> Clone(const TSharedPtr<FJsonObject>& O){TSharedPtr<FJsonObject> C;FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Json(MakeShared<FJsonValueObject>(O))),C);return C;}
TSharedPtr<FJsonObject> NewEdge(const FString& From,const FString& To)
{
    auto E=MakeShared<FJsonObject>();E->SetStringField(TEXT("from"),From);E->SetStringField(TEXT("to"),To);E->SetStringField(TEXT("event"),TEXT("ChangeState"));E->SetArrayField(TEXT("all"),{});E->SetNumberField(TEXT("priority"),0);E->SetBoolField(TEXT("interrupt"),false);return E;
}
TSet<FString> Descendants(const TSharedPtr<FJsonObject>& Definition,const FString& Root)
{
    TSet<FString> Ids;Ids.Add(Root);
    for(int32 Pass=0;Pass<32;++Pass){const int32 Before=Ids.Num();for(const auto& V:Array(Definition,TEXT("states")))if(auto S=Object(V))if(Ids.Contains(Text(S,TEXT("parent"))))Ids.Add(Text(S,TEXT("id")));if(Before==Ids.Num())break;}
    return Ids;
}
FString HierarchyPath(const TSharedPtr<FJsonObject>& S,const TMap<FString,TSharedPtr<FJsonObject>>& Nodes,int32& Depth)
{
    FString Path,Parent=Text(S,TEXT("parent"));TSet<FString> Seen;Depth=0;
    while(!Parent.IsEmpty() && Depth<8){if(Seen.Contains(Parent)){Path=TEXT("[循环父级] / ")+Path;break;}Seen.Add(Parent);Path=Parent+(Path.IsEmpty()?FString():TEXT(" / ")+Path);++Depth;const auto* P=Nodes.Find(Parent);if(!P)break;Parent=Text(*P,TEXT("parent"));}
    return Path;
}
// This is a structural preview guard, not the runtime validator. Invalid drafts stay editable in raw JSON.
FString PreviewProblem(const TSharedPtr<FJsonObject>& D)
{
    if(!D)return TEXT("behavior_graph 必须是对象");
    const FValues *States=nullptr,*Edges=nullptr;const TSharedPtr<FJsonObject>* Vars=nullptr;
    if(!D->TryGetArrayField(TEXT("states"),States) || !D->TryGetArrayField(TEXT("transitions"),Edges))return TEXT("states / transitions 必须是数组");
    if(States->Num()>32 || Edges->Num()>128)return TEXT("最多32个状态与128条连接");
    if(D->HasField(TEXT("variables")) && !D->TryGetObjectField(TEXT("variables"),Vars))return TEXT("variables 必须是对象");
    const FValues* Inputs=nullptr;if(D->HasField(TEXT("inputs")) && !D->TryGetArrayField(TEXT("inputs"),Inputs))return TEXT("inputs 必须是数组");
    for(const auto& V:*States)
    {
        auto S=Object(V);if(!S)return TEXT("states 中每项必须是对象");
        for(const TCHAR* K:{TEXT("resources"),TEXT("on_entry"),TEXT("on_exit"),TEXT("on_complete")})if(S->HasField(K) && S->TryGetField(K)->Type!=EJson::Array)return FString(K)+TEXT(" 必须是数组");
        for(const TCHAR* K:{TEXT("id"),TEXT("player"),TEXT("parent"),TEXT("initial"),TEXT("database_role")})if(S->HasField(K) && S->TryGetField(K)->Type!=EJson::String)return FString(K)+TEXT(" 必须是文本");
    }
    for(const auto& V:*Edges)
    {
        auto E=Object(V);if(!E)return TEXT("transitions 中每项必须是对象");
        for(const TCHAR* K:{TEXT("all"),TEXT("actions")})if(E->HasField(K) && E->TryGetField(K)->Type!=EJson::Array)return FString(K)+TEXT(" 必须是数组");
        if(E->HasField(TEXT("condition")) && E->TryGetField(TEXT("condition"))->Type!=EJson::Object)return TEXT("condition 必须是对象");
    }
    return FString();
}
}

void SGaspBehaviorEditor::Construct(const FArguments& Args)
{
    Definition=Args._Definition;Allowed=Args._AllowedResources;Changed=Args._OnChanged;
    ChildSlot[SNew(SVerticalBox)
        +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("嵌套行为状态机：金色为父组，右侧缩进为子状态，标题显示父级路径。Out → In 表示状态跳转；分组的initial指定进入时的子状态。蓝色状态使用MM。连线默认ChangeState事件，请设置事件与条件。")))]
        +SVerticalBox::Slot().AutoHeight().Padding(0,6)[SAssignNew(Diagram,SBox).HeightOverride(340)]
        +SVerticalBox::Slot().AutoHeight()[SAssignNew(Message,STextBlock).AutoWrapText(true)]
        +SVerticalBox::Slot().AutoHeight()[SAssignNew(Fields,SVerticalBox)]];
    Refresh();
}
void SGaspBehaviorEditor::Commit(){Changed.ExecuteIfBound();Message->SetText(FText::FromString(TEXT("状态图已修改，请检查草案。缺少资源或条件的草案可以继续编辑，通过完整校验后才能应用。")));}
void SGaspBehaviorEditor::PromoteVersion(){Definition->SetNumberField(TEXT("version"),FMath::Max(2.,Number(Definition,TEXT("version"))));}
void SGaspBehaviorEditor::BuildDiagram()
{
    EdGraph.Reset(NewObject<UEdGraph>());EdGraph->Schema=UGaspBehaviorEdSchema::StaticClass();
    TMap<FString,TSharedPtr<FJsonObject>> StateMap;for(const auto& V:Array(Definition,TEXT("states")))if(auto S=Object(V))StateMap.Add(Text(S,TEXT("id")),S);
    TArray<TSharedPtr<FJsonObject>> Ordered;TSet<FString> Visited;
    TFunction<void(const TSharedPtr<FJsonObject>&)> Visit=[&](const TSharedPtr<FJsonObject>& S){const FString Id=Text(S,TEXT("id"));if(Visited.Contains(Id))return;Visited.Add(Id);Ordered.Add(S);for(const auto& V:Array(Definition,TEXT("states")))if(auto Child=Object(V))if(Text(Child,TEXT("parent"))==Id)Visit(Child);};
    for(const auto& V:Array(Definition,TEXT("states")))if(auto S=Object(V))if(Text(S,TEXT("parent")).IsEmpty())Visit(S);
    for(const auto& V:Array(Definition,TEXT("states")))if(auto S=Object(V))Visit(S);
    TMap<FString,UGaspBehaviorEdNode*> Nodes;int32 I=0;
    for(const auto& S:Ordered)
    {
        auto* N=NewObject<UGaspBehaviorEdNode>(EdGraph.Get());N->StateId=Text(S,TEXT("id"));N->Player=Text(S,TEXT("player"));N->InitialState=Text(S,TEXT("initial"));int32 Depth=0;N->ParentPath=HierarchyPath(S,StateMap,Depth);N->NodePosX=Depth*290;N->NodePosY=I++*150;N->AllocateDefaultPins();EdGraph->AddNode(N);Nodes.Add(N->StateId,N);
    }
    for(const auto& V:Array(Definition,TEXT("transitions")))if(Text(Object(V),TEXT("from"))==TEXT("*") && !Nodes.Contains(TEXT("*")))
    {auto* N=NewObject<UGaspBehaviorEdNode>(EdGraph.Get());N->StateId=TEXT("*");N->Player=TEXT("AnyState");N->NodePosX=-290;N->AllocateDefaultPins();EdGraph->AddNode(N);Nodes.Add(TEXT("*"),N);}
    for(const auto& V:Array(Definition,TEXT("transitions")))
    {const auto E=Object(V);auto* A=Nodes.FindRef(Text(E,TEXT("from")));auto* B=Nodes.FindRef(Text(E,TEXT("to")));if(A && B)A->Pins[1]->MakeLinkTo(B->Pins[0]);}
    EdGraph->AddOnGraphChangedHandler(FOnGraphChanged::FDelegate::CreateSP(this,&SGaspBehaviorEditor::SyncConnections));
    Diagram->SetContent(SNew(SGraphEditor).GraphToEdit(EdGraph.Get()).IsEditable(true).ShowGraphStateOverlay(false));
}
void SGaspBehaviorEditor::SyncConnections(const FEdGraphEditAction& Action)
{
    TSet<FString> Pairs,NodeIds;
    for(auto N:EdGraph->Nodes)if(auto* Node=Cast<UGaspBehaviorEdNode>(N.Get()))
    {NodeIds.Add(Node->StateId);for(auto* P:Node->Pins)if(P->Direction==EGPD_Output)for(auto* Other:P->LinkedTo)if(auto* Target=Cast<UGaspBehaviorEdNode>(Other->GetOwningNode()))Pairs.Add(Node->StateId+TEXT("|")+Target->StateId);}
    auto Edges=Array(Definition,TEXT("transitions"));TSet<FString> Old,Original;
    for(const auto& V:Edges){const auto E=Object(V);if(NodeIds.Contains(Text(E,TEXT("from"))) && NodeIds.Contains(Text(E,TEXT("to"))))Original.Add(Text(E,TEXT("from"))+TEXT("|")+Text(E,TEXT("to")));}
    if(Original.Num()==Pairs.Num() && Original.Includes(Pairs))return;
    // Keep every rule on retained connections, including multiple events between the same states.
    Edges.RemoveAll([&](const auto& V){const auto E=Object(V);const FString From=Text(E,TEXT("from")),To=Text(E,TEXT("to")),Pair=From+TEXT("|")+To;if(!NodeIds.Contains(From) || !NodeIds.Contains(To))return false;if(!Pairs.Contains(Pair))return true;Old.Add(Pair);return false;});
    for(const FString& Pair:Pairs)if(!Old.Contains(Pair)){FString A,B;Pair.Split(TEXT("|"),&A,&B);Edges.Add(MakeShared<FJsonValueObject>(NewEdge(A,B)));}
    Definition->SetArrayField(TEXT("transitions"),Edges);Commit();
    RegisterActiveTimer(0,FWidgetActiveTimerDelegate::CreateLambda([this](double,float){Refresh();return EActiveTimerReturnType::Stop;}));
}
void SGaspBehaviorEditor::AddState(const FString& Parent,bool bGroup)
{
    auto States=Array(Definition,TEXT("states"));if(States.Num()>=32){Message->SetText(FText::FromString(TEXT("最多32个状态（包括父组）。")));return;}
    if(!Parent.IsEmpty())
    {
        TMap<FString,TSharedPtr<FJsonObject>> Map;for(const auto& V:States)if(auto S=Object(V))Map.Add(Text(S,TEXT("id")),S);
        const auto P=Map.FindRef(Parent);int32 Depth=0;HierarchyPath(P,Map,Depth);
        if(!P || Text(P,TEXT("player"))!=TEXT("group") || Depth>=7){Message->SetText(FText::FromString(TEXT("无法添加：父级必须是有效组，层级最多8层。")));return;}
    }
    auto S=MakeShared<FJsonObject>();const FString Id=(bGroup?TEXT("Group_"):TEXT("State_"))+FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(6);
    S->SetStringField(TEXT("id"),Id);S->SetStringField(TEXT("player"),bGroup?TEXT("group"):TEXT("sequence"));S->SetArrayField(TEXT("resources"),{});S->SetBoolField(TEXT("loop"),false);S->SetBoolField(TEXT("allow_movement"),true);S->SetBoolField(TEXT("lock_until_finished"),false);S->SetNumberField(TEXT("min_duration"),0);S->SetNumberField(TEXT("blend_seconds"),.2);
    if(!Parent.IsEmpty()){S->SetStringField(TEXT("parent"),Parent);for(const auto& V:States)if(auto P=Object(V))if(Text(P,TEXT("id"))==Parent && Text(P,TEXT("initial")).IsEmpty())P->SetStringField(TEXT("initial"),Id);PromoteVersion();}
    if(bGroup){S->SetStringField(TEXT("initial"),TEXT(""));PromoteVersion();}
    States.Add(MakeShared<FJsonValueObject>(S));Definition->SetArrayField(TEXT("states"),States);if(Text(Definition,TEXT("entry")).IsEmpty())Definition->SetStringField(TEXT("entry"),Id);Commit();Refresh();
}
void SGaspBehaviorEditor::DeleteState(const TSharedPtr<FJsonObject>& State)
{
    const auto Removed=Descendants(Definition,Text(State,TEXT("id")));auto Nodes=Array(Definition,TEXT("states"));Nodes.RemoveAll([&](const auto& V){return Removed.Contains(Text(Object(V),TEXT("id")));});
    for(const auto& V:Nodes)if(auto S=Object(V))if(Removed.Contains(Text(S,TEXT("initial")))){S->SetStringField(TEXT("initial"),TEXT(""));for(const auto& C:Nodes)if(Text(Object(C),TEXT("parent"))==Text(S,TEXT("id"))){S->SetStringField(TEXT("initial"),Text(Object(C),TEXT("id")));break;}}
    if(Removed.Contains(Text(Definition,TEXT("entry")))){Definition->SetStringField(TEXT("entry"),TEXT(""));for(const auto& V:Nodes)if(Text(Object(V),TEXT("parent")).IsEmpty()){Definition->SetStringField(TEXT("entry"),Text(Object(V),TEXT("id")));break;}}
    Definition->SetArrayField(TEXT("states"),Nodes);auto Edges=Array(Definition,TEXT("transitions"));Edges.RemoveAll([&](const auto& V){return Removed.Contains(Text(Object(V),TEXT("from"))) || Removed.Contains(Text(Object(V),TEXT("to")));});Definition->SetArrayField(TEXT("transitions"),Edges);
    if(Definition->HasField(TEXT("handlers"))){auto Handlers=Array(Definition,TEXT("handlers"));Handlers.RemoveAll([&](const auto& V){return Removed.Contains(Text(Object(V),TEXT("from")));});Definition->SetArrayField(TEXT("handlers"),Handlers);}
    Commit();Refresh();
}
void SGaspBehaviorEditor::DuplicateState(const TSharedPtr<FJsonObject>& State)
{
    const auto Copied=Descendants(Definition,Text(State,TEXT("id")));auto Nodes=Array(Definition,TEXT("states"));auto Edges=Array(Definition,TEXT("transitions"));
    if(Nodes.Num()+Copied.Num()>32){Message->SetText(FText::FromString(TEXT("复制后会超过32个状态，未修改。")));return;}
    TMap<FString,FString> Remap;const FString Suffix=TEXT("_copy_")+FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(6);for(const auto& Id:Copied)Remap.Add(Id,Id.Left(50)+Suffix);
    FValues NewNodes,NewEdges;
    for(const auto& V:Nodes)if(Copied.Contains(Text(Object(V),TEXT("id")))){auto S=Clone(Object(V));for(const TCHAR* K:{TEXT("id"),TEXT("parent"),TEXT("initial")})if(const auto* NewId=Remap.Find(Text(S,K)))S->SetStringField(K,*NewId);NewNodes.Add(MakeShared<FJsonValueObject>(S));}
    for(const auto& V:Edges)if(Copied.Contains(Text(Object(V),TEXT("from")))){auto E=Clone(Object(V));for(const TCHAR* K:{TEXT("from"),TEXT("to")})if(const auto* NewId=Remap.Find(Text(E,K)))E->SetStringField(K,*NewId);NewEdges.Add(MakeShared<FJsonValueObject>(E));}
    if(Edges.Num()+NewEdges.Num()>128){Message->SetText(FText::FromString(TEXT("复制后会超过128条连接，未修改。")));return;}
    auto Handlers=Array(Definition,TEXT("handlers"));FValues NewHandlers;
    for(const auto& V:Handlers)if(Copied.Contains(Text(Object(V),TEXT("from")))){auto H=Clone(Object(V));H->SetStringField(TEXT("from"),Remap[Text(H,TEXT("from"))]);NewHandlers.Add(MakeShared<FJsonValueObject>(H));}
    if(Handlers.Num()+NewHandlers.Num()>128){Message->SetText(FText::FromString(TEXT("复制后会超过128个内部事件，未修改。")));return;}
    if(Definition->HasField(TEXT("handlers"))){Handlers.Append(NewHandlers);Definition->SetArrayField(TEXT("handlers"),Handlers);}
    Nodes.Append(NewNodes);Edges.Append(NewEdges);Definition->SetArrayField(TEXT("states"),Nodes);Definition->SetArrayField(TEXT("transitions"),Edges);Commit();Refresh();
}
void SGaspBehaviorEditor::AddJsonField(const TSharedPtr<FJsonObject>& Owner,const FString& Key,const FString& Label,EJson Expected,bool bOptional)
{
    TSharedPtr<FJsonValue> Value=Owner->TryGetField(Key);
    if(!Value.IsValid() && !bOptional)
    {
        if(Expected==EJson::Array)Value=MakeShared<FJsonValueArray>(FValues());
        else Value=MakeShared<FJsonValueObject>(MakeShared<FJsonObject>());
    }
    Fields->AddSlot().AutoHeight().Padding(0,3)[SNew(SExpandableArea).InitiallyCollapsed(true).HeaderContent()[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(Label))].BodyContent()[SNew(SBox).MinDesiredHeight(65).MaxDesiredHeight(170)[SNew(SMultiLineEditableTextBox).Text(FText::FromString(Json(Value))).HintText(FText::FromString(bOptional?TEXT("留空可移除此可选字段"):TEXT("填写JSON"))).OnTextCommitted_Lambda([this,Owner,Key,Expected,bOptional](const FText& T,ETextCommit::Type)
    {
        if(bOptional && T.ToString().TrimStartAndEnd().IsEmpty()){Owner->RemoveField(Key);Commit();return;}
        TSharedPtr<FJsonValue> V;if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(T.ToString()),V) || !V.IsValid() || V->Type!=Expected){Message->SetText(FText::FromString(Key+TEXT(" JSON格式或类型不符，未修改；数组使用[]，对象使用{}。")));return;}
        Owner->SetField(Key,V);if(Key==TEXT("condition") || Key==TEXT("actions") || Key.StartsWith(TEXT("on_")) || Key==TEXT("inputs"))PromoteVersion();Commit();
    })]]];
}
void SGaspBehaviorEditor::Refresh()
{
    Fields->ClearChildren();const FString Problem=PreviewProblem(Definition);
    if(!Problem.IsEmpty()){Diagram->SetContent(SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("状态图暂不能预览：")+Problem+TEXT("。请在下方高级JSON中修正；原草案保留。"))));Message->SetText(FText::FromString(Problem));return;}
    BuildDiagram();
    auto Label=[&](const FString& S){Fields->AddSlot().AutoHeight().Padding(0,6)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(S))];};
    Label(TEXT("入口状态（填顶层状态或父组ID）"));
    Fields->AddSlot().AutoHeight()[SNew(SEditableTextBox).Text(FText::FromString(Text(Definition,TEXT("entry")))).OnTextCommitted_Lambda([this](const FText& T,ETextCommit::Type){Definition->SetStringField(TEXT("entry"),T.ToString());Commit();})];
    Fields->AddSlot().AutoHeight().Padding(0,6)[SNew(SHorizontalBox)
        +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("添加顶层状态"))).OnClicked_Lambda([this](){AddState(TEXT(""),false);return FReply::Handled();})]
        +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("添加顶层分组"))).OnClicked_Lambda([this](){AddState(TEXT(""),true);return FReply::Handled();})]];
    TMap<FString,TSharedPtr<FJsonObject>> StateMap;for(const auto& V:Array(Definition,TEXT("states")))if(auto S=Object(V))StateMap.Add(Text(S,TEXT("id")),S);
    for(const auto& V:Array(Definition,TEXT("states")))
    {
        const auto S=Object(V);int32 Depth=0;const FString Path=HierarchyPath(S,StateMap,Depth),Id=Text(S,TEXT("id"));const bool bGroup=Text(S,TEXT("player"))==TEXT("group");
        Label((bGroup?TEXT("分组："):TEXT("状态："))+(Path.IsEmpty()?FString():Path+TEXT(" / "))+Id);
        Fields->AddSlot().AutoHeight()[SNew(SHorizontalBox)
            +SHorizontalBox::Slot().FillWidth(1)[SNew(SEditableTextBox).Text(FText::FromString(Id)).OnTextCommitted_Lambda([this,S](const FText& T,ETextCommit::Type){const FString Old=Text(S,TEXT("id")),NewId=T.ToString().TrimStartAndEnd();if(NewId.IsEmpty()){Message->SetText(FText::FromString(TEXT("状态ID不能为空。")));return;}for(const auto& V:Array(Definition,TEXT("states")))if(Object(V)!=S && Text(Object(V),TEXT("id")).Equals(NewId,ESearchCase::IgnoreCase)){Message->SetText(FText::FromString(TEXT("状态ID已存在（不区分大小写），未修改。")));return;}S->SetStringField(TEXT("id"),NewId);if(Text(Definition,TEXT("entry"))==Old)Definition->SetStringField(TEXT("entry"),NewId);for(const auto& V:Array(Definition,TEXT("states")))for(const TCHAR* K:{TEXT("parent"),TEXT("initial")})if(Text(Object(V),K)==Old)Object(V)->SetStringField(K,NewId);for(const auto& E:Array(Definition,TEXT("transitions")))for(const TCHAR* K:{TEXT("from"),TEXT("to")})if(Text(Object(E),K)==Old)Object(E)->SetStringField(K,NewId);Commit();Refresh();})]
            +SHorizontalBox::Slot().FillWidth(1)[SNew(SEditableTextBox).HintText(FText::FromString(TEXT("group/locomotion/mm/sequence/montage"))).Text(FText::FromString(Text(S,TEXT("player")))).OnTextCommitted_Lambda([this,S](const FText& T,ETextCommit::Type){const FString Player=T.ToString().TrimStartAndEnd();if(Player!=TEXT("group")){for(const auto& V:Array(Definition,TEXT("states")))if(Text(Object(V),TEXT("parent"))==Text(S,TEXT("id"))){Message->SetText(FText::FromString(TEXT("该组还有子状态；先移动或删除子状态，再改为动画状态。")));return;}}S->SetStringField(TEXT("player"),Player);if(Player==TEXT("group") || Player==TEXT("locomotion")){S->SetArrayField(TEXT("resources"),{});S->RemoveField(TEXT("database_role"));S->SetBoolField(TEXT("loop"),Player==TEXT("locomotion"));S->SetBoolField(TEXT("lock_until_finished"),false);S->RemoveField(TEXT("on_complete"));PromoteVersion();}if(Player!=TEXT("group")) S->RemoveField(TEXT("initial"));Commit();Refresh();})]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("复制子树"))).OnClicked_Lambda([this,S](){DuplicateState(S);return FReply::Handled();})]
            +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(bGroup?TEXT("删除组及子状态"):TEXT("删除状态"))).OnClicked_Lambda([this,S](){DeleteState(S);return FReply::Handled();})]];
        Fields->AddSlot().AutoHeight().Padding(0,3)[SNew(SEditableTextBox).HintText(FText::FromString(TEXT("parent：父组ID，留空为顶层；最多8层"))).Text(FText::FromString(Text(S,TEXT("parent")))).OnTextCommitted_Lambda([this,S](const FText& T,ETextCommit::Type)
        {
            const FString Parent=T.ToString().TrimStartAndEnd(),Id=Text(S,TEXT("id")),OldParent=Text(S,TEXT("parent"));const auto Subtree=Descendants(Definition,Id);
            if(Subtree.Contains(Parent)){Message->SetText(FText::FromString(TEXT("不能把状态移动到自身或自己的子组。")));return;}
            TMap<FString,TSharedPtr<FJsonObject>> Map;for(const auto& V:Array(Definition,TEXT("states")))if(auto N=Object(V))Map.Add(Text(N,TEXT("id")),N);
            TSharedPtr<FJsonObject> NewParent;if(!Parent.IsEmpty()){NewParent=Map.FindRef(Parent);if(!NewParent || Text(NewParent,TEXT("player"))!=TEXT("group")){Message->SetText(FText::FromString(TEXT("parent必须引用已有group。")));return;}}
            int32 NewDepth=-1,OldDepth=0,SubtreeDepth=0;if(NewParent)HierarchyPath(NewParent,Map,NewDepth);HierarchyPath(S,Map,OldDepth);
            for(const FString& ChildId:Subtree){int32 D=0;HierarchyPath(Map.FindRef(ChildId),Map,D);SubtreeDepth=FMath::Max(SubtreeDepth,D-OldDepth);}
            if(NewDepth+1+SubtreeDepth>=8){Message->SetText(FText::FromString(TEXT("移动后会超过8层嵌套，未修改。")));return;}
            if(Parent.IsEmpty())S->RemoveField(TEXT("parent"));else S->SetStringField(TEXT("parent"),Parent);
            for(const auto& V:Array(Definition,TEXT("states")))if(auto P=Object(V))if(Text(P,TEXT("id"))==OldParent && Text(P,TEXT("initial"))==Id && OldParent!=Parent){P->SetStringField(TEXT("initial"),TEXT(""));for(const auto& C:Array(Definition,TEXT("states")))if(Text(Object(C),TEXT("parent"))==OldParent){P->SetStringField(TEXT("initial"),Text(Object(C),TEXT("id")));break;}}
            if(NewParent && Text(NewParent,TEXT("initial")).IsEmpty())NewParent->SetStringField(TEXT("initial"),Id);
            if(Text(Definition,TEXT("entry"))==Id && !Parent.IsEmpty()){FString Root=Parent;for(int32 I=0;I<8;++I){FString Next;for(const auto& V:Array(Definition,TEXT("states")))if(Text(Object(V),TEXT("id"))==Root)Next=Text(Object(V),TEXT("parent"));if(Next.IsEmpty())break;Root=Next;}Definition->SetStringField(TEXT("entry"),Root);}
            PromoteVersion();Commit();Refresh();
        })];
        if(bGroup)
        {
            Fields->AddSlot().AutoHeight()[SNew(SEditableTextBox).HintText(FText::FromString(TEXT("initial：必须是此组的直接子状态ID"))).Text(FText::FromString(Text(S,TEXT("initial")))).OnTextCommitted_Lambda([this,S](const FText& T,ETextCommit::Type){const FString Initial=T.ToString().TrimStartAndEnd();if(!Initial.IsEmpty()){bool Found=false;for(const auto& V:Array(Definition,TEXT("states")))Found|=Text(Object(V),TEXT("id"))==Initial && Text(Object(V),TEXT("parent"))==Text(S,TEXT("id"));if(!Found){Message->SetText(FText::FromString(TEXT("initial必须是该组的直接子状态ID，未修改。")));return;}}S->SetStringField(TEXT("initial"),Initial);PromoteVersion();Commit();Refresh();})];
            Fields->AddSlot().AutoHeight()[SNew(SHorizontalBox)+SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("添加子状态"))).OnClicked_Lambda([this,S](){AddState(Text(S,TEXT("id")),false);return FReply::Handled();})]+SHorizontalBox::Slot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("添加子组"))).OnClicked_Lambda([this,S](){AddState(Text(S,TEXT("id")),true);return FReply::Handled();})]];
        }
        else if(Text(S,TEXT("player"))==TEXT("locomotion"))
        {
            Label(TEXT("地面移动选择器：按实际移动输入和步态使用配置中的待机、行走和跑步 Motion Matching 数据库。此节点不直接绑定动画；请在资源类别中检查候选。"));
        }
        else
        {
            Fields->AddSlot().AutoHeight().Padding(0,3)[SNew(SObjectPropertyEntryBox).AllowedClass(UObject::StaticClass()).ObjectPath_Lambda([S](){const auto& A=Array(S,TEXT("resources"));FString P;if(!A.IsEmpty() && A[0])A[0]->TryGetString(P);return P;}).OnShouldFilterAsset_Lambda([this](const FAssetData& A){return !Allowed.Contains(A.GetSoftObjectPath().ToString());}).OnObjectChanged_Lambda([this,S](const FAssetData& A){const FString Path=A.GetSoftObjectPath().ToString();S->SetArrayField(TEXT("resources"),Path.IsEmpty()?FValues():FValues{MakeShared<FJsonValueString>(Path)});S->RemoveField(TEXT("database_role"));Commit();})];
            AddJsonField(S,TEXT("resources"),TEXT("资源路径数组（MM可选多个数据库；仅允许本次选定资源）"),EJson::Array);
            Fields->AddSlot().AutoHeight()[SNew(SEditableTextBox).HintText(FText::FromString(TEXT("mm的database_role：idle/walk/run/sprint/crouch/jump；填后清空直接资源"))).Text(FText::FromString(Text(S,TEXT("database_role")))).OnTextCommitted_Lambda([this,S](const FText& T,ETextCommit::Type){if(T.IsEmpty())S->RemoveField(TEXT("database_role"));else{S->SetStringField(TEXT("database_role"),T.ToString());S->SetArrayField(TEXT("resources"),{});}Commit();})];
        }
        auto Checks=SNew(SHorizontalBox);
        for(const auto& Pair:TArray<TPair<FString,FString>>{{TEXT("loop"),TEXT("循环")},{TEXT("allow_movement"),TEXT("允许移动")},{TEXT("lock_until_finished"),TEXT("锁定至结束")}})
            Checks->AddSlot().AutoWidth().Padding(4)[SNew(SCheckBox).IsEnabled(!bGroup || Pair.Key==TEXT("allow_movement")).IsChecked(Flag(S,Pair.Key)?ECheckBoxState::Checked:ECheckBoxState::Unchecked).OnCheckStateChanged_Lambda([this,S,Key=Pair.Key](ECheckBoxState B){S->SetBoolField(Key,B==ECheckBoxState::Checked);Commit();})[SNew(STextBlock).Text(FText::FromString(Pair.Value))]];
        Fields->AddSlot().AutoHeight()[Checks];
        for(const auto& Pair:TArray<TPair<FString,FString>>{{TEXT("min_duration"),TEXT("最短停留秒")},{TEXT("blend_seconds"),TEXT("混合秒")}})
            Fields->AddSlot().AutoHeight()[SNew(SHorizontalBox)+SHorizontalBox::Slot().AutoWidth()[SNew(STextBlock).Text(FText::FromString(Pair.Value))]+SHorizontalBox::Slot().FillWidth(1)[SNew(SSpinBox<float>).MinValue(0).MaxValue(Pair.Key==TEXT("blend_seconds")?2:60).Value(Number(S,Pair.Key)).OnValueChanged_Lambda([this,S,Key=Pair.Key](float N){S->SetNumberField(Key,N);Commit();})]];
        AddJsonField(S,TEXT("on_entry"),TEXT("进入时动作 on_entry（例如计数清零、加一或jump起跳）"),EJson::Array,true);
        AddJsonField(S,TEXT("on_exit"),TEXT("退出时动作 on_exit"),EJson::Array,true);
        if(!bGroup)AddJsonField(S,TEXT("on_complete"),TEXT("播放完成动作 on_complete（仅非循环sequence/montage；每次进入只触发一次）"),EJson::Array,true);
    }
    Label(TEXT("连接：all与condition同时成立才跳转。condition支持嵌套all/any/not。事件留空为每帧判断；组连接作用于其活动子状态，自跳转会重新进入。"));
    Fields->AddSlot().AutoHeight()[SNew(SButton).Text(FText::FromString(TEXT("添加连接（也可Out拖到In）"))).OnClicked_Lambda([this](){auto Edges=Array(Definition,TEXT("transitions"));if(Edges.Num()>=128){Message->SetText(FText::FromString(TEXT("最多128条连接。")));return FReply::Handled();}const FString Entry=Text(Definition,TEXT("entry"));Edges.Add(MakeShared<FJsonValueObject>(NewEdge(Entry,Entry)));Definition->SetArrayField(TEXT("transitions"),Edges);Commit();Refresh();return FReply::Handled();})];
    for(const auto& V:Array(Definition,TEXT("transitions")))
    {
        const auto E=Object(V);auto Row=SNew(SHorizontalBox);
        for(const TCHAR* Key:{TEXT("from"),TEXT("to"),TEXT("event")})Row->AddSlot().FillWidth(1)[SNew(SEditableTextBox).HintText(FText::FromString(Key)).Text(FText::FromString(Text(E,Key))).OnTextCommitted_Lambda([this,E,K=FString(Key)](const FText& T,ETextCommit::Type){E->SetStringField(K,T.ToString());Commit();Refresh();})];
        Row->AddSlot().AutoWidth()[SNew(SButton).Text(FText::FromString(TEXT("删除连接"))).OnClicked_Lambda([this,E](){auto A=Array(Definition,TEXT("transitions"));A.RemoveAll([&](const auto& X){return Object(X)==E;});Definition->SetArrayField(TEXT("transitions"),A);Commit();Refresh();return FReply::Handled();})];
        Fields->AddSlot().AutoHeight().Padding(0,4)[Row];
        AddJsonField(E,TEXT("all"),TEXT("基础AND条件 all：[{\"var\":\"finished\",\"op\":\"eq\",\"value\":true}]"),EJson::Array);
        AddJsonField(E,TEXT("condition"),TEXT("复杂条件 condition：嵌套all / any / not 或单个var/op/value条件"),EJson::Object,true);
        AddJsonField(E,TEXT("actions"),TEXT("跳转动作 actions：[{\"op\":\"add\",\"var\":\"AttackCount\",\"value\":1}]"),EJson::Array,true);
        Fields->AddSlot().AutoHeight()[SNew(SHorizontalBox)+SHorizontalBox::Slot().AutoWidth()[SNew(STextBlock).Text(FText::FromString(TEXT("优先级 ")))]+SHorizontalBox::Slot().FillWidth(1)[SNew(SSpinBox<int32>).MinValue(-1000).MaxValue(1000).Value(Number(E,TEXT("priority"))).OnValueChanged_Lambda([this,E](int32 N){E->SetNumberField(TEXT("priority"),N);Commit();})]+SHorizontalBox::Slot().AutoWidth()[SNew(SCheckBox).IsChecked(Flag(E,TEXT("interrupt"))?ECheckBoxState::Checked:ECheckBoxState::Unchecked).OnCheckStateChanged_Lambda([this,E](ECheckBoxState B){E->SetBoolField(TEXT("interrupt"),B==ECheckBoxState::Checked);Commit();})[SNew(STextBlock).Text(FText::FromString(TEXT("绕过来源锁定/最短时间")))]]];
    }
    Label(TEXT("变量初始值与按键：外部条件可声明bhit=false，再由蓝图SetVariable传入。内部计数用set/add；输入动作可配置jump速度，动作顺序按数组执行。"));
    AddJsonField(Definition,TEXT("variables"),TEXT("变量 variables：{\"bhit\":false,\"AttackCount\":0}"),EJson::Object);
    AddJsonField(Definition,TEXT("inputs"),TEXT("输入 inputs：UE键名、pressed/released、event、set，可选actions数组"),EJson::Array);
    if(Number(Definition,TEXT("version"))>=3)
    {
        Label(TEXT("v3内部事件不切换状态、不重启动画；与转换共享优先级，消费一次事件。外部变量在SetVariable接入前阻断相关条件。"));
        AddJsonField(Definition,TEXT("handlers"),TEXT("条件内部事件 handlers：from/event/condition/actions/priority"),EJson::Array);
        AddJsonField(Definition,TEXT("variable_sources"),TEXT("变量来源 variable_sources：scope internal/external，source 接口说明"),EJson::Object);
    }
}
