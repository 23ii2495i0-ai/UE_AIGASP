#include "GaspBehaviorEdGraph.h"
#include "EdGraph/EdGraph.h"
void UGaspBehaviorEdNode::AllocateDefaultPins()
{
    CreatePin(EGPD_Input,TEXT("exec"),TEXT("In"));
    CreatePin(EGPD_Output,TEXT("exec"),TEXT("Out"));
}
const FPinConnectionResponse UGaspBehaviorEdSchema::CanCreateConnection(const UEdGraphPin* A,const UEdGraphPin* B) const
{
    if(!A || !B || A==B || A->Direction==B->Direction)return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW,TEXT("Connect Out to In"));
    if(A->GetOwningNode()==B->GetOwningNode())return FPinConnectionResponse(CONNECT_RESPONSE_DISALLOW,TEXT("Use transition fields for explicit self transitions"));
    return FPinConnectionResponse(CONNECT_RESPONSE_MAKE,TEXT("Add transition; set event/conditions below"));
}
bool UGaspBehaviorEdSchema::TryCreateConnection(UEdGraphPin* A,UEdGraphPin* B) const
{
    if(CanCreateConnection(A,B).Response!=CONNECT_RESPONSE_MAKE)return false;
    A->MakeLinkTo(B);A->GetOwningNode()->GetGraph()->NotifyGraphChanged();return true;
}
void UGaspBehaviorEdSchema::BreakPinLinks(UEdGraphPin& Pin,bool Notify) const
{
    Super::BreakPinLinks(Pin,Notify);Pin.GetOwningNode()->GetGraph()->NotifyGraphChanged();
}
