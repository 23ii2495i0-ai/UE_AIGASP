#include "GaspFoleyMigration.h"
#include "GaspFoleyNotify.h"
#include "Animation/AnimSequenceBase.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Editor.h"
#include "Sound/SoundBase.h"
#include "UObject/StructOnScope.h"
#include "UObject/UnrealType.h"
#include "UObject/SavePackage.h"
#include "Misc/PackageName.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"

bool MigrateGaspFoleyNotifies()
{
    auto& Registry=FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();
    TArray<FAssetData> Assets;
    Registry.GetAssetsByPath(TEXT("/Game/Characters/UEFN_Mannequin/Animations"), Assets, true);
    int32 Count=0; TSet<FString> Remaining;
    for (const auto& Data:Assets)
    {
        if (Data.AssetClassPath.GetAssetName()!=TEXT("AnimSequence") && Data.AssetClassPath.GetAssetName()!=TEXT("AnimMontage")) continue;
        auto* Animation=Cast<UAnimSequenceBase>(Data.GetAsset()); if (!Animation) continue;
        bool Changed=false;
        for (auto& Event:Animation->Notifies)
        {
            if (auto* OldState=Event.NotifyStateClass.Get(); OldState && OldState->GetClass()->GetName()==TEXT("BP_NotifyState_EarlyTransition_C"))
            {
                auto* Native=NewObject<UGaspEarlyTransitionNotify>(Animation);
                auto Label=[OldState](const TCHAR* Name)
                {
                    const auto* P=FindFProperty<FByteProperty>(OldState->GetClass(),Name);
                    return P && P->Enum ? P->Enum->GetDisplayNameTextByValue(P->GetPropertyValue_InContainer(OldState)).ToString() : FString();
                };
                const FString Condition=Label(TEXT("TransitionCondition")), Destination=Label(TEXT("TransitionDestination"));
                Native->bAlways=Condition.Contains(TEXT("Always")) || Condition.Contains(TEXT("Force"));
                if (!Native->bAlways && !Condition.Contains(TEXT("Gait"))) { UE_LOG(LogTemp,Error,TEXT("Unknown early transition condition %s"),*Condition); return false; }
                Native->bToLoop=Destination.Contains(TEXT("Loop"));
                if (!Native->bToLoop && !Destination.Contains(TEXT("Transition"))) { UE_LOG(LogTemp,Error,TEXT("Unknown early transition destination %s"),*Destination); return false; }
                if (const auto* P=FindFProperty<FByteProperty>(OldState->GetClass(),TEXT("GaitNotEqual"))) Native->GaitNotEqual=P->GetPropertyValue_InContainer(OldState);
                Event.NotifyStateClass=Native; Changed=true; ++Count;
            }
            if (Event.NotifyStateClass && Event.NotifyStateClass->GetClass()->ClassGeneratedBy) Remaining.Add(Event.NotifyStateClass->GetClass()->GetName());
            UAnimNotify* Old=Event.Notify.Get(); if (!Old || !Old->GetClass()->ClassGeneratedBy) continue;
            if (!Old->GetClass()->GetName().StartsWith(TEXT("BP_AnimNotify_FoleyEvent")))
            { Remaining.Add(Old->GetClass()->GetName()); continue; }
            auto* Native=NewObject<UGaspFoleyNotify>(Animation);
            FEditorScriptExecutionGuard Guard;
            Native->DisplayName=Old->GetNotifyName();
            if (const auto* P=FindFProperty<FNumericProperty>(Old->GetClass(),TEXT("VolumeMultiplier"))) Native->VolumeMultiplier=P->GetFloatingPointPropertyValue(P->ContainerPtrToValuePtr<void>(Old));
            if (const auto* P=FindFProperty<FNumericProperty>(Old->GetClass(),TEXT("PitchMultiplier"))) Native->PitchMultiplier=P->GetFloatingPointPropertyValue(P->ContainerPtrToValuePtr<void>(Old));
            UObject* Bank=nullptr;
            if (const auto* P=FindFProperty<FObjectProperty>(Old->GetClass(),TEXT("DefaultBank"))) Bank=P->GetObjectPropertyValue_InContainer(Old);
            if (Bank)
            {
                UFunction* Function=Bank->FindFunction(TEXT("GetSoundFromFoleyEvent"));
                auto* Input=Function ? FindFProperty<FStructProperty>(Function,TEXT("Event")) : nullptr;
                auto* Source=FindFProperty<FStructProperty>(Old->GetClass(),TEXT("Event"));
                if (!Function || !Input || !Source || Input->Struct!=Source->Struct) return false;
                FStructOnScope Parameters(Function);
                Input->CopyCompleteValue(Input->ContainerPtrToValuePtr<void>(Parameters.GetStructMemory()), Source->ContainerPtrToValuePtr<void>(Old));
                Bank->ProcessEvent(Function,Parameters.GetStructMemory());
                for (TFieldIterator<FObjectProperty> P(Function);P;++P)
                    if (P->HasAnyPropertyFlags(CPF_ReturnParm|CPF_OutParm) && P->PropertyClass->IsChildOf(USoundBase::StaticClass()))
                        Native->Sound=Cast<USoundBase>(P->GetObjectPropertyValue_InContainer(Parameters.GetStructMemory()));
                for (TFieldIterator<FStructProperty> P(Function);P;++P) if (P->HasAnyPropertyFlags(CPF_ReturnParm|CPF_OutParm) && P->GetName()!=TEXT("Event"))
                    for (TFieldIterator<FObjectProperty> Field(P->Struct);Field;++Field)
                        if (Field->PropertyClass->IsChildOf(USoundBase::StaticClass()))
                            Native->Sound=Cast<USoundBase>(Field->GetObjectPropertyValue_InContainer(P->ContainerPtrToValuePtr<void>(Parameters.GetStructMemory())));
            }
            Event.Notify=Native; Changed=true; ++Count;
        }
        if (Changed)
        {
            UPackage* Package=Animation->GetOutermost();
            const FString File=FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
            const FString Relative=Package->GetName().RightChop(6);
            const FString Backup=FPaths::ProjectSavedDir()/TEXT("PortBackups/PureCpp")/(Relative+TEXT(".uasset"));
            IFileManager::Get().MakeDirectory(*FPaths::GetPath(Backup),true);
            if (!IFileManager::Get().FileExists(*Backup)) IFileManager::Get().Copy(*Backup,*File);
            FSavePackageArgs Args; Args.TopLevelFlags=RF_Public|RF_Standalone;
            if (!UPackage::SavePackage(Package,Animation,*File,Args)) return false;
        }
    }
    for (const auto& Name:Remaining) UE_LOG(LogTemp,Display,TEXT("GASP_OTHER_NOTIFY %s"),*Name);
    if (!Remaining.IsEmpty()) return false;
    UE_LOG(LogTemp,Display,TEXT("GASP_NATIVE_FOLEY_CONVERTED=%d"),Count);
    return true;
}

