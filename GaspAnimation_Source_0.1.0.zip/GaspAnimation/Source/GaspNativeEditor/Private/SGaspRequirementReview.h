#pragma once

// Human review is separate from model evidence. Exact source location is resolved
// by the Python compiler; semantic support is explicitly attested by the user.
static TSharedRef<SWidget> MakeGaspRequirementReview(
    const TSharedPtr<FJsonObject>& Info, const FString& RequestText,
    TFunction<void()> Changed, TFunction<bool()> Idle)
{
    const auto IR=Info->GetObjectField(TEXT("behavior_requirements"));
    const TSharedPtr<FJsonObject>* Found=nullptr;
    TSharedPtr<FJsonObject> Review;
    if(Info->TryGetObjectField(TEXT("behavior_human_review"),Found)) Review=*Found;
    else
    {
        Review=MakeShared<FJsonObject>(); Review->SetNumberField(TEXT("version"),1);
        Review->SetObjectField(TEXT("fields"),MakeShared<FJsonObject>());
        Review->SetBoolField(TEXT("all_ir_confirmed"),false);
        Info->SetObjectField(TEXT("behavior_human_review"),Review);
    }
    if(!Review->HasTypedField<EJson::Object>(TEXT("fields"))) Review->SetObjectField(TEXT("fields"),MakeShared<FJsonObject>());
    const auto Fields=Review->GetObjectField(TEXT("fields"));
    const auto Box=SNew(SVerticalBox);
    Box->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("人工确认跳跃：逐项填写原文短句并确认其含义。程序只定位引用，不证明语义。修改后需重新确认、重新编译；不计为模型自动生成成功。")))];
    Box->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("原始需求：\n")+RequestText))];
    const TSharedPtr<FJsonObject>* JumpPtr=nullptr;
    const bool HasJump=IR->TryGetObjectField(TEXT("jump"),JumpPtr);
    const TSharedPtr<FJsonObject> Jump=HasJump ? *JumpPtr : nullptr;
    auto AddRow=[&](const FString& Key,const FString& Label,TSharedPtr<FJsonValue> Value,bool Editable,bool Numeric)
    {
        if(!Value.IsValid())Value=MakeShared<FJsonValueNull>();
        const TSharedPtr<FJsonObject>* Existing=nullptr;
        TSharedPtr<FJsonObject> Field;
        if(Fields->TryGetObjectField(Key,Existing)) Field=*Existing;
        else
        {
            Field=MakeShared<FJsonObject>(); Field->SetField(TEXT("value"),Value);
            Field->SetField(TEXT("original_value"),Value);
            Field->SetStringField(TEXT("quote"),TEXT("")); Field->SetBoolField(TEXT("confirmed"),false);
            Field->SetBoolField(TEXT("value_edited_by_human"),false); Fields->SetObjectField(Key,Field);
        }
        // The value presented must always be the current IR, never a stale confirmation.
        FString Current,Recorded;
        auto Render=[](TSharedPtr<FJsonValue> V){return !V.IsValid() || V->Type==EJson::Null ? FString(TEXT("未填写")) : V->Type==EJson::String ? V->AsString() : V->Type==EJson::Boolean ? (V->AsBool()?FString(TEXT("true")):FString(TEXT("false"))) : V->Type==EJson::Number ? FString::FromInt(int32(V->AsNumber())) : FString(TEXT("格式无效"));};
        Current=Render(Value); const auto Prior=Field->TryGetField(TEXT("value"));
        if(!Prior || Render(Prior)!=Current){Field->SetBoolField(TEXT("confirmed"),false);Review->SetBoolField(TEXT("all_ir_confirmed"),false);}
        Field->SetField(TEXT("value"),Value);
        FString Display=Current;
        if(!Editable)
        {
            if(Key==TEXT("jump_enabled"))Display=HasJump ? TEXT("允许实际起跳") : TEXT("没有跳跃策略（须与原文核对）");
            else if(Key==TEXT("trigger"))Display=TEXT("起跳事件（空格输入）");
            else if(Key==TEXT("count_when"))Display=TEXT("只在实际成功起跳时计数；拒绝的输入不计数");
            else if(Key==TEXT("reset_when"))Display=TEXT("角色真实落地时重置");
        }
        const auto Row=SNew(SVerticalBox);
        Row->AddSlot().AutoHeight()[SNew(SHorizontalBox)
            +SHorizontalBox::Slot().AutoWidth().Padding(4)[SNew(STextBlock).Text(FText::FromString(Label))]
            +SHorizontalBox::Slot().FillWidth(1)[SNew(SEditableTextBox).Text(FText::FromString(Display)).ToolTipText(FText::FromString(Current)).IsReadOnly(!Editable).IsEnabled_Lambda([Idle](){return Idle();})
                .OnTextChanged_Lambda([=](const FText& Text){
                    if(!Editable)return;
                    Field->SetBoolField(TEXT("uncommitted"),true);Field->SetStringField(TEXT("pending_text"),Text.ToString());
                    Field->SetBoolField(TEXT("confirmed"),false);Review->SetBoolField(TEXT("all_ir_confirmed"),false);
                    Review->RemoveField(TEXT("compiled_signature"));Changed();})
                .OnTextCommitted_Lambda([=](const FText& Text,ETextCommit::Type){
                    if(!Editable || !Idle())return;
                    bool Dirty=false;Field->TryGetBoolField(TEXT("uncommitted"),Dirty);if(!Dirty)return;
                    TSharedPtr<FJsonValue> NewValue;
                    if(Numeric){int32 N=0;if(!LexTryParseString(N,*Text.ToString()) || N<1 || N>8){Field->SetStringField(TEXT("input_error"),TEXT("次数必须为1～8的整数"));Field->SetBoolField(TEXT("confirmed"),false);Review->SetBoolField(TEXT("all_ir_confirmed"),false);Changed();return;}NewValue=MakeShared<FJsonValueNumber>(N);}
                    else NewValue=MakeShared<FJsonValueString>(Text.ToString());
                    Field->RemoveField(TEXT("input_error"));
                    Field->RemoveField(TEXT("uncommitted"));Field->RemoveField(TEXT("pending_text"));
                    Jump->SetField(Key,NewValue);Field->SetField(TEXT("value"),NewValue);
                    Field->SetBoolField(TEXT("value_edited_by_human"),true);Field->SetBoolField(TEXT("confirmed"),false);
                    Review->SetBoolField(TEXT("all_ir_confirmed"),false);Changed();})]];
        Row->AddSlot().AutoHeight()[SNew(SEditableTextBox).HintText(FText::FromString(TEXT("粘贴支持此项规则的连续原文短句"))).Text(FText::FromString(Field->GetStringField(TEXT("quote")))).IsEnabled_Lambda([Idle](){return Idle();})
            .OnTextChanged_Lambda([=](const FText& T){Field->SetStringField(TEXT("quote"),T.ToString());Field->SetBoolField(TEXT("quote_edited_by_human"),true);Field->SetBoolField(TEXT("confirmed"),false);Review->SetBoolField(TEXT("all_ir_confirmed"),false);Changed();})];
        Row->AddSlot().AutoHeight()[SNew(STextBlock).ColorAndOpacity(FSlateColor(FLinearColor(1,.35f,.1f))).Text_Lambda([=](){bool Dirty=false;Field->TryGetBoolField(TEXT("uncommitted"),Dirty);if(Dirty)return FText::FromString(TEXT("输入尚未提交：旧确认已取消，请按回车或移开焦点后重新确认"));FString Error;if(Field->TryGetStringField(TEXT("input_error"),Error))return FText::FromString(Error);const FString Q=Field->GetStringField(TEXT("quote"));return FText::FromString(Q.TrimStartAndEnd().IsEmpty() || !RequestText.Contains(Q,ESearchCase::CaseSensitive) ? TEXT("缺失或无法在原文精确找到依据") : TEXT("已找到原文；请人工判断它是否支持本项规则"));})];
        Row->AddSlot().AutoHeight()[SNew(SCheckBox).IsEnabled_Lambda([=](){bool Dirty=false;Field->TryGetBoolField(TEXT("uncommitted"),Dirty);const FString Q=Field->GetStringField(TEXT("quote"));return Idle() && !Dirty && !Field->HasField(TEXT("input_error")) && !Q.TrimStartAndEnd().IsEmpty() && RequestText.Contains(Q,ESearchCase::CaseSensitive);})
            .IsChecked_Lambda([=](){return Field->GetBoolField(TEXT("confirmed"))?ECheckBoxState::Checked:ECheckBoxState::Unchecked;})
            .OnCheckStateChanged_Lambda([=](ECheckBoxState S){Field->SetBoolField(TEXT("confirmed"),S==ECheckBoxState::Checked);Field->SetStringField(TEXT("confirmed_utc"),FDateTime::UtcNow().ToIso8601());Review->SetBoolField(TEXT("all_ir_confirmed"),false);Changed();})
            [SNew(STextBlock).Text(FText::FromString(TEXT("我确认此值正确，且上述原文支持这项规则")))]];
        Box->AddSlot().AutoHeight().Padding(4)[Row];
    };
    AddRow(TEXT("jump_enabled"),TEXT("是否有实际跳跃"),MakeShared<FJsonValueBoolean>(HasJump),false,false);
    if(HasJump)
    {
        for(const auto& Pair:TArray<TPair<FString,FString>>{{TEXT("group"),TEXT("空中父组")},{TEXT("rise"),TEXT("上升状态")},{TEXT("fall"),TEXT("下降状态")},{TEXT("counter"),TEXT("内部计数变量")},{TEXT("max_jumps"),TEXT("每次落地前最多起跳次数（1～8）")}})
            AddRow(Pair.Key,Pair.Value,Jump->TryGetField(Pair.Key),true,Pair.Key==TEXT("max_jumps"));
        AddRow(TEXT("trigger"),TEXT("触发事件"),MakeShared<FJsonValueString>(TEXT("Jump")),false,false);
        AddRow(TEXT("initial"),TEXT("计数初始值"),MakeShared<FJsonValueNumber>(0),false,false);
        AddRow(TEXT("count_when"),TEXT("计数时机：仅成功起跳"),MakeShared<FJsonValueString>(TEXT("successful_launch_only")),false,false);
        AddRow(TEXT("increment"),TEXT("每次成功起跳增加"),MakeShared<FJsonValueNumber>(1),false,false);
        AddRow(TEXT("reset_when"),TEXT("重置事件：真实落地"),MakeShared<FJsonValueString>(TEXT("Landed")),false,false);
        AddRow(TEXT("reset_value"),TEXT("落地后重置为"),MakeShared<FJsonValueNumber>(0),false,false);
    }
    Box->AddSlot().AutoHeight().Padding(4)[SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("触发、初值、计数与重置为当前编译器支持的固定行为；不同需求请保留未确认。添加/取消跳跃、编辑层级和连招，请使用下方高级IR编辑区；不会自动补出策略。")))];
    Box->AddSlot().AutoHeight().Padding(4)[SNew(SCheckBox).IsEnabled_Lambda([Idle](){return Idle();})
        .IsChecked_Lambda([=](){return Review->GetBoolField(TEXT("all_ir_confirmed"))?ECheckBoxState::Checked:ECheckBoxState::Unchecked;})
        .OnCheckStateChanged_Lambda([=](ECheckBoxState S){
            Review->SetBoolField(TEXT("all_ir_confirmed"),S==ECheckBoxState::Checked);Review->SetStringField(TEXT("request"),RequestText);
            FString Snapshot;FJsonSerializer::Serialize(IR.ToSharedRef(),TJsonWriterFactory<>::Create(&Snapshot));TSharedPtr<FJsonObject> Copy;
            FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Snapshot),Copy);Review->SetObjectField(TEXT("reviewed_ir"),Copy);Changed();})
        [SNew(STextBlock).AutoWrapText(true).Text(FText::FromString(TEXT("我已审阅全部需求IR，包括层级、入口、连招、外部变量和未支持项；重新编译仍须通过全部校验。")))]];
    return Box;
}
