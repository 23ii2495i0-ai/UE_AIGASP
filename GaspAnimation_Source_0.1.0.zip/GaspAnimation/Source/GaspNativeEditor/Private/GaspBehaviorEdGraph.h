#pragma once
#include "CoreMinimal.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraphSchema.h"
#include "GaspBehaviorEdGraph.generated.h"

UCLASS()
class UGaspBehaviorEdNode : public UEdGraphNode
{
    GENERATED_BODY()
public:
    UPROPERTY() FString StateId;
    UPROPERTY() FString Player;
    UPROPERTY() FString ParentPath;
    UPROPERTY() FString InitialState;
    virtual FText GetNodeTitle(ENodeTitleType::Type Type) const override
    {
        return FText::FromString((ParentPath.IsEmpty()?FString():ParentPath+TEXT(" /\n"))+StateId+TEXT("\n")+(Player==TEXT("group")?TEXT("分组 → ")+InitialState:Player));
    }
    virtual FLinearColor GetNodeTitleColor() const override{return Player==TEXT("group")?FLinearColor(.4f,.29f,.05f):(Player==TEXT("locomotion") || Player==TEXT("mm") ? FLinearColor(.03f,.35f,.38f):FLinearColor(.35f,.16f,.4f));}
    virtual void AllocateDefaultPins() override;
};
UCLASS()
class UGaspBehaviorEdSchema : public UEdGraphSchema
{
    GENERATED_BODY()
public:
    virtual const FPinConnectionResponse CanCreateConnection(const UEdGraphPin* A,const UEdGraphPin* B) const override;
    virtual bool TryCreateConnection(UEdGraphPin* A,UEdGraphPin* B) const override;
    virtual void BreakPinLinks(UEdGraphPin& Pin,bool bSendsNodeNotification) const override;
};
