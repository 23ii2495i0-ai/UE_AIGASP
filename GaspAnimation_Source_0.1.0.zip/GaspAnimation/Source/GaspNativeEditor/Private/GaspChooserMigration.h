#pragma once
#include "CoreMinimal.h"
class UChooserTable;
UChooserTable* BuildGaspChooserTable(const FString& Rules, const FString& PackageName, UClass* ResultClass);
bool ValidateGaspChooserMigration(const FString& Rules, UChooserTable* Table);
