#include "Modules/ModuleManager.h"
#include "GaspConfigTool.h"
class FGaspNativeEditorModule : public IModuleInterface
{
public:
    virtual void StartupModule() override { if (!IsRunningCommandlet() && !IsRunningGame()) GaspConfigTool::Register(); }
    virtual void ShutdownModule() override { if (!IsRunningCommandlet() && !IsRunningGame()) GaspConfigTool::Unregister(); }
};
IMPLEMENT_MODULE(FGaspNativeEditorModule, GaspNativeEditor);
