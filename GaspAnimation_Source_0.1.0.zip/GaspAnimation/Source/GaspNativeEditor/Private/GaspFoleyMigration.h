#pragma once
bool MigrateGaspFoleyNotifies();
