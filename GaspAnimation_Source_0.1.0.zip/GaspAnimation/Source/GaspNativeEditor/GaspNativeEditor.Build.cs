using UnrealBuildTool;

public class GaspNativeEditor : ModuleRules
{
    public GaspNativeEditor(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PrivateDependencyModuleNames.AddRange(new[] {
            "Core", "CoreUObject", "Engine", "GaspNative", "UnrealEd", "AnimGraph",
            "BlueprintGraph", "GraphEditor", "Kismet", "KismetCompiler", "AssetRegistry", "Projects",
            "AnimGraphRuntime", "PoseSearch", "PoseSearchEditor", "BlendStack",
            "AnimationWarpingRuntime", "AnimationWarpingEditor", "Json", "Chooser", "Slate", "SlateCore", "ToolMenus", "ContentBrowser", "InputCore", "PropertyEditor", "PythonScriptPlugin"
        });
    }
}


