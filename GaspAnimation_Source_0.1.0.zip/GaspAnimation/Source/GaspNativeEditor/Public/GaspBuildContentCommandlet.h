#pragma once
#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "GaspBuildContentCommandlet.generated.h"

UCLASS()
class UGaspBuildContentCommandlet : public UCommandlet
{
    GENERATED_BODY()
public:
    UGaspBuildContentCommandlet();
    virtual int32 Main(const FString& Params) override;
};
