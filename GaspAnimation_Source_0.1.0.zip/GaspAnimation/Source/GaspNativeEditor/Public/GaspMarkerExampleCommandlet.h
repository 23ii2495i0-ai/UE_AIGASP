#pragma once
#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "GaspMarkerExampleCommandlet.generated.h"
UCLASS()
class UGaspMarkerExampleCommandlet : public UCommandlet
{
    GENERATED_BODY()
public:
    UGaspMarkerExampleCommandlet() { IsClient=false; IsServer=false; IsEditor=true; LogToConsole=true; }
    virtual int32 Main(const FString& Params) override;
};
