#pragma once
#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "GaspConfigureCommandlet.generated.h"
UCLASS()
class UGaspConfigureCommandlet : public UCommandlet
{
    GENERATED_BODY()
public:
    UGaspConfigureCommandlet() { IsClient=false; IsServer=false; IsEditor=true; LogToConsole=true; }
    virtual int32 Main(const FString& Params) override;
};
