#pragma once
#include "CoreMinimal.h"
#include "AnimGraphNode_Base.h"
#include "AnimNode_GaspSampleWarp.h"
#include "AnimGraphNode_GaspSampleWarp.generated.h"

UCLASS()
class UAnimGraphNode_GaspSampleWarp : public UAnimGraphNode_Base
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, Category=Settings) FAnimNode_GaspSampleWarp Node;
    virtual FText GetNodeTitle(ENodeTitleType::Type) const override { return FText::FromString(TEXT("GASP native sample warping")); }
    virtual FText GetTooltipText() const override { return GetNodeTitle(ENodeTitleType::FullTitle); }
    virtual FString GetNodeCategory() const override { return TEXT("GASP"); }
};
