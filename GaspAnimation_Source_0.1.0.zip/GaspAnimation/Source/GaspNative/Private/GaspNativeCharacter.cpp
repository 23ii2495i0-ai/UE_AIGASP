#include "GaspNativeCharacter.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/InputComponent.h"
#include "Engine/SkeletalMesh.h"
#include "GaspAnimationSettings.h"
#include "GaspAnimationSet.h"
#include "GaspCppAnimInstance.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "GaspTraversalComponent.h"
#include "GaspActionFlowComponent.h"
#include "GaspBehaviorComponent.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "MotionWarpingComponent.h"


AGaspNativeCharacter::AGaspNativeCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCapsuleComponent()->InitCapsuleSize(30.f, 86.f);
    GetMesh()->SetRelativeLocation(FVector(0, 0, -88));
    GetMesh()->SetRelativeRotation(FRotator(0, -90, 0));
    GetMesh()->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
    GetMesh()->bEnableUpdateRateOptimizations = false;
    GetMesh()->SetDisablePostProcessBlueprint(true);
    bUseControllerRotationYaw = false;
    auto* Move = GetCharacterMovement();
    Move->JumpZVelocity = 500.f;
    Move->AirControl = .25f;
    Move->AirControlBoostMultiplier = 2.f;
    Move->AirControlBoostVelocityThreshold = 25.f;
    Move->MaxAcceleration = 800.f;
    Move->BrakingFrictionFactor = 1.f;
    Move->BrakingFriction = 0.f;
    Move->bUseSeparateBrakingFriction = true;
    Move->BrakingSubStepTime = 1.f / 33.f;
    Move->MinAnalogWalkSpeed = 150.f;
    Move->MaxWalkSpeed = 500.f;
    Move->MaxWalkSpeedCrouched = 225.f;
    Move->SetCrouchedHalfHeight(60.f);
    Move->GetNavAgentPropertiesRef().bCanCrouch = true;
    Move->bUseFlatBaseForFloorChecks = true;
    Move->PerchRadiusThreshold = 20.f;
    Move->MaxStepHeight = 45.f;
    Move->SetWalkableFloorAngle(44.765f);
    Move->RotationRate = FRotator(0, -1, 0); // CMC's negative rate means snap.
    Move->bUseControllerDesiredRotation = true;
    MotionWarping = CreateDefaultSubobject<UMotionWarpingComponent>(TEXT("MotionWarping"));
    Traversal = CreateDefaultSubobject<UGaspTraversalComponent>(TEXT("Traversal"));
    ActionFlow = CreateDefaultSubobject<UGaspActionFlowComponent>(TEXT("ActionFlow"));
    Behavior = CreateDefaultSubobject<UGaspBehaviorComponent>(TEXT("Behavior"));
    Move->PrimaryComponentTick.AddPrerequisite(Behavior,Behavior->PrimaryComponentTick);
    CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
    CameraBoom->SetupAttachment(RootComponent);
    CameraBoom->TargetArmLength = 300;
    CameraBoom->SocketOffset = FVector(0, 35, 65);
    CameraBoom->bUsePawnControlRotation = true;
    CameraBoom->bEnableCameraLag = true;
    CameraBoom->CameraLagSpeed = 12.f;
    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
    Camera->SetupAttachment(CameraBoom);
    Camera->FieldOfView = 90.f;
    AnimationClass = UGaspCppAnimInstance::StaticClass();
    if (FParse::Param(FCommandLine::Get(), TEXT("LegacyAnimGraph")))
        AnimationClass = TSoftClassPtr<UAnimInstance>(FSoftObjectPath(TEXT("/Game/Native/ABP_Gasp_Host.ABP_Gasp_Host_C")));
}

void AGaspNativeCharacter::BeginPlay()
{
    UGaspAnimationSet* Resources = AnimationSetOverride;
    FString ConfigProfile;
    if (FParse::Value(FCommandLine::Get(),TEXT("AnimationSet="),ConfigProfile))
        Resources=LoadObject<UGaspAnimationSet>(nullptr,*ConfigProfile);
    if (!Resources) Resources = GetDefault<UGaspAnimationSettings>()->DefaultAnimationSet.LoadSynchronous();
    if (Resources)
    {
        if (USkeletalMesh* CharacterMeshAsset = Resources->Mesh.LoadSynchronous()) GetMesh()->SetSkeletalMesh(CharacterMeshAsset);
        GetMesh()->SetRelativeRotation(FRotator(0, Resources->Bones.MeshYawOffset, 0));
    }
    if (UClass* Class = AnimationClass.LoadSynchronous())
    {
        if (Class->IsChildOf(UGaspCppAnimInstance::StaticClass()))
        {
            AnimationSetOverride=Resources;
            // Components may already own an instance initialized from the blueprint CDO.
            // Assigning the same class is a no-op: reinitialize after selecting the resources.
            GetMesh()->SetAnimInstanceClass(nullptr);
        }
        GetMesh()->SetAnimInstanceClass(Class);
    }
    Super::BeginPlay();
}

bool AGaspNativeCharacter::ApplyAnimationSet(UGaspAnimationSet* Resources)
{
    if (!Resources || Traversal->bDoingTraversal || !ActionFlow->ActiveAction.IsNone()) return false;
    USkeletalMesh* Target=Resources->Mesh.LoadSynchronous();
    FString Error;
    if (!Resources->ValidateForMesh(Target, Error)) return false;
    GetMesh()->GetAnimInstance()->Montage_Stop(0.f);
    AnimationSetOverride=Resources;
    GetMesh()->SetSkeletalMesh(Target);
    GetMesh()->SetRelativeRotation(FRotator(0,Resources->Bones.MeshYawOffset,0));
    // A resource swap must discard the proxy's continuing pose and blend players.
    UClass* RuntimeClass=GetMesh()->GetAnimInstance()->GetClass();
    GetMesh()->SetAnimInstanceClass(nullptr);
    GetMesh()->SetAnimInstanceClass(RuntimeClass);
    return true;
}

bool AGaspNativeCharacter::CanSprint() const
{
    if (!bWantsToSprint || bIsCrouched || (bWantsToAim && !(AnimationSetOverride && AnimationSetOverride->ActionPolicy.bBlockAimWhenSprinting))) return false;
    if (!bWantsToStrafe) return true;
    FVector Direction = GetCharacterMovement()->GetCurrentAcceleration();
    if (Direction.IsNearlyZero()) Direction = GetPendingMovementInputVector();
    return FMath::Abs(FMath::FindDeltaAngleDegrees(GetActorRotation().Yaw, Direction.Rotation().Yaw)) < 50.f;
}

bool AGaspNativeCharacter::IsAimAllowed() const
{
    return bWantsToAim && !(AnimationSetOverride && AnimationSetOverride->ActionPolicy.bBlockAimWhenSprinting && CanSprint());
}

float AGaspNativeCharacter::DirectionalSpeed(const FVector& Speeds) const
{
    float Strafe = 0.f;
    if (GetCharacterMovement()->bUseControllerDesiredRotation)
    {
        const FVector Local = GetActorQuat().UnrotateVector(GetVelocity());
        const float Angle = FMath::Abs(FMath::RadiansToDegrees(FMath::Atan2(Local.Y, Local.X)));
        const float Angles[] = { 0, 45, 80, 100, 135, 180 };
        const float Values[] = { 0, 0, 1, 1, 2, 2 };
        for (int32 I = 1; I < 6; ++I)
            if (Angle <= Angles[I])
            {
                Strafe = FMath::GetMappedRangeValueClamped(FVector2D(Angles[I-1], Angles[I]), FVector2D(Values[I-1], Values[I]), Angle);
                break;
            }
    }
    return Strafe < 1 ? FMath::Lerp(Speeds.X, Speeds.Y, Strafe) : FMath::Lerp(Speeds.Y, Speeds.Z, Strafe - 1);
}

void AGaspNativeCharacter::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    auto* Move = GetCharacterMovement();
    Move->bUseControllerDesiredRotation = bWantsToStrafe || IsAimAllowed();
    if(Behavior->IsEnabled() && !Behavior->AllowsMovement())ConsumeMovementInputVector();
    Move->bOrientRotationToMovement = !Move->bUseControllerDesiredRotation;
    Gait = CanSprint() ? EGaspGait::Sprint : (bWantsToWalk ? EGaspGait::Walk : EGaspGait::Run);
    const FVector Speeds[] = { FVector(200,180,150), FVector(500,350,300), FVector(700,700,700) };
    Move->MaxWalkSpeed = DirectionalSpeed(Speeds[uint8(Gait)]);
    Move->MaxWalkSpeedCrouched = DirectionalSpeed(FVector(225,200,180));
    const float Speed = GetVelocity().Size2D();
    Move->MaxAcceleration = Gait == EGaspGait::Sprint ? FMath::GetMappedRangeValueClamped(FVector2D(300,700), FVector2D(800,300), Speed) : 800.f;
    Move->GroundFriction = Gait == EGaspGait::Sprint ? FMath::GetMappedRangeValueClamped(FVector2D(0,500), FVector2D(5,3), Speed) : 5.f;
    Move->BrakingDecelerationWalking = GetPendingMovementInputVector().IsNearlyZero() ? 2000.f : 500.f;
    JustLandedTime = FMath::Max(0.f, JustLandedTime - DeltaSeconds);
    if (bJumpHeld && !Traversal->bDoingTraversal) Traversal->TryTraversal();
}

void AGaspNativeCharacter::Landed(const FHitResult& Hit)
{
    LandVelocity = GetVelocity();
    JustLandedTime = .3f;
    Super::Landed(Hit);
    if(Behavior->IsEnabled())Behavior->SendEvent(TEXT("Landed"));
    if (ActionFlow->ActiveAction==TEXT("jump")) ActionFlow->RequestLocomotion();
    // A jump interrupted by damage must not resume its airborne pose after landing.
    if (ActionFlow->SuspendedAction==TEXT("jump")) ActionFlow->SuspendedAction=NAME_None;
}

void AGaspNativeCharacter::OnJumped_Implementation()
{
    Super::OnJumped_Implementation();
    if(Behavior->IsEnabled())Behavior->SendEvent(TEXT("Jumped"));else ActionFlow->RequestAction(TEXT("jump"));
}

float AGaspNativeCharacter::TakeDamage(float DamageAmount,const FDamageEvent& DamageEvent,AController* EventInstigator,AActor* DamageCauser)
{
    const float Applied=Super::TakeDamage(DamageAmount,DamageEvent,EventInstigator,DamageCauser);
    if (Applied>0 && !IsActorBeingDestroyed()) {if(Behavior->IsEnabled())Behavior->SendEvent(TEXT("Hit"));else ActionFlow->RequestAction(TEXT("hit"));}
    return Applied;
}

void AGaspNativeCharacter::MoveForward(float Value)
{
    RawMoveInput.X=FMath::Clamp(Value,-1.f,1.f);
    if (Controller && !Traversal->bDoingTraversal && Behavior->AllowsMovement())
        AddMovementInput(FRotationMatrix(FRotator(0, Controller->GetControlRotation().Yaw, 0)).GetUnitAxis(EAxis::X), Value);
}
void AGaspNativeCharacter::MoveRight(float Value)
{
    RawMoveInput.Y=FMath::Clamp(Value,-1.f,1.f);
    if (Controller && !Traversal->bDoingTraversal && Behavior->AllowsMovement())
        AddMovementInput(FRotationMatrix(FRotator(0, Controller->GetControlRotation().Yaw, 0)).GetUnitAxis(EAxis::Y), Value);
}
void AGaspNativeCharacter::Turn(float Value) { AddControllerYawInput(Value * .175f); }
void AGaspNativeCharacter::LookUp(float Value) { AddControllerPitchInput(Value * .175f); }
void AGaspNativeCharacter::JumpPressed() { if (ActionFlow->IsActionLocked() || !Behavior->AllowsMovement() || Behavior->HandlesKey(TEXT("SpaceBar"))) return; bJumpHeld = true; if (!Traversal->TryTraversal()) Jump(); }
void AGaspNativeCharacter::AttackPressed() { if(Behavior->IsEnabled()){if(!Behavior->HandlesKey(TEXT("LeftMouseButton")))Behavior->SendEvent(TEXT("Attack"));}else ActionFlow->RequestAction(TEXT("attack")); }
void AGaspNativeCharacter::HitPressed() { if(Behavior->IsEnabled()){if(!Behavior->HandlesKey(TEXT("H")))Behavior->SendEvent(TEXT("Hit"));}else ActionFlow->RequestAction(TEXT("hit")); }
void AGaspNativeCharacter::DodgePressed() { if(Behavior->IsEnabled()){if(!Behavior->HandlesKey(TEXT("LeftAlt")))Behavior->SendEvent(TEXT("Dodge"));}else ActionFlow->RequestAction(TEXT("dodge")); }
void AGaspNativeCharacter::AimPressed(){if(!Behavior->HandlesKey(TEXT("RightMouseButton")))bWantsToAim=true;}
void AGaspNativeCharacter::AimReleased(){if(!Behavior->HandlesKey(TEXT("RightMouseButton")))bWantsToAim=false;}
void AGaspNativeCharacter::JumpReleased() { if(Behavior->HandlesKey(TEXT("SpaceBar")))return; bJumpHeld = false; StopJumping(); }
void AGaspNativeCharacter::CrouchPressed() { if(Behavior->HandlesKey(TEXT("C")))return; if (bIsCrouched) UnCrouch(); else Crouch(); }
void AGaspNativeCharacter::SprintPressed(){if(!Behavior->HandlesKey(TEXT("LeftShift")))bWantsToSprint=true;}
void AGaspNativeCharacter::SprintReleased(){if(!Behavior->HandlesKey(TEXT("LeftShift")))bWantsToSprint=false;}
void AGaspNativeCharacter::WalkPressed(){if(!Behavior->HandlesKey(TEXT("LeftControl")))bWantsToWalk=!bWantsToWalk;}
void AGaspNativeCharacter::StrafePressed(){if(!Behavior->HandlesKey(TEXT("Q")))bWantsToStrafe=!bWantsToStrafe;}

void AGaspNativeCharacter::SetupPlayerInputComponent(UInputComponent* Input)
{
    Super::SetupPlayerInputComponent(Input);
    Input->BindAxis("MoveForward", this, &ThisClass::MoveForward);
    Input->BindAxis("MoveRight", this, &ThisClass::MoveRight);
    Input->BindAxis("Turn", this, &ThisClass::Turn);
    Input->BindAxis("LookUp", this, &ThisClass::LookUp);
    Input->BindAction("Jump", IE_Pressed, this, &ThisClass::JumpPressed);
    Input->BindAction("Jump", IE_Released, this, &ThisClass::JumpReleased);
    Input->BindAction("Sprint", IE_Pressed, this, &ThisClass::SprintPressed);
    Input->BindAction("Sprint", IE_Released, this, &ThisClass::SprintReleased);
    Input->BindAction("Walk", IE_Pressed, this, &ThisClass::WalkPressed);
    Input->BindAction("Crouch", IE_Pressed, this, &ThisClass::CrouchPressed);
    Input->BindAction("Aim", IE_Pressed, this, &ThisClass::AimPressed);
    Input->BindAction("Aim", IE_Released, this, &ThisClass::AimReleased);
    Input->BindAction("Strafe", IE_Pressed, this, &ThisClass::StrafePressed);
    Input->BindAction("Attack", IE_Pressed, this, &ThisClass::AttackPressed);
    Input->BindAction("Hit", IE_Pressed, this, &ThisClass::HitPressed);
    Input->BindAction("Dodge", IE_Pressed, this, &ThisClass::DodgePressed);
    Behavior->BindInputs(Input);
}



