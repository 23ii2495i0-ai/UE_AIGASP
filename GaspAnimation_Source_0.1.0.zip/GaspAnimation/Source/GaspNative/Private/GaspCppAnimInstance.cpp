#include "GaspCppAnimInstance.h"
#include "GaspAnimationSet.h"
#include "AnimNode_GaspSampleWarp.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimRootMotionProvider.h"
#include "Animation/AnimNodeMessages.h"
#include "Animation/AnimNodeSpaceConversions.h"
#include "AnimNodes/AnimNode_TwoWayBlend.h"
#include "Animation/AnimNode_ApplyMeshSpaceAdditive.h"
#include "AnimNodes/AnimNode_BlendSpacePlayer.h"
#include "AnimNodes/AnimNode_Slot.h"
#include "BoneControllers/AnimNode_OffsetRootBone.h"
#include "BoneControllers/AnimNode_FootPlacement.h"
#include "BoneControllers/AnimNode_LegIK.h"
#include "BlendStack/AnimNode_BlendStack.h"
#include "BlendStack/AnimNode_BlendStackInput.h"
#include "PoseSearch/AnimNode_PoseSearchHistoryCollector.h"
#include "PoseSearch/PoseSearchLibrary.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "UObject/UObjectGlobals.h"

namespace
{
struct FGaspCppReferencePose : FAnimNode_Base
{
    virtual void Evaluate_AnyThread(FPoseContext& Output) override { Output.ResetToRefPose(); }
};
// Standalone BlendStack avoids folded properties which require a compiled ABP.
// Selection uses the engine's core MM entry point, with the same continuation,
// throttle, reselection history and play-rate settings as the existing graph.
struct FGaspCppMotionMatching : FAnimNode_BlendStack_Standalone
{
    FGaspCppMotionMatching() { PlayerDepthBlendInTimeMultiplier=1.1f; MaxBlendInTimeToOverrideAnimation=.03f; }
    UGaspNativeAnimInstance* Anim = nullptr;
    TArray<TObjectPtr<const UPoseSearchDatabase>> Databases;
    FMotionMatchingState State;
    EPoseSearchInterruptMode Interrupt = EPoseSearchInterruptMode::DoNotInterrupt;

    virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override
    {
        State.Reset();
        FAnimNode_BlendStack_Standalone::Initialize_AnyThread(Context);
    }
    virtual void UpdateAssetPlayer(const FAnimationUpdateContext& Context) override
    {
        if (!Anim || !Anim->bAnimationSetValid) return;
        if (State.SearchResult.SelectedAnim && !AnimPlayers.IsEmpty()) State.SearchResult.SelectedTime=GetCurrentAssetTime();
        FChooserEvaluationContext SearchContext(Anim);
        const FVector2D Rates=Anim->AnimationSet->PlayRateRange;
        PRAGMA_DISABLE_DEPRECATION_WARNINGS
        UPoseSearchLibrary::UpdateMotionMatchingState(&SearchContext, Anim->GetSearchPoseHistory(), Databases,
            Context.GetDeltaTime(), FFloatInterval(0,0), .3f, 0.f, FFloatInterval(Rates.X,Rates.Y), State, Interrupt, false);
        PRAGMA_ENABLE_DEPRECATION_WARNINGS
        Interrupt=EPoseSearchInterruptMode::DoNotInterrupt;
        const auto& Result=State.SearchResult;
        if (auto* Asset=Cast<UAnimationAsset>(Result.SelectedAnim))
        {
            if (!Result.bIsContinuingPoseSearch || AnimPlayers.IsEmpty())
            {
                UMirrorDataTable* Mirror=nullptr;
                if (Result.SelectedDatabase && Result.SelectedDatabase->Schema)
                {
                    const auto* Schema=Result.SelectedDatabase->Schema.Get();
                    Mirror=Schema->GetMirrorDataTable(Schema->GetDefaultRole());
                }
                BlendTo(Context, Asset, Result.SelectedTime, Result.bLoop, Result.bIsMirrored, Mirror,
                    Anim->MotionBlendTime, nullptr, EAlphaBlendOption::Linear, false, NAME_None,
                    Result.BlendParameters, Result.WantedPlayRate);
            }
            UpdatePlayRate(Result.WantedPlayRate);
        }
        NotifyRecencyTimeOut=Anim->NotifyRecencyTimeOut;
        FAnimNode_BlendStack_Standalone::UpdateAssetPlayer(Context);
    }
};

// Port of native/src/anim_graph.cpp::EvaluateOffsetRoot. Parameters remain
// ordinary native data in cooked builds; no generated-class folded properties.
struct FGaspCppOffsetRoot : FAnimNode_Base
{
    FPoseLink Source;
    EOffsetRootBoneMode TranslationMode=EOffsetRootBoneMode::Interpolate, RotationMode=EOffsetRootBoneMode::Interpolate;
    float TranslationHalflife=.1f, RotationHalfLife=.1f, MaxTranslationError=30;
    bool bClampToTranslationVelocity=false, bEnabled=true;
    FTransform Component=FTransform::Identity;
    FQuat Rotation=FQuat::Identity;
    FVector Translation=FVector::ZeroVector;
    float DeltaTime=0;
    virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override
    {
        FAnimNode_Base::Initialize_AnyThread(Context);
        Component=Context.AnimInstanceProxy->GetComponentTransform();
        Rotation=Component.GetRotation(); Translation=Component.GetLocation();
        Source.Initialize(Context);
    }
    virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override { Source.CacheBones(Context); }
    virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override
    {
        DeltaTime=Context.GetDeltaTime();
        UE::Anim::TScopedGraphMessage<UE::AnimationWarping::FRootOffsetProvider> Provider(Context,FTransform(Rotation,Translation));
        Source.Update(Context);
    }
    static bool Extract(EOffsetRootBoneMode Mode)
    {
        return Mode==EOffsetRootBoneMode::Accumulate || Mode==EOffsetRootBoneMode::Interpolate ||
            Mode==EOffsetRootBoneMode::LockOffsetAndConsumeAnimation || Mode==EOffsetRootBoneMode::LockOffsetIncreaseAndConsumeAnimation;
    }
    static bool Counter(EOffsetRootBoneMode Mode) { return Mode!=EOffsetRootBoneMode::Accumulate && Mode!=EOffsetRootBoneMode::Interpolate; }
    float Damp(float Halflife) const
    {
        return FMath::Clamp(float(1.0-FMath::InvExpApprox((.69314718056*DeltaTime)/(FMath::Max(Halflife,DeltaTime)+1.e-8f))),0.f,1.f);
    }
    virtual void Evaluate_AnyThread(FPoseContext& Output) override
    {
        Source.Evaluate(Output);
        if (!bEnabled) return;
        const FTransform Last=Component;
        Component=Output.AnimInstanceProxy->GetComponentTransform();
        FTransform Motion=FTransform::Identity;
        if (const auto* Provider=UE::Anim::IAnimRootMotionProvider::Get()) Provider->ExtractRootMotion(Output.CustomAttributes,Motion);
        FTransform Consumed=FTransform::Identity;
        if (Extract(TranslationMode)) Consumed.SetTranslation(Motion.GetTranslation());
        if (Extract(RotationMode)) Consumed.SetRotation(Motion.GetRotation());
        if (Counter(RotationMode)) Rotation=(Last.GetRotation().Inverse()*Component.GetRotation())*Rotation;
        if (Counter(TranslationMode)) Translation+=Component.GetTranslation()-Last.GetTranslation();
        if (TranslationMode==EOffsetRootBoneMode::LockOffsetIncreaseAndConsumeAnimation)
        {
            const FVector Direction=Rotation.UnrotateVector((Translation-Component.GetTranslation()).GetSafeNormal()).GetSafeNormal();
            Consumed.SetTranslation(Direction*FVector::DotProduct(Consumed.GetTranslation(),Direction));
        }
        const FTransform Sim=Consumed*FTransform(Rotation,Translation);
        Translation=FVector::PointPlaneProject(Sim.GetTranslation(),Component.GetTranslation(),FVector(0,0,-1));
        Rotation=Sim.GetRotation();
        if (TranslationMode==EOffsetRootBoneMode::Release || TranslationMode==EOffsetRootBoneMode::Interpolate)
        {
            FVector Delta=(Component.GetTranslation()-Translation)*Damp(TranslationHalflife);
            const double MaxDelta=.5*Motion.GetTranslation().Size();
            if (bClampToTranslationVelocity && Delta.Size()>MaxDelta) Delta=Delta.GetSafeNormal2D()*MaxDelta;
            Translation+=Delta;
        }
        if (RotationMode==EOffsetRootBoneMode::Release || RotationMode==EOffsetRootBoneMode::Interpolate)
        {
            FQuat Offset=(Component.GetRotation()*Rotation.Inverse()).GetNormalized();
            if (Offset.W<0) Offset=Offset*-1.;
            Rotation=FQuat::Slerp(FQuat::Identity,Offset,Damp(RotationHalfLife))*Rotation;
        }
        if (MaxTranslationError>=0)
            Translation=Component.GetTranslation()-(Component.GetTranslation()-Translation).GetClampedToMaxSize(MaxTranslationError);
        const FTransform Relative=FTransform(Rotation,Translation)*Component.Inverse();
        FTransform& Root=Output.Pose[FCompactPoseBoneIndex(0)];
        Root.SetRotation(Relative.GetRotation()*Root.GetRotation());
        Root.AddToTranslation(Relative.GetTranslation()); Root.NormalizeRotation();
    }
    virtual void GatherDebugData(FNodeDebugData& DebugData) override { Source.GatherDebugData(DebugData); }
};

struct FGaspCppAnimProxy : FAnimInstanceProxy
{
    FGaspCppMotionMatching Motion;
    FGaspCppReferencePose Reference;
    FAnimNode_TwoWayBlend StopBlend;
    FAnimNode_BlendSpacePlayer_Standalone Lean, Aim;
    FAnimNode_ApplyMeshSpaceAdditive ApplyLean;
    FAnimNode_ApplyMeshSpaceAdditive ApplyAim;
    FAnimNode_Slot Slot;
    FGaspCppOffsetRoot Offset;
    FAnimNode_ConvertLocalToComponentSpace ToComponent;
    FAnimNode_FootPlacement Feet;
    FAnimNode_LegIK Legs;
    FAnimNode_ConvertComponentToLocalSpace ToLocal;
    FAnimNode_PoseSearchHistoryCollector History;
    FAnimNode_BlendStackInput Inputs[5];
    FAnimNode_GaspSampleWarp Warps[5];

    explicit FGaspCppAnimProxy(UAnimInstance* Instance) : FAnimInstanceProxy(Instance)
    {
        Motion.Anim=CastChecked<UGaspNativeAnimInstance>(Instance);
        Motion.SetMaxActiveBlends(4);
        Motion.bShouldFilterNotifies=true;
        Motion.PerSampleGraphPoseLinks.SetNum(5);
        Motion.SampleGraphExecutionHelpers.SetNum(5);
        for (int32 I=0; I<5; ++I)
        {
            Inputs[I].SampleIndex=I;
            Inputs[I].Player=&Motion.SampleGraphExecutionHelpers[I].Player;
            Warps[I].Source.SetLinkNode(&Inputs[I]);
            Motion.PerSampleGraphPoseLinks[I].SetLinkNode(&Warps[I]);
        }
        StopBlend.A.SetLinkNode(&Reference); StopBlend.B.SetLinkNode(&Motion); StopBlend.Alpha=1;
        ApplyLean.Base.SetLinkNode(&StopBlend); ApplyLean.Additive.SetLinkNode(&Lean);
        ApplyAim.Base.SetLinkNode(&ApplyLean); ApplyAim.Additive.SetLinkNode(&Aim);
        Slot.Source.SetLinkNode(&ApplyAim); Slot.bAlwaysUpdateSourcePose=false;
        Offset.Source.SetLinkNode(&Slot); Offset.MaxTranslationError=30; Offset.RotationHalfLife=.1f;
        ToComponent.LocalPose.SetLinkNode(&Offset);
        Feet.ComponentPose.SetLinkNode(&ToComponent);
        Legs.ComponentPose.SetLinkNode(&Feet); Legs.SoftPercentLength=.99f;
        ToLocal.ComponentPose.SetLinkNode(&Legs);
        History.Source.SetLinkNode(&ToLocal); History.PoseCount=2; History.SamplingInterval=.04f;
        History.CollectedCurves={TEXT("Phase")};
    }
    void Bindings(TArray<FGaspGraphNode>& Nodes)
    {
        Nodes.Add({&History,FAnimNode_PoseSearchHistoryCollector::StaticStruct()});
        Nodes.Add({&Feet,FAnimNode_FootPlacement::StaticStruct()});
        Nodes.Add({&Legs,FAnimNode_LegIK::StaticStruct()});
        Nodes.Add({&Slot,FAnimNode_Slot::StaticStruct()});
    }
    virtual FAnimNode_Base* GetCustomRootNode() override { return &History; }
    virtual void GetCustomNodes(TArray<FAnimNode_Base*>& Nodes) override
    {
        Nodes.Append({&Reference,&StopBlend,&Motion,&Lean,&Aim,&ApplyLean,&ApplyAim,&Slot,&Offset,&ToComponent,&Feet,&Legs,&ToLocal,&History});
        for (int32 I=0; I<5; ++I) { Nodes.Add(&Inputs[I]); Nodes.Add(&Warps[I]); }
    }
    virtual void Update(float DeltaSeconds) override
    {
        const auto* Anim=Motion.Anim;
        Lean.SetBlendSpace(Anim->LeanAsset); Lean.SetPosition(FVector(Anim->LeanAmount,0,0));
        Aim.SetBlendSpace(Anim->AimAsset); Aim.SetPosition(FVector(Anim->AimYaw,Anim->AimPitch,0));
        ApplyLean.Alpha=Anim->LeanAsset ? Anim->LeanAlpha : 0; ApplyAim.Alpha=Anim->AimAsset ? Anim->AimAlpha : 0;
        const auto* Set=Anim->AnimationSet.Get();
        // Keep locomotion searching while a behavior montage owns the output pose.
        // Returning from a combo must blend to a current trajectory, not a frozen source.
        Slot.bAlwaysUpdateSourcePose=Set && !Set->BehaviorGraphJson.IsEmpty();
        StopBlend.Alpha=FMath::FInterpConstantTo(StopBlend.Alpha, Set && Set->bReferencePoseWhenStopped && Anim->Speed2D<5 ? 0.f : 1.f,DeltaSeconds,5.f);
        Offset.bEnabled=!Set || Set->bEnableRootOffset;
        Legs.Alpha=Set && !Set->bEnableFootIK ? 0.f : 1.f;
        Feet.Alpha=Set && !Set->bEnableFootIK ? 0.f : Anim->FootPlacementAlpha;
        Offset.TranslationMode=Anim->TranslationMode; Offset.RotationMode=Anim->RotationMode;
        Offset.TranslationHalflife=Anim->TranslationHalflife; Offset.bClampToTranslationVelocity=Anim->bClampTranslation;
    }
    virtual void AddReferencedObjects(UAnimInstance* Instance, FReferenceCollector& Collector) override
    {
        FAnimInstanceProxy::AddReferencedObjects(Instance, Collector);
        Collector.AddPropertyReferencesWithStructARO(FAnimNode_BlendStack_Standalone::StaticStruct(), &Motion, Instance);
        Collector.AddPropertyReferencesWithStructARO(FMotionMatchingState::StaticStruct(), &Motion.State, Instance);
        Collector.AddPropertyReferencesWithStructARO(FAnimNode_BlendSpacePlayer_Standalone::StaticStruct(), &Lean, Instance);
        Collector.AddPropertyReferencesWithStructARO(FAnimNode_BlendSpacePlayer_Standalone::StaticStruct(), &Aim, Instance);
        Collector.AddPropertyReferencesWithStructARO(FAnimNode_FootPlacement::StaticStruct(), &Feet, Instance);
        Collector.AddPropertyReferencesWithStructARO(FAnimNode_LegIK::StaticStruct(), &Legs, Instance);
        Collector.AddPropertyReferencesWithStructARO(FAnimNode_PoseSearchHistoryCollector::StaticStruct(), &History, Instance);
        for (int32 I=0; I<5; ++I) Collector.AddPropertyReferencesWithStructARO(FAnimNode_GaspSampleWarp::StaticStruct(), &Warps[I], Instance);
    }
};
}

FAnimInstanceProxy* UGaspCppAnimInstance::CreateAnimInstanceProxy() { return new FGaspCppAnimProxy(this); }
void UGaspCppAnimInstance::DestroyAnimInstanceProxy(FAnimInstanceProxy* Proxy) { delete static_cast<FGaspCppAnimProxy*>(Proxy); }
void UGaspCppAnimInstance::EnumerateGraphNodes(TArray<FGaspGraphNode>& Nodes)
{ GetProxyOnGameThread<FGaspCppAnimProxy>().Bindings(Nodes); }
bool UGaspCppAnimInstance::HasMotionGraph() const { return true; }
void UGaspCppAnimInstance::SubmitDatabases(const TArray<UPoseSearchDatabase*>& Databases, EPoseSearchInterruptMode Mode)
{
    auto& Node=GetProxyOnGameThread<FGaspCppAnimProxy>().Motion;
    Node.Databases.Reset(); for (auto* Database:Databases) Node.Databases.Add(Database);
    Node.Interrupt=Mode;
}
FPoseSearchBlueprintResult UGaspCppAnimInstance::ReadMotionResult() const
{ return GetProxyOnGameThread<FGaspCppAnimProxy>().Motion.State.SearchResult; }


