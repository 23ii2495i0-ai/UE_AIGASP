#include "AnimNode_GaspSampleWarp.h"
#include "GaspNativeAnimInstance.h"
#include "GaspAnimationSet.h"
#include "Animation/AnimInstanceProxy.h"
#include "Animation/AnimSequenceBase.h"
#include "BlendStack/AnimNode_BlendStack.h"
#include "BlendStack/AnimNode_BlendStackInput.h"

void FAnimNode_GaspSampleWarp::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
    FAnimNode_Base::Initialize_AnyThread(Context);
    ToComponent.LocalPose = Source;
    Orientation.ComponentPose.SetLinkNode(&ToComponent);
    Orientation.Mode = EWarpingEvaluationMode::Graph;
    Orientation.WarpingSpace = EOrientationWarpingSpace::RootBoneTransform;
    const auto* Anim = Cast<UGaspNativeAnimInstance>(Context.AnimInstanceProxy->GetAnimInstanceObject());
    bPassThrough=Anim && Anim->AnimationSet && !Anim->AnimationSet->bEnableSampleWarping;
    if (bPassThrough) { Source.Initialize(Context); return; }
    const FGaspBoneLayout Bones = Anim && Anim->AnimationSet ? Anim->AnimationSet->Bones : FGaspBoneLayout();
    Orientation.IKFootRootBone.BoneName = Bones.IKRoot;
    Orientation.IKFootBones.SetNum(2);
    for (int32 I=0; I<2; ++I) Orientation.IKFootBones[I].BoneName = Bones.IKFeet[I];
    Orientation.SpineBones.SetNum(Bones.Spine.Num());
    for (int32 I=0; I<Bones.Spine.Num(); ++I) Orientation.SpineBones[I].BoneName = Bones.Spine[I];
    ResetRoot.ComponentPose.SetLinkNode(&Orientation);
    ResetRoot.BoneToModify.BoneName = Bones.Root;
    ResetRoot.TranslationMode = BMM_Replace;
    ResetRoot.RotationMode = BMM_Replace;
    ResetRoot.TranslationSpace = BCS_ComponentSpace;
    ResetRoot.RotationSpace = BCS_ComponentSpace;
    Steering.ComponentPose.SetLinkNode(&ResetRoot);
    TurnSteering.ComponentPose.SetLinkNode(&Steering);
    ToLocal.ComponentPose.SetLinkNode(&TurnSteering);
    ToLocal.Initialize_AnyThread(Context);
}

void FAnimNode_GaspSampleWarp::CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) { if (bPassThrough) Source.CacheBones(Context); else ToLocal.CacheBones_AnyThread(Context); }
void FAnimNode_GaspSampleWarp::Update_AnyThread(const FAnimationUpdateContext& Context)
{
    auto* Anim = Cast<UGaspNativeAnimInstance>(Context.AnimInstanceProxy->GetAnimInstanceObject());
    if (bPassThrough) { if (Anim) ++Anim->SampleUpdateCount; Source.Update(Context); return; }
    auto* Input = static_cast<FAnimNode_BlendStackInput*>(ToComponent.LocalPose.GetLinkNode());
    FBlendStackAnimPlayer* Player = Input && Input->Player ? *Input->Player : nullptr;
    UAnimationAsset* Asset = Player ? Player->GetAnimationAsset() : nullptr;
    const float Time = Player ? Player->GetCurrentAssetTime() : 0;
    if (Anim) ++Anim->SampleUpdateCount;
    const auto* Sequence = Cast<UAnimSequenceBase>(Asset);
    const float OrientationCurve = Sequence ? Sequence->EvaluateCurveData(TEXT("Enable_OrientationWarping"), Time) : 0;
    Orientation.CurrentAnimAsset = Asset;
    Orientation.CurrentAnimAssetTime = Time;
    Orientation.Alpha = OrientationCurve;
    Orientation.LocomotionAngle = Anim ? Anim->LocomotionAngle : 0;
    Steering.TargetOrientation = TurnSteering.TargetOrientation = Anim ? Anim->DesiredFacing : FQuat::Identity;
    Steering.CurrentAnimAsset = TurnSteering.CurrentAnimAsset = Asset;
    Steering.CurrentAnimAssetTime = TurnSteering.CurrentAnimAssetTime = Time;
    Steering.bMirrored = TurnSteering.bMirrored = Player && Player->GetMirror();
    Steering.MirrorDataTable = TurnSteering.MirrorDataTable = Player ? Player->GetMirrorNode().GetMirrorDataTable() : nullptr;
    Steering.Alpha = Anim ? Anim->SteeringAlpha : 0;
    TurnSteering.Alpha = Sequence ? Sequence->EvaluateCurveData(TEXT("Enable_TurnInPlaceSteering"), Time) : 0;
    ToLocal.Update_AnyThread(Context);
}
void FAnimNode_GaspSampleWarp::Evaluate_AnyThread(FPoseContext& Output) { if (bPassThrough) Source.Evaluate(Output); else ToLocal.Evaluate_AnyThread(Output); }
void FAnimNode_GaspSampleWarp::GatherDebugData(FNodeDebugData& DebugData) { if (bPassThrough) Source.GatherDebugData(DebugData); else ToLocal.GatherDebugData(DebugData); }

