#include "GaspNativeAnimInstance.h"
#include "GaspBehaviorComponent.h"
#include "GaspAnimationSet.h"
#include "GaspNativeCharacter.h"
#include "GaspTraversalComponent.h"
#include "Animation/AnimClassInterface.h"
#include "Animation/AnimInstanceProxy.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "PoseSearch/AnimNode_MotionMatching.h"
#include "PoseSearch/AnimNode_PoseSearchHistoryCollector.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "PoseSearch/PoseSearchFeatureChannel_Trajectory.h"
#include "PoseSearch/PoseSearchFeatureChannel_Pose.h"
#include "Animation/AnimationAsset.h"
#include "Engine/SkeletalMesh.h"
#include "PoseSearch/PoseSearchTrajectoryLibrary.h"
#include "Misc/Paths.h"
#include "BoneControllers/AnimNode_FootPlacement.h"
#include "BoneControllers/AnimNode_LegIK.h"
#include "AnimNodes/AnimNode_Slot.h"
#include "Misc/EngineVersionComparison.h"
#include "UObject/UnrealType.h"

struct FGaspAnimState
{
    FVector VelocityLast = FVector::ZeroVector;
    float DesiredYawLast = 0;
#if UE_VERSION_OLDER_THAN(5, 6, 0)
    FPoseSearchQueryTrajectory Trajectory;
#else
    FTransformTrajectory Trajectory;
#endif
};

UGaspNativeAnimInstance::UGaspNativeAnimInstance() : State(MakeShared<FGaspAnimState>())
{
    RootMotionMode = ERootMotionMode::RootMotionFromMontagesOnly;
    // World queries, chooser asset loads and state snapshots run on the game thread.
    bUseMultiThreadedAnimationUpdate = false;
}
UGaspNativeAnimInstance::~UGaspNativeAnimInstance() = default;

bool UGaspNativeAnimInstance::GetMotionMatchingAnimationGroup(FName Group,TArray<UPoseSearchDatabase*>& Databases) const
{
    const auto* Override=MotionMatchingAnimationGroups.Find(Group);
    if(!Override)return false;
    Databases.Reset();
    if(!Override->PublicVariableName.IsNone())
    {
        const auto* Array=FindFProperty<FArrayProperty>(GetClass(),Override->PublicVariableName);
        const auto* Object=Array ? CastField<FObjectPropertyBase>(Array->Inner):nullptr;
        if(Array && Object && Object->PropertyClass->IsChildOf(UPoseSearchDatabase::StaticClass()))
        {
            FScriptArrayHelper Values(Array,Array->ContainerPtrToValuePtr<void>(this));
            for(int32 Index=0;Index<Values.Num();++Index)
                if(auto* Database=Cast<UPoseSearchDatabase>(Object->GetObjectPropertyValue(Values.GetRawPtr(Index))))Databases.AddUnique(Database);
            return true;
        }
        return true; // Missing public bindings must not silently use stale embedded assets.
    }
    for(UPoseSearchDatabase* Database:Override->Databases)if(Database)Databases.AddUnique(Database);
    return true; // A deliberately empty override must not silently fall back to the original assets.
}

bool UGaspNativeAnimInstance::ValidateMotionMatchingAnimationGroups(const USkeletalMesh* Mesh,FString& Error) const
{
    Error.Reset();
    if(MotionMatchingAnimationGroups.IsEmpty())return true;
    if(!Mesh || !Mesh->GetSkeleton()){Error=TEXT("Motion Matching animation groups require a target skeleton");return false;}
    for(const auto& Pair:MotionMatchingAnimationGroups)
    {
        TArray<UPoseSearchDatabase*> Effective;GetMotionMatchingAnimationGroup(Pair.Key,Effective);
        if(Pair.Key.IsNone() || Effective.IsEmpty()){Error=TEXT("Motion Matching animation group has no databases: ")+Pair.Key.ToString();return false;}
        for(const auto* DB:Effective)
        {
            const auto* Schema=DB ? DB->Schema.Get():nullptr;
            if(!Schema || Schema->GetSkeleton(Schema->GetDefaultRole())!=Mesh->GetSkeleton() ||
                !Schema->FindFirstChannelOfType<UPoseSearchFeatureChannel_Trajectory>() ||
                !Schema->FindFirstChannelOfType<UPoseSearchFeatureChannel_Pose>() || DB->GetNumAnimationAssets()==0)
            {Error=TEXT("Motion Matching group needs nonempty databases with compatible skeleton, trajectory and pose channels: ")+Pair.Key.ToString();return false;}
            for(int32 Index=0;Index<DB->GetNumAnimationAssets();++Index)
            {
                const auto* Asset=Cast<UAnimationAsset>(DB->GetAnimationAsset(Index));
                if(!Asset || Asset->GetSkeleton()!=Mesh->GetSkeleton())
                {Error=TEXT("Motion Matching database contains an incompatible animation in group: ")+Pair.Key.ToString();return false;}
            }
        }
    }
    return true;
}

UGaspNativeAnimInstance* UGaspNativeAnimInstance::Resolve(USkeletalMeshComponent* Mesh)
{
    UAnimInstance* Main = Mesh ? Mesh->GetAnimInstance() : nullptr;
    if (Main)
        if (auto* Linked = Cast<UGaspNativeAnimInstance>(Main->GetLinkedAnimGraphInstanceByTag(TEXT("GaspCore")))) return Linked;
    return Cast<UGaspNativeAnimInstance>(Main);
}

FGaspCharacterInputs UGaspNativeAnimInstance::ReadCharacterInputs_Implementation() const
{
    FGaspCharacterInputs Inputs;
    if (const auto* Character = Cast<AGaspNativeCharacter>(TryGetPawnOwner()))
    {
        Inputs.Gait = uint8(Character->Gait);
        Inputs.WantsToAim = Character->IsAimAllowed();
        Inputs.JustLandedTime = Character->JustLandedTime;
        Inputs.LandVelocity = Character->LandVelocity;
    }
    else if (const auto* GenericCharacter = Cast<ACharacter>(TryGetPawnOwner()))
    {
        const float SpeedLimit = GenericCharacter->GetCharacterMovement()->MaxWalkSpeed;
        Inputs.Gait = SpeedLimit > 600 ? 2 : (SpeedLimit <= 225 ? 0 : 1);
    }
    return Inputs;
}

void UGaspNativeAnimInstance::NativeInitializeAnimation()
{
    Super::NativeInitializeAnimation();
    State = MakeShared<FGaspAnimState>();
    SampleUpdateCount = 0;
    MotionMatching = nullptr;
    History = nullptr;
    Feet = nullptr;
    CurrentDatabases.Reset();
    LoadedAssets.Reset();
    if (const auto* Character = Cast<AGaspNativeCharacter>(TryGetPawnOwner()))
        if (Character->AnimationSetOverride) AnimationSet = Character->AnimationSetOverride;
    FString Error;
    bAnimationSetValid = AnimationSet && AnimationSet->ValidateForMesh(GetSkelMeshComponent()->GetSkeletalMeshAsset(), Error);
    if(bAnimationSetValid)bAnimationSetValid=ValidateMotionMatchingAnimationGroups(GetSkelMeshComponent()->GetSkeletalMeshAsset(),Error);
    if (!bAnimationSetValid)
    {
        UE_LOG(LogTemp, Error, TEXT("GASP animation set invalid on %s: %s"), *GetName(), AnimationSet ? *Error : TEXT("No AnimationSet assigned"));
        return;
    }
    LeanAsset = AnimationSet->Lean;
    AimAsset = AnimationSet->Aim;
    Dense.LoadTable(AnimationSet->DenseTable);
    Sparse.LoadTable(AnimationSet->SparseTable);
    SetUseMainInstanceMontageEvaluationData(GetSkelMeshComponent()->GetAnimInstance() != this);
    TArray<FGaspGraphNode> Nodes; EnumerateGraphNodes(Nodes);
    {
        for (const FGaspGraphNode& Entry : Nodes)
        {
            if (Entry.Type == FAnimNode_MotionMatching::StaticStruct())
                MotionMatching = static_cast<FAnimNode_MotionMatching*>(Entry.Node);
            if (Entry.Type == FAnimNode_PoseSearchHistoryCollector::StaticStruct())
                History = static_cast<FAnimNode_PoseSearchHistoryCollector*>(Entry.Node);
            if (Entry.Type == FAnimNode_FootPlacement::StaticStruct())
            {
                Feet = static_cast<FAnimNode_FootPlacement*>(Entry.Node);
                Feet->IKFootRootBone.BoneName = AnimationSet->Bones.IKRoot;
                Feet->PelvisBone.BoneName = AnimationSet->Bones.Pelvis;
                Feet->LegDefinitions.SetNum(2);
                for (int32 I=0; I<2; ++I)
                {
                    Feet->LegDefinitions[I].FKFootBone.BoneName = AnimationSet->Bones.Feet[I];
                    Feet->LegDefinitions[I].IKFootBone.BoneName = AnimationSet->Bones.IKFeet[I];
                    Feet->LegDefinitions[I].BallBone.BoneName = AnimationSet->Bones.Balls[I];
                    Feet->LegDefinitions[I].SpeedCurveName = I==0 ? TEXT("FootSpeed_L") : TEXT("FootSpeed_R");
                }
            }
            if (Entry.Type == FAnimNode_LegIK::StaticStruct())
            {
                auto* Legs = static_cast<FAnimNode_LegIK*>(Entry.Node);
                Legs->LegsDefinition.SetNum(2);
                for (int32 I=0; I<2; ++I)
                {
                    Legs->LegsDefinition[I].IKFootBone.BoneName = AnimationSet->Bones.IKFeet[I];
                    Legs->LegsDefinition[I].FKFootBone.BoneName = AnimationSet->Bones.Feet[I];
                    Legs->LegsDefinition[I].HingeRotationAxis = AnimationSet->Bones.KneeHingeAxis;
                    Legs->LegsDefinition[I].FootBoneForwardAxis = AnimationSet->Bones.FootForwardAxis;
                    Legs->LegsDefinition[I].bEnableRotationLimit = true;
                }
            }
            if (Entry.Type == FAnimNode_Slot::StaticStruct())
                static_cast<FAnimNode_Slot*>(Entry.Node)->SlotName = AnimationSet->MontageSlot;
        }
        if (History)
        {
            History->CollectedBones.Reset();
            TArray<FName> Names = AnimationSet->Bones.Feet;
            Names.Append(AnimationSet->Bones.Thighs); Names.Add(AnimationSet->Bones.Spine.Last()); Names.Add(AnimationSet->Bones.Pelvis);
            for (FName Name : Names) { FBoneReference Bone; Bone.BoneName = Name; History->CollectedBones.Add(Bone); }
        }
    }
}

void UGaspNativeAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
    Super::NativeUpdateAnimation(DeltaSeconds);
    auto* Character = Cast<ACharacter>(TryGetPawnOwner());
    if (!Character || !bAnimationSetValid || !HasMotionGraph() || !History || DeltaSeconds <= 0) return;
    // Complete any outstanding evaluation before updating runtime node data.
    GetProxyOnGameThread<FAnimInstanceProxy>();
    const auto* Move = Character->GetCharacterMovement();
    const FGaspCharacterInputs Inputs = ReadCharacterInputs();
    const int32 PreviousMovementMode = MovementMode;
    const int32 PreviousMovementState = MovementState;
    const int32 PreviousGait = Gait;
    const int32 PreviousStance = Stance;
    const FVector Velocity = Character->GetVelocity();
    Speed2D = Velocity.Size2D();
    Gait = FMath::Clamp(Inputs.Gait, 0, 2);
    Stance = Character->bIsCrouched ? 1 : 0;
    MovementMode = Move->IsFalling() ? 1 : 0; // Flying counts as OnGround in the 5.5 ABP.
    FPoseSearchTrajectoryData Data;
    // In the transform-trajectory API a negative rate disables clamping; zero
    // suppresses predicted controller rotation and makes mouse turns straight.
#if UE_VERSION_OLDER_THAN(5, 6, 0)
    Data.MaxControllerYawRate = Speed2D > 0 ? 0.f : 100.f;
#else
    Data.MaxControllerYawRate = Speed2D > 0 ? -1.f : 100.f;
#endif
    Data.RotateTowardsMovementSpeed = 10.f;
#if UE_VERSION_OLDER_THAN(5, 6, 0)
    FPoseSearchQueryTrajectory Generated;
    UPoseSearchTrajectoryLibrary::PoseSearchGenerateTrajectory(this, Data, DeltaSeconds, State->Trajectory,
        State->DesiredYawLast, Generated, -1.f, 30, .1f, 15);
#else
    FTransformTrajectory Generated;
    UPoseSearchTrajectoryLibrary::PoseSearchGenerateTransformTrajectory(this, Data, DeltaSeconds, State->Trajectory,
        State->DesiredYawLast, Generated, -1.f, 30, .1f, 15);
#endif
    FPoseSearchTrajectory_WorldCollisionResults Collision;
    const TArray<AActor*> Ignore = { Character };
#if UE_VERSION_OLDER_THAN(5, 6, 0)
    UPoseSearchTrajectoryLibrary::HandleTrajectoryWorldCollisions(this, this, Generated, true, .01f,
        State->Trajectory, Collision, TraceTypeQuery1, false, Ignore, EDrawDebugTrace::None, true, 150.f);
    History->Trajectory = State->Trajectory;
#else
    UPoseSearchTrajectoryLibrary::HandleTransformTrajectoryWorldCollisions(this, this, Generated, true, .01f,
        State->Trajectory, Collision, TraceTypeQuery1, false, Ignore, EDrawDebugTrace::None, true, 150.f);
    History->TransformTrajectory = State->Trajectory;
#endif
    FVector FutureVelocity;
#if UE_VERSION_OLDER_THAN(5, 6, 0)
    UPoseSearchTrajectoryLibrary::GetTrajectoryVelocity(State->Trajectory, .4f, .5f, FutureVelocity);
#else
    UPoseSearchTrajectoryLibrary::GetTransformTrajectoryVelocity(State->Trajectory, .4f, .5f, FutureVelocity);
#endif
    const FVector Acceleration = (Velocity - State->VelocityLast) / DeltaSeconds;
    State->VelocityLast = Velocity;
    const bool bMoving = !FutureVelocity.IsNearlyZero(10.f) && !Move->GetCurrentAcceleration().IsNearlyZero(KINDA_SMALL_NUMBER);
    MovementState = bMoving ? 1 : 0;
    bool bPivots = false;
    bool bStops = false;
    for (const auto& DB : CurrentDatabases) if (DB && DB->GetFName() == SelectedDatabase)
    {
        bPivots = DB->Tags.Contains(TEXT("Pivots"));
        bStops = DB->Tags.Contains(TEXT("Stops"));
    }
    IsStarting = bMoving && FutureVelocity.Size2D() >= Speed2D + 100.f && !bPivots;
    const float TurnAngle = FMath::FindDeltaAngleDegrees(Velocity.Rotation().Yaw, FutureVelocity.Rotation().Yaw);
    IsPivoting = bMoving && FMath::Abs(TurnAngle) >= (Move->bOrientRotationToMovement ? 45.f : 30.f);
    FRotator RootRotation = GetSkelMeshComponent()->GetSocketQuaternion(AnimationSet->Bones.Root).Rotator();
    RootRotation.Yaw -= AnimationSet->Bones.MeshYawOffset;
    const float RootYawError = FMath::Abs(FMath::FindDeltaAngleDegrees(Character->GetActorRotation().Yaw, RootRotation.Yaw));
    ShouldTurnInPlace = RootYawError >= 50.f && (Inputs.WantsToAim || (!bMoving && PreviousMovementState == 1));
    ShouldSpinTransition = RootYawError >= 130.f && Speed2D >= 150.f && !bPivots;
    JustLanded_Light = Inputs.JustLandedTime > 0 && FMath::Abs(Inputs.LandVelocity.Z) < 700;
    JustLanded_Heavy = Inputs.JustLandedTime > 0 && FMath::Abs(Inputs.LandVelocity.Z) >= 700;
    const bool bSlotActive = IsSlotActive(AnimationSet->MontageSlot);
    JustTraversed = !bSlotActive && GetCurveValue(TEXT("MovingTraversal")) > 0 && FMath::Abs(TurnAngle) <= 50;
    TranslationMode = !bSlotActive && bMoving && MovementMode == 0 ? EOffsetRootBoneMode::Interpolate : EOffsetRootBoneMode::Release;
    RotationMode = bSlotActive ? EOffsetRootBoneMode::Release : EOffsetRootBoneMode::Accumulate;
    TranslationHalflife = bMoving ? .3f : .1f;
    bClampTranslation = bMoving;
    NotifyRecencyTimeOut = Gait == 2 ? .16f : .2f;
    FootPlacementAlpha = Move->IsFalling() ? 0.f : 1.f;
    if (Feet)
    {
        Feet->PelvisSettings.MaxOffset = 250.f;
        Feet->PelvisSettings.LinearStiffness = 100.f;
        Feet->TraceSettings.MaxGroundPenetration = 20.f;
        Feet->PlantSettings.SpeedThreshold = bStops ? 20.f : 60.f;
        Feet->PlantSettings.UnplantRadius = bStops ? 40.f : 20.f;
        Feet->PlantSettings.ReplantRadiusRatio = bStops ? .75f : .2f;
        Feet->PlantSettings.UnplantAngle = 60.f;
        Feet->PlantSettings.ReplantAngleRatio = .2f;
        Feet->InterpolationSettings.UnplantLinearStiffness = bStops ? 250.f : 100.f;
        Feet->InterpolationSettings.UnplantAngularStiffness = 450.f;
    }
    LeanAmount = Character->GetActorQuat().UnrotateVector(Acceleration).Y / FMath::Max(Move->MaxAcceleration, 1.f);
    LeanAlpha = FMath::FInterpTo(LeanAlpha, bMoving ? 1.f : 0.f, DeltaSeconds, 5.f);
    const FRotator Aim = (Character->GetBaseAimRotation() - RootRotation).GetNormalized();
    AimBlend = FVector(Aim.Yaw, Aim.Pitch, 0);
    AimYaw = Aim.Yaw;
    AimPitch = Aim.Pitch;
    const bool bEnableAim = FMath::Abs(Aim.Yaw) <= (bMoving ? 180.f : 115.f) && !Move->bOrientRotationToMovement && !bSlotActive && !(AnimationSet->ActionPolicy.bBlockAimWhenSprinting && Gait==2);
    AimAlpha = FMath::FInterpTo(AimAlpha, bEnableAim ? 1.f : 0.f, DeltaSeconds, 5.f);
    LocomotionAngle = FMath::FindDeltaAngleDegrees(Character->GetActorRotation().Yaw, Velocity.Rotation().Yaw);
    DesiredFacing = State->Trajectory.GetSampleAtTime(.5f).Facing;
    const FVector TrajectoryOrigin=State->Trajectory.GetSampleAtTime(0.f).Position;
    PredictedTrajectoryNear=State->Trajectory.GetSampleAtTime(.2f).Position-TrajectoryOrigin;
    PredictedTrajectoryFar=State->Trajectory.GetSampleAtTime(.6f).Position-TrajectoryOrigin;
    SteeringAlpha = bMoving || MovementMode == 1 ? 1.f : 0.f;
    TMap<FString, double> Context = {
        {TEXT("Speed2D"), double(Speed2D)}, {TEXT("MovementMode"), double(MovementMode)}, {TEXT("MovementState"), double(MovementState)},
        {TEXT("Gait"), double(Gait)}, {TEXT("Stance"), double(Stance)}, {TEXT("IsStarting"), double(IsStarting)}, {TEXT("IsPivoting"), double(IsPivoting)},
        {TEXT("ShouldTurnInPlace"), double(ShouldTurnInPlace)}, {TEXT("ShouldSpinTransition"), double(ShouldSpinTransition)},
        {TEXT("JustLanded_Light"), double(JustLanded_Light)}, {TEXT("JustLanded_Heavy"), double(JustLanded_Heavy)},
        {TEXT("JustTraversed"), double(JustTraversed)}, {TEXT("TrajectoryCollision.TimeToLand"), double(Collision.TimeToLand)}
    };
    TMap<FString, double> Outputs;
    const TArray<FSoftObjectPath> Paths = MMDatabaseLOD == 0 ? Dense.Evaluate(Context, Outputs) :
        MMDatabaseLOD == 1 ? Sparse.Evaluate(Context, Outputs) : TArray<FSoftObjectPath>();
    CurrentDatabases.Reset();
    TArray<UPoseSearchDatabase*> Databases;
    for (const auto& Path : Paths)
        if (auto* Database = Cast<UPoseSearchDatabase>(AnimationSet->ResolveDatabase(Path).TryLoad()))
        {
            LoadedAssets.AddUnique(Database);
            CurrentDatabases.Add(Database);
            Databases.Add(Database);
        }
    if (Databases.IsEmpty() && !AnimationSet->ConfiguredLocomotion.IsEmpty())
    {
        const auto& Configured=AnimationSet->ConfiguredLocomotion;
        const TObjectPtr<UPoseSearchDatabase>* Fallback=nullptr;
        if (MovementMode==1) Fallback=Configured.Find(TEXT("jump"));
        if (!Fallback && Stance==1) Fallback=Configured.Find(TEXT("crouch"));
        if (!Fallback && !bMoving) Fallback=Configured.Find(TEXT("idle"));
        const FName Gaits[]={TEXT("walk"),TEXT("run"),TEXT("sprint")};
        if (!Fallback)
            for(int32 Distance=0;Distance<3 && !Fallback;++Distance)
                for(int32 Index=0;Index<3;++Index)
                    if(FMath::Abs(Index-Gait)==Distance) if(const auto* Entry=Configured.Find(Gaits[Index])){Fallback=Entry;break;}
        if(Fallback && *Fallback)
        {
            LoadedAssets.AddUnique(Fallback->Get());CurrentDatabases.Add(Fallback->Get());Databases.Add(Fallback->Get());
        }
    }
    if(!MotionMatchingAnimationGroups.IsEmpty())
    {
        TArray<UPoseSearchDatabase*> Replacements;
        for(auto* Database:Databases)
        {
            bool bReplaced=false;
            for(const auto& Pair:MotionMatchingAnimationGroups)
                if(Pair.Value.SourceDatabase==Database)
                {
                    TArray<UPoseSearchDatabase*> Group;GetMotionMatchingAnimationGroup(Pair.Key,Group);
                    for(auto* Replacement:Group)Replacements.AddUnique(Replacement);
                    bReplaced=true;break;
                }
            if(!bReplaced)Replacements.AddUnique(Database);
        }
        Databases=MoveTemp(Replacements);CurrentDatabases.Reset();
        for(auto* Database:Databases){CurrentDatabases.Add(Database);LoadedAssets.AddUnique(Database);}
    }
    bool bBehaviorOverride=false;
    if(auto* Behavior=Character->FindComponentByClass<UGaspBehaviorComponent>())
    {
        TArray<UPoseSearchDatabase*> Override;
        bBehaviorOverride=Behavior->GetDatabaseOverride(Override);
        if(bBehaviorOverride){Databases=Override;CurrentDatabases.Reset();for(auto* DB:Override){CurrentDatabases.Add(DB);LoadedAssets.AddUnique(DB);}}
    }
    const bool bStateChange = MovementState != PreviousMovementState || (Gait != PreviousGait && bMoving) || Stance != PreviousStance;
    const bool bInterrupt = MovementMode != PreviousMovementMode || (bStateChange && MovementMode == 0);
    MotionBlendTime = MovementMode == 0 ? (PreviousMovementMode == 0 ? .5f : .2f) : (Velocity.Z > 100 ? .15f : .5f);
    if (MovementMode==0 && Databases.Num()==1)
        for (const auto& Rule:AnimationSet->ConfiguredTransitions)
            if (Rule.FromDatabase==SelectedDatabase && Rule.ToDatabase==Databases[0]->GetFName())
            { MotionBlendTime=FMath::Clamp(Rule.BlendSeconds,0.f,2.f); break; }
    if(auto* Behavior=Character->FindComponentByClass<UGaspBehaviorComponent>())if(Behavior->IsEnabled()){MotionBlendTime=Behavior->GetBlendSeconds();bBehaviorOverride=true;}
    for(const auto* Database:Databases)
        if(!Database || !Database->Schema || Database->Schema->GetSkeleton(Database->Schema->GetDefaultRole())!=GetSkelMeshComponent()->GetSkeletalMeshAsset()->GetSkeleton())
        {bAnimationSetValid=false;CurrentDatabases.Reset();UE_LOG(LogTemp,Error,TEXT("Public MM animation variable contains an incompatible database on %s"),*GetName());return;}
    SubmitDatabases(Databases, (bInterrupt || bBehaviorOverride) ? EPoseSearchInterruptMode::InterruptOnDatabaseChange : EPoseSearchInterruptMode::DoNotInterrupt);
}

void UGaspNativeAnimInstance::NativePostEvaluateAnimation()
{
    Super::NativePostEvaluateAnimation();
#if !UE_VERSION_OLDER_THAN(5, 7, 0)
    if (HasMotionGraph())
    {
        const auto Result = ReadMotionResult();
        SelectedDatabase = Result.SelectedDatabase ? Result.SelectedDatabase->GetFName() : NAME_None;
        SelectedAnimation = Result.SelectedAnim ? Result.SelectedAnim->GetFName() : NAME_None;
        SelectedTime = Result.SelectedTime;
        SearchCost = Result.SearchCost;

    }
#endif
}







void UGaspNativeAnimInstance::EnumerateGraphNodes(TArray<FGaspGraphNode>& Nodes)
{
    if (const auto* Class=IAnimClassInterface::GetFromClass(GetClass()))
        for (const auto* Property:Class->GetAnimNodeProperties())
            Nodes.Add({Property->ContainerPtrToValuePtr<FAnimNode_Base>(this), Property->Struct});
}
bool UGaspNativeAnimInstance::HasMotionGraph() const { return MotionMatching!=nullptr; }
void UGaspNativeAnimInstance::SubmitDatabases(const TArray<UPoseSearchDatabase*>& Databases, EPoseSearchInterruptMode Mode)
{ if (MotionMatching) MotionMatching->SetDatabasesToSearch(Databases, Mode); }
FPoseSearchBlueprintResult UGaspNativeAnimInstance::ReadMotionResult() const
{ return MotionMatching ? MotionMatching->GetMotionMatchingState().SearchResult : FPoseSearchBlueprintResult(); }
const UE::PoseSearch::IPoseHistory* UGaspNativeAnimInstance::GetSearchPoseHistory() const
{ return History ? History->GetPoseHistoryPtr() : nullptr; }
