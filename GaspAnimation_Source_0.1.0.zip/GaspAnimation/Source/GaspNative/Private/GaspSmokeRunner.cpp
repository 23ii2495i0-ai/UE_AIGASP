#include "GaspSmokeRunner.h"
#include "Engine/StaticMesh.h"
#include "GaspNativeCharacter.h"
#include "GaspNativeAnimInstance.h"
#include "GaspCppAnimInstance.h"
#include "GaspFoleyNotify.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "UObject/UObjectIterator.h"
#include "UObject/GarbageCollection.h"
#include "GaspAnimationSet.h"
#include "GaspActionFlowComponent.h"
#include "GaspBehaviorComponent.h"
#include "GaspTraversalComponent.h"
#include "GaspTraversableBlock.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMeshActor.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/DamageEvents.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"
#include "HAL/PlatformMisc.h"
#include "HAL/PlatformTime.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Kismet/GameplayStatics.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonReader.h"

AGaspSmokeRunner::AGaspSmokeRunner()
{
    PrimaryActorTick.bCanEverTick = true;
    PrimaryActorTick.TickGroup = TG_PrePhysics;
}
void AGaspSmokeRunner::Advance(EPhase Next)
{
    Phase = Next;
    PhaseTime = 0;
    PhaseRealTime = FPlatformTime::Seconds();
}
void AGaspSmokeRunner::Check(const TCHAR* Name, bool Passed, const FString& Detail)
{
    auto Item = MakeShared<FJsonObject>();
    Item->SetStringField(TEXT("name"), Name);
    Item->SetBoolField(TEXT("passed"), Passed);
    Item->SetStringField(TEXT("detail"), Detail);
    Checks.Add(MakeShared<FJsonValueObject>(Item));
    UE_LOG(LogTemp, Display, TEXT("NATIVE_CHECK %s %s %s"), Name, Passed ? TEXT("PASS") : TEXT("FAIL"), *Detail);
    if (!Passed) ++Failures;
}
void AGaspSmokeRunner::Finish()
{
    auto Report = MakeShared<FJsonObject>();
    if(Character)if(const auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh()))
    {if(Anim->AnimationSet)Report->SetStringField(TEXT("animation_set"),Anim->AnimationSet->GetPathName());Report->SetStringField(TEXT("character_class"),Character->GetClass()->GetPathName());Report->SetStringField(TEXT("animation_class"),Anim->GetClass()->GetPathName());}
    Report->SetArrayField(TEXT("checks"), Checks);
    Report->SetNumberField(TEXT("failures"), Failures);
    FString Text;
    FJsonSerializer::Serialize(Report, TJsonWriterFactory<>::Create(&Text));
    if(FParse::Param(FCommandLine::Get(),TEXT("DirectionalQualitySmoke")))
        FFileHelper::SaveStringToFile(Text,*(FPaths::ProjectSavedDir()/TEXT("directional_quality_smoke.json")));
    if(FParse::Param(FCommandLine::Get(),TEXT("BehaviorQualitySmoke")))
        FFileHelper::SaveStringToFile(Text,*(FPaths::ProjectSavedDir()/TEXT("behavior_quality_smoke.json")));
    if(FParse::Param(FCommandLine::Get(),TEXT("BehaviorCompilerSmoke")))
        FFileHelper::SaveStringToFile(Text,*(FPaths::ProjectSavedDir()/TEXT("behavior_compiler_smoke.json")));
    if(FParse::Param(FCommandLine::Get(),TEXT("BehaviorGeneratedSmoke")))
        FFileHelper::SaveStringToFile(Text,*(FPaths::ProjectSavedDir()/TEXT("behavior_generated_smoke.json")));
    FFileHelper::SaveStringToFile(Text, *(FPaths::ProjectSavedDir()/(FParse::Param(FCommandLine::Get(),TEXT("ConfigQualitySmoke")) ? TEXT("config_quality_smoke.json") : FParse::Param(FCommandLine::Get(),TEXT("FlowSmoke")) ? TEXT("flow_smoke.json") : FParse::Param(FCommandLine::Get(),TEXT("ConfigSmoke")) ? TEXT("config_smoke.json") : FParse::Param(FCommandLine::Get(),TEXT("MarkerSmoke")) ? TEXT("marker_smoke.json") : TEXT("native_smoke.json"))));
    UE_LOG(LogTemp, Display, TEXT("GASP_NATIVE_SMOKE_FINISHED failures=%d"), Failures);
    Phase = EPhase::Done;
    FPlatformMisc::RequestExitWithStatus(false, Failures ? 1 : 0);
}

void AGaspSmokeRunner::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    if(FParse::Param(FCommandLine::Get(),TEXT("BehaviorQualitySmoke"))){TickBehaviorQuality(DeltaSeconds);return;}
    if(FParse::Param(FCommandLine::Get(),TEXT("DirectionalQualitySmoke"))){TickDirectionalQuality(DeltaSeconds);return;}
    if (FParse::Param(FCommandLine::Get(),TEXT("ConfigQualitySmoke"))) {TickConfigQuality(DeltaSeconds);return;}
    if (FParse::Param(FCommandLine::Get(),TEXT("FlowSmoke"))) { TickFlow(DeltaSeconds); return; }
    if (FParse::Param(FCommandLine::Get(),TEXT("MarkerSmoke")) || FParse::Param(FCommandLine::Get(),TEXT("ConfigSmoke"))) { TickMarker(DeltaSeconds); return; }
    if (Phase == EPhase::Done) return;
    const double Now = FPlatformTime::Seconds();
    if (Started == 0) { Started = Now; PhaseRealTime = Now; }
    if (Now-Started > 120) { Check(TEXT("timeout"), false); Finish(); return; }
    PhaseTime += DeltaSeconds;
    if (!Character)
    {
        Character = Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this, 0));
        if (!Character) return;
        Character->PrimaryActorTick.AddPrerequisite(this, PrimaryActorTick);
        Character->GetCharacterMovement()->PrimaryComponentTick.AddPrerequisite(this, PrimaryActorTick);
        Character->SetActorLocation(FVector(-1400,-1000,88.2), false, nullptr, ETeleportType::TeleportPhysics);
    }
    auto* Anim = UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    auto* Move = Character->GetCharacterMovement();
    if (!Anim) { if (Now-Started > 20) { Check(TEXT("native_anim_instance"), false); Finish(); } return; }
    switch (Phase)
    {
    case EPhase::Warmup:
        if (Anim->SelectedAnimation.IsNone() && Now-PhaseRealTime < 30) return;
        Check(TEXT("native_anim_instance"), true);
        Check(TEXT("idle_database"), !Anim->CurrentDatabases.IsEmpty(), Anim->SelectedDatabase.ToString());
        Check(TEXT("idle_pose"), !Anim->SelectedAnimation.IsNone(), Anim->SelectedAnimation.ToString());
        Check(TEXT("native_class_no_blueprint"), Anim->IsA<UGaspCppAnimInstance>() ? !Anim->GetClass()->HasAnyClassFlags(CLASS_CompiledFromBlueprint) : Character->GetMesh()->GetAnimInstance()!=Anim);
        Check(TEXT("animation_set_valid"), Anim->bAnimationSetValid);
        {
            bool NativeNotifies=true, HasSound=false;
            // Idle clips have no Foley events; load a landing clip before inspecting resources.
            LoadObject<UAnimSequenceBase>(nullptr,TEXT("/Game/Characters/UEFN_Mannequin/Animations/Jump/M_Neutral_Jump_B_Land_Walk_Heavy.M_Neutral_Jump_B_Land_Walk_Heavy"));
            for (TObjectIterator<UAnimSequenceBase> It; It; ++It)
                if (It->GetPathName().StartsWith(TEXT("/Game/Characters/UEFN_Mannequin/")))
                    for (const auto& Event:It->Notifies)
                    {
                        if (Event.Notify && Event.Notify->GetClass()->HasAnyClassFlags(CLASS_CompiledFromBlueprint)) NativeNotifies=false;
                        if (Event.NotifyStateClass && Event.NotifyStateClass->GetClass()->HasAnyClassFlags(CLASS_CompiledFromBlueprint)) NativeNotifies=false;
                        if (const auto* Foley=Cast<UGaspFoleyNotify>(Event.Notify)) HasSound |= Foley->Sound!=nullptr;
                    }
            Check(TEXT("no_blueprint_animation_notifies"), NativeNotifies);
            Check(TEXT("native_foley_resource"), HasSound);
        }
        Check(TEXT("profile_blendspaces"), Anim->LeanAsset == Anim->AnimationSet->Lean && Anim->AimAsset == Anim->AnimationSet->Aim);
        Check(TEXT("montage_instance_ownership"), Anim->IsA<UGaspCppAnimInstance>() ? Character->GetMesh()->GetAnimInstance()==Anim : Anim->IsUsingMainInstanceMontageEvaluationData());
        {
            auto* Invalid = DuplicateObject<UGaspAnimationSet>(Anim->AnimationSet, this);
            Invalid->Bones.Feet[0] = TEXT("MissingBoneForValidationTest");
            FString Error;
            Check(TEXT("reject_invalid_bone_layout"), !Invalid->ValidateForMesh(Character->GetMesh()->GetSkeletalMeshAsset(), Error));
        }
        {
            if (Anim->IsA<UGaspCppAnimInstance>())
                Check(TEXT("native_resource_profile_switch"), Character->ApplyAnimationSet(LoadObject<UGaspAnimationSet>(nullptr,TEXT("/Game/Native/DA_Gasp_Alternate.DA_Gasp_Alternate"))));
            else
            {
                auto* AlternateClass = LoadClass<UAnimInstance>(nullptr, TEXT("/Game/Native/ABP_Gasp_Alternate.ABP_Gasp_Alternate_C"));
                Check(TEXT("shared_template_parent"), AlternateClass && AlternateClass->GetSuperClass() == Anim->GetClass()->GetSuperClass());
                if (AlternateClass) Character->GetMesh()->GetAnimInstance()->LinkAnimGraphByTag(TEXT("GaspCore"), AlternateClass);
            }
        }
        Advance(EPhase::ProfileAlternate); break;
    case EPhase::ProfileAlternate:
        if (PhaseTime < .5f) return;
        if (Anim->SelectedDatabase.IsNone() && Now-PhaseRealTime < 20) return;
        Check(TEXT("resource_override_without_graph_copy"), Anim->SelectedDatabase == TEXT("PSD_Dense_Crouch_Idles") &&
            Anim->AnimationSet->GetName() == TEXT("DA_Gasp_Alternate"), Anim->SelectedDatabase.ToString());
        if (Anim->IsA<UGaspCppAnimInstance>()) Character->ApplyAnimationSet(LoadObject<UGaspAnimationSet>(nullptr,TEXT("/Game/Native/DA_Gasp_UEFN.DA_Gasp_UEFN")));
        else Character->GetMesh()->GetAnimInstance()->LinkAnimGraphByTag(TEXT("GaspCore"),
            LoadClass<UAnimInstance>(nullptr, TEXT("/Game/Native/ABP_Gasp_UEFN.ABP_Gasp_UEFN_C")));
        Advance(EPhase::ProfileRestore); break;
    case EPhase::ProfileRestore:
        if (PhaseTime < .5f) return;
        Check(TEXT("resource_profile_restore"), Anim->SelectedDatabase == TEXT("PSD_Dense_Stand_Idles"));
        CollectGarbage(RF_NoFlags);
        Check(TEXT("native_proxy_survives_gc"), UGaspNativeAnimInstance::Resolve(Character->GetMesh())==Anim);
        InitialLocation = Character->GetActorLocation();
        InitialFoot = Character->GetMesh()->GetSocketLocation(TEXT("foot_l"));
        PreviousThighRotation = Character->GetMesh()->GetBoneSpaceTransforms()[Character->GetMesh()->GetBoneIndex(TEXT("thigh_l"))].GetRotation();
        Advance(EPhase::Run); break;
    case EPhase::Run:
        Character->AddMovementInput(FVector::ForwardVector);
        {
            const FQuat Thigh = Character->GetMesh()->GetBoneSpaceTransforms()[Character->GetMesh()->GetBoneIndex(TEXT("thigh_l"))].GetRotation();
            if (PreviousThighRotation.AngularDistance(Thigh) > .0001f) ++PoseChangedFrames;
            PreviousThighRotation = Thigh;

        }
        if (PhaseTime < 2) return;
        Check(TEXT("run_movement"), Character->GetActorLocation().X > InitialLocation.X+300, Character->GetActorLocation().ToString());
        Check(TEXT("run_database"), !Anim->SelectedDatabase.IsNone(), Anim->SelectedDatabase.ToString());
        Check(TEXT("animated_pose_finite"), !Character->GetMesh()->GetSocketLocation(TEXT("foot_l")).ContainsNaN() &&
            !Character->GetMesh()->GetSocketLocation(TEXT("foot_l")).Equals(InitialFoot) && PoseChangedFrames > 30,
            FString::Printf(TEXT("local_thigh_changed_frames=%d"), PoseChangedFrames));
        Check(TEXT("native_sample_warp_updates"), Anim->SampleUpdateCount > 30, FString::FromInt(Anim->SampleUpdateCount));
        Character->bWantsToSprint = true;
        Advance(EPhase::Sprint); break;
    case EPhase::Sprint:
        Character->AddMovementInput(FVector::ForwardVector);
        if (PhaseTime < 1.5f) return;
        Check(TEXT("sprint"), Character->Gait == EGaspGait::Sprint && Character->GetVelocity().Size2D() > 600, Character->GetVelocity().ToString());
        Character->bWantsToSprint = false;
        Character->bWantsToWalk = true;
        Advance(EPhase::Walk); break;
    case EPhase::Walk:
        Character->AddMovementInput(FVector::ForwardVector);
        if (PhaseTime < 1.5f) return;
        Check(TEXT("walk"), Character->Gait == EGaspGait::Walk && Character->GetVelocity().Size2D() < 210);
        Advance(EPhase::Stop); break;
    case EPhase::Stop:
        if (PhaseTime < 1) return;
        Character->Crouch(); Advance(EPhase::Crouch); break;
    case EPhase::Crouch:
        if (PhaseTime < .5f) return;
        Check(TEXT("crouch"), Character->bIsCrouched && Anim->Stance == 1);
        Character->UnCrouch(); Character->bWantsToWalk = false;
        Advance(EPhase::Uncrouch); break;
    case EPhase::Uncrouch:
        if (PhaseTime < .5f) return;
        Character->Jump(); Advance(EPhase::Jump); break;
    case EPhase::Jump:
        if (PhaseTime < .1f) return;
        Check(TEXT("jump"), Move->IsFalling() && Anim->MovementMode == 1);
        Character->StopJumping(); Advance(EPhase::Land); break;
    case EPhase::Land:
        if (PhaseTime < 1.5f) return;
        Check(TEXT("land"), Move->IsMovingOnGround());
        Anim->MMDatabaseLOD = 1; Advance(EPhase::Sparse); break;
    case EPhase::Sparse:
        Character->AddMovementInput(FVector::ForwardVector);
        if (PhaseTime < .5f) return;
        {
            bool bHasSparse = false;
            for (auto& DB : Anim->CurrentDatabases) bHasSparse |= DB->GetName().Contains(TEXT("Sparse"));
            Check(TEXT("sparse_database"), bHasSparse);
        }
        Anim->MMDatabaseLOD = 0; Advance(EPhase::PrepareTraversal); break;
    case EPhase::PrepareTraversal:
        if (!Block)
        {
            const float Heights[] = {100,150,200,100,100,100};
            const FVector Base(-900, TraversalCase*350-600, TraversalCase == 4 ? 300 : 0);
            if (TraversalCase == 4)
            {
                Platform = GetWorld()->SpawnActor<AStaticMeshActor>();
                Platform->GetStaticMeshComponent()->SetMobility(EComponentMobility::Movable);
                Platform->GetStaticMeshComponent()->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube")));
                Platform->SetActorLocation(Base+FVector(50,0,-25));
                Platform->SetActorScale3D(FVector(1.5,3,.5));
                Platform->GetStaticMeshComponent()->SetCollisionProfileName(TEXT("BlockAll"));
            }
            Block = GetWorld()->SpawnActor<AGaspTraversableBlock>();
            Block->GetRootComponent()->SetMobility(EComponentMobility::Movable);
            Block->SetActorLocation(Base+FVector(200,0,Heights[TraversalCase]/2));
            Block->SetActorScale3D(FVector(TraversalCase == 3 || TraversalCase == 4 ? .2 : 1.2,3,Heights[TraversalCase]/100));
            Character->SetActorLocation(Base+FVector(100,0,88.2), false, nullptr, ETeleportType::TeleportPhysics);
            Character->SetActorRotation(FRotator::ZeroRotator);
            Move->StopMovementImmediately();
            Move->SetMovementMode(MOVE_Walking);
            InitialLocation = Character->GetActorLocation();
        }
        if (PhaseTime < .5f) return;
        bStartedTraversal = false;
        Advance(EPhase::Traverse); break;
    case EPhase::Traverse:
        bStartedTraversal = Character->Traversal->TryTraversal();
        if (!bStartedTraversal && Now-PhaseRealTime < 20) return;
        Check(*FString::Printf(TEXT("traversal_%d_started"), TraversalCase), bStartedTraversal,
            FString::Printf(TEXT("action=%d montage=%s"), uint8(Character->Traversal->LastResult.Action), *GetNameSafe(Character->Traversal->LastResult.Montage)));
        {
            const EGaspTraversalAction Expected[] = {EGaspTraversalAction::Mantle, EGaspTraversalAction::Mantle,
                EGaspTraversalAction::Mantle, EGaspTraversalAction::Hurdle, EGaspTraversalAction::Vault, EGaspTraversalAction::Mantle};
            Check(*FString::Printf(TEXT("traversal_%d_action"), TraversalCase), Character->Traversal->LastResult.Action == Expected[TraversalCase]);
        }
        Advance(TraversalCase == 5 ? EPhase::Interrupt : EPhase::Settle); break;
    case EPhase::Settle:
        if (PhaseTime < 4) return;
        Check(*FString::Printf(TEXT("traversal_%d_finished"), TraversalCase), bStartedTraversal && !Character->Traversal->bDoingTraversal &&
            !Character->GetCapsuleComponent()->GetMoveIgnoreActors().Contains(Block.Get()) &&
            !Character->GetActorLocation().ContainsNaN() && Character->GetActorLocation().X > InitialLocation.X+25, Character->GetActorLocation().ToString());
        Block->Destroy(); Block = nullptr;
        if (Platform) { Platform->Destroy(); Platform = nullptr; }
        ++TraversalCase;
        Advance(EPhase::PrepareTraversal); break;
    case EPhase::Interrupt:
        if (PhaseTime < .15f) return;
        Character->GetMesh()->GetAnimInstance()->Montage_Stop(.1f);
        Check(TEXT("traversal_interrupted"), bStartedTraversal && !Character->Traversal->bDoingTraversal &&
            !Character->GetCapsuleComponent()->GetMoveIgnoreActors().Contains(Block.Get()));
        Finish(); break;
    default: break;
    }
}





void AGaspSmokeRunner::TickMarker(float DeltaSeconds)
{
    const bool ConfigTest=FParse::Param(FCommandLine::Get(),TEXT("ConfigSmoke"));
    if (Phase==EPhase::Done) return;
    const double Now=FPlatformTime::Seconds();
    if (!Started) Started=Now;
    if (Now-Started>60) { Check(TEXT("marker_timeout"),false); Finish(); return; }
    if (!Character) Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if (!Character) return;
    auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    if (!Anim || !Anim->AnimationSet) return;
    PhaseTime+=DeltaSeconds;
    const FName Thigh=Anim->AnimationSet->Bones.Thighs[0];
    const int32 Index=Character->GetMesh()->GetBoneIndex(Thigh);
    if (Phase==EPhase::Warmup)
    {
        if (PhaseTime<.5f) return;
        Check(TEXT("marker_native_class"),Anim->IsA<UGaspCppAnimInstance>() && !Anim->GetClass()->HasAnyClassFlags(CLASS_CompiledFromBlueprint));
        Check(TEXT("marker_resource_valid"),Anim->bAnimationSetValid && Anim->AnimationSet->GetName()==(ConfigTest ? TEXT("DA_Config") : TEXT("DA_Marker_Run")));
        Check(TEXT("marker_own_mesh"),Character->GetMesh()->GetSkeletalMeshAsset()->GetName()==TEXT("SK_Marker"));
        InitialLocation=Character->GetActorLocation();
        PreviousThighRotation=Character->GetMesh()->GetBoneSpaceTransforms()[Index].GetRotation();
        Advance(EPhase::Run); return;
    }
    if (Phase==EPhase::Run)
    {
        Character->AddMovementInput(FVector::ForwardVector);
        const FQuat Rotation=Character->GetMesh()->GetBoneSpaceTransforms()[Index].GetRotation();
        if (PreviousThighRotation.AngularDistance(Rotation)>.0001f) ++PoseChangedFrames;
        PreviousThighRotation=Rotation;
        if (PhaseTime<3 || (Anim->SelectedAnimation.IsNone() && Now-Started<30)) return;
        Check(TEXT("marker_run_database"),Anim->SelectedDatabase==(ConfigTest ? TEXT("PSD_run") : TEXT("PSD_Marker_Run")),Anim->SelectedDatabase.ToString());
        Check(TEXT("marker_fbx_animation"),Anim->SelectedAnimation==TEXT("A_FastRun"),Anim->SelectedAnimation.ToString());
        Check(TEXT("marker_continuous_pose"),PoseChangedFrames>50,FString::FromInt(PoseChangedFrames));
        Check(TEXT("marker_cmc_movement"),Character->GetActorLocation().X-InitialLocation.X>500);
        CollectGarbage(RF_NoFlags);
        Advance(EPhase::Stop); return;
    }
    if (Phase==EPhase::Stop && PhaseTime>1)
    {
        Check(TEXT("marker_stop"),Character->GetVelocity().Size2D()<5);
        const auto& Actual=Character->GetMesh()->GetBoneSpaceTransforms();
        const auto& Reference=Character->GetMesh()->GetSkeletalMeshAsset()->GetRefSkeleton().GetRefBonePose();
        Check(TEXT("marker_reference_idle"),Actual[Index].Equals(Reference[Index],.01f));
        Finish();
    }
}

void AGaspSmokeRunner::TickDirectionalQuality(float DeltaSeconds)
{
    if(Phase==EPhase::Done)return;
    const double Now=FPlatformTime::Seconds();if(!Started)Started=Now;
    if(Now-Started>90){Check(TEXT("directional_timeout"),false);Finish();return;}
    if(!Character)Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if(!Character)return;
    auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh());auto* Move=Character->GetCharacterMovement();
    if(!Anim || !Anim->bAnimationSetValid)return;
    if(QualityStage==0)
    {
        PhaseTime+=DeltaSeconds;if(PhaseTime<2 || Anim->SelectedAnimation.IsNone())return;
        Check(TEXT("directional_sample_warping_enabled"),Anim->AnimationSet->bEnableSampleWarping);
        Check(TEXT("directional_root_offset_enabled"),Anim->AnimationSet->bEnableRootOffset);
        if(Failures){Finish();return;}
        ++QualityStage;PhaseTime=0;
    }
    if(PhaseTime==0)
    {
        Move->StopMovementImmediately();Character->SetActorLocation(FVector(500,-750,88.2),false,nullptr,ETeleportType::TeleportPhysics);
        Character->SetActorRotation(FRotator::ZeroRotator);
        Character->GetController()->SetControlRotation(FRotator::ZeroRotator);
        Character->bWantsToWalk=false;Character->bWantsToSprint=false;Character->bWantsToStrafe=QualityStage<=10;
        if(QualityStage>=5 && QualityStage<=8)Character->Crouch();else Character->UnCrouch();
        QualityEmptyFrames=QualityPoseFrames=PoseChangedFrames=0;DirectionalMaxCurve=0;
        QualityLastTime=Anim->SelectedTime;QualityMaxAngularStep=0;
        PreviousThighRotation=Character->GetMesh()->GetBoneSpaceTransforms()[Character->GetMesh()->GetBoneIndex(Anim->AnimationSet->Bones.Thighs[0])].GetRotation();
    }
    PhaseTime+=DeltaSeconds;
    const FVector Diagonals[]={FVector(1,-1,0),FVector(1,1,0),FVector(-1,-1,0),FVector(-1,1,0)};
    if(QualityStage<=8)
    {
        const FVector Input=Diagonals[(QualityStage-1)%4];
        // Two separate inputs, as produced by simultaneous WASD axis bindings.
        Character->AddMovementInput(FVector::ForwardVector,Input.X);
        Character->AddMovementInput(FVector::RightVector,Input.Y);
    }
    else
    {
        auto* Controller=Character->GetController();
        const float Sign=QualityStage%2 ? 1.f : -1.f;
        Controller->SetControlRotation(FRotator(0,Sign*PhaseTime*60.f,0));
        Character->AddMovementInput(FRotationMatrix(Controller->GetControlRotation()).GetUnitAxis(EAxis::X));
    }
    const FQuat Thigh=Character->GetMesh()->GetBoneSpaceTransforms()[Character->GetMesh()->GetBoneIndex(Anim->AnimationSet->Bones.Thighs[0])].GetRotation();
    const float Step=PreviousThighRotation.AngularDistance(Thigh);PreviousThighRotation=Thigh;
    if(PhaseTime>.4f)
    {
        if(Anim->SelectedAnimation.IsNone() || Anim->CurrentDatabases.IsEmpty())++QualityEmptyFrames;
        if(FMath::Abs(Anim->SelectedTime-QualityLastTime)>.0001f)++QualityPoseFrames;
        QualityLastTime=Anim->SelectedTime;
        if(Step>.0001f)++PoseChangedFrames;
        QualityMaxAngularStep=FMath::Max(QualityMaxAngularStep,Step);
        const FVector Near=Anim->PredictedTrajectoryNear.GetSafeNormal2D(),Far=Anim->PredictedTrajectoryFar.GetSafeNormal2D();
        if(!Near.IsNearlyZero() && !Far.IsNearlyZero())DirectionalMaxCurve=FMath::Max(DirectionalMaxCurve,FMath::RadiansToDegrees(FMath::Acos(FMath::Clamp(FVector::DotProduct(Near,Far),-1.f,1.f))));
    }
    if(PhaseTime<1.8f)return;
    const FString Prefix=FString::Printf(TEXT("directional_stage_%d"),QualityStage);
    Check(*(Prefix+TEXT("_no_empty_pose")),QualityEmptyFrames==0);
    Check(*(Prefix+TEXT("_animation_advances")),QualityPoseFrames>10 && PoseChangedFrames>10);
    Check(*(Prefix+TEXT("_finite_no_snap")),!Character->GetMesh()->GetSocketLocation(Anim->AnimationSet->Bones.Feet[0]).ContainsNaN() && QualityMaxAngularStep<1.2f,FString::Printf(TEXT("max_thigh_degrees=%.2f"),FMath::RadiansToDegrees(QualityMaxAngularStep)));
    if(QualityStage<=8)
    {
        const FVector Expected=Diagonals[(QualityStage-1)%4].GetSafeNormal();
        Check(*(Prefix+TEXT("_combined_direction")),FVector::DotProduct(Expected,Character->GetVelocity().GetSafeNormal2D())>.98f,Character->GetVelocity().ToString());
        const float MaxSpeed=Character->bIsCrouched ? Move->MaxWalkSpeedCrouched : Move->MaxWalkSpeed;
        Check(*(Prefix+TEXT("_no_diagonal_speed_boost")),Character->GetVelocity().Size2D()<=MaxSpeed+2 && Character->GetVelocity().Size2D()>50);
    }
    else Check(*(Prefix+TEXT("_curved_prediction")),DirectionalMaxCurve>3.f,FString::Printf(TEXT("near_far_angle=%.2f"),DirectionalMaxCurve));
    ++QualityStage;PhaseTime=0;if(QualityStage>12)Finish();
}

void AGaspSmokeRunner::TickConfigQuality(float DeltaSeconds)
{
    const bool bGroundLeaf=FParse::Param(FCommandLine::Get(),TEXT("GroundLeafSmoke"));
    const bool bSemanticTemplate=FParse::Param(FCommandLine::Get(),TEXT("SemanticTemplateSmoke"));
    const bool bMMGroups=FParse::Param(FCommandLine::Get(),TEXT("MMGroupsSmoke"));
    const bool bMMGroupOverride=FParse::Param(FCommandLine::Get(),TEXT("MMGroupOverrideSmoke"));
    if(Phase==EPhase::Done)return;
    const double Now=FPlatformTime::Seconds();if(!Started)Started=Now;
    if(Now-Started>90){Check(TEXT("quality_timeout"),false);Finish();return;}
    if(!Character)Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if(!Character)return;
    auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh());auto* Move=Character->GetCharacterMovement();
    if(!Anim || !Anim->bAnimationSetValid)return;
    auto CheckSemanticState=[&](const FString& Label,FName Machine,FName Expected)
    {
        const int32 Index=Anim->GetStateMachineIndex(Machine);
        const FName Actual=Index!=INDEX_NONE ? Anim->GetCurrentStateName(Index):NAME_None;
        Check(*Label,Index!=INDEX_NONE && Actual==Expected,Machine.ToString()+TEXT(": ")+Actual.ToString());
    };
    if(QualityStage==0)
    {
        PhaseTime+=DeltaSeconds;
        if(Anim->SelectedAnimation.IsNone() || PhaseTime<2.f)return;
        Check(TEXT("quality_native_graph"),Anim->IsA<UGaspCppAnimInstance>() || Anim->GetClass()->HasAnyClassFlags(CLASS_CompiledFromBlueprint));
        if(bSemanticTemplate)
        {
            Check(TEXT("semantic_template_condition_variables_inherited"),FindFProperty<FProperty>(Anim->GetClass()->GetSuperClass(),TEXT("move_input")) && FindFProperty<FProperty>(Anim->GetClass()->GetSuperClass(),TEXT("SemanticTransition_000")));
            CheckSemanticState(TEXT("semantic_template_initial_group"),TEXT("SemanticStateMachine"),TEXT("Ground"));
            CheckSemanticState(TEXT("semantic_template_initial_leaf"),TEXT("Ground_States"),TEXT("Idle"));
        }
        if(bMMGroups || bMMGroupOverride)
        {
            FString GroupError;
            Check(TEXT("mm_groups_loaded_from_child_defaults"),Anim->MotionMatchingAnimationGroups.Num()>=7);
            Check(TEXT("mm_groups_valid_databases"),Anim->ValidateMotionMatchingAnimationGroups(Character->GetMesh()->GetSkeletalMeshAsset(),GroupError),GroupError);
            auto* Walk=Anim->MotionMatchingAnimationGroups.Find(TEXT("mm_Walk"));
            auto* Run=Anim->MotionMatchingAnimationGroups.Find(TEXT("mm_Run"));
            Check(TEXT("mm_groups_walk_and_run_mapped"),Walk && Run);
            if(Walk && Run)
            {
                TArray<UPoseSearchDatabase*> Original;Anim->GetMotionMatchingAnimationGroup(TEXT("mm_Walk"),Original);
                auto SetWalk=[&](const TArray<UPoseSearchDatabase*>& Databases)
                {
                    if(Walk->PublicVariableName.IsNone()){Walk->Databases.Reset();for(auto* DB:Databases)Walk->Databases.Add(DB);return;}
                    auto* Array=FindFProperty<FArrayProperty>(Anim->GetClass(),Walk->PublicVariableName);
                    auto* Object=Array ? CastField<FObjectPropertyBase>(Array->Inner):nullptr;
                    if(!Object)return;
                    FScriptArrayHelper Values(Array,Array->ContainerPtrToValuePtr<void>(Anim));Values.EmptyAndAddValues(Databases.Num());
                    for(int32 Index=0;Index<Databases.Num();++Index)Object->SetObjectPropertyValue(Values.GetRawPtr(Index),Databases[Index]);
                };
                SetWalk({});Check(TEXT("mm_groups_reject_empty"),!Anim->ValidateMotionMatchingAnimationGroups(Character->GetMesh()->GetSkeletalMeshAsset(),GroupError));
                SetWalk({nullptr});Check(TEXT("mm_groups_reject_invalid_database"),!Anim->ValidateMotionMatchingAnimationGroups(Character->GetMesh()->GetSkeletalMeshAsset(),GroupError));
                SetWalk(Original);
                if(bMMGroupOverride)
                {
                    FString DatabasePath;FParse::Value(FCommandLine::Get(),TEXT("MMGroupOverrideDatabase="),DatabasePath);
                    auto* Database=DatabasePath.IsEmpty() ? nullptr:LoadObject<UPoseSearchDatabase>(nullptr,*DatabasePath);
                    Check(TEXT("mm_groups_override_database_loaded"),Database!=nullptr,DatabasePath);
                    if(Database)SetWalk({Database});
                    TArray<UPoseSearchDatabase*> Effective;Anim->GetMotionMatchingAnimationGroup(TEXT("mm_Walk"),Effective);
                    Check(TEXT("mm_groups_override_uses_different_database"),Effective!=Original);
                    Check(TEXT("mm_groups_override_database_valid"),Anim->ValidateMotionMatchingAnimationGroups(Character->GetMesh()->GetSkeletalMeshAsset(),GroupError),GroupError);
                    const auto* Defaults=Cast<UGaspNativeAnimInstance>(Anim->GetClass()->GetDefaultObject());
                    TArray<UPoseSearchDatabase*> Saved;if(Defaults)Defaults->GetMotionMatchingAnimationGroup(TEXT("mm_Walk"),Saved);
                    Check(TEXT("mm_groups_override_keeps_child_defaults"),Defaults && Saved==Original);
                }
            }
        }
        Check(TEXT("quality_configured_databases"),!Anim->AnimationSet->ConfiguredLocomotion.IsEmpty());
        for(const auto& Pair:Anim->AnimationSet->ConfiguredLocomotion)
        {
            const auto* DB=Pair.Value.Get();
            Check(*(TEXT("quality_pose_index_")+Pair.Key.ToString()),DB && DB->Schema && DB->Schema->SchemaCardinality>6 && DB->GetSearchIndex().GetNumPoses()>DB->GetNumAnimationAssets(),DB ? FString::Printf(TEXT("assets=%d poses=%d dimensions=%d"),DB->GetNumAnimationAssets(),DB->GetSearchIndex().GetNumPoses(),DB->Schema ? DB->Schema->SchemaCardinality : 0):TEXT("missing"));
        }
        if(Failures){Finish();return;}
        ++QualityStage;PhaseTime=0;
    }
    if(PhaseTime==0 && QualityStage<=16)
    {
        Character->StopJumping();Move->StopMovementImmediately();
        Character->SetActorLocation(FVector(500,-750,88.2),false,nullptr,ETeleportType::TeleportPhysics);
        Character->SetActorRotation(FRotator::ZeroRotator);
        if(auto* Controller=Character->GetController())Controller->SetControlRotation(FRotator::ZeroRotator);
        Move->SetMovementMode(MOVE_Walking);Character->bWantsToSprint=false;Character->bWantsToWalk=QualityStage<=4;
        Character->bWantsToStrafe=true;Character->bWantsToAim=false;
        if((QualityStage>=9 && QualityStage<=13))Character->Crouch();else Character->UnCrouch();
        QualityEmptyFrames=QualityPoseFrames=0;QualityLastTime=Anim->SelectedTime;
        PoseChangedFrames=0;QualityMaxAngularStep=0;
        const int32 Bone=Character->GetMesh()->GetBoneIndex(Anim->AnimationSet->Bones.Thighs[0]);
        const auto& Pose=Character->GetMesh()->GetBoneSpaceTransforms();
        if(Pose.IsValidIndex(Bone))PreviousThighRotation=Pose[Bone].GetRotation();
        if(QualityStage==15){Character->bWantsToSprint=true;Character->bWantsToStrafe=false;}
        if(QualityStage==16)Character->Jump();
    }
    PhaseTime+=DeltaSeconds;
    if(QualityStage<=15)
    {
        const int32 Bone=Character->GetMesh()->GetBoneIndex(Anim->AnimationSet->Bones.Thighs[0]);
        const auto& Pose=Character->GetMesh()->GetBoneSpaceTransforms();
        if(Pose.IsValidIndex(Bone))
        {
            const FQuat Rotation=Pose[Bone].GetRotation();const float Step=PreviousThighRotation.AngularDistance(Rotation);
            if(Step>.0001f)++PoseChangedFrames;
            QualityMaxAngularStep=FMath::Max(QualityMaxAngularStep,Step);PreviousThighRotation=Rotation;
        }
    }
    if(QualityStage<=12)
    {
        const FVector Directions[]={FVector::ForwardVector,-FVector::ForwardVector,-FVector::RightVector,FVector::RightVector};
        Character->AddMovementInput(Directions[(QualityStage-1)%4]);
    }
    else if(QualityStage==15)Character->AddMovementInput(FVector::ForwardVector);
    if(PhaseTime>.35f && QualityStage<=15)
    {
        const bool Matched=Anim->CurrentDatabases.ContainsByPredicate([Anim](const auto& DB){return DB && DB->GetFName()==Anim->SelectedDatabase;});
        if(!Matched || Anim->SelectedAnimation.IsNone())++QualityEmptyFrames;
        if(FMath::Abs(Anim->SelectedTime-QualityLastTime)>.0001f)++QualityPoseFrames;
        QualityLastTime=Anim->SelectedTime;
    }
    if(QualityStage<=15 && PhaseTime>1.25f)
    {
        const FString Prefix=FString::Printf(TEXT("quality_stage_%d"),QualityStage);
        Check(*(Prefix+TEXT("_no_empty_pose")),QualityEmptyFrames==0);
        Check(*(Prefix+TEXT("_pose_time_advances")),QualityPoseFrames>5);
        if(bGroundLeaf)
        {
            const FString State=Character->Behavior ? Character->Behavior->CurrentState.ToString() : TEXT("none");
            const FString Detail=FString::Printf(TEXT("selected=%s state=%s behavior=%d error=%s raw=(%.2f,%.2f) gait=%d crouched=%d falling=%d"),*Anim->SelectedDatabase.ToString(),*State,Character->Behavior && Character->Behavior->IsEnabled(),Character->Behavior ? *Character->Behavior->LastError : TEXT("missing"),Character->RawMoveInput.X,Character->RawMoveInput.Y,uint8(Character->Gait),Character->bIsCrouched,Move->IsFalling());
            bool bExpectedDatabase=false;
            if(Character->Behavior && Character->Behavior->IsEnabled())
            {
                TArray<UPoseSearchDatabase*> StateDatabases;
                bExpectedDatabase=Character->Behavior->GetDatabaseOverride(StateDatabases) && StateDatabases.ContainsByPredicate([Anim](const UPoseSearchDatabase* DB){return DB && DB->GetFName()==Anim->SelectedDatabase;});
            }
            else
            {
                const FName ExpectedRole=QualityStage<=4 ? TEXT("walk") : QualityStage<=8 ? TEXT("run") : TEXT("idle");
                const auto* DB=Anim->AnimationSet->ConfiguredLocomotion.Find(ExpectedRole);
                bExpectedDatabase=DB && *DB && Anim->SelectedDatabase==(*DB)->GetFName();
            }
            Check(*(Prefix+TEXT("_expected_database")),bExpectedDatabase,Detail);
            if(bSemanticTemplate)
            {
                const FName ExpectedLeaf=QualityStage<=4 ? TEXT("Walk"):QualityStage<=8 ? TEXT("Run"):TEXT("Idle");
                CheckSemanticState(Prefix+TEXT("_semantic_group"),TEXT("SemanticStateMachine"),TEXT("Ground"));
                CheckSemanticState(Prefix+TEXT("_semantic_leaf"),TEXT("Ground_States"),ExpectedLeaf);
            }
            if((bMMGroupOverride || FParse::Param(FCommandLine::Get(),TEXT("ExpectedMMGroupOverride"))) && QualityStage<=4)
            {
                TArray<UPoseSearchDatabase*> Group;Anim->GetMotionMatchingAnimationGroup(TEXT("mm_Walk"),Group);
                const auto Original=Anim->AnimationSet->ConfiguredLocomotion.FindRef(TEXT("mm_Walk"));
                Check(*(Prefix+TEXT("_mm_group_override_applied")),Group.ContainsByPredicate([Anim](const auto* DB){return DB && DB->GetFName()==Anim->SelectedDatabase;}) && Original && Original->GetFName()!=Anim->SelectedDatabase,Anim->SelectedDatabase.ToString());
            }
            FString ExpectedState;
            if(FParse::Value(FCommandLine::Get(),TEXT("ExpectedBehaviorState="),ExpectedState))
                Check(*(Prefix+TEXT("_same_behavior_leaf")),Character->Behavior && Character->Behavior->CurrentState==FName(*ExpectedState));
        }
        Check(*(Prefix+TEXT("_no_bone_snap")),QualityMaxAngularStep<1.2f,FString::Printf(TEXT("max_thigh_degrees_per_frame=%.3f"),FMath::RadiansToDegrees(QualityMaxAngularStep)));
        if(QualityStage<=12 || QualityStage==15)Check(*(Prefix+TEXT("_skeleton_animates")),PoseChangedFrames>5,FString::FromInt(PoseChangedFrames));
        if(QualityStage==13)Check(TEXT("quality_crouch_stopped_idle"),Anim->SelectedAnimation.ToString().Contains(TEXT("Crouch_Idle")),Anim->SelectedAnimation.ToString());
        if(QualityStage<=12)
        {
            const TCHAR* Suffixes[]={TEXT("_F"),TEXT("_B"),TEXT("_LL"),TEXT("_RL")};
            Check(*(Prefix+TEXT("_direction_clip")),Anim->SelectedAnimation.ToString().EndsWith(Suffixes[(QualityStage-1)%4]),Anim->SelectedAnimation.ToString());
        }
        if(QualityStage<=12 || QualityStage==15)Check(*(Prefix+TEXT("_moves")),Character->GetVelocity().Size2D()>20,Character->GetActorLocation().ToString());
        if(bGroundLeaf && QualityStage==14){if(bSemanticTemplate){QualityStage=16;PhaseTime=0;}else Finish();return;}
        ++QualityStage;if(bGroundLeaf && QualityStage==9)QualityStage=14;PhaseTime=0;return;
    }
    if(QualityStage==16 && PhaseTime>.2f)
    {
        if(bSemanticTemplate)
        {
            Check(TEXT("semantic_template_jump_airborne"),Move->IsFalling());
            CheckSemanticState(TEXT("semantic_template_air_group"),TEXT("SemanticStateMachine"),TEXT("Air"));
            CheckSemanticState(TEXT("semantic_template_jump_rise"),TEXT("Air_States"),TEXT("JumpRise"));
            Character->StopJumping();QualityStage=17;PhaseTime=0;return;
        }
        Check(TEXT("quality_jump_airborne"),Move->IsFalling());
        const auto* DB=Anim->AnimationSet->ConfiguredLocomotion.Find(TEXT("jump"));
        Check(TEXT("quality_jump_searches_airborne_database"),DB && *DB && Anim->SelectedDatabase==(*DB)->GetFName() && !Anim->SelectedAnimation.IsNone());
        Character->StopJumping();++QualityStage;return;
    }
    if(bSemanticTemplate && QualityStage==17 && Character->GetVelocity().Z< -20.f)
    {
        CheckSemanticState(TEXT("semantic_template_jump_fall"),TEXT("Air_States"),TEXT("JumpFall"));
        QualityStage=18;PhaseTime=0;return;
    }
    if(bSemanticTemplate && QualityStage==18 && PhaseTime>.2f && !Move->IsFalling())
    {
        CheckSemanticState(TEXT("semantic_template_landed_group"),TEXT("SemanticStateMachine"),TEXT("Ground"));
        CheckSemanticState(TEXT("semantic_template_landed_leaf"),TEXT("Ground_States"),TEXT("Idle"));
        Finish();return;
    }
    if(!bSemanticTemplate && QualityStage==17 && Move->IsMovingOnGround() && PhaseTime>1.4f)
    {Check(TEXT("quality_landed_returns_to_ground_database"),!Anim->SelectedAnimation.IsNone() && !Anim->CurrentDatabases.IsEmpty());Finish();}
}

void AGaspSmokeRunner::TickBehaviorQuality(float DeltaSeconds)
{
    if(FParse::Param(FCommandLine::Get(),TEXT("BehaviorGeneratedSmoke"))){TickBehaviorGenerated(DeltaSeconds);return;}
    if(FParse::Param(FCommandLine::Get(),TEXT("BehaviorCompilerSmoke"))){TickBehaviorCompiler(DeltaSeconds);return;}
    if(Phase==EPhase::Done)return;
    const double Now=FPlatformTime::Seconds();if(!Started)Started=Now;
    if(Now-Started>120){Check(TEXT("behavior_timeout"),false,FString::Printf(TEXT("stage=%d"),FlowStage));Finish();return;}
    PhaseTime+=DeltaSeconds;
    if(!Character)Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if(!Character)return;
    auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    auto* Behavior=Character->Behavior.Get();auto* Move=Character->GetCharacterMovement();
    if(!Anim || !Anim->bAnimationSetValid || !Behavior || !Behavior->IsEnabled())
    {if(PhaseTime>15){Check(TEXT("behavior_runtime_ready"),false,Behavior ? Behavior->LastError:TEXT("missing behavior component"));Finish();}return;}
    auto Next=[&](){++FlowStage;PhaseTime=0;};
    auto Is=[&](const TCHAR* State){return Behavior->CurrentState==FName(State);};
    auto Value=[&](const TCHAR* Name){return Behavior->GetVariable(FName(Name));};
    auto Key=[&](const TCHAR* Name,EInputEvent Event=IE_Pressed)
    {
        int32 Count=0;const FKey K{FName(Name)};
        if(Character->InputComponent)for(const auto& Binding:Character->InputComponent->KeyBindings)
            if(Binding.Chord.Key==K && Binding.KeyEvent==Event){Binding.KeyDelegate.Execute(K);++Count;}
        Check(*(FString::Printf(TEXT("behavior_input_%d_%s_%d"),FlowStage,Name,int32(Event))),Count==1,FString::FromInt(Count));
    };
    if(FlowStage>0 && PhaseTime>15)
    {Check(TEXT("behavior_stage_timeout"),false,FString::Printf(TEXT("stage=%d state=%s error=%s"),FlowStage,*Behavior->CurrentState.ToString(),*Behavior->LastError));Finish();return;}
    switch(FlowStage)
    {
    case 0:
        if(PhaseTime<2 || Anim->SelectedAnimation.IsNone())return;
        Check(TEXT("behavior_actual_target_blueprint"),Character->GetClass()->GetPathName()==TEXT("/Game/Blueprints/Character/BP_CusGaspNativeCharacter.BP_CusGaspNativeCharacter_C"),Character->GetClass()->GetPathName());
        Check(TEXT("behavior_isolated_config"),Anim->AnimationSet->GetName()==TEXT("DA_BehaviorQuality"),Anim->AnimationSet->GetPathName());
        Check(TEXT("behavior_native_mm_initial_pose"),Anim->IsA<UGaspCppAnimInstance>() && !Anim->CurrentDatabases.IsEmpty());
        Check(TEXT("behavior_nested_entry"),Is(TEXT("Move")) && Behavior->IsStateActive(TEXT("Root")) && Value(TEXT("RootEntries"))==1);
        Check(TEXT("behavior_external_bool_initial_false"),!Behavior->GetBoolVariable(TEXT("bHit")));
        Check(TEXT("behavior_reject_unknown_variable"),!Behavior->SetVariable(TEXT("MissingVariable"),1));
        Check(TEXT("behavior_reject_builtin_write"),!Behavior->SetVariable(TEXT("finished"),1));
        {
            auto Reject=[&](const TCHAR* Name,TFunction<void(TSharedPtr<FJsonObject>)> Mutate)
            {
                auto* Invalid=DuplicateObject<UGaspAnimationSet>(Anim->AnimationSet,this);
                TSharedPtr<FJsonObject> G;FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Invalid->BehaviorGraphJson),G);
                if(!G){Check(Name,false,TEXT("fixture JSON failed to parse"));return;}
                Mutate(G);FJsonSerializer::Serialize(G,TJsonWriterFactory<>::Create(&Invalid->BehaviorGraphJson));
                FString Error;Check(Name,!Invalid->ValidateForMesh(Character->GetMesh()->GetSkeletalMeshAsset(),Error),Error);
            };
            Reject(TEXT("behavior_reject_missing_parent"),[](auto G){G->GetArrayField(TEXT("states"))[1]->AsObject()->SetStringField(TEXT("parent"),TEXT("MissingParent"));});
            Reject(TEXT("behavior_reject_parent_cycle"),[](auto G){G->GetArrayField(TEXT("states"))[0]->AsObject()->SetStringField(TEXT("parent"),TEXT("Combo"));});
            Reject(TEXT("behavior_reject_invalid_group_entry"),[](auto G){G->GetArrayField(TEXT("states"))[0]->AsObject()->SetStringField(TEXT("initial"),TEXT("Attack3"));});
            Reject(TEXT("behavior_reject_unretained_resource"),[](auto G){G->GetArrayField(TEXT("states"))[4]->AsObject()->SetArrayField(TEXT("resources"),{MakeShared<FJsonValueString>(TEXT("/Game/Missing.Missing"))});});
            Reject(TEXT("behavior_reject_unknown_action"),[](auto G){G->GetArrayField(TEXT("states"))[0]->AsObject()->GetArrayField(TEXT("on_entry"))[0]->AsObject()->SetStringField(TEXT("op"),TEXT("execute_code"));});
            Reject(TEXT("behavior_reject_missing_bool"),[](auto G){G->GetArrayField(TEXT("states"))[1]->AsObject()->RemoveField(TEXT("allow_movement"));});
        }
        if(Failures){Finish();return;}
        Character->SetActorLocation(FVector(500,-750,88.2),false,nullptr,ETeleportType::TeleportPhysics);
        Move->StopMovementImmediately();Move->SetMovementMode(MOVE_Walking);
        Key(TEXT("RightMouseButton"));Check(TEXT("behavior_guard_key_enter"),Is(TEXT("Guard")) && Value(TEXT("Held"))==1);
        Next();break;
    case 1:
        if(PhaseTime<.4f)return;
        Check(TEXT("behavior_guard_slot_plays"),Character->GetMesh()->GetAnimInstance()->IsSlotActive(Anim->AnimationSet->MontageSlot));
        Check(TEXT("behavior_loop_has_no_completion"),Value(TEXT("finished"))==0);
        CollectGarbage(RF_NoFlags);
        Check(TEXT("behavior_survives_gc"),Behavior->IsEnabled() && Is(TEXT("Guard")) && UGaspNativeAnimInstance::Resolve(Character->GetMesh())==Anim);
        Key(TEXT("LeftMouseButton"));Check(TEXT("behavior_guard_has_no_attack_edge"),Is(TEXT("Guard")));
        Key(TEXT("RightMouseButton"),IE_Released);Check(TEXT("behavior_release_returns_mm"),Is(TEXT("Move")) && Value(TEXT("Held"))==0);
        Key(TEXT("LeftMouseButton"));Check(TEXT("behavior_nested_combo_initial"),Is(TEXT("Attack1")) && Behavior->IsStateActive(TEXT("Combat")) && Behavior->IsStateActive(TEXT("Combo")));
        Next();break;
    case 2:
        if(!Is(TEXT("Move")))return;
        Check(TEXT("behavior_internal_attack_repeats_three_times"),Value(TEXT("Attack1Done"))==3 && Value(TEXT("Attack1Entries"))==3,FString::Printf(TEXT("done=%.0f entries=%.0f"),Value(TEXT("Attack1Done")),Value(TEXT("Attack1Entries"))));
        Check(TEXT("behavior_external_false_blocks_attack2"),Value(TEXT("Attack2Entries"))==0);
        Check(TEXT("behavior_groups_enter_exit_once"),Value(TEXT("CombatEntries"))==1 && Value(TEXT("CombatExits"))==1 && Value(TEXT("ComboEntries"))==1 && Value(TEXT("ComboExits"))==1);
        Check(TEXT("behavior_external_bool_setter"),Behavior->SetBoolVariable(TEXT("bHit"),true) && Behavior->GetBoolVariable(TEXT("bHit")));
        Key(TEXT("LeftMouseButton"));Next();break;
    case 3:
        if(!Is(TEXT("Attack2")))return;
        Check(TEXT("behavior_external_true_recursive_condition_attack2"),Value(TEXT("Attack1Done"))==6 && Value(TEXT("Attack2Entries"))==1);
        Check(TEXT("behavior_sequence_movement_locked"),!Behavior->AllowsMovement());
        Key(TEXT("LeftMouseButton"));Check(TEXT("behavior_press_buffered_while_locked"),Is(TEXT("Attack2")) && Value(TEXT("Queued"))==1);
        Next();break;
    case 4:
        if(!Is(TEXT("Attack3")))return;
        Check(TEXT("behavior_buffer_consumed_for_attack3"),Value(TEXT("Attack2Done"))==1 && Value(TEXT("Queued"))==0 && Value(TEXT("Attack3Entries"))==1);
        Next();break;
    case 5:
        if(!Is(TEXT("Move")))return;
        Check(TEXT("behavior_combo_three_finished_returns_mm"),Value(TEXT("Attack3Done"))==1 && Behavior->AllowsMovement());
        Key(TEXT("LeftMouseButton"));Next();break;
    case 6:
        if(PhaseTime<.08f)return;
        Check(TEXT("behavior_lock_rejects_noninterrupt"),!Behavior->SendEvent(TEXT("Cancel")) && Is(TEXT("Attack1")));
        Key(TEXT("H"));
        Check(TEXT("behavior_parent_interrupt_catches_descendant"),Is(TEXT("Hurt")) && Value(TEXT("CombatHit"))==1 && Value(TEXT("RootHit"))==0);
        Check(TEXT("behavior_interruption_does_not_count_completion"),Value(TEXT("Attack1Done"))==6);
        Key(TEXT("RightMouseButton"));Check(TEXT("behavior_hold_updates_during_reaction"),Is(TEXT("Hurt")) && Value(TEXT("Held"))==1);
        Next();break;
    case 7:
        if(!Is(TEXT("Guard")))return;
        Check(TEXT("behavior_hit_completed_conditional_guard_return"),Value(TEXT("HurtDone"))==1 && Value(TEXT("Attack1Done"))==6);
        Key(TEXT("RightMouseButton"),IE_Released);Key(TEXT("LeftMouseButton"));Behavior->SendEvent(TEXT("Probe"));
        Check(TEXT("behavior_deeper_edge_wins_equal_priority"),Is(TEXT("Guard")) && Value(TEXT("LeafProbe"))==1 && Value(TEXT("ParentProbe"))==0);
        Check(TEXT("behavior_common_parent_preserved"),Value(TEXT("RootEntries"))==1 && Value(TEXT("RootExits"))==0 && Value(TEXT("CombatEntries"))==4 && Value(TEXT("CombatExits"))==4);
        Key(TEXT("RightMouseButton"),IE_Released);
        Move->StopMovementImmediately();Character->SetActorLocation(FVector(500,-750,88.2),false,nullptr,ETeleportType::TeleportPhysics);Move->SetMovementMode(MOVE_Walking);
        Key(TEXT("SpaceBar"));Next();break;
    case 8:
        if(PhaseTime<.12f)return;
        Check(TEXT("behavior_first_jump_has_physics"),Is(TEXT("Jump1")) && Move->IsFalling() && Move->Velocity.Z>100 && Value(TEXT("JumpCount"))==1,Move->Velocity.ToString());
        Check(TEXT("behavior_jump_parent_active"),Behavior->IsStateActive(TEXT("JumpGroup")) && Value(TEXT("JumpEntries"))==1);
        Key(TEXT("SpaceBar"));Check(TEXT("behavior_jump_self_reentry_count"),Is(TEXT("Jump1")) && Value(TEXT("JumpCount"))==2 && Value(TEXT("Jump1Entries"))==2);
        Next();break;
    case 9:
        if(PhaseTime<.12f)return;
        Check(TEXT("behavior_second_air_jump_has_physics"),Move->IsFalling() && Move->Velocity.Z>100 && Value(TEXT("JumpEntries"))==1,Move->Velocity.ToString());
        Key(TEXT("SpaceBar"));Next();break;
    case 10:
        if(PhaseTime<.12f)return;
        Check(TEXT("behavior_third_press_special_jump"),Is(TEXT("Jump2")) && Value(TEXT("JumpCount"))==3 && Value(TEXT("Jump2Entries"))==1 && Move->Velocity.Z>500,Move->Velocity.ToString());
        {
            const auto* DB=Anim->AnimationSet->ConfiguredLocomotion.Find(TEXT("jump"));
            Check(TEXT("behavior_airborne_mm_override"),DB && *DB && Anim->CurrentDatabases.Contains(*DB) && !Anim->SelectedAnimation.IsNone(),Anim->SelectedDatabase.ToString());
        }
        Key(TEXT("SpaceBar"));Check(TEXT("behavior_fourth_jump_not_invented"),Is(TEXT("Jump2")) && Value(TEXT("JumpCount"))==3);
        Next();break;
    case 11:
        if(!Is(TEXT("Move")) || !Move->IsMovingOnGround())return;
        Check(TEXT("behavior_landing_exits_jump_group_and_resets"),Value(TEXT("JumpExits"))==1 && Value(TEXT("JumpCount"))==0 && !Behavior->IsStateActive(TEXT("JumpGroup")));
        Check(TEXT("behavior_mm_role_event"),Behavior->SendEvent(TEXT("RoleToggle")) && Is(TEXT("MMRole")));
        Next();break;
    case 12:
        if(PhaseTime<.4f)return;
        {
            const auto* DB=Anim->AnimationSet->ConfiguredLocomotion.Find(TEXT("walk"));
            Check(TEXT("behavior_ground_mm_override"),DB && *DB && Anim->CurrentDatabases.Contains(*DB) && !Anim->SelectedAnimation.IsNone(),Anim->SelectedDatabase.ToString());
        }
        CollectGarbage(RF_NoFlags);
        Check(TEXT("behavior_mm_override_survives_gc"),Behavior->SendEvent(TEXT("RoleToggle")) && Is(TEXT("Move")));
        QualityEmptyFrames=QualityPoseFrames=0;QualityLastTime=Anim->SelectedTime;InitialLocation=Character->GetActorLocation();
        Next();break;
    case 13:
        Character->AddMovementInput(FVector::ForwardVector);
        if(PhaseTime>.35f)
        {
            if(Anim->SelectedAnimation.IsNone() || Anim->CurrentDatabases.IsEmpty())++QualityEmptyFrames;
            if(FMath::Abs(Anim->SelectedTime-QualityLastTime)>.0001f)++QualityPoseFrames;
            QualityLastTime=Anim->SelectedTime;
        }
        if(PhaseTime<1.3f)return;
        Check(TEXT("behavior_restored_mm_time_advances"),QualityPoseFrames>10 && QualityEmptyFrames==0,FString::Printf(TEXT("advancing=%d empty=%d"),QualityPoseFrames,QualityEmptyFrames));
        Check(TEXT("behavior_restored_movement"),Character->GetActorLocation().X>InitialLocation.X+100);
        Move->StopMovementImmediately();Behavior->SendEvent(TEXT("HoldTest"));Next();break;
    case 14:
        if(Value(TEXT("finished"))==0)return;
        Check(TEXT("behavior_natural_completion_runs_action"),Is(TEXT("CompleteHold")) && Value(TEXT("HoldDone"))==1);
        Next();break;
    case 15:
        if(PhaseTime<.5f)return;
        Check(TEXT("behavior_completion_action_only_once"),Is(TEXT("CompleteHold")) && Value(TEXT("HoldDone"))==1 && Value(TEXT("finished"))==1);
        Behavior->SendEvent(TEXT("Acknowledge"));Behavior->SendEvent(TEXT("HoldTest"));Next();break;
    case 16:
        if(PhaseTime<.08f)return;
        Check(TEXT("behavior_external_interrupt_test_playing"),Is(TEXT("CompleteHold")) && Character->GetMesh()->GetAnimInstance()->IsAnyMontagePlaying());
        Character->GetMesh()->GetAnimInstance()->Montage_Stop(.03f);Next();break;
    case 17:
        if(!Is(TEXT("Move")))return;
        Check(TEXT("behavior_external_interrupt_recovers_without_completion"),Value(TEXT("HoldDone"))==1 && Behavior->AllowsMovement());
        Check(TEXT("behavior_no_unexpected_root_reentry"),Value(TEXT("RootEntries"))==1 && Value(TEXT("RootExits"))==0);
        Finish();break;
    }
}

void AGaspSmokeRunner::TickBehaviorCompiler(float DeltaSeconds)
{
    if(Phase==EPhase::Done)return;
    const double Now=FPlatformTime::Seconds();if(!Started)Started=Now;PhaseTime+=DeltaSeconds;
    if(Now-Started>100 || PhaseTime>15){Check(TEXT("v3_timeout"),false,FString::Printf(TEXT("stage=%d"),FlowStage));Finish();return;}
    if(!Character)Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if(!Character)return;
    auto* B=Character->Behavior.Get();auto* A=Character->GetMesh()->GetAnimInstance();auto* M=Character->GetCharacterMovement();
    if(!B || !A || !B->IsEnabled())return;
    auto Is=[&](const TCHAR* S){return B->CurrentState==FName(S);};
    auto V=[&](const TCHAR* N){return B->GetVariable(FName(N));};
    auto Next=[&](){++FlowStage;PhaseTime=0;};
    auto Key=[&](const TCHAR* Name)
    {
        int32 Count=0;if(Character->InputComponent)for(const auto& Binding:Character->InputComponent->KeyBindings)
            if(Binding.Chord.Key==FKey(FName(Name)) && Binding.KeyEvent==IE_Pressed){Binding.KeyDelegate.Execute(FKey(FName(Name)));++Count;}
        Check(*FString::Printf(TEXT("v3_input_%d_%s"),FlowStage,Name),Count==1);
    };
    auto Position=[&](float PhaseValue,bool Pause=true)
    {
        if(auto* Montage=A->GetCurrentActiveMontage()){A->Montage_SetPosition(Montage,Montage->GetPlayLength()*PhaseValue);A->Montage_SetPlayRate(Montage,Pause?0.f:1.f);}
        else Check(TEXT("v3_missing_active_montage"),false);
    };
    switch(FlowStage)
    {
    case 0:
        if(PhaseTime<2)return;
        Check(TEXT("v3_reviewed_fixture_initial"),Is(TEXT("Rest")) && B->IsStateActive(TEXT("Travel")));
        Check(TEXT("v3_external_initial_is_unbound"),B->GetUnboundExternalVariables().Contains(TEXT("ExternalReady")));
        Character->RawMoveInput=FVector2D(.3,.4);Check(TEXT("v3_builtin_actual_input"),FMath::IsNearlyEqual(V(TEXT("move_input")),.5f));Character->RawMoveInput=FVector2D::ZeroVector;
        Check(TEXT("v3_builtin_actual_gait"),V(TEXT("gait"))==uint8(Character->Gait));
        M->StopMovementImmediately();Character->SetActorLocation(FVector(500,-750,88.2),false,nullptr,ETeleportType::TeleportPhysics);M->SetMovementMode(MOVE_Walking);
        Key(TEXT("LeftMouseButton"));Check(TEXT("v3_attack_starts_without_buffer"),Is(TEXT("SwingA")) && V(TEXT("Buffered"))==0);Next();break;
    case 1:
        Position(.1f);QualityStage=B->TransitionCount;Key(TEXT("LeftMouseButton"));
        Check(TEXT("v3_before_window_not_buffered"),V(TEXT("Buffered"))==0 && V(TEXT("BufferWrites"))==0);
        Position(.4f);Key(TEXT("LeftMouseButton"));Key(TEXT("LeftMouseButton"));
        Check(TEXT("v3_inside_window_buffered_once"),V(TEXT("Buffered"))==1 && V(TEXT("BufferWrites"))==1);
        Check(TEXT("v3_internal_event_does_not_reenter"),Is(TEXT("SwingA")) && B->TransitionCount==QualityStage && FMath::IsNearlyEqual(V(TEXT("animation_phase")),.4f,.001f));
        B->SetBoolVariable(TEXT("Buffered"),false);Position(.8f);Key(TEXT("LeftMouseButton"));
        Check(TEXT("v3_after_window_not_buffered"),V(TEXT("Buffered"))==0 && V(TEXT("BufferWrites"))==1);
        B->SendEvent(TEXT("ExternalProbe"));Check(TEXT("v3_unbound_external_not_is_blocked"),V(TEXT("ProbeCount"))==0);
        Check(TEXT("v3_external_binding_setter"),B->SetBoolVariable(TEXT("ExternalReady"),false) && B->GetUnboundExternalVariables().IsEmpty());
        B->SendEvent(TEXT("ExternalProbe"));Check(TEXT("v3_bound_false_condition_can_run"),V(TEXT("ProbeCount"))==1);
        Position(.4f);Key(TEXT("LeftMouseButton"));QualityLastTime=B->StateTime;Next();break;
    case 2:
        if(PhaseTime<.1f)return;
        Check(TEXT("v3_internal_event_preserves_time_and_clip"),B->StateTime>QualityLastTime && B->TransitionCount==QualityStage && FMath::IsNearlyEqual(V(TEXT("animation_phase")),.4f,.001f));
        Key(TEXT("H"));Check(TEXT("v3_hit_interrupt_clears_buffer"),Is(TEXT("Flinch")) && V(TEXT("Buffered"))==0);Next();break;
    case 3:
        if(!Is(TEXT("Rest")))return;
        Check(TEXT("v3_ground_hit_recovery"),B->IsStateActive(TEXT("Travel")));
        Key(TEXT("LeftMouseButton"));Position(.4f);Key(TEXT("LeftMouseButton"));Position(.98f,false);Next();break;
    case 4:
        if(!Is(TEXT("SwingB")))return;
        Check(TEXT("v3_buffer_consumed_and_cleared"),V(TEXT("Buffered"))==0);Next();break;
    case 5:
        if(!Is(TEXT("Rest")))return;
        Check(TEXT("v3_combo_end_returns_ground_and_clears"),V(TEXT("Buffered"))==0);
        Key(TEXT("LeftMouseButton"));Position(.8f);Key(TEXT("LeftMouseButton"));Position(.98f,false);Next();break;
    case 6:
        if(Is(TEXT("SwingB"))){Check(TEXT("v3_window_outside_did_not_start_combo"),false);Finish();return;}
        if(!Is(TEXT("Rest")))return;
        Check(TEXT("v3_no_buffer_finishes_to_ground"),V(TEXT("Buffered"))==0);
        Key(TEXT("SpaceBar"));Check(TEXT("v3_first_allowed_jump_increments_once"),B->IsStateActive(TEXT("Sky")) && V(TEXT("Count"))==1);Next();break;
    case 7:
        if(PhaseTime<.12f)return;
        Check(TEXT("v3_first_jump_real_physics"),M->IsFalling() && M->Velocity.Z>100 && V(TEXT("Count"))==1,M->Velocity.ToString());
        Check(TEXT("v3_builtin_actual_vertical_speed"),FMath::IsNearlyEqual(V(TEXT("vertical_speed")),float(M->Velocity.Z),.01f));
        QualityStage=B->TransitionCount;Key(TEXT("SpaceBar"));Check(TEXT("v3_second_jump_no_state_reentry"),V(TEXT("Count"))==2 && B->TransitionCount==QualityStage);Next();break;
    case 8:
        if(PhaseTime<.12f)return;
        Check(TEXT("v3_second_jump_real_physics"),M->IsFalling() && M->Velocity.Z>100,M->Velocity.ToString());
        Key(TEXT("SpaceBar"));Check(TEXT("v3_third_jump_rejected_without_increment"),V(TEXT("Count"))==2 && B->TransitionCount==QualityStage);
        Character->SetActorLocation(FVector(500,-750,2000),false,nullptr,ETeleportType::TeleportPhysics);M->Velocity.Z=-100;
        Key(TEXT("H"));Check(TEXT("v3_air_hit_does_not_reset_jump_count"),Is(TEXT("Flinch")) && V(TEXT("Count"))==2);Next();break;
    case 9:
        if(Is(TEXT("Flinch")))return;
        Check(TEXT("v3_hit_recovers_by_actual_air_condition"),B->IsStateActive(TEXT("Sky")) && V(TEXT("Count"))==2 && M->IsFalling());Next();break;
    case 10:
        if(!M->IsMovingOnGround() || !Is(TEXT("Rest")))return;
        Check(TEXT("v3_landing_resets_jump_count"),V(TEXT("Count"))==0 && B->IsStateActive(TEXT("Travel")));
        Key(TEXT("SpaceBar"));Next();break;
    case 11:
        if(PhaseTime<.12f)return;
        Check(TEXT("v3_jump_allowed_again_after_landing"),V(TEXT("Count"))==1 && M->IsFalling());
        Key(TEXT("H"));Position(.2f);Next();break;
    case 12:
        if(!M->IsMovingOnGround())return;
        Check(TEXT("v3_landing_during_hit_clears_count_without_restart"),Is(TEXT("Flinch")) && V(TEXT("Count"))==0);
        Position(.98f,false);Next();break;
    case 13:
        if(!Is(TEXT("Rest")))return;
        Check(TEXT("v3_hit_recovery_after_landing_uses_ground"),V(TEXT("Buffered"))==0 && V(TEXT("Count"))==0);
        CollectGarbage(RF_NoFlags);Check(TEXT("v3_gc_preserves_runtime"),B->IsEnabled());Finish();break;
    }
}

void AGaspSmokeRunner::TickBehaviorGenerated(float DeltaSeconds)
{
    if(Phase==EPhase::Done)return;
    const double Now=FPlatformTime::Seconds();if(!Started)Started=Now;PhaseTime+=DeltaSeconds;
    if(Now-Started>70 || PhaseTime>15){Check(TEXT("generated_timeout"),false,FString::Printf(TEXT("stage=%d"),FlowStage));Finish();return;}
    if(!BehaviorExpected)
    {
        FString Path,Text;const TSharedPtr<FJsonObject> *Ground=nullptr,*Air=nullptr;
        if(!FParse::Value(FCommandLine::Get(),TEXT("BehaviorExpected="),Path) || !FFileHelper::LoadFileToString(Text,*Path) || Text.Len()>65536 || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),BehaviorExpected) || !BehaviorExpected || !BehaviorExpected->TryGetObjectField(TEXT("locomotion"),Ground) || !BehaviorExpected->TryGetObjectField(TEXT("jump"),Air))
        {Check(TEXT("generated_independent_expected_labels"),false);Finish();return;}
    }
    if(!Character)Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));if(!Character)return;
    auto* B=Character->Behavior.Get();auto* M=Character->GetCharacterMovement();auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    if(!B || !B->IsEnabled() || !Anim || !Anim->bAnimationSetValid)return;
    const auto Ground=BehaviorExpected->GetObjectField(TEXT("locomotion")),Air=BehaviorExpected->GetObjectField(TEXT("jump"));
    const FName Counter(*Air->GetStringField(TEXT("counter")));const int32 Limit=Air->GetIntegerField(TEXT("max_jumps"));
    if(Limit<1 || Limit>8){Check(TEXT("generated_jump_limit_label"),false);Finish();return;}
    auto Is=[&](const TCHAR* StateRole){return B->CurrentState==FName(*Ground->GetStringField(StateRole));};
    auto Next=[&](){++FlowStage;PhaseTime=0;};
    auto Axis=[&](float Value)
    {
        int32 Count=0;if(Character->InputComponent)for(const auto& Binding:Character->InputComponent->AxisBindings)
            if(Binding.AxisName==TEXT("MoveForward")){Binding.AxisDelegate.Execute(Value);++Count;}
        if(Count!=1){Check(TEXT("generated_real_axis_binding"),false);Finish();}
    };
    auto Jump=[&]()
    {
        int32 Count=0;if(Character->InputComponent)for(const auto& Binding:Character->InputComponent->KeyBindings)
            if(Binding.Chord.Key==EKeys::SpaceBar && Binding.KeyEvent==IE_Pressed){Binding.KeyDelegate.Execute(EKeys::SpaceBar);++Count;}
        Check(*FString::Printf(TEXT("generated_jump_input_%d"),QualityStage),Count==1);
    };
    switch(FlowStage)
    {
    case 0:
        if(PhaseTime<2)return;
        Check(TEXT("generated_actual_target_class"),Character->GetClass()->GetPathName()==TEXT("/Game/Blueprints/Character/BP_CusGaspNativeCharacter.BP_CusGaspNativeCharacter_C"));
        Check(TEXT("generated_actual_blueprint_native_mm"),Anim->IsA<UGaspCppAnimInstance>() && !Anim->CurrentDatabases.IsEmpty());
        Check(TEXT("generated_independent_initial_state"),Is(TEXT("idle")) && B->IsStateActive(FName(*Ground->GetStringField(TEXT("group")))));
        if(auto* Controller=Character->GetController())AddTickPrerequisiteActor(Controller);B->AddTickPrerequisiteActor(this);B->AddTickPrerequisiteActor(Character);
        Character->SetActorLocation(FVector(500,-750,88.2),false,nullptr,ETeleportType::TeleportPhysics);M->StopMovementImmediately();M->SetMovementMode(MOVE_Walking);
        Character->bWantsToWalk=true;Character->bWantsToSprint=false;QualityPoseFrames=0;QualityLastTime=Anim->SelectedTime;Next();break;
    case 1:
        Axis(1);if(FMath::Abs(Anim->SelectedTime-QualityLastTime)>.0001f)++QualityPoseFrames;QualityLastTime=Anim->SelectedTime;
        if(PhaseTime<.8f)return;
        Check(TEXT("generated_walk_from_actual_input_gait"),Is(TEXT("walk")) && B->GetVariable(TEXT("gait"))==0 && B->GetVariable(TEXT("move_input"))>0 && QualityPoseFrames>3);
        Character->bWantsToWalk=false;Next();break;
    case 2:
        Axis(1);if(PhaseTime<.8f)return;
        Check(TEXT("generated_run_from_actual_input_gait"),Is(TEXT("run")) && B->GetVariable(TEXT("gait"))==1 && !Anim->SelectedAnimation.IsNone());Next();break;
    case 3:
        Axis(0);if(PhaseTime<.4f)return;
        Check(TEXT("generated_stop_returns_idle"),Is(TEXT("idle")));
        M->StopMovementImmediately();QualityStage=1;Jump();Check(TEXT("generated_first_launch_count"),B->GetVariable(Counter)==1);Next();break;
    case 4:
        Axis(0);if(PhaseTime<.12f)return;
        Check(*FString::Printf(TEXT("generated_real_launch_%d"),QualityStage),M->IsFalling() && M->Velocity.Z>100 && B->GetVariable(Counter)==QualityStage,M->Velocity.ToString());
        if(QualityStage<Limit){++QualityStage;Jump();PhaseTime=0;return;}
        Jump();Check(TEXT("generated_jump_over_limit_rejected"),B->GetVariable(Counter)==Limit);Next();break;
    case 5:
        Axis(0);if(!M->IsMovingOnGround() || !Is(TEXT("idle")))return;
        Check(TEXT("generated_actual_landing_reset"),B->GetVariable(Counter)==0 && B->IsStateActive(FName(*Ground->GetStringField(TEXT("group")))));
        Finish();break;
    }
}

void AGaspSmokeRunner::TickFlow(float DeltaSeconds)
{
    if (Phase==EPhase::Done) return;
    const double Now=FPlatformTime::Seconds(); if (!Started) Started=Now;
    if (Now-Started>60) { Check(TEXT("flow_timeout"),false); Finish(); return; }
    if (!Character) Character=Cast<AGaspNativeCharacter>(UGameplayStatics::GetPlayerCharacter(this,0));
    if (!Character) return;
    auto* Anim=UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    auto* Flow=Character->ActionFlow.Get();
    if (!Anim || !Anim->bAnimationSetValid) return;
    PhaseTime+=DeltaSeconds;
    if (FlowStage==0 && PhaseTime>.5f)
    {
        if(FParse::Param(FCommandLine::Get(),TEXT("FlowCandidateSmoke")))
            for(const auto& Pair:Anim->AnimationSet->ConfiguredActions)
            {
                auto& Candidates=Anim->AnimationSet->ActionCandidates.FindOrAdd(Pair.Key);
                Candidates.Sequences={Pair.Value,DuplicateObject<UAnimSequence>(Pair.Value.Get(),Anim->AnimationSet, FName(*(Pair.Key.ToString()+TEXT("_RuntimeCandidate"))))};
            }
        Check(TEXT("flow_native_graph"),Anim->IsA<UGaspCppAnimInstance>());
        Check(TEXT("flow_saved_policy"),Anim->AnimationSet->ActionPolicy.bAttackMustFinish && Anim->AnimationSet->ConfiguredActions.Num()==2);
        Check(TEXT("flow_unknown_rejected"),!Flow->RequestAction(TEXT("invented")));
        Character->bWantsToStrafe=false; Character->bWantsToSprint=true; Character->bWantsToAim=true;
        Check(TEXT("flow_sprint_blocks_aim"),Character->CanSprint() && !Character->IsAimAllowed());
        Character->bWantsToSprint=false; Check(TEXT("flow_aim_restored"),Character->IsAimAllowed()); Character->bWantsToAim=false;
        Check(TEXT("flow_attack_started"),Flow->RequestAction(TEXT("attack")));
        if(FParse::Param(FCommandLine::Get(),TEXT("FlowCandidateSmoke"))) Check(TEXT("flow_candidate_first"),Flow->GetActiveSequence()==Anim->AnimationSet->ConfiguredActions[TEXT("attack")]);
        Check(TEXT("flow_attack_locked"),Flow->IsActionLocked() && !Flow->RequestLocomotion() && !Flow->RequestAction(TEXT("attack")));
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==1 && PhaseTime>.15f)
    {
        Check(TEXT("flow_montage_slot_active"),Character->GetMesh()->GetAnimInstance()->IsSlotActive(Anim->AnimationSet->MontageSlot));
        Check(TEXT("flow_hit_interrupt"),Flow->RequestAction(TEXT("hit")) && Flow->ActiveAction==TEXT("hit"));
        FlowSavedPosition=Flow->SuspendedPosition;
        Check(TEXT("flow_previous_captured"),Flow->SuspendedAction==TEXT("attack") && FlowSavedPosition>0);
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==2 && PhaseTime>.05f)
    {
        Check(TEXT("flow_repeated_hit"),Flow->RequestAction(TEXT("hit")) && Flow->SuspendedAction==TEXT("attack") && Flow->SuspendedPosition==FlowSavedPosition);
        if(FParse::Param(FCommandLine::Get(),TEXT("FlowCandidateSmoke"))) Check(TEXT("flow_candidate_hit_rotated"),Flow->GetActiveSequence()==Anim->AnimationSet->ActionCandidates[TEXT("hit")].Sequences[1]);
        CollectGarbage(RF_NoFlags);
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==3 && Flow->ResumedActions>0)
    {
        Check(TEXT("flow_previous_resumed"),Flow->ActiveAction==TEXT("attack") && Flow->IsActionLocked());
        if(FParse::Param(FCommandLine::Get(),TEXT("FlowCandidateSmoke"))) Check(TEXT("flow_candidate_original_resumed"),Flow->GetActiveSequence()==Anim->AnimationSet->ConfiguredActions[TEXT("attack")]);
        UAnimMontage* Current=Character->GetMesh()->GetAnimInstance()->GetCurrentActiveMontage();
        Check(TEXT("flow_resume_position"),Current && Character->GetMesh()->GetAnimInstance()->Montage_GetPosition(Current)>=FlowSavedPosition);
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==4 && Flow->ActiveAction.IsNone())
    {
        Check(TEXT("flow_natural_completion"),Flow->CompletedActions>=2 && Flow->RequestLocomotion());
        Character->bWantsToStrafe=false;
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==5)
    {
        Character->AddMovementInput(FVector::ForwardVector);
        if (PhaseTime<1) return;
        Check(TEXT("flow_mm_recovered"),!Anim->SelectedAnimation.IsNone() && !Anim->CurrentDatabases.IsEmpty());
        Check(TEXT("flow_hit_from_mm"),Character->TakeDamage(1.f,FDamageEvent(),nullptr,nullptr)>0 && Flow->ActiveAction==TEXT("hit"));
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==6 && Flow->ActiveAction.IsNone())
    {
        Check(TEXT("flow_hit_returns_mm"),Flow->ResumedActions==1 && Flow->SuspendedAction.IsNone());
        auto* Alternate=DuplicateObject<UGaspAnimationSet>(Anim->AnimationSet,Character);
        Alternate->ActionPolicy.bResumePreviousAfterHit=false;
        Alternate->ActionPolicy.bBlockAimWhenSprinting=false;
        Check(TEXT("flow_alternate_profile"),Character->ApplyAnimationSet(Alternate));
        Character->bWantsToAim=true; Character->bWantsToSprint=true;
        Check(TEXT("flow_no_aim_block_without_policy"),Character->IsAimAllowed() && !Character->CanSprint());
        Character->bWantsToAim=Character->bWantsToSprint=false;
        Check(TEXT("flow_locomotion_recovery_start"),Flow->RequestAction(TEXT("attack")) && Flow->RequestAction(TEXT("hit")));
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==7 && Flow->ActiveAction.IsNone())
    {
        Check(TEXT("flow_explicit_locomotion_recovery"),Flow->ResumedActions==1);
        Anim->AnimationSet->ActionPolicy.bHitInterruptsAll=false;
        Check(TEXT("flow_no_priority_hit_respects_lock"),Flow->RequestAction(TEXT("attack")) && !Flow->RequestAction(TEXT("hit")));
        ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==8 && Flow->ActiveAction.IsNone())
    {
        Anim->AnimationSet->ActionPolicy.bAttackMustFinish=false;
        Check(TEXT("flow_unlocked_attack_can_exit"),Flow->RequestAction(TEXT("attack")) && Flow->RequestLocomotion());
        if(FParse::Param(FCommandLine::Get(),TEXT("FlowCandidateSmoke"))) {Check(TEXT("flow_candidate_restart"),Flow->RequestAction(TEXT("attack")));Check(TEXT("flow_candidate_attack_rotated"),Flow->GetActiveSequence()==Anim->AnimationSet->ActionCandidates[TEXT("attack")].Sequences[0]);}
        if (FParse::Param(FCommandLine::Get(),TEXT("ExpandedFlowSmoke")))
        {
            Flow->RequestLocomotion();
            // Timing fixtures only: semantic recognition is tested separately.
            Anim->AnimationSet->ConfiguredActions.Add(TEXT("jump"),Anim->AnimationSet->ConfiguredActions[TEXT("attack")]);
            Anim->AnimationSet->ConfiguredActions.Add(TEXT("dodge"),Anim->AnimationSet->ConfiguredActions[TEXT("hit")]);
            Character->GetCharacterMovement()->StopMovementImmediately();
            Character->SetActorLocation(FVector(-1400,-1000,88.2),false,nullptr,ETeleportType::TeleportPhysics);
            Character->GetCharacterMovement()->SetMovementMode(MOVE_Walking);
            ++FlowStage; PhaseTime=0; return;
        }
        Finish();
    }
    if (FlowStage==9 && PhaseTime>.2f)
    {
        Check(TEXT("flow_jump_grounded_rejected"),Character->GetCharacterMovement()->IsMovingOnGround() && !Flow->RequestAction(TEXT("jump")));
        Character->Jump(); ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==10 && PhaseTime>.05f)
    {
        Check(TEXT("flow_jump_physics"),Character->GetCharacterMovement()->IsFalling());
        Check(TEXT("flow_jump_event"),Flow->ActiveAction==TEXT("jump"));
        Check(TEXT("flow_dodge_airborne_rejected"),!Flow->RequestAction(TEXT("dodge")));
        Character->StopJumping(); ++FlowStage; PhaseTime=0; return;
    }
    if (FlowStage==11 && Character->GetCharacterMovement()->IsMovingOnGround())
    {
        Check(TEXT("flow_jump_landed_exit"),Flow->ActiveAction!=TEXT("jump"));
        Check(TEXT("flow_dodge_started"),Flow->RequestAction(TEXT("dodge")));
        Anim->AnimationSet->ActionPolicy.bHitInterruptsAll=true;
        Check(TEXT("flow_hit_interrupts_dodge"),Flow->RequestAction(TEXT("hit")) && Flow->ActiveAction==TEXT("hit"));
        Finish();
    }
}


