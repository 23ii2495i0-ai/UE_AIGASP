#include "GaspNativeHUD.h"
#include "GaspNativeCharacter.h"
#include "GaspNativeAnimInstance.h"
#include "GaspTraversalComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"

void AGaspNativeHUD::DrawHUD()
{
    Super::DrawHUD();
    auto* Character = Cast<AGaspNativeCharacter>(GetOwningPawn());
    if (!Character || !Canvas) return;
    auto* Anim = UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    DrawRect(FLinearColor(0,0,0,.65f), 14, 14, 660, 120);
    const FString State = Anim ? FString::Printf(TEXT("GASP C++  |  %.0f cm/s  |  %s\nDB: %s\nAnimation: %s  (%.2f s)"),
        Character->GetVelocity().Size2D(), Character->Traversal->bDoingTraversal ? TEXT("Traversal") : TEXT("Locomotion"),
        *Anim->SelectedDatabase.ToString(), *Anim->SelectedAnimation.ToString(), Anim->SelectedTime) : TEXT("Loading animation...");
    DrawText(State, FLinearColor::White, 26, 24, GEngine->GetSmallFont());
    DrawText(TEXT("WASD move | Mouse look | Shift sprint | Ctrl walk | C crouch | Space traversal/jump\nQ strafe | RMB aim | Alt+F4 exits"),
        FLinearColor(.65f,.85f,1.f), 26, 92, GEngine->GetSmallFont());
}


