#include "GaspTraversalChannels.h"
#include "GaspNativeAnimInstance.h"
#include "PoseSearch/PoseSearchContext.h"
#include "PoseSearch/PoseSearchFeatureVectorHelper.h"
#include "IObjectChooser.h"
#include "Misc/EngineVersionComparison.h"

namespace
{
const UGaspNativeAnimInstance* GetNativeAnim(UE::PoseSearch::FSearchContext& Context, FName Role)
{
#if UE_VERSION_OLDER_THAN(5, 7, 0)
    return Cast<UGaspNativeAnimInstance>(Context.GetAnimInstance(Role));
#else
    const auto* Input = Context.GetContext(Role);
    return Input ? Cast<UGaspNativeAnimInstance>(Input->GetFirstObjectParam()) : nullptr;
#endif
}
}

void UGaspTraversalPositionChannel::BuildQuery(UE::PoseSearch::FSearchContext& Context) const
{
    const auto* Anim = GetNativeAnim(Context, SampleRole);
    const FVector World = Anim ? Anim->InteractionTransform.GetLocation() : FVector::ZeroVector;
    const FVector Position = Context.GetSamplePosition(SampleTimeOffset, OriginTimeOffset,
        SchemaBoneIdx, SchemaOriginBoneIdx, SampleRole, OriginRole, PermutationTimeType, &World);
    UE::PoseSearch::FFeatureVectorHelper::EncodeVector(Context.EditFeatureVector(), GetChannelDataOffset(), Position, ComponentStripping, false);
}

void UGaspTraversalHeadingChannel::BuildQuery(UE::PoseSearch::FSearchContext& Context) const
{
    const auto* Anim = GetNativeAnim(Context, SampleRole);
    const FQuat World = Anim ? Anim->InteractionTransform.GetRotation() : FQuat::Identity;
    const FQuat Rotation = Context.GetSampleRotation(SampleTimeOffset, OriginTimeOffset,
        SchemaBoneIdx, SchemaOriginBoneIdx, SampleRole, OriginRole, PermutationTimeType, &World);
    const FVector Direction = HeadingAxis == EHeadingAxis::Y ? Rotation.GetAxisY() :
        HeadingAxis == EHeadingAxis::Z ? Rotation.GetAxisZ() : Rotation.GetAxisX();
    UE::PoseSearch::FFeatureVectorHelper::EncodeVector(Context.EditFeatureVector(), GetChannelDataOffset(), Direction, ComponentStripping, true);
}
