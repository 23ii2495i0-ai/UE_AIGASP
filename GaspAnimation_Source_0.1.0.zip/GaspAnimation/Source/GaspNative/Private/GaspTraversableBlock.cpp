#include "GaspTraversableBlock.h"
#include "Engine/StaticMesh.h"
#include "Components/StaticMeshComponent.h"
#include "UObject/ConstructorHelpers.h"

AGaspTraversableBlock::AGaspTraversableBlock()
{
    Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Block"));
    RootComponent = Mesh;
    static ConstructorHelpers::FObjectFinder<UStaticMesh> Cube(TEXT("/Engine/BasicShapes/Cube"));
    Mesh->SetStaticMesh(Cube.Object);
    Mesh->SetCollisionProfileName(TEXT("BlockAll"));
    Mesh->SetCollisionResponseToChannel(ECC_GameTraceChannel1, ECR_Block);
}

bool AGaspTraversableBlock::GetLedges(const FVector& Hit, const FVector& ActorLocation,
    FVector& Front, FVector& FrontNormal, FVector& Back, FVector& BackNormal) const
{
    const FTransform& X = Mesh->GetComponentTransform();
    const FVector A[] = { {-50,-50,50}, {50,50,50}, {50,-50,50}, {-50,50,50} };
    const FVector B[] = { {-50,50,50}, {50,-50,50}, {-50,-50,50}, {50,50,50} };
    const FVector N[] = { {-1,0,0}, {1,0,0}, {0,-1,0}, {0,1,0} };
    int32 Best = INDEX_NONE;
    double BestDistance = DBL_MAX;
    for (int32 I=0; I<4; ++I)
    {
        const FVector Start = X.TransformPosition(A[I]), End = X.TransformPosition(B[I]);
        const FVector Normal = X.TransformVectorNoScale(N[I]).GetSafeNormal();
        const double Distance = FVector::DistSquared(FMath::ClosestPointOnSegment(ActorLocation, Start, End) + Normal*10, ActorLocation);
        if (Distance < BestDistance) { Best = I; BestDistance = Distance; }
    }
    const FVector Start = X.TransformPosition(A[Best]), End = X.TransformPosition(B[Best]);
    const double Length = FVector::Distance(Start, End);
    if (Length < 60) return false;
    const FVector Direction = (End-Start)/Length;
    const double Along = FMath::Clamp(FVector::DotProduct(Hit-Start, Direction), 30., Length-30.);
    Front = Start + Direction*Along;
    FrontNormal = X.TransformVectorNoScale(N[Best]).GetSafeNormal();
    const int32 Opposite = Best ^ 1;
    Back = FMath::ClosestPointOnSegment(Front, X.TransformPosition(A[Opposite]), X.TransformPosition(B[Opposite]));
    BackNormal = X.TransformVectorNoScale(N[Opposite]).GetSafeNormal();
    return true;
}
