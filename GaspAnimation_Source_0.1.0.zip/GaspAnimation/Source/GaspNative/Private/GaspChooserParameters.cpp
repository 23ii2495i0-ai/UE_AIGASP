#include "GaspChooserParameters.h"

namespace
{
FGaspChooserValues* Values(FChooserEvaluationContext& Context)
{
    return Context.Params.Num() ? Context.Params[0].GetPtr<FGaspChooserValues>() : nullptr;
}
const double* Input(FChooserEvaluationContext& Context, const FString& Key)
{
    const auto* Data = Values(Context);
    return Data && Data->Inputs ? Data->Inputs->Find(Key) : nullptr;
}
}
bool FGaspChooserBool::GetValue(FChooserEvaluationContext& Context, bool& Value) const
{
    if (const double* Found=Input(Context, Binding)) { Value=*Found!=0; return true; }
    return false;
}
bool FGaspChooserFloat::GetValue(FChooserEvaluationContext& Context, double& Value) const
{
    if (const double* Found=Input(Context, Binding)) { Value=*Found; return true; }
    return false;
}
bool FGaspChooserEnum::GetValue(FChooserEvaluationContext& Context, uint8& Value) const
{
    if (const double* Found=Input(Context, Binding)) { Value=uint8(*Found); return true; }
    return false;
}
bool FGaspChooserEnum::SetValue(FChooserEvaluationContext& Context, uint8 Value) const
{
    if (auto* Data=Values(Context); Data && Data->Outputs) { Data->Outputs->Add(Binding, Value); return true; }
    return false;
}
