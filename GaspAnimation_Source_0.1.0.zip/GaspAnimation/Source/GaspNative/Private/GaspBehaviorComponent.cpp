#include "GaspBehaviorComponent.h"
#include "GaspAnimationSet.h"
#include "GaspNativeCharacter.h"
#include "GaspNativeAnimInstance.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "Components/InputComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/SkeletalMesh.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "UObject/UnrealType.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

namespace {
double Numeric(const TSharedPtr<FJsonValue>& V){return V->Type==EJson::Boolean ? double(V->AsBool()) : V->AsNumber();}
bool Bool(const TSharedPtr<FJsonObject>& O,const TCHAR* K,bool Default=false){bool B=Default;if(O)O->TryGetBoolField(K,B);return B;}
FString Str(const TSharedPtr<FJsonObject>& O,const TCHAR* K){FString S;if(O)O->TryGetStringField(K,S);return S;}
double Num(const TSharedPtr<FJsonObject>& O,const TCHAR* K){double N=0;O->TryGetNumberField(K,N);return N;}
bool Identifier(const FString& S){if(S.IsEmpty() || S.Len()>64 || !(FChar::IsAlpha(S[0]) || S[0]=='_'))return false;for(TCHAR C:S)if(!(FChar::IsAlnum(C)||C=='_') || C>127)return false;return true;}
}

UGaspBehaviorComponent::UGaspBehaviorComponent(){PrimaryComponentTick.bCanEverTick=true;PrimaryComponentTick.TickGroup=TG_PrePhysics;}
void UGaspBehaviorComponent::BeginPlay(){Super::BeginPlay();Configure();}
void UGaspBehaviorComponent::Configure()
{
    auto* C=Cast<AGaspNativeCharacter>(GetOwner());auto* Set=C ? C->AnimationSetOverride.Get():nullptr;
    if(LoadedSet==Set)return;
    if(ActiveMontage && C && C->GetMesh()->GetAnimInstance()){auto* Old=ActiveMontage.Get();ActiveMontage=nullptr;C->GetMesh()->GetAnimInstance()->Montage_Stop(.2f,Old);}
    LoadedSet=Set;bEnabled=false;bFinished=bInterrupted=false;CurrentState=NAME_None;Graph.Reset();States.Reset();Variables.Reset();UnboundExternalVariables.Reset();ActivePath.Reset();ActiveTimes.Reset();LastError.Reset();StateTime=0;TransitionCount=0;
    if(!Set || Set->BehaviorGraphJson.IsEmpty())return;
    const auto* Mesh=C->GetMesh()->GetSkeletalMeshAsset();
    if(!Mesh || !ValidateDefinition(Set,Mesh->GetSkeleton(),LastError)){UE_LOG(LogTemp,Error,TEXT("%s"),*LastError);return;}
    FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Set->BehaviorGraphJson),Graph);
    for(const auto& V:Graph->GetObjectField(TEXT("variables"))->Values)Variables.Add(FName(*V.Key),Numeric(V.Value));
    const TSharedPtr<FJsonObject>* Sources=nullptr;
    if(Graph->TryGetObjectField(TEXT("variable_sources"),Sources))for(const auto& P:(*Sources)->Values)
        if(Str(P.Value->AsObject(),TEXT("scope"))==TEXT("external"))
        {
            const FName VariableName(*P.Key); double BlueprintValue=0;
            if(!ReadBlueprintVariable(VariableName,BlueprintValue))UnboundExternalVariables.Add(VariableName);
            else Variables.FindOrAdd(VariableName)=BlueprintValue;
        }
    if(!UnboundExternalVariables.IsEmpty())LastError=TEXT("External variables await SetVariable binding; conditions using them are blocked");
    for(const auto& V:Graph->GetArrayField(TEXT("states")))States.Add(FName(*Str(V->AsObject(),TEXT("id"))),V->AsObject());
    bEnabled=true;if(!Enter(FName(*Str(Graph,TEXT("entry")))))bEnabled=false;
    SyncBlueprintVariables();
    BindInputs(C->InputComponent);
}
bool UGaspBehaviorComponent::Enter(FName State,const TSharedPtr<FJsonObject>& Transition)
{
    auto* C=Cast<AGaspNativeCharacter>(GetOwner());auto* Anim=C ? C->GetMesh()->GetAnimInstance():nullptr;
    if(!States.Contains(State) || !Anim)return false;
    FName Leaf=State;
    for(int32 Depth=0;Depth<8 && Str(States[Leaf],TEXT("player"))==TEXT("group");++Depth)Leaf=FName(*Str(States[Leaf],TEXT("initial")));
    TArray<FName> Path;for(FName N=Leaf;!N.IsNone();N=FName(*Str(States[N],TEXT("parent"))))Path.Insert(N,0);
    int32 Common=0;while(Common<ActivePath.Num() && Common<Path.Num() && ActivePath[Common]==Path[Common])++Common;
    const int32 Reenter=ActivePath.IndexOfByKey(State);if(Reenter!=INDEX_NONE)Common=FMath::Min(Common,Reenter);
    const auto S=States[Leaf];const FString Player=Str(S,TEXT("player"));
    UAnimMontage* New=nullptr;
    if(Player==TEXT("sequence"))
    {
        auto* Sequence=LoadObject<UAnimSequence>(nullptr,*S->GetArrayField(TEXT("resources"))[0]->AsString());
        if(!Sequence)return false;
        New=UAnimMontage::CreateSlotAnimationAsDynamicMontage(Sequence,C->AnimationSetOverride->MontageSlot,Num(S,TEXT("blend_seconds")),Num(S,TEXT("blend_seconds")),1.f,Bool(S,TEXT("loop")) ? 1000000:1);
    }
    else if(Player==TEXT("montage"))
    {
        if(auto* Template=LoadObject<UAnimMontage>(nullptr,*S->GetArrayField(TEXT("resources"))[0]->AsString()))
            New=DuplicateObject<UAnimMontage>(Template,this); // Distinct callback identity on self-reentry.
    }
    if((Player==TEXT("sequence") || Player==TEXT("montage")) && !New){LastError=TEXT("Cannot create state player");return false;}
    bTransitioning=true;UAnimMontage* Old=ActiveMontage;ActiveMontage=nullptr;
    if(Old)Anim->Montage_Stop(Num(S,TEXT("blend_seconds")),Old);
    if(New)
    {
        const float Length=Anim->Montage_Play(New,1.f,EMontagePlayReturnType::MontageLength,0.f,false);
        if(Length<=0){bTransitioning=false;bInterrupted=true;LastError=TEXT("Montage_Play failed; transition rejected");return false;}
        ActiveMontage=New;FOnMontageEnded D;D.BindUObject(this,&ThisClass::OnMontageEnded);Anim->Montage_SetEndDelegate(D,New);
    }
    const FName Previous=CurrentState;
    for(int32 I=ActivePath.Num()-1;I>=Common;--I){RunActions(States[ActivePath[I]],TEXT("on_exit"));ActiveTimes.Remove(ActivePath[I]);}
    if(Transition)RunActions(Transition,TEXT("actions"));
    CurrentState=Leaf;ActivePath=Path;StateTime=0;bFinished=bInterrupted=false;++TransitionCount;
    if(!AllowsMovement())C->GetCharacterMovement()->StopMovementImmediately();
    for(int32 I=Common;I<Path.Num();++I){ActiveTimes.Add(Path[I],0);RunActions(States[Path[I]],TEXT("on_entry"));}
    OnStateChanged.Broadcast(Previous,Leaf);bTransitioning=false;
    return true;
}
double UGaspBehaviorComponent::Value(const FString& Name) const
{
    const TSharedPtr<FJsonObject>* Sources=nullptr;
    if(Graph && Graph->TryGetObjectField(TEXT("variable_sources"),Sources))
        for(const auto& Pair:(*Sources)->Values)if(FString(*Pair.Key)==Name && Str(Pair.Value->AsObject(),TEXT("scope"))==TEXT("external"))
        {double BlueprintValue=0;if(ReadBlueprintVariable(FName(*Name),BlueprintValue))return BlueprintValue;break;}
    const auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    if(Name==TEXT("state_time"))return StateTime;if(Name==TEXT("finished"))return bFinished;if(Name==TEXT("interrupted"))return bInterrupted;
    if(C){if(Name==TEXT("speed"))return C->GetVelocity().Size2D();if(Name==TEXT("falling"))return C->GetCharacterMovement()->IsFalling();if(Name==TEXT("crouched"))return C->bIsCrouched;}
    if(C && Graph && Num(Graph,TEXT("version"))>=3)
    {
        if(Name==TEXT("vertical_speed"))return C->GetVelocity().Z;
        if(Name==TEXT("move_input"))return FMath::Min(1.,FMath::Max(C->RawMoveInput.Size(),C->GetLastMovementInputVector().Size2D()));
        if(Name==TEXT("gait"))return uint8(C->Gait);
        if(Name==TEXT("animation_phase"))
        {
            auto* Anim=C->GetMesh()->GetAnimInstance();
            return ActiveMontage && Anim && ActiveMontage->GetPlayLength()>0 ? FMath::Clamp(Anim->Montage_GetPosition(ActiveMontage)/ActiveMontage->GetPlayLength(),0.f,1.f):0;
        }
    }
    return Variables.FindRef(FName(*Name));
}
void UGaspBehaviorComponent::RunActions(const TSharedPtr<FJsonObject>& O,const TCHAR* Field)
{
    const TArray<TSharedPtr<FJsonValue>>* Actions=nullptr;if(!O || !O->TryGetArrayField(Field,Actions))return;
    for(const auto& V:*Actions)
    {
        const auto A=V->AsObject();const FString Op=Str(A,TEXT("op"));
        if(Op==TEXT("jump"))
        {
            // The graph's explicit conditions control extra jumps; horizontal momentum is retained.
            if(auto* C=Cast<AGaspNativeCharacter>(GetOwner()))C->LaunchCharacter(FVector(0,0,Num(A,TEXT("velocity"))),false,true);
        }
        else
        {
            const FName K(*Str(A,TEXT("var")));double* Current=Variables.Find(K);if(!Current)continue;
            const double N=Numeric(A->TryGetField(TEXT("value"))),Result=Op==TEXT("add") ? *Current+N:N;
            if(FMath::IsFinite(Result) && FMath::Abs(Result)<=MAX_flt)*Current=Result;
            else LastError=TEXT("Variable arithmetic overflow rejected: ")+K.ToString();
        }
    }
    SyncBlueprintVariables();
}
bool UGaspBehaviorComponent::TestCondition(const TSharedPtr<FJsonObject>& O) const
{
    // An unbound external inside NOT/ANY must not turn into a true condition.
    TFunction<bool(const TSharedPtr<FJsonObject>&)> IsBound;
    IsBound=[&](const auto& N)
    {
        if(N->HasField(TEXT("var")) && UnboundExternalVariables.Contains(FName(*Str(N,TEXT("var")))))return false;
        const TArray<TSharedPtr<FJsonValue>>* Children=nullptr;
        for(const TCHAR* K:{TEXT("all"),TEXT("any")})if(N->TryGetArrayField(K,Children))for(const auto& V:*Children)if(!IsBound(V->AsObject()))return false;
        return !N->HasField(TEXT("not")) || IsBound(N->GetObjectField(TEXT("not")));
    };
    if(!IsBound(O))return false;
    const TArray<TSharedPtr<FJsonValue>>* Children=nullptr;
    if(O->TryGetArrayField(TEXT("all"),Children)){for(const auto& C:*Children)if(!TestCondition(C->AsObject()))return false;return true;}
    if(O->TryGetArrayField(TEXT("any"),Children)){for(const auto& C:*Children)if(TestCondition(C->AsObject()))return true;return false;}
    if(O->HasField(TEXT("not")))return !TestCondition(O->GetObjectField(TEXT("not")));
    const double A=Value(Str(O,TEXT("var"))),B=Numeric(O->TryGetField(TEXT("value")));const FString Op=Str(O,TEXT("op"));
    return Op==TEXT("eq") ? FMath::IsNearlyEqual(A,B,1.e-6) : Op==TEXT("ne") ? !FMath::IsNearlyEqual(A,B,1.e-6) : Op==TEXT("lt") ? A<B : Op==TEXT("le") ? A<=B : Op==TEXT("gt") ? A>B : A>=B;
}
bool UGaspBehaviorComponent::Evaluate(const FString& Event)
{
    if(!bEnabled || bTransitioning)return false;
    const TArray<FName> PendingBindings=UnboundExternalVariables.Array();
    for(FName Name:PendingBindings){double ValueFromBlueprint=0;if(ReadBlueprintVariable(Name,ValueFromBlueprint)){Variables.FindOrAdd(Name)=ValueFromBlueprint;UnboundExternalVariables.Remove(Name);}}
    TSharedPtr<FJsonObject> Winner;double Priority=-1001;int32 Specificity=-2;bool Locked=false;
    for(FName N:ActivePath){const auto S=States[N];Locked |= ActiveTimes.FindRef(N)<Num(S,TEXT("min_duration")) || (Bool(S,TEXT("lock_until_finished")) && !bFinished && !bInterrupted);}
    for(const auto& V:Graph->GetArrayField(TEXT("transitions")))
    {
        const auto E=V->AsObject();const FString From=Str(E,TEXT("from"));
        const int32 Depth=From==TEXT("*") ? -1:ActivePath.IndexOfByKey(FName(*From));const double Rank=Num(E,TEXT("priority"));
        if((From!=TEXT("*") && Depth==INDEX_NONE) || FName(*Str(E,TEXT("event")))!=FName(*Event) || Rank<Priority || (Rank==Priority && Depth<=Specificity) || (!Bool(E,TEXT("interrupt")) && Locked))continue;
        bool Pass=true;
        for(const auto& C:E->GetArrayField(TEXT("all")))
        {
            if(!TestCondition(C->AsObject())){Pass=false;break;}
        }
        if(Pass && E->HasField(TEXT("condition")))Pass=TestCondition(E->GetObjectField(TEXT("condition")));
        if(Pass){Winner=E;Priority=Rank;Specificity=Depth;}
    }
    // Internal handlers share the priority/depth arbitration with transitions,
    // consume the event once, and never reenter a state or touch its player/time.
    bool Internal=false;const TArray<TSharedPtr<FJsonValue>>* Handlers=nullptr;
    if(Graph->TryGetArrayField(TEXT("handlers"),Handlers))for(const auto& V:*Handlers)
    {
        const auto H=V->AsObject();const FString From=Str(H,TEXT("from"));
        const int32 Depth=From==TEXT("*") ? -1:ActivePath.IndexOfByKey(FName(*From));const double Rank=Num(H,TEXT("priority"));
        if((From!=TEXT("*") && Depth==INDEX_NONE) || FName(*Str(H,TEXT("event")))!=FName(*Event) || Rank<Priority || (Rank==Priority && Depth<=Specificity) || !TestCondition(H->GetObjectField(TEXT("condition"))))continue;
        Winner=H;Priority=Rank;Specificity=Depth;Internal=true;
    }
    if(!Winner)return false;
    if(Internal){bTransitioning=true;RunActions(Winner,TEXT("actions"));bTransitioning=false;return true;}
    return Enter(FName(*Str(Winner,TEXT("to"))),Winner);
}
bool UGaspBehaviorComponent::SendEvent(FName Event){Configure();return !Event.IsNone() && Evaluate(Event.ToString());}
bool UGaspBehaviorComponent::SetVariable(FName Name,float V){Configure();if(!FMath::IsFinite(V) || !Variables.Contains(Name))return false;Variables[Name]=V;WriteBlueprintVariable(Name,V);UnboundExternalVariables.Remove(Name);return true;}
TArray<FName> UGaspBehaviorComponent::GetUnboundExternalVariables() const{return UnboundExternalVariables.Array();}
bool UGaspBehaviorComponent::SetBoolVariable(FName Name,bool V){return SetVariable(Name,V?1.f:0.f);}
float UGaspBehaviorComponent::GetVariable(FName Name) const{return Value(Name.ToString());}
bool UGaspBehaviorComponent::GetBoolVariable(FName Name) const{return GetVariable(Name)!=0;}
bool UGaspBehaviorComponent::IsStateActive(FName State) const{return bEnabled && ActivePath.Contains(State);}
bool UGaspBehaviorComponent::AllowsMovement() const{if(bEnabled)for(FName N:ActivePath)if(!Bool(States.FindRef(N),TEXT("allow_movement"),true))return false;return true;}
float UGaspBehaviorComponent::GetBlendSeconds() const{return bEnabled ? Num(States.FindRef(CurrentState),TEXT("blend_seconds")):.2f;}
void UGaspBehaviorComponent::OnMontageEnded(UAnimMontage* M,bool Interrupted)
{
    if(M!=ActiveMontage || bTransitioning)return;
    ActiveMontage=nullptr;bInterrupted=Interrupted;const auto S=States.FindRef(CurrentState);
    bFinished=!Interrupted && !Bool(S,TEXT("loop"));
    if(bFinished){bTransitioning=true;RunActions(S,TEXT("on_complete"));bTransitioning=false;}
    if(Interrupted)LastError=TEXT("State montage interrupted externally; completion was not counted");
}
void UGaspBehaviorComponent::TickComponent(float Dt,ELevelTick T,FActorComponentTickFunction* F)
{
    Super::TickComponent(Dt,T,F);Configure();if(!bEnabled)return;
    StateTime+=Dt;for(auto& P:ActiveTimes)P.Value+=Dt;Evaluate(TEXT(""));SyncBlueprintVariables();
}
bool UGaspBehaviorComponent::HandlesKey(FName Key) const
{
    if(!bEnabled)return false;for(const auto& V:Graph->GetArrayField(TEXT("inputs")))if(FName(*Str(V->AsObject(),TEXT("key")))==Key)return true;return false;
}
void UGaspBehaviorComponent::HandleKey(FName Key,bool Pressed)
{
    if(!bEnabled || bTransitioning)return;
    for(const auto& V:Graph->GetArrayField(TEXT("inputs")))
    {
        const auto B=V->AsObject();if(FName(*Str(B,TEXT("key")))!=Key || Str(B,TEXT("phase"))!=(Pressed?TEXT("pressed"):TEXT("released")))continue;
        for(const auto& P:B->GetObjectField(TEXT("set"))->Values)Variables.FindOrAdd(FName(*P.Key))=Numeric(P.Value);
        RunActions(B,TEXT("actions"));SyncBlueprintVariables();SendEvent(FName(*Str(B,TEXT("event"))));
    }
}
void UGaspBehaviorComponent::BindInputs(UInputComponent* Input)
{
    if(!Input || !bEnabled || !Graph)return;
    if(BoundInput!=Input){BoundInput=Input;BoundKeys.Reset();}
    for(const auto& V:Graph->GetArrayField(TEXT("inputs")))
    {
        const auto B=V->AsObject();const FString Key=Str(B,TEXT("key")),Phase=Str(B,TEXT("phase")),Token=Key+Phase;
        if(BoundKeys.Contains(Token))continue;BoundKeys.Add(Token);const bool Pressed=Phase==TEXT("pressed");TWeakObjectPtr<UGaspBehaviorComponent> Weak(this);
        FInputKeyBinding Binding(FInputChord(FKey(FName(*Key)),false,false,false,false),Pressed ? IE_Pressed:IE_Released);
        Binding.KeyDelegate.GetDelegateForManualSet().BindLambda([Weak,Key,Pressed](){if(Weak.IsValid())Weak->HandleKey(FName(*Key),Pressed);});
        Input->KeyBindings.Add(MoveTemp(Binding));
    }
}
bool UGaspBehaviorComponent::GetDatabaseOverride(TArray<UPoseSearchDatabase*>& Out) const
{
    if(!bEnabled)return false;const auto S=States.FindRef(CurrentState);if(Str(S,TEXT("player"))!=TEXT("mm"))return false;
    const FString Role=Str(S,TEXT("database_role"));
    const auto* Character=Cast<AGaspNativeCharacter>(GetOwner());
    const auto* Anim=Character ? UGaspNativeAnimInstance::Resolve(Character->GetMesh()):nullptr;
    if(Anim && Anim->GetMotionMatchingAnimationGroup(Role.IsEmpty() ? CurrentState:FName(*Role),Out))return true;
    if(!Role.IsEmpty()){if(const auto* DB=LoadedSet->ConfiguredLocomotion.Find(FName(*Role)))if(*DB)Out.Add(*DB);}
    else for(const auto& P:S->GetArrayField(TEXT("resources")))if(auto* DB=LoadObject<UPoseSearchDatabase>(nullptr,*P->AsString()))Out.Add(DB);
    return true;
}
void UGaspBehaviorComponent::EndPlay(const EEndPlayReason::Type R){bEnabled=false;ActiveMontage=nullptr;ActivePath.Reset();ActiveTimes.Reset();Super::EndPlay(R);}
bool UGaspBehaviorComponent::ReadBlueprintVariable(FName Name,double& OutValue) const
{
    const auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    auto* Anim=C && C->GetMesh() ? UGaspNativeAnimInstance::Resolve(C->GetMesh()) : nullptr;
    if(!Anim)return false;
    FProperty* Property=FindFProperty<FProperty>(Anim->GetClass(),Name);
    if(const auto* BoolProperty=CastField<FBoolProperty>(Property))
    {
        OutValue=BoolProperty->GetPropertyValue_InContainer(Anim) ? 1.0 : 0.0;
        return true;
    }
    if(const auto* NumericProperty=CastField<FNumericProperty>(Property))
    {
        const void* ValuePtr=NumericProperty->ContainerPtrToValuePtr<void>(Anim);
        if(NumericProperty->IsFloatingPoint())OutValue=NumericProperty->GetFloatingPointPropertyValue(ValuePtr);
        else if(NumericProperty->IsInteger())OutValue=NumericProperty->GetSignedIntPropertyValue_InContainer(Anim);
        else return false;
        return FMath::IsFinite(OutValue);
    }
    return false;
}
bool UGaspBehaviorComponent::WriteBlueprintVariable(FName Name,double Value) const
{
    const auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    auto* Anim=C && C->GetMesh() ? UGaspNativeAnimInstance::Resolve(C->GetMesh()) : nullptr;
    if(!Anim || !FMath::IsFinite(Value))return false;
    FProperty* Property=FindFProperty<FProperty>(Anim->GetClass(),Name);
    if(auto* BoolProperty=CastField<FBoolProperty>(Property))
    {
        BoolProperty->SetPropertyValue_InContainer(Anim,Value!=0.0);
        return true;
    }
    if(auto* NumericProperty=CastField<FNumericProperty>(Property))
    {
        void* ValuePtr=NumericProperty->ContainerPtrToValuePtr<void>(Anim);
        if(NumericProperty->IsFloatingPoint())NumericProperty->SetFloatingPointPropertyValue(ValuePtr,Value);
        else if(NumericProperty->IsInteger())NumericProperty->SetIntPropertyValue(ValuePtr,int64(Value));
        else return false;
        return true;
    }
    return false;
}
void UGaspBehaviorComponent::SyncBlueprintVariables()
{
    const TSharedPtr<FJsonObject>* Sources=nullptr;
    for(const auto& Variable:Variables)
    {
        bool bExternal=false;
        if(Graph && Graph->TryGetObjectField(TEXT("variable_sources"),Sources))
            for(const auto& Pair:(*Sources)->Values)if(FString(*Pair.Key)==Variable.Key.ToString()){bExternal=Str(Pair.Value->AsObject(),TEXT("scope"))==TEXT("external");break;}
        if(!bExternal)WriteBlueprintVariable(Variable.Key,Variable.Value);
    }
    if(!Graph)return;
    const auto& Transitions=Graph->GetArrayField(TEXT("transitions"));
    for(int32 Index=0;Index<Transitions.Num();++Index)
    {
        const auto Edge=Transitions[Index]->AsObject();
        const FName Target(*Str(Edge,TEXT("to")));
        // The compiled UE state machine follows the native event/priority arbitration.
        // A stable target-active rule also survives an anim graph being temporarily inactive.
        WriteBlueprintVariable(FName(*FString::Printf(TEXT("SemanticTransition_%03d"),Index)),IsStateActive(Target) ? 1.0 : 0.0);
    }
    TSet<FName> ConditionVariables;
    TFunction<void(const TSharedPtr<FJsonObject>&)> CollectCondition;
    CollectCondition=[&](const TSharedPtr<FJsonObject>& Condition)
    {
        if(!Condition)return;
        FString Name;
        if(Condition->TryGetStringField(TEXT("var"),Name) && !Name.IsEmpty())ConditionVariables.Add(FName(*Name));
        const TArray<TSharedPtr<FJsonValue>>* Children=nullptr;
        for(const TCHAR* Key:{TEXT("all"),TEXT("any")})
            if(Condition->TryGetArrayField(Key,Children))for(const auto& Child:*Children)CollectCondition(Child->AsObject());
        const TSharedPtr<FJsonObject>* Not=nullptr;
        if(Condition->TryGetObjectField(TEXT("not"),Not))CollectCondition(*Not);
    };
    for(const TCHAR* Collection:{TEXT("transitions"),TEXT("handlers")})
    {
        const TArray<TSharedPtr<FJsonValue>>* Entries=nullptr;
        if(!Graph->TryGetArrayField(Collection,Entries))continue;
        for(const auto& Entry:*Entries)
        {
            const auto Object=Entry->AsObject();
            const TArray<TSharedPtr<FJsonValue>>* All=nullptr;
            if(Object->TryGetArrayField(TEXT("all"),All))for(const auto& Condition:*All)CollectCondition(Condition->AsObject());
            const TSharedPtr<FJsonObject>* Condition=nullptr;
            if(Object->TryGetObjectField(TEXT("condition"),Condition))CollectCondition(*Condition);
        }
    }
    for(FName Name:ConditionVariables)
    {
        bool bExternal=false;
        if(Graph->TryGetObjectField(TEXT("variable_sources"),Sources))
            for(const auto& Pair:(*Sources)->Values)if(FString(*Pair.Key)==Name.ToString()){bExternal=Str(Pair.Value->AsObject(),TEXT("scope"))==TEXT("external");break;}
        if(!bExternal)WriteBlueprintVariable(Name,Value(Name.ToString()));
    }
}
