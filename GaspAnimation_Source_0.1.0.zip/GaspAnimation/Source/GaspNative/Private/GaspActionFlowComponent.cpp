#include "GaspActionFlowComponent.h"
#include "GaspBehaviorComponent.h"
#include "GaspNativeCharacter.h"
#include "GaspAnimationSet.h"
#include "GaspTraversalComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "Engine/SkeletalMesh.h"
#include "GameFramework/CharacterMovementComponent.h"

UGaspActionFlowComponent::UGaspActionFlowComponent() { PrimaryComponentTick.bCanEverTick=false; }
bool UGaspActionFlowComponent::IsActionLocked() const
{
    const auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    return C && C->AnimationSetOverride && ActiveAction==TEXT("attack") && C->AnimationSetOverride->ActionPolicy.bAttackMustFinish;
}
bool UGaspActionFlowComponent::StartAction(FName Action,float Position,UAnimSequence* ResumeSequence)
{
    auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    auto* Set=C ? C->AnimationSetOverride.Get() : nullptr;
    auto* Anim=C ? C->GetMesh()->GetAnimInstance() : nullptr;
    auto* Entry=Set ? Set->ConfiguredActions.Find(Action) : nullptr;
    if (!Anim || !Entry || !*Entry || (*Entry)->bLoop || (*Entry)->GetSkeleton()!=C->GetMesh()->GetSkeletalMeshAsset()->GetSkeleton()) return false;
    UAnimSequence* Sequence=ResumeSequence ? ResumeSequence : Entry->Get();
    if (!ResumeSequence) if (const auto* Candidates=Set->ActionCandidates.Find(Action); Candidates && !Candidates->Sequences.IsEmpty())
        Sequence=Candidates->Sequences[NextCandidate.FindRef(Action)%Candidates->Sequences.Num()];
    if (!Sequence || Sequence->bLoop || Sequence->GetSkeleton()!=(*Entry)->GetSkeleton()) return false;
    UAnimMontage* NewMontage=UAnimMontage::CreateSlotAnimationAsDynamicMontage(Sequence,Set->MontageSlot,Set->ActionPolicy.BlendSeconds,Set->ActionPolicy.BlendSeconds,1.f,1);
    if (!NewMontage) return false;
    // Clear identity before Montage_Play interrupts the old instance, so its delegate cannot resume stale state.
    UAnimMontage* Old=ActiveMontage; const FName OldAction=ActiveAction;
    ActiveMontage=nullptr; ActiveAction=NAME_None;
    const bool bStopAll=Action==TEXT("hit") && Set->ActionPolicy.bHitInterruptsAll;
    const float Duration=Anim->Montage_Play(NewMontage,1.f,EMontagePlayReturnType::MontageLength,Position,bStopAll);
    if (Duration<=0) { ActiveMontage=Old; ActiveAction=OldAction; return false; }
    ActiveMontage=NewMontage; ActiveAction=Action; ActiveSequence=Sequence;
    if (!ResumeSequence) ++NextCandidate.FindOrAdd(Action);
    FOnMontageEnded Delegate; Delegate.BindUObject(this,&ThisClass::OnEnded); Anim->Montage_SetEndDelegate(Delegate,NewMontage);
    return true;
}
bool UGaspActionFlowComponent::RequestAction(FName Action)
{
    auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    if(C && C->Behavior->IsEnabled())return C->Behavior->SendEvent(Action);
    if (!C || !C->AnimationSetOverride || !C->AnimationSetOverride->ConfiguredActions.Contains(Action) ||
        (Action!=TEXT("hit") && Action!=TEXT("attack") && Action!=TEXT("jump") && Action!=TEXT("dodge"))) return false;
    if (Action==TEXT("dodge") && (!C->GetCharacterMovement()->IsMovingOnGround() || C->bIsCrouched)) return false;
    if (Action==TEXT("jump") && !C->GetCharacterMovement()->IsFalling()) return false;
    const auto& Policy=C->AnimationSetOverride->ActionPolicy;
    const bool bPriorityHit=Action==TEXT("hit") && Policy.bHitInterruptsAll;
    if (C->Traversal->bDoingTraversal && !bPriorityHit) return false;
    if (!bPriorityHit && (IsActionLocked() || ActiveAction==TEXT("hit"))) return false;
    // Keep the original suspended action through repeated hits, never suspend a hit over itself.
    const FName OldSuspended=SuspendedAction; const float OldPosition=SuspendedPosition; UAnimSequence* OldSequence=SuspendedSequence;
    if (Action==TEXT("hit") && ActiveAction!=TEXT("hit"))
    {
        SuspendedAction=Policy.bResumePreviousAfterHit ? ActiveAction : NAME_None;
        SuspendedSequence=Policy.bResumePreviousAfterHit ? ActiveSequence.Get() : nullptr;
        SuspendedPosition=ActiveMontage ? C->GetMesh()->GetAnimInstance()->Montage_GetPosition(ActiveMontage) : 0.f;
    }
    if (StartAction(Action)) return true;
    SuspendedAction=OldSuspended; SuspendedPosition=OldPosition; SuspendedSequence=OldSequence; return false;
}
bool UGaspActionFlowComponent::RequestLocomotion()
{
    if (IsActionLocked()) return false;
    auto* C=Cast<AGaspNativeCharacter>(GetOwner());
    if(C && C->Behavior->IsEnabled())return C->Behavior->SendEvent(TEXT("LocomotionRequested"));
    auto* Anim=C ? C->GetMesh()->GetAnimInstance() : nullptr;
    UAnimMontage* Old=ActiveMontage;
    ActiveMontage=nullptr; ActiveAction=SuspendedAction=NAME_None; SuspendedPosition=0;
    ActiveSequence=SuspendedSequence=nullptr;
    if (Anim && Old) Anim->Montage_Stop(.2f,Old);
    return true;
}
void UGaspActionFlowComponent::OnEnded(UAnimMontage* Montage,bool bInterrupted)
{
    if (Montage!=ActiveMontage) return;
    const bool bWasHit=ActiveAction==TEXT("hit");
    ActiveAction=NAME_None; ActiveMontage=nullptr;
    if (!bInterrupted) ++CompletedActions;
    const FName Resume=SuspendedAction; const float Position=SuspendedPosition;
    UAnimSequence* ResumeSequence=SuspendedSequence; ActiveSequence=SuspendedSequence=nullptr;
    SuspendedAction=NAME_None; SuspendedPosition=0;
    if (!bInterrupted && bWasHit && !Resume.IsNone() && StartAction(Resume,Position,ResumeSequence)) ++ResumedActions;
}
void UGaspActionFlowComponent::EndPlay(const EEndPlayReason::Type Reason)
{
    ActiveMontage=nullptr; ActiveAction=SuspendedAction=NAME_None;
    ActiveSequence=SuspendedSequence=nullptr; NextCandidate.Reset();
    Super::EndPlay(Reason);
}
