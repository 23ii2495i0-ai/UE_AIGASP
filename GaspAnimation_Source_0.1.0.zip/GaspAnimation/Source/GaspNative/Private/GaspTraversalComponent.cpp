#include "GaspTraversalComponent.h"
#include "GaspNativeCharacter.h"
#include "GaspActionFlowComponent.h"
#include "GaspNativeAnimInstance.h"
#include "GaspAnimationSet.h"
#include "GaspTraversableBlock.h"
#include "Animation/AnimMontage.h"
#include "AnimNotifyState_MotionWarping.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Engine/World.h"
#include "Misc/Paths.h"
#include "MotionWarpingComponent.h"
#include "PoseSearch/PoseSearchLibrary.h"
#include "RootMotionModifier.h"

UGaspTraversalComponent::UGaspTraversalComponent() { PrimaryComponentTick.bCanEverTick = false; }
void UGaspTraversalComponent::BeginPlay()
{
    Super::BeginPlay();
}
void UGaspTraversalComponent::EndPlay(const EEndPlayReason::Type Reason)
{
    ++Generation;
    RestoreCollision();
    Super::EndPlay(Reason);
}

bool UGaspTraversalComponent::Trace(FHitResult& Hit, const FVector& Start, const FVector& End,
    float Radius, float HalfHeight, ECollisionChannel Channel) const
{
    FCollisionQueryParams Params(SCENE_QUERY_STAT(GaspTraversal), false, GetOwner());
    return GetWorld()->SweepSingleByChannel(Hit, Start, End, FQuat::Identity, Channel,
        FCollisionShape::MakeCapsule(Radius, HalfHeight), Params);
}

bool UGaspTraversalComponent::TryTraversal()
{
    if (const auto* Native=Cast<AGaspNativeCharacter>(GetOwner()))
        if (!Native->ActionFlow->ActiveAction.IsNone()) return false;
    auto* Character = Cast<ACharacter>(GetOwner());
    if (!Character || bDoingTraversal) return bDoingTraversal;
    if (!Character->FindComponentByClass<UMotionWarpingComponent>()) return false;
    auto* Anim = UGaspNativeAnimInstance::Resolve(Character->GetMesh());
    if (!Anim || !Anim->bAnimationSetValid) return false;
    if (LoadedSet.Get() != Anim->AnimationSet)
    {
        Chooser.LoadTable(Anim->AnimationSet->TraversalTable, Anim->AnimationSet->bTraversalUsesCMC);
        LoadedSet = Anim->AnimationSet;
    }
    if (!Chooser.IsValid()) return false;
    UAnimInstance* MontageOwner = Character->GetMesh()->GetAnimInstance();
    const auto* Move = Character->GetCharacterMovement();
    const FVector Location = Character->GetActorLocation();
    const FVector Forward = Character->GetActorForwardVector();
    const bool bOnGround = Move->IsMovingOnGround();
    const float ForwardSpeed = Character->GetActorQuat().UnrotateVector(Character->GetVelocity()).X;
    const float Distance = bOnGround ? FMath::GetMappedRangeValueClamped(FVector2D(0,500), FVector2D(75,350), ForwardSpeed) : 75.f;
    const FVector End = Location + Forward * Distance + (bOnGround ? FVector::ZeroVector : FVector(0,0,50));
    FHitResult Hit;
    FGaspTraversalResult Result;
    if (!Trace(Hit, Location, End, 30, bOnGround ? 60 : 86, ECC_GameTraceChannel1)) return false;
    const auto* Block = Cast<AGaspTraversableBlock>(Hit.GetActor());
    if (!Block || Hit.bStartPenetrating) return false;
    Result.HitComponent = Hit.GetComponent();
    if (!Block->GetLedges(Hit.ImpactPoint, Location, Result.FrontLedge, Result.FrontNormal, Result.BackLedge, Result.BackNormal)) return false;
    Result.bHasFrontLedge = Result.bHasBackLedge = true;
    const float Radius = Character->GetCapsuleComponent()->GetScaledCapsuleRadius();
    const float HalfHeight = Character->GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
    const FVector RoomFront = Result.FrontLedge + Result.FrontNormal*(Radius+2) + FVector(0,0,HalfHeight+2);
    const FVector RoomBack = Result.BackLedge + Result.BackNormal*(Radius+2) + FVector(0,0,HalfHeight+2);
    FHitResult Room;
    if (Trace(Room, Location, RoomFront, Radius, HalfHeight, ECC_Visibility)) return false;
    Result.ObstacleHeight = FMath::Abs(Location.Z-HalfHeight-Result.FrontLedge.Z);
    FHitResult Top;
    if (!Trace(Top, RoomFront, RoomBack, Radius, HalfHeight, ECC_Visibility))
    {
        Result.ObstacleDepth = FVector::Dist2D(Result.FrontLedge, Result.BackLedge);
        FHitResult Floor;
        const FVector FloorEnd = Result.BackLedge + Result.BackNormal*(Radius+2) - FVector(0,0,50);
        if (Trace(Floor, RoomBack, FloorEnd, Radius, HalfHeight, ECC_Visibility))
        {
            Result.bHasBackFloor = true;
            Result.BackFloor = Floor.ImpactPoint;
            Result.BackLedgeHeight = FMath::Abs(Floor.ImpactPoint.Z-Result.BackLedge.Z);
        }
    }
    else
    {
        Result.ObstacleDepth = FVector::Dist2D(Top.ImpactPoint, Result.FrontLedge);
        Result.bHasBackLedge = false;
    }
    const TMap<FString, double> Context = {
        {TEXT("ActionType"), 0.}, {TEXT("HasFrontLedge"), double(Result.bHasFrontLedge)},
        {TEXT("HasBackLedge"), double(Result.bHasBackLedge)}, {TEXT("HasBackFloor"), double(Result.bHasBackFloor)},
        {TEXT("ObstacleHeight"), Result.ObstacleHeight}, {TEXT("ObstacleDepth"), Result.ObstacleDepth},
        {TEXT("BackLedgeHeight"), Result.BackLedgeHeight},
        {TEXT("MovementMode"), Chooser.UsesCharacterMovementMode() ? double(Move->MovementMode) : (Move->IsFalling() ? 1. : 0.)},
        {TEXT("Gait"), double(FMath::Clamp(Anim->ReadCharacterInputs().Gait, 0, 2))}, {TEXT("Speed"), Character->GetVelocity().Size2D()}
    };
    TMap<FString, double> Outputs;
    const auto Paths = Chooser.Evaluate(Context, Outputs);
    Result.Action = EGaspTraversalAction(int32(Outputs.FindRef(TEXT("ActionType"))));
    LastResult = Result;
    if (Result.Action == EGaspTraversalAction::None) return false;
    MontageAssets.Reset();
    TArray<UObject*> Candidates;
    for (const auto& Path : Paths)
        if (auto* Montage = Cast<UAnimMontage>(Anim->AnimationSet->ResolveTraversal(Path).TryLoad()))
        {
            MontageAssets.Add(Montage);
            Candidates.Add(Montage);
        }
    if (Candidates.IsEmpty()) return false;
    Anim->InteractionTransform = FTransform(FRotationMatrix::MakeFromZ(Result.FrontNormal).ToQuat(), Result.FrontLedge);
    FPoseSearchBlueprintResult Selection;
    TArray<const UObject*> Contexts={Anim};
    TArray<UE::PoseSearch::FRole> Roles={UE::PoseSearch::DefaultRole};
    TArray<const UE::PoseSearch::IPoseHistory*> Histories={Anim->GetSearchPoseHistory()};
    TArray<const UObject*> Assets; for (const auto* Candidate:Candidates) Assets.Add(Candidate);
    const auto Search=UPoseSearchLibrary::MotionMatch(Contexts, Roles, Histories, Assets,
        FPoseSearchContinuingProperties(), FPoseSearchFutureProperties(), FPoseSearchEvent());
    Selection.InitFrom(Search, 1.f);
    Result.Montage = Cast<UAnimMontage>(Selection.SelectedAnim);
    if (!Result.Montage) return false;
    Result.StartTime = Selection.SelectedTime;
    Result.PlayRate = Selection.WantedPlayRate;
    UpdateWarpTargets(Result);
    // Old instances may continue blending out; their callbacks cannot finish this instance.
    const uint32 ThisGeneration = ++Generation;
    if (MontageOwner->Montage_Play(Result.Montage, Result.PlayRate, EMontagePlayReturnType::MontageLength,
        Result.StartTime, true) <= 0) return false;
    LastResult = Result;
    bDoingTraversal = true;
    IgnoredActor = Hit.GetActor();
    bAddedIgnore = !Character->GetCapsuleComponent()->GetMoveIgnoreActors().Contains(IgnoredActor.Get());
    if (bAddedIgnore) Character->GetCapsuleComponent()->IgnoreActorWhenMoving(IgnoredActor.Get(), true);
    Character->GetCharacterMovement()->SetMovementMode(MOVE_Flying);
    FOnMontageEnded Ended;
    Ended.BindWeakLambda(this, [this, ThisGeneration](UAnimMontage*, bool) { FinishTraversal(ThisGeneration); });
    MontageOwner->Montage_SetEndDelegate(Ended, Result.Montage);
    FOnMontageBlendingOutStarted Blending;
    Blending.BindWeakLambda(this, [this, ThisGeneration](UAnimMontage*, bool bInterrupted)
    { if (bInterrupted) FinishTraversal(ThisGeneration); });
    MontageOwner->Montage_SetBlendingOutDelegate(Blending, Result.Montage);
    return true;
}

void UGaspTraversalComponent::UpdateWarpTargets(const FGaspTraversalResult& R)
{
    auto* Character = CastChecked<ACharacter>(GetOwner());
    auto* Warp = Character->FindComponentByClass<UMotionWarpingComponent>();
    Warp->AddOrUpdateWarpTargetFromLocationAndRotation(TEXT("FrontLedge"), R.FrontLedge+FVector(0,0,.5), (-R.FrontNormal).Rotation());
    auto EndOfWindow = [&R](FName Name, float& EndTime)
    {
        for (const auto& Notify : R.Montage->Notifies)
            if (const auto* State = Cast<UAnimNotifyState_MotionWarping>(Notify.NotifyStateClass))
                if (const auto* Modifier = Cast<URootMotionModifier_Warp>(State->RootMotionModifier))
                    if (Modifier->WarpTargetName == Name) { EndTime = Notify.GetEndTriggerTime(); return true; }
        return false;
    };
    float BackTime = 0, FloorTime = 0;
    const bool bBack = (R.Action == EGaspTraversalAction::Hurdle || R.Action == EGaspTraversalAction::Vault) && EndOfWindow(TEXT("BackLedge"), BackTime);
    if (bBack) Warp->AddOrUpdateWarpTargetFromLocationAndRotation(TEXT("BackLedge"), R.BackLedge, FRotator::ZeroRotator);
    else Warp->RemoveWarpTarget(TEXT("BackLedge"));
    if (R.Action == EGaspTraversalAction::Hurdle && EndOfWindow(TEXT("BackFloor"), FloorTime))
    {
        const float BackDistance = R.Montage->EvaluateCurveData(TEXT("Distance_From_Ledge"), BackTime);
        const float FloorDistance = R.Montage->EvaluateCurveData(TEXT("Distance_From_Ledge"), FloorTime);
        FVector Target = R.BackLedge + R.BackNormal * FMath::Abs(BackDistance-FloorDistance);
        Target.Z = R.BackFloor.Z;
        Warp->AddOrUpdateWarpTargetFromLocationAndRotation(TEXT("BackFloor"), Target, FRotator::ZeroRotator);
    }
    else Warp->RemoveWarpTarget(TEXT("BackFloor"));
}

void UGaspTraversalComponent::RestoreCollision()
{
    if (auto* Character = Cast<ACharacter>(GetOwner()))
        if (bAddedIgnore && IgnoredActor.IsValid()) Character->GetCapsuleComponent()->IgnoreActorWhenMoving(IgnoredActor.Get(), false);
    bAddedIgnore = false;
    IgnoredActor.Reset();
}
void UGaspTraversalComponent::FinishTraversal(uint32 ExpectedGeneration)
{
    if (!bDoingTraversal || ExpectedGeneration != Generation) return;
    bDoingTraversal = false;
    RestoreCollision();
    if (auto* Character = Cast<ACharacter>(GetOwner()))
        Character->GetCharacterMovement()->SetMovementMode(LastResult.Action == EGaspTraversalAction::Vault ? MOVE_Falling : MOVE_Walking);
}


