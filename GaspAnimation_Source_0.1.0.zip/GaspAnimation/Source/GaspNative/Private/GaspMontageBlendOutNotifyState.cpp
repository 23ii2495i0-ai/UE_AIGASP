#include "GaspMontageBlendOutNotifyState.h"
#include "GaspNativeCharacter.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"

void UGaspMontageBlendOutNotifyState::NotifyTick(USkeletalMeshComponent* Mesh, UAnimSequenceBase* Animation,
    float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
    auto* Character = Cast<ACharacter>(Mesh->GetOwner());
    auto* Anim = Mesh->GetAnimInstance();
    auto* Montage = Cast<UAnimMontage>(Animation);
    if (!Character || !Anim || !Montage) return;
    const bool bBlendOut = Condition == EGaspBlendOutCondition::Always ||
        (Condition == EGaspBlendOutCondition::WithInput && !Character->GetCharacterMovement()->GetCurrentAcceleration().IsNearlyZero(.1f)) ||
        (Condition == EGaspBlendOutCondition::Falling && Character->GetCharacterMovement()->IsFalling());
    FAnimMontageInstance* Instance = Anim->GetActiveInstanceForMontage(Montage);
    if (bBlendOut && Instance && !Instance->IsStopped())
    {
        FMontageBlendSettings Settings;
        Settings.BlendProfile = const_cast<UBlendProfile*>(Anim->GetBlendProfileByName(BlendProfile));
        Settings.Blend.BlendTime = BlendOutTime;
        Settings.Blend.BlendOption = EAlphaBlendOption::HermiteCubic;
        Anim->Montage_StopWithBlendSettings(Settings, Montage);
    }
}

