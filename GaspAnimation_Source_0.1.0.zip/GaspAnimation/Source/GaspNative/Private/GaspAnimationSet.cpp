#include "GaspAnimationSet.h"
#include "GaspBehaviorComponent.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "Animation/BlendSpace.h"
#include "Engine/SkeletalMesh.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "PoseSearch/PoseSearchFeatureChannel_Trajectory.h"
#include "PoseSearch/PoseSearchFeatureChannel_Pose.h"

FSoftObjectPath UGaspAnimationSet::ResolveDatabase(FSoftObjectPath Source) const
{
    if (const auto* Override = DatabaseOverrides.Find(TSoftObjectPtr<UPoseSearchDatabase>(Source))) return Override->ToSoftObjectPath();
    return Source;
}
FSoftObjectPath UGaspAnimationSet::ResolveTraversal(FSoftObjectPath Source) const
{
    if (const auto* Override = TraversalOverrides.Find(TSoftObjectPtr<UAnimMontage>(Source))) return Override->ToSoftObjectPath();
    return Source;
}
bool UGaspAnimationSet::ValidateForMesh(const USkeletalMesh* Target, FString& Error) const
{
    if (!Target || !DenseTable || !SparseTable || !TraversalTable)
    { Error = TEXT("Mesh and all three chooser rule sets are required"); return false; }
    if (PlayRateRange.X<=0 || PlayRateRange.Y<PlayRateRange.X)
    { Error=TEXT("PlayRateRange must be positive and ordered"); return false; }
    if (Bones.Feet.Num()!=2 || Bones.IKFeet.Num()!=2 || Bones.Balls.Num()!=2 || Bones.Thighs.Num()!=2 || Bones.Spine.IsEmpty())
    { Error = TEXT("GASP requires two legs and at least one spine bone"); return false; }
    TArray<FName> Required = {Bones.Root, Bones.Pelvis};
    Required.Append(Bones.Feet); Required.Append(Bones.Thighs); Required.Append(Bones.Spine);
    if (bEnableFootIK || bEnableSampleWarping) { Required.Add(Bones.IKRoot); Required.Append(Bones.IKFeet); Required.Append(Bones.Balls); }
    for (FName Bone : Required) if (Target->GetRefSkeleton().FindBoneIndex(Bone) == INDEX_NONE)
    { Error = FString::Printf(TEXT("Missing configured bone: %s"), *Bone.ToString()); return false; }
    const USkeleton* Skeleton = Target->GetSkeleton();
    if(!UGaspBehaviorComponent::ValidateDefinition(this,Skeleton,Error))return false;
    for(const auto& Pair:ConfiguredLocomotion)
    {
        const auto* DB=Pair.Value.Get();const auto* Schema=DB ? DB->Schema.Get() : nullptr;
        if(!Schema || Schema->GetSkeleton(Schema->GetDefaultRole())!=Skeleton ||
            !Schema->FindFirstChannelOfType<UPoseSearchFeatureChannel_Trajectory>() ||
            !Schema->FindFirstChannelOfType<UPoseSearchFeatureChannel_Pose>())
        {Error=TEXT("Configured MM database requires compatible trajectory and pose channels: ")+Pair.Key.ToString();return false;}
    }
    for (const auto& Pair:ActionCandidates)
    {
        const auto* Primary=ConfiguredActions.Find(Pair.Key);
        if (!Primary || Pair.Value.Sequences.IsEmpty() || Pair.Value.Sequences[0]!=*Primary) {Error=TEXT("Action candidate primary mismatch");return false;}
        TSet<const UAnimSequence*> Seen;
        for (const UAnimSequence* Sequence:Pair.Value.Sequences)
            if (!Sequence || Sequence->bLoop || Sequence->GetSkeleton()!=Skeleton || Seen.Contains(Sequence)) {Error=TEXT("Invalid action candidate");return false;}
            else Seen.Add(Sequence);
    }
    if (!FMath::IsFinite(ActionPolicy.BlendSeconds) || ActionPolicy.BlendSeconds<0 || ActionPolicy.BlendSeconds>2)
    { Error=TEXT("Action blend must be 0..2"); return false; }
    for (const auto& Pair:ConfiguredActions)
        if ((Pair.Key!=TEXT("hit") && Pair.Key!=TEXT("attack") && Pair.Key!=TEXT("jump") && Pair.Key!=TEXT("dodge")) || !Pair.Value || Pair.Value->bLoop || Pair.Value->GetSkeleton()!=Skeleton)
        { Error=TEXT("Configured actions require compatible nonloop hit/attack/jump/dodge sequences"); return false; }
    if (((ActionPolicy.bHitInterruptsAll || ActionPolicy.bResumePreviousAfterHit) && !ConfiguredActions.Contains(TEXT("hit"))) || (ActionPolicy.bAttackMustFinish && !ConfiguredActions.Contains(TEXT("attack"))))
    { Error=TEXT("Policy refers to missing action"); return false; }
    if ((Lean && Lean->GetSkeleton()!=Skeleton) || (Aim && Aim->GetSkeleton()!=Skeleton))
    { Error = TEXT("Lean/Aim must use the target skeleton; the template does not retarget assets"); return false; }
    return true;
}
