#include "GaspNativeGameMode.h"
#include "GaspNativeCharacter.h"
#include "GaspSmokeRunner.h"
#include "GaspNativeHUD.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "Engine/World.h"
#include "Misc/Paths.h"
#include "TimerManager.h"
#include "UnrealClient.h"
#include "HAL/PlatformMisc.h"
AGaspNativeGameMode::AGaspNativeGameMode()
{
    DefaultPawnClass = AGaspNativeCharacter::StaticClass();
    HUDClass = AGaspNativeHUD::StaticClass();
}
void AGaspNativeGameMode::StartPlay()
{
    Super::StartPlay();
    if (FParse::Param(FCommandLine::Get(), TEXT("BehaviorQualitySmoke")) || FParse::Param(FCommandLine::Get(), TEXT("DirectionalQualitySmoke")) || FParse::Param(FCommandLine::Get(), TEXT("ConfigQualitySmoke")) || FParse::Param(FCommandLine::Get(), TEXT("FlowSmoke")) || FParse::Param(FCommandLine::Get(), TEXT("NativeSmoke")) || FParse::Param(FCommandLine::Get(), TEXT("MarkerSmoke")) || FParse::Param(FCommandLine::Get(), TEXT("ConfigSmoke"))) GetWorld()->SpawnActor<AGaspSmokeRunner>();
    if (FParse::Param(FCommandLine::Get(), TEXT("NativePreview")))
    {
        FString Filename = FPaths::ProjectSavedDir()/TEXT("Screenshots/NativePreview.png");
        FParse::Value(FCommandLine::Get(), TEXT("NativePreviewFile="), Filename);
        FTimerHandle Capture, Exit;
        GetWorldTimerManager().SetTimer(Capture, FTimerDelegate::CreateWeakLambda(this, [Filename]()
        { FScreenshotRequest::RequestScreenshot(Filename, true, false); }), 3.f, false);
        GetWorldTimerManager().SetTimer(Exit, FTimerDelegate::CreateWeakLambda(this, []()
        { FPlatformMisc::RequestExitWithStatus(false, 0); }), 5.f, false);
    }
}
UClass* AGaspNativeGameMode::GetDefaultPawnClassForController_Implementation(AController* Controller)
{
    FString PawnPath;
    if(FParse::Param(FCommandLine::Get(),TEXT("ConfigQualitySmoke")) && FParse::Value(FCommandLine::Get(),TEXT("SmokePawnClass="),PawnPath))
        if(auto* Class=LoadClass<AGaspNativeCharacter>(nullptr,*PawnPath))return Class;
    return Super::GetDefaultPawnClassForController_Implementation(Controller);
}
