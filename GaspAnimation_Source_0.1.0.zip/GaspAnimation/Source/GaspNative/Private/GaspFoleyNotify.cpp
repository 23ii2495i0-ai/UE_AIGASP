#include "GaspFoleyNotify.h"
#include "GaspNativeAnimInstance.h"
#include "Animation/AnimNotifyLibrary.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"

void UGaspFoleyNotify::Notify(USkeletalMeshComponent* Mesh, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& Reference)
{
    if (Mesh && Sound && !UAnimNotifyLibrary::IsBlendingOut(Reference))
        UGameplayStatics::PlaySound2D(Mesh, Sound, VolumeMultiplier, PitchMultiplier);
}

void UGaspEarlyTransitionNotify::NotifyTick(USkeletalMeshComponent* Mesh, UAnimSequenceBase* Animation, float DeltaTime, const FAnimNotifyEventReference& Reference)
{
    if (UAnimNotifyLibrary::IsBlendingOut(Reference)) return;
    if (auto* Anim=UGaspNativeAnimInstance::Resolve(Mesh); Anim && (bAlways || Anim->Gait!=GaitNotEqual))
    {
        if (bToLoop) Anim->NotifyTransitionToLoop=true;
        else Anim->NotifyTransitionReTransition=true;
    }
}
