#include "GaspBehaviorComponent.h"
#include "GaspAnimationSet.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "InputCoreTypes.h"
#include "PoseSearch/PoseSearchDatabase.h"
#include "PoseSearch/PoseSearchSchema.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

namespace GaspBehaviorValidation {
using FObject=TSharedPtr<FJsonObject>;
using FValues=TArray<TSharedPtr<FJsonValue>>;
FObject Object(const TSharedPtr<FJsonValue>& V){return V && V->Type==EJson::Object ? V->AsObject():nullptr;}
bool Scalar(const TSharedPtr<FJsonValue>& V,bool AllowBool=true){return V && ((V->Type==EJson::Number && FMath::IsFinite(V->AsNumber()) && FMath::Abs(V->AsNumber())<=MAX_flt) || (AllowBool && V->Type==EJson::Boolean));}
bool Bool(const FObject& O,const TCHAR* K){bool B=false;if(O)O->TryGetBoolField(K,B);return B;}
FString Str(const FObject& O,const TCHAR* K){FString S;if(O)O->TryGetStringField(K,S);return S;}
double Num(const FObject& O,const TCHAR* K){double N=0;if(O)O->TryGetNumberField(K,N);return N;}
bool Identifier(const FString& S){if(S.IsEmpty() || S.Equals(TEXT("None"),ESearchCase::IgnoreCase) || S.Len()>64 || !(FChar::IsAlpha(S[0]) || S[0]=='_'))return false;for(TCHAR C:S)if(!(FChar::IsAlnum(C)||C=='_') || C>127)return false;return true;}
bool Keys(const FObject& O,const TSet<FString>& Required,const TSet<FString>& Optional={})
{
    if(!O)return false;
    for(const auto& K:Required)if(!O->HasField(K))return false;
    for(const auto& P:O->Values){const FString K(P.Key.ToView());if(!Required.Contains(K) && !Optional.Contains(K))return false;}
    return true;
}
bool BooleanField(const FObject& O,const TCHAR* K){const auto V=O->TryGetField(K);return V && V->Type==EJson::Boolean;}
bool NumberField(const FObject& O,const TCHAR* K,double Min,double Max){const auto V=O->TryGetField(K);return Scalar(V,false) && V->AsNumber()>=Min && V->AsNumber()<=Max;}
const TSet<FString> Builtins={TEXT("speed"),TEXT("falling"),TEXT("crouched"),TEXT("state_time"),TEXT("finished"),TEXT("interrupted")};
bool Validate(const UGaspAnimationSet* Set,const USkeleton* Skeleton,FString& Error)
{
    if(!Set || Set->BehaviorGraphJson.IsEmpty())return true;
    FObject G;auto Fail=[&](const FString& S){Error=TEXT("Behavior graph: ")+S;return false;};
    if(Set->BehaviorGraphJson.Len()>1048576 || !FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Set->BehaviorGraphJson),G) || !G)return Fail(TEXT("invalid/oversized JSON"));
    const FValues *Nodes=nullptr,*Edges=nullptr,*Inputs=nullptr;const FObject* Vars=nullptr;
    const double Version=Num(G,TEXT("version"));
    TSet<FString> RootFields={TEXT("version"),TEXT("entry"),TEXT("variables"),TEXT("inputs"),TEXT("states"),TEXT("transitions")};
    if(Version==3){RootFields.Add(TEXT("handlers"));RootFields.Add(TEXT("variable_sources"));}
    if(!Keys(G,RootFields) || (Version!=1 && Version!=2 && Version!=3) || !G->TryGetArrayField(TEXT("states"),Nodes) || !G->TryGetArrayField(TEXT("transitions"),Edges) || !G->TryGetArrayField(TEXT("inputs"),Inputs) || !G->TryGetObjectField(TEXT("variables"),Vars) || Nodes->IsEmpty() || Nodes->Num()>32 || Edges->Num()>128 || Inputs->Num()>64 || (*Vars)->Values.Num()>64)return Fail(TEXT("invalid version, fields or graph limits"));
    TSet<FName> FoldedVars,FoldedNames;TSet<FString> VarNames=Builtins,Names;TMap<FString,FObject> Definitions;
    if(Version==3)for(const TCHAR* K:{TEXT("vertical_speed"),TEXT("move_input"),TEXT("gait"),TEXT("animation_phase")})VarNames.Add(K);
    for(const auto& K:VarNames)FoldedVars.Add(FName(*K));
    for(const auto& V:(*Vars)->Values)
    {
        const FString K(V.Key.ToView());if(!Identifier(K) || FoldedVars.Contains(FName(*K)) || !Scalar(V.Value))return Fail(TEXT("invalid or reserved variable: ")+K);
        FoldedVars.Add(FName(*K));VarNames.Add(K);
    }
    if(Version==3)
    {
        const FObject* Sources=nullptr;if(!G->TryGetObjectField(TEXT("variable_sources"),Sources) || (*Sources)->Values.Num()!=(*Vars)->Values.Num())return Fail(TEXT("variable_sources must cover variables"));
        for(const auto& P:(*Sources)->Values)
        {
            const auto S=Object(P.Value);const FString Scope=Str(S,TEXT("scope"));
            if(!(*Vars)->HasField(P.Key) || !Keys(S,{TEXT("scope"),TEXT("source")}) || (Scope!=TEXT("internal") && Scope!=TEXT("external")) || Str(S,TEXT("source")).TrimStartAndEnd().IsEmpty())return Fail(TEXT("invalid variable source"));
        }
    }
    auto ActionsValid=[&](const FObject& O,const TCHAR* Field)
    {
        if(!O->HasField(Field))return true;const FValues* Actions=nullptr;
        if(Version<2 || !O->TryGetArrayField(Field,Actions) || Actions->Num()>32)return false;
        for(const auto& V:*Actions)
        {
            const auto A=Object(V);if(!A)return false;const FString Op=Str(A,TEXT("op"));
            if(Op==TEXT("jump")){if(!Keys(A,{TEXT("op"),TEXT("velocity")}) || !NumberField(A,TEXT("velocity"),1,2000))return false;}
            else if((Op!=TEXT("set") && Op!=TEXT("add")) || !Keys(A,{TEXT("op"),TEXT("var"),TEXT("value")}) || !(*Vars)->HasField(Str(A,TEXT("var"))) || !Scalar(A->TryGetField(TEXT("value"))))return false;
        }
        return true;
    };
    TFunction<bool(const FObject&,int32,int32&)> ConditionValid;
    ConditionValid=[&](const FObject& C,int32 Depth,int32& Count)
    {
        if(!C || Depth>8 || ++Count>128)return false;
        for(const TCHAR* Key:{TEXT("all"),TEXT("any")})if(C->HasField(Key))
        {
            const FValues* Children=nullptr;if(!Keys(C,{Key}) || !C->TryGetArrayField(Key,Children) || Children->IsEmpty())return false;
            for(const auto& Child:*Children)if(!ConditionValid(Object(Child),Depth+1,Count))return false;return true;
        }
        if(C->HasField(TEXT("not")))return Keys(C,{TEXT("not")}) && ConditionValid(Object(C->TryGetField(TEXT("not"))),Depth+1,Count);
        const TSet<FString> Ops={TEXT("eq"),TEXT("ne"),TEXT("lt"),TEXT("le"),TEXT("gt"),TEXT("ge")};
        return Keys(C,{TEXT("var"),TEXT("op"),TEXT("value")}) && VarNames.Contains(Str(C,TEXT("var"))) && Ops.Contains(Str(C,TEXT("op"))) && Scalar(C->TryGetField(TEXT("value")));
    };
    for(const auto& V:*Nodes)
    {
        const auto S=Object(V);if(!S)return Fail(TEXT("invalid state"));
        TSet<FString> Optional={TEXT("database_role")};
        if(Version>=2)for(const TCHAR* K:{TEXT("parent"),TEXT("initial"),TEXT("on_entry"),TEXT("on_exit"),TEXT("on_complete")})Optional.Add(K);
        if(!Keys(S,{TEXT("id"),TEXT("player"),TEXT("resources"),TEXT("loop"),TEXT("allow_movement"),TEXT("lock_until_finished"),TEXT("min_duration"),TEXT("blend_seconds")},Optional))return Fail(TEXT("unknown/missing state fields"));
        const FString Id=Str(S,TEXT("id")),Player=Str(S,TEXT("player")),Role=Str(S,TEXT("database_role"));const FValues* Paths=nullptr;
        if(!Identifier(Id) || FoldedNames.Contains(FName(*Id)) || !S->TryGetArrayField(TEXT("resources"),Paths) || !NumberField(S,TEXT("blend_seconds"),0,2) || !NumberField(S,TEXT("min_duration"),0,60) || !BooleanField(S,TEXT("loop")) || !BooleanField(S,TEXT("allow_movement")) || !BooleanField(S,TEXT("lock_until_finished")))return Fail(TEXT("invalid state id/resources/timing: ")+Id);
        Names.Add(Id);FoldedNames.Add(FName(*Id));Definitions.Add(Id,S);
        if(Player!=TEXT("locomotion") && Player!=TEXT("mm") && Player!=TEXT("sequence") && Player!=TEXT("montage") && !(Version>=2 && Player==TEXT("group")))return Fail(TEXT("unknown player"));
        for(const TCHAR* Field:{TEXT("on_entry"),TEXT("on_exit"),TEXT("on_complete")})if(!ActionsValid(S,Field))return Fail(TEXT("invalid state actions"));
        const bool Endless=Bool(S,TEXT("loop")) || Player==TEXT("mm") || Player==TEXT("locomotion") || Player==TEXT("group");
        if(Endless && Bool(S,TEXT("lock_until_finished")))return Fail(TEXT("non-finishing state cannot lock until finished"));
        if(S->HasField(TEXT("on_complete")) && Endless && !S->GetArrayField(TEXT("on_complete")).IsEmpty())return Fail(TEXT("on_complete requires a finite sequence/montage"));
        if((Player==TEXT("locomotion") || Player==TEXT("group")) && (!Paths->IsEmpty() || !Role.IsEmpty()))return Fail(TEXT("group/locomotion cannot bind resources"));
        if(Player==TEXT("group")){if(!Identifier(Str(S,TEXT("initial"))) || Bool(S,TEXT("loop")))return Fail(TEXT("group needs initial child and loop=false"));}
        else if(S->HasField(TEXT("initial")))return Fail(TEXT("only groups have initial children"));
        if(S->HasField(TEXT("parent")) && !Identifier(Str(S,TEXT("parent"))))return Fail(TEXT("parent must name a group; omit for top-level states"));
        for(const TCHAR* K:{TEXT("parent"),TEXT("initial"),TEXT("database_role")})if(S->HasField(K) && S->TryGetField(K)->Type!=EJson::String)return Fail(TEXT("optional state reference must be string"));
        if(Player==TEXT("mm"))
        {
            if(!Role.IsEmpty()){if(!Set->ConfiguredLocomotion.Contains(FName(*Role)) || !Paths->IsEmpty())return Fail(TEXT("unknown MM role"));}
            else if(Paths->IsEmpty() || Paths->Num()>8)return Fail(TEXT("MM database missing"));
        }
        if((Player==TEXT("sequence") || Player==TEXT("montage")) && (Paths->Num()!=1 || !Role.IsEmpty()))return Fail(TEXT("sequence/montage needs exactly one resource"));
        if(Player==TEXT("montage") && Bool(S,TEXT("loop")))return Fail(TEXT("looped montage is unsupported; use a looping sequence"));
        for(const auto& P:*Paths)
        {
            if(!P || P->Type!=EJson::String)return Fail(TEXT("invalid resource path"));
            UObject* Asset=nullptr;for(const auto& R:Set->BehaviorResources)if(R && R->GetPathName()==P->AsString()){Asset=R;break;}
            if(!Asset)return Fail(TEXT("resource is not retained for cooking: ")+P->AsString());
            if(Player==TEXT("sequence")){const auto* A=Cast<UAnimSequence>(Asset);if(!A || A->GetSkeleton()!=Skeleton || A->IsValidAdditive() || A->GetNumberOfSampledKeys()<2)return Fail(TEXT("invalid sequence"));}
            if(Player==TEXT("montage"))
            {
                const auto* A=Cast<UAnimMontage>(Asset);if(!A || A->GetSkeleton()!=Skeleton || !A->bEnableAutoBlendOut || A->GetPlayLength()<=0)return Fail(TEXT("invalid or non-finishing montage"));
                for(int32 I=0;I<A->CompositeSections.Num();++I)
                {
                    TSet<FName> Visited;FName Section=A->GetSectionName(I);
                    while(!Section.IsNone())
                    {
                        if(Visited.Contains(Section))return Fail(TEXT("montage section cycle is unsupported"));Visited.Add(Section);
                        const int32 Index=A->GetSectionIndex(Section);if(Index==INDEX_NONE)break;Section=A->CompositeSections[Index].NextSectionName;
                    }
                }
                if(A->SlotAnimTracks.Num()!=1 || A->SlotAnimTracks[0].SlotName!=Set->MontageSlot)return Fail(TEXT("montage must use the configured native Slot"));
            }
            if(Player==TEXT("mm")){const auto* A=Cast<UPoseSearchDatabase>(Asset);if(!A || !A->Schema || A->Schema->GetSkeleton(A->Schema->GetDefaultRole())!=Skeleton)return Fail(TEXT("invalid database"));}
        }
    }
    for(const auto& P:Definitions)
    {
        FString Parent=Str(P.Value,TEXT("parent"));TSet<FString> Visited={P.Key};
        while(!Parent.IsEmpty())
        {
            if(Visited.Contains(Parent) || Visited.Num()>=8 || !Definitions.Contains(Parent) || Str(Definitions[Parent],TEXT("player"))!=TEXT("group"))return Fail(TEXT("invalid parent/cycle/depth: ")+P.Key);
            Visited.Add(Parent);Parent=Str(Definitions[Parent],TEXT("parent"));
        }
        if(Str(P.Value,TEXT("player"))==TEXT("group")){const auto Child=Definitions.FindRef(Str(P.Value,TEXT("initial")));if(!Child || Str(Child,TEXT("parent"))!=P.Key)return Fail(TEXT("group initial must be a direct child"));}
    }
    const FString Entry=Str(G,TEXT("entry"));if(!Names.Contains(Entry))return Fail(TEXT("entry missing"));
    for(const auto& V:*Edges)
    {
        const auto E=Object(V);if(!E)return Fail(TEXT("invalid transition"));TSet<FString> Optional;if(Version>=2)Optional={TEXT("condition"),TEXT("actions")};
        if(!Keys(E,{TEXT("from"),TEXT("to"),TEXT("event"),TEXT("all"),TEXT("priority"),TEXT("interrupt")},Optional))return Fail(TEXT("transition fields invalid"));
        const FString From=Str(E,TEXT("from")),To=Str(E,TEXT("to")),Event=Str(E,TEXT("event"));const FValues* Conditions=nullptr;
        if((From!=TEXT("*") && !Names.Contains(From)) || !Names.Contains(To) || E->TryGetField(TEXT("event"))->Type!=EJson::String || (!Event.IsEmpty() && !Identifier(Event)) || !E->TryGetArrayField(TEXT("all"),Conditions) || Conditions->Num()>16 || (Event.IsEmpty() && Conditions->IsEmpty() && !E->HasField(TEXT("condition"))) || !NumberField(E,TEXT("priority"),-1000,1000) || Num(E,TEXT("priority"))!=FMath::FloorToDouble(Num(E,TEXT("priority"))) || !BooleanField(E,TEXT("interrupt")) || !ActionsValid(E,TEXT("actions")))return Fail(TEXT("invalid transition endpoints/condition/actions"));
        for(const auto& C:*Conditions){int32 Count=0;const auto O=Object(C);if(!O || !O->HasField(TEXT("var")) || !ConditionValid(O,1,Count))return Fail(TEXT("invalid all predicate"));}
        if(E->HasField(TEXT("condition"))){int32 Count=0;if(!ConditionValid(Object(E->TryGetField(TEXT("condition"))),1,Count))return Fail(TEXT("invalid nested condition"));}
    }
    TSet<FString> SeenInputs;
    for(const auto& V:*Inputs)
    {
        const auto B=Object(V);if(!B)return Fail(TEXT("invalid input"));const FString Key=Str(B,TEXT("key")),Phase=Str(B,TEXT("phase")),Token=Key.ToLower()+Phase;const FObject* Assign=nullptr;
        TSet<FString> Optional;if(Version>=2)Optional.Add(TEXT("actions"));
        if(!Keys(B,{TEXT("key"),TEXT("phase"),TEXT("event"),TEXT("set")},Optional) || !Identifier(Key) || !FKey(FName(*Key)).IsValid() || (Phase!=TEXT("pressed") && Phase!=TEXT("released")) || !Identifier(Str(B,TEXT("event"))) || !B->TryGetObjectField(TEXT("set"),Assign) || SeenInputs.Contains(Token) || !ActionsValid(B,TEXT("actions")))return Fail(TEXT("invalid/duplicate key binding"));SeenInputs.Add(Token);
        for(const auto& P:(*Assign)->Values)if(!(*Vars)->HasField(P.Key) || !Scalar(P.Value))return Fail(TEXT("invalid input assignment"));
    }
    if(Version==3)
    {
        const FValues* Handlers=nullptr;if(!G->TryGetArrayField(TEXT("handlers"),Handlers) || Handlers->Num()>128)return Fail(TEXT("invalid handlers"));
        for(const auto& V:*Handlers)
        {
            const auto H=Object(V);int32 Count=0;
            if(!Keys(H,{TEXT("from"),TEXT("event"),TEXT("condition"),TEXT("actions"),TEXT("priority")}) || (Str(H,TEXT("from"))!=TEXT("*") && !Names.Contains(Str(H,TEXT("from")))) || !Identifier(Str(H,TEXT("event"))) || !NumberField(H,TEXT("priority"),-1000,1000) || Num(H,TEXT("priority"))!=FMath::FloorToDouble(Num(H,TEXT("priority"))) || !ConditionValid(Object(H->TryGetField(TEXT("condition"))),1,Count) || !ActionsValid(H,TEXT("actions")) || H->GetArrayField(TEXT("actions")).IsEmpty())return Fail(TEXT("invalid conditional internal handler"));
        }
    }
    TSet<FString> Reachable={Entry};
    for(int32 Iter=0;Iter<Nodes->Num()*2;++Iter)
    {
        const auto Before=Reachable;
        for(const auto& Id:Before)
        {
            const auto S=Definitions.FindRef(Id);if(!S)continue;const FString Parent=Str(S,TEXT("parent")),Initial=Str(S,TEXT("initial"));
            if(!Parent.IsEmpty())Reachable.Add(Parent);if(!Initial.IsEmpty())Reachable.Add(Initial);
        }
        for(const auto& V:*Edges){const auto E=Object(V);if(Str(E,TEXT("from"))==TEXT("*") || Reachable.Contains(Str(E,TEXT("from"))))Reachable.Add(Str(E,TEXT("to")));}
    }
    if(Reachable.Num()!=Names.Num())return Fail(TEXT("unreachable state"));
    return true;
}
}

bool UGaspBehaviorComponent::ValidateDefinition(const UGaspAnimationSet* Set,const USkeleton* Skeleton,FString& Error)
{
    return GaspBehaviorValidation::Validate(Set,Skeleton,Error);
}
