#include "GaspChooser.h"
#include "GaspChooserParameters.h"
#include "Chooser.h"
#include "Misc/FileHelper.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"

bool FGaspChooser::Load(const FString& Filename)
{
    FString Text;
    return FFileHelper::LoadFileToString(Text, *Filename) && LoadText(Text);
}

bool FGaspChooser::LoadText(const FString& Text)
{
    NativeTable.Reset();
    Document.Reset();
    return FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text), Document) && Document.IsValid();
}

TArray<FSoftObjectPath> FGaspChooser::Evaluate(const TMap<FString, double>& Context, TMap<FString, double>& Outputs) const
{
    TArray<FSoftObjectPath> Results;
    Outputs.Reset();
    if (NativeTable.IsValid())
    {
        FGaspChooserValues Values; Values.Inputs=&Context; Values.Outputs=&Outputs;
        FChooserEvaluationContext NativeContext; NativeContext.AddStructParam(Values);
        UChooserTable::EvaluateChooser(NativeContext, NativeTable.Get(),
            FObjectChooserBase::FObjectChooserSoftObjectIteratorCallback::CreateLambda([&Results](const TSoftObjectPtr<UObject>& Object)
            { Results.AddUnique(Object.ToSoftObjectPath()); return FObjectChooserBase::EIteratorStatus::Continue; }));
        return Results;
    }
    TSet<FString> Active;
    if (Document) EvaluateTable(Document->GetStringField(TEXT("root")), Context, Outputs, Results, Active);
    return Results;
}

void FGaspChooser::EvaluateTable(const FString& Name, const TMap<FString, double>& Context,
    TMap<FString, double>& Outputs, TArray<FSoftObjectPath>& Results, TSet<FString>& Active) const
{
    checkf(!Active.Contains(Name), TEXT("Recursive chooser: %s"), *Name);
    Active.Add(Name);
    const TSharedPtr<FJsonObject> Table = Document->GetObjectField(TEXT("tables"))->GetObjectField(Name);
    const auto& Rows = Table->GetArrayField(TEXT("results"));
    const auto& Columns = Table->GetArrayField(TEXT("columns"));
    const auto& Disabled = Table->GetArrayField(TEXT("disabled"));
    for (int32 RowIndex = 0; RowIndex < Rows.Num(); ++RowIndex)
    {
        if (Disabled.IsValidIndex(RowIndex) && Disabled[RowIndex]->AsBool()) continue;
        bool bMatches = true;
        for (const auto& Value : Columns)
        {
            const auto Col = Value->AsObject();
            const FString Type = Col->GetStringField(TEXT("type"));
            if (Type == TEXT("OutputEnumColumn")) continue;
            const FString Key = Col->GetStringField(TEXT("binding"));
            const double* Input = Context.Find(Key);
            if (!Input) { bMatches = false; break; } // Missing inputs must never silently match.
            const auto& Values = Col->GetArrayField(TEXT("rows"));
            if (!Values.IsValidIndex(RowIndex)) { bMatches = false; break; }
            const auto& Row = Values[RowIndex];
            if (Type == TEXT("BoolColumn"))
            {
                const FString Match = Row->AsString();
                bMatches = Match == TEXT("MatchAny") || (Match == TEXT("MatchTrue") && *Input != 0) ||
                    (Match == TEXT("MatchFalse") && *Input == 0);
            }
            else if (Type == TEXT("FloatRangeColumn"))
            {
                auto Range = Row->AsObject();
                bMatches = (Range->GetBoolField(TEXT("no_min")) || *Input >= Range->GetNumberField(TEXT("min"))) &&
                    (Range->GetBoolField(TEXT("no_max")) || *Input <= Range->GetNumberField(TEXT("max")));
            }
            else if (Type == TEXT("EnumColumn"))
            {
                auto Enum = Row->AsObject();
                const FString Comparison = Enum->GetStringField(TEXT("comparison"));
                const bool bEqual = int32(*Input) == int32(Enum->GetNumberField(TEXT("value")));
                bMatches = Comparison == TEXT("MatchAny") || (Comparison == TEXT("MatchEqual") && bEqual) ||
                    (Comparison == TEXT("MatchNotEqual") && !bEqual);
            }
            else if (Type == TEXT("MultiEnumColumn"))
                bMatches = *Input >= 0 && *Input < 32 && (uint32(Row->AsNumber()) & (1u << uint32(*Input))) != 0;
            else bMatches = false;
            if (!bMatches) break;
        }
        if (!bMatches) continue;
        for (const auto& Value : Columns)
        {
            const auto Col = Value->AsObject();
            if (Col->GetStringField(TEXT("type")) == TEXT("OutputEnumColumn"))
                Outputs.Add(Col->GetStringField(TEXT("binding")), Col->GetArrayField(TEXT("rows"))[RowIndex]->AsNumber());
        }
        const auto Row = Rows[RowIndex]->AsObject();
        FString Nested;
        if (Row->TryGetStringField(TEXT("nested"), Nested)) EvaluateTable(Nested, Context, Outputs, Results, Active);
        else
        {
            FString Asset;
            if (Row->TryGetStringField(TEXT("asset"), Asset)) Results.AddUnique(FSoftObjectPath(Asset));
        }
    }
    Active.Remove(Name);
}
