using UnrealBuildTool;

public class GaspNative : ModuleRules
{
    public GaspNative(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        PublicDependencyModuleNames.AddRange(new[] {
            "Core", "CoreUObject", "Engine", "InputCore", "AnimGraphRuntime",
            "PoseSearch", "BlendStack", "MotionWarping", "AnimationWarpingRuntime", "Chooser", "DeveloperSettings"
        });
        PrivateDependencyModuleNames.AddRange(new[] { "Json", "JsonUtilities" });
    }
}
