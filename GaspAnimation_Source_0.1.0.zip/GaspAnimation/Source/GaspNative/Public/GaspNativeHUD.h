#pragma once
#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "GaspNativeHUD.generated.h"

UCLASS()
class GASPNATIVE_API AGaspNativeHUD : public AHUD
{
    GENERATED_BODY()
public:
    virtual void DrawHUD() override;
};
