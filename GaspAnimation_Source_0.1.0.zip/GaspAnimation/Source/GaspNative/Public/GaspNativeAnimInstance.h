#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "AnimationWarpingTypes.h"
#include "GaspChooser.h"
#include "GaspNativeAnimInstance.generated.h"

struct FAnimNode_MotionMatching;
struct FAnimNode_PoseSearchHistoryCollector;
struct FAnimNode_FootPlacement;
struct FGaspAnimState;
class UPoseSearchDatabase;
class UGaspAnimationSet;
class UBlendSpace;
class USkeletalMesh;
struct FAnimNode_Base;
struct FPoseSearchBlueprintResult;
enum class EPoseSearchInterruptMode : uint8;
namespace UE::PoseSearch { struct IPoseHistory; }
struct FGaspGraphNode { FAnimNode_Base* Node; UScriptStruct* Type; };

USTRUCT(BlueprintType)
struct GASPNATIVE_API FGaspMotionMatchingAnimationGroup
{
    GENERATED_BODY()
    // Retained only to map embedded chooser results to this group's replacement databases.
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Motion Matching") TObjectPtr<UPoseSearchDatabase> SourceDatabase;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Motion Matching") TArray<FName> SemanticStates;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Motion Matching") FName PublicVariableName;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Motion Matching", meta=(DisplayName="Motion Matching Databases", ToolTip="Edit each Pose Search Database's animation assets to change clips. Only compatible Motion Matching databases are accepted."))
    TArray<TObjectPtr<UPoseSearchDatabase>> Databases;
};

USTRUCT(BlueprintType)
struct GASPNATIVE_API FGaspCharacterInputs
{
    GENERATED_BODY()
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) int32 Gait = 1;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) bool WantsToAim = false;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) float JustLandedTime = 0;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) FVector LandVelocity = FVector::ZeroVector;
};

UCLASS(Transient, Blueprintable)
class GASPNATIVE_API UGaspNativeAnimInstance : public UAnimInstance
{
    GENERATED_BODY()
public:
    UGaspNativeAnimInstance();
    virtual ~UGaspNativeAnimInstance();
    virtual void NativeInitializeAnimation() override;
    virtual void NativeUpdateAnimation(float DeltaSeconds) override;
    virtual void NativePostEvaluateAnimation() override;
    UFUNCTION(BlueprintPure, Category="GASP") static UGaspNativeAnimInstance* Resolve(USkeletalMeshComponent* Mesh);
    // Override just this adapter for an existing ACharacter; no graph/state logic duplication.
    UFUNCTION(BlueprintNativeEvent, Category="GASP") FGaspCharacterInputs ReadCharacterInputs() const;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="GASP", meta=(PinShownByDefault)) TObjectPtr<UGaspAnimationSet> AnimationSet;
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, AdvancedDisplay, Category="GASP|Motion Matching|Legacy Groups", meta=(DisplayName="Motion Matching Group Bindings", ToolTip="Compatibility bindings. Generated public MMGroup variables on the template take precedence. Edit those inherited variables in child blueprints."))
    TMap<FName,FGaspMotionMatchingAnimationGroup> MotionMatchingAnimationGroups;
    UFUNCTION(BlueprintPure, Category="GASP|Motion Matching") bool GetMotionMatchingAnimationGroup(FName Group,TArray<UPoseSearchDatabase*>& Databases) const;
    bool ValidateMotionMatchingAnimationGroups(const USkeletalMesh* Mesh,FString& Error) const;
    UPROPERTY(BlueprintReadOnly, Category="GASP") TObjectPtr<UBlendSpace> LeanAsset;
    UPROPERTY(BlueprintReadOnly, Category="GASP") TObjectPtr<UBlendSpace> AimAsset;
    UPROPERTY(BlueprintReadOnly, Category="GASP") bool bAnimationSetValid = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float Speed2D = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) int32 Gait = 1;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) int32 Stance = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) int32 MovementMode = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) int32 MovementState = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool IsStarting = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool IsPivoting = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool ShouldTurnInPlace = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool ShouldSpinTransition = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool JustLanded_Light = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool JustLanded_Heavy = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool JustTraversed = false;
    UPROPERTY(BlueprintReadWrite, Category=Gasp) int32 MMDatabaseLOD = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) EOffsetRootBoneMode TranslationMode = EOffsetRootBoneMode::Interpolate;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) EOffsetRootBoneMode RotationMode = EOffsetRootBoneMode::Accumulate;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float FootPlacementAlpha = 1;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float LeanAmount = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float LeanAlpha = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FVector AimBlend = FVector::ZeroVector;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float AimYaw = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float AimPitch = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float AimAlpha = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float LocomotionAngle = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FQuat DesiredFacing = FQuat::Identity;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FVector PredictedTrajectoryNear = FVector::ZeroVector;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FVector PredictedTrajectoryFar = FVector::ZeroVector;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float SteeringAlpha = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float MotionBlendTime = .5f;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float TranslationHalflife = .1f;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool bClampTranslation = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float NotifyRecencyTimeOut = .2f;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FName SelectedDatabase;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FName SelectedAnimation;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float SelectedTime = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) float SearchCost = 0;
    int32 SampleUpdateCount = 0;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) TArray<TObjectPtr<UPoseSearchDatabase>> CurrentDatabases;
    // PoseSearch interaction channel calls this when choosing a traversal montage.
    UFUNCTION(Category="GASP", BlueprintPure, meta=(BlueprintThreadSafe)) FTransform GetInteractionTransform() const { return InteractionTransform; }
    UPROPERTY(BlueprintReadOnly, Category=Gasp) FTransform InteractionTransform = FTransform::Identity;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool NotifyTransitionReTransition = false;
    UPROPERTY(BlueprintReadOnly, Category=Gasp) bool NotifyTransitionToLoop = false;
    virtual const UE::PoseSearch::IPoseHistory* GetSearchPoseHistory() const;
protected:
    virtual void EnumerateGraphNodes(TArray<FGaspGraphNode>& Nodes);
    virtual bool HasMotionGraph() const;
    virtual void SubmitDatabases(const TArray<UPoseSearchDatabase*>& Databases, EPoseSearchInterruptMode Mode);
    virtual FPoseSearchBlueprintResult ReadMotionResult() const;
private:
    FGaspChooser Dense, Sparse;
    TSharedPtr<FGaspAnimState> State;
    FAnimNode_MotionMatching* MotionMatching = nullptr;
    FAnimNode_PoseSearchHistoryCollector* History = nullptr;
    FAnimNode_FootPlacement* Feet = nullptr;
    UPROPERTY() TArray<TObjectPtr<UObject>> LoadedAssets;
};



