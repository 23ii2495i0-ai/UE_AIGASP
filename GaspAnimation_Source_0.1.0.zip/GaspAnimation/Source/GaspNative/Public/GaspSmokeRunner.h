#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Dom/JsonObject.h"
#include "GaspSmokeRunner.generated.h"

class AGaspNativeCharacter;
class AGaspTraversableBlock;
class AStaticMeshActor;

// Runs in the normal game engine loop (-game -NativeSmoke), including CMC/physics.
UCLASS(NotBlueprintable)
class GASPNATIVE_API AGaspSmokeRunner : public AActor
{
    GENERATED_BODY()
public:
    AGaspSmokeRunner();
    virtual void Tick(float DeltaSeconds) override;
private:
    enum class EPhase { Warmup, ProfileAlternate, ProfileRestore, Run, Sprint, Walk, Stop, Crouch, Uncrouch, Jump, Land, Sparse, PrepareTraversal, Traverse, Settle, Interrupt, Done };
    EPhase Phase = EPhase::Warmup;
    float PhaseTime = 0;
    double PhaseRealTime = 0;
    double Started = 0;
    int32 TraversalCase = 0;
    int32 Failures = 0;
    bool bStartedTraversal = false;
    FVector InitialLocation = FVector::ZeroVector;
    FVector InitialFoot = FVector::ZeroVector;
    FQuat PreviousThighRotation = FQuat::Identity;
    int32 PoseChangedFrames = 0;
    TArray<TSharedPtr<FJsonValue>> Checks;
    UPROPERTY() TObjectPtr<AGaspNativeCharacter> Character;
    UPROPERTY() TObjectPtr<AGaspTraversableBlock> Block;
    UPROPERTY() TObjectPtr<AStaticMeshActor> Platform;
    void Advance(EPhase Next);
    void Check(const TCHAR* Name, bool Passed, const FString& Detail = FString());
    void Finish();
    void TickMarker(float DeltaSeconds);
    void TickFlow(float DeltaSeconds);
    void TickConfigQuality(float DeltaSeconds);
    void TickDirectionalQuality(float DeltaSeconds);
    void TickBehaviorQuality(float DeltaSeconds);
    void TickBehaviorCompiler(float DeltaSeconds);
    void TickBehaviorGenerated(float DeltaSeconds);
    TSharedPtr<FJsonObject> BehaviorExpected;
    float DirectionalMaxCurve=0;
    int32 QualityStage=0, QualityEmptyFrames=0, QualityPoseFrames=0;
    float QualityLastTime=0;
    float QualityMaxAngularStep=0;
    int32 FlowStage=0;
    float FlowSavedPosition=0;
};
