#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GaspActionFlowComponent.generated.h"
class UAnimMontage;
class UAnimSequence;

// Events are gameplay inputs; configuration and playback are entirely native.
UCLASS(ClassGroup=(GASP), meta=(BlueprintSpawnableComponent))
class GASPNATIVE_API UGaspActionFlowComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UGaspActionFlowComponent();
    UFUNCTION(BlueprintCallable, Category="GASP|Flow") bool RequestAction(FName Action);
    UFUNCTION(BlueprintCallable, Category="GASP|Flow") bool RequestLocomotion();
    UFUNCTION(BlueprintPure, Category="GASP|Flow") bool IsActionLocked() const;
    UFUNCTION(BlueprintPure, Category="GASP|Flow") UAnimSequence* GetActiveSequence() const {return ActiveSequence;}
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="GASP|Flow") FName ActiveAction;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="GASP|Flow") FName SuspendedAction;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="GASP|Flow") float SuspendedPosition = 0;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="GASP|Flow") int32 CompletedActions = 0;
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="GASP|Flow") int32 ResumedActions = 0;
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
private:
    UPROPERTY() TObjectPtr<UAnimMontage> ActiveMontage;
    UPROPERTY() TObjectPtr<UAnimSequence> ActiveSequence;
    UPROPERTY() TObjectPtr<UAnimSequence> SuspendedSequence;
    TMap<FName,int32> NextCandidate;
    bool StartAction(FName Action, float Position=0, UAnimSequence* ResumeSequence=nullptr);
    void OnEnded(UAnimMontage* Montage, bool bInterrupted);
};
