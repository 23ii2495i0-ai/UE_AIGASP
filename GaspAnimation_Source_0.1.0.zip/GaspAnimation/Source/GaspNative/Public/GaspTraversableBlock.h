#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GaspTraversableBlock.generated.h"

UCLASS()
class GASPNATIVE_API AGaspTraversableBlock : public AActor
{
    GENERATED_BODY()
public:
    AGaspTraversableBlock();
    UPROPERTY(Category="GASP", VisibleAnywhere) TObjectPtr<UStaticMeshComponent> Mesh;
    // World-space ledges follow level_builder.gd's OppositeLedges pairs.
    bool GetLedges(const FVector& Hit, const FVector& ActorLocation, FVector& Front,
        FVector& FrontNormal, FVector& Back, FVector& BackNormal) const;
};
