#pragma once
#include "CoreMinimal.h"
#include "PoseSearch/PoseSearchFeatureChannel_Position.h"
#include "PoseSearch/PoseSearchFeatureChannel_Heading.h"
#include "GaspTraversalChannels.generated.h"

UCLASS(EditInlineNew)
class GASPNATIVE_API UGaspTraversalPositionChannel : public UPoseSearchFeatureChannel_Position
{
    GENERATED_BODY()
public:
    virtual void BuildQuery(UE::PoseSearch::FSearchContext& Context) const override;
};

UCLASS(EditInlineNew)
class GASPNATIVE_API UGaspTraversalHeadingChannel : public UPoseSearchFeatureChannel_Heading
{
    GENERATED_BODY()
public:
    virtual void BuildQuery(UE::PoseSearch::FSearchContext& Context) const override;
};
