#pragma once
#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GaspNativeGameMode.generated.h"

UCLASS()
class GASPNATIVE_API AGaspNativeGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    AGaspNativeGameMode();
    virtual void StartPlay() override;
    virtual UClass* GetDefaultPawnClassForController_Implementation(AController* Controller) override;
};
