#pragma once
#include "CoreMinimal.h"
#include "IChooserParameterBool.h"
#include "IChooserParameterFloat.h"
#include "IChooserParameterEnum.h"
#include "GaspChooserParameters.generated.h"

UENUM()
enum class EGaspChooserMovementState : uint8 { Idle, Moving };

// Stack-owned view of the animation/traversal snapshot. No UObject allocation per evaluation.
USTRUCT()
struct GASPNATIVE_API FGaspChooserValues
{
    GENERATED_BODY()
    const TMap<FString, double>* Inputs = nullptr;
    TMap<FString, double>* Outputs = nullptr;
};

USTRUCT(DisplayName="GASP Bool Input")
struct GASPNATIVE_API FGaspChooserBool : public FChooserParameterBoolBase
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, Category="GASP") FString Binding;
    virtual bool GetValue(FChooserEvaluationContext& Context, bool& Value) const override;
    virtual void GetDisplayName(FText& Name) const override { Name=FText::FromString(Binding); }
};

USTRUCT(DisplayName="GASP Float Input")
struct GASPNATIVE_API FGaspChooserFloat : public FChooserParameterFloatBase
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, Category="GASP") FString Binding;
    virtual bool GetValue(FChooserEvaluationContext& Context, double& Value) const override;
    virtual void GetDisplayName(FText& Name) const override { Name=FText::FromString(Binding); }
};

USTRUCT(DisplayName="GASP Enum Input / Output")
struct GASPNATIVE_API FGaspChooserEnum : public FChooserParameterEnumBase
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, Category="GASP") FString Binding;
    UPROPERTY(EditAnywhere, Category="GASP") TObjectPtr<UEnum> Enumeration;
    virtual bool GetValue(FChooserEvaluationContext& Context, uint8& Value) const override;
    virtual bool SetValue(FChooserEvaluationContext& Context, uint8 Value) const override;
    virtual void GetDisplayName(FText& Name) const override { Name=FText::FromString(Binding); }
#if WITH_EDITOR
    virtual const UEnum* GetEnum() const override { return Enumeration; }
#endif
};
