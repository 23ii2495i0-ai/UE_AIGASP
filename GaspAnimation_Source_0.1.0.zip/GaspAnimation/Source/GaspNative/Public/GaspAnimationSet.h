#pragma once
#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GaspAnimationSet.generated.h"

class UBlendSpace;
class UAnimMontage;
class UPoseSearchDatabase;
class USkeletalMesh;
class UChooserTable;
class UAnimSequence;

USTRUCT(BlueprintType)
struct GASPNATIVE_API FGaspActionPolicy
{
    GENERATED_BODY()
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadOnly) bool bHitInterruptsAll = false;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadOnly) bool bAttackMustFinish = false;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadOnly) bool bResumePreviousAfterHit = false;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadOnly) bool bBlockAimWhenSprinting = false;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadOnly) float BlendSeconds = .2f;
};

USTRUCT(BlueprintType)
struct FGaspActionCandidates
{
    GENERATED_BODY()
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadOnly) TArray<TObjectPtr<UAnimSequence>> Sequences;
};

USTRUCT(BlueprintType)
struct FGaspConfiguredTransition
{
    GENERATED_BODY()
    UPROPERTY(Category="GASP", EditAnywhere) FName FromDatabase;
    UPROPERTY(Category="GASP", EditAnywhere) FName ToDatabase;
    UPROPERTY(Category="GASP", EditAnywhere, meta=(ClampMin="0",ClampMax="2")) float BlendSeconds=.2f;
};

USTRUCT(BlueprintType)
struct GASPNATIVE_API FGaspBoneLayout
{
    GENERATED_BODY()
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) FName Root = TEXT("root");
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) FName Pelvis = TEXT("pelvis");
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) FName IKRoot = TEXT("ik_foot_root");
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TArray<FName> Feet = {TEXT("foot_l"), TEXT("foot_r")};
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TArray<FName> IKFeet = {TEXT("ik_foot_l"), TEXT("ik_foot_r")};
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TArray<FName> Balls = {TEXT("ball_l"), TEXT("ball_r")};
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TArray<FName> Thighs = {TEXT("thigh_l"), TEXT("thigh_r")};
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TArray<FName> Spine = {TEXT("spine_01"), TEXT("spine_02"), TEXT("spine_03"), TEXT("spine_04"), TEXT("spine_05")};
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) float MeshYawOffset = -90.f;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TEnumAsByte<EAxis::Type> FootForwardAxis = EAxis::Y;
    UPROPERTY(Category="GASP", EditAnywhere, BlueprintReadWrite) TEnumAsByte<EAxis::Type> KneeHingeAxis = EAxis::Z;
};

// One asset per character animation family. The template contains no character assets.
UCLASS(BlueprintType)
class GASPNATIVE_API UGaspAnimationSet : public UDataAsset
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Behavior",meta=(MultiLine=true)) FString BehaviorGraphJson;
    UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Behavior") TArray<TObjectPtr<UObject>> BehaviorResources;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Character") TSoftObjectPtr<USkeletalMesh> Mesh;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Character") FGaspBoneLayout Bones;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation") TObjectPtr<UBlendSpace> Lean;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation") TObjectPtr<UBlendSpace> Aim;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation") FName MontageSlot = TEXT("DefaultSlot");
    UPROPERTY(EditAnywhere, Category="Animation") bool bEnableFootIK = true;
    UPROPERTY(EditAnywhere, Category="Animation") bool bEnableSampleWarping = true;
    UPROPERTY(EditAnywhere, Category="Animation") bool bEnableRootOffset = true;
    // Useful for a single-clip demonstration until a proper idle is supplied.
    UPROPERTY(EditAnywhere, Category="Animation") bool bReferencePoseWhenStopped = false;
    UPROPERTY(EditAnywhere, Category="Animation") FVector2D PlayRateRange = FVector2D(.85,1.15);
    UPROPERTY(EditAnywhere, Category="Flow") TArray<FGaspConfiguredTransition> ConfiguredTransitions;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Flow") TMap<FName,TObjectPtr<UAnimSequence>> ConfiguredActions;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Flow") TMap<FName,FGaspActionCandidates> ActionCandidates;
    // Generated configurations retain coverage when an unrequested gait (e.g. sprint) is entered.
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Flow") TMap<FName,TObjectPtr<UPoseSearchDatabase>> ConfiguredLocomotion;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Flow") FGaspActionPolicy ActionPolicy;
    // Selected resource variants, baked at authoring time (not equipment simulation).
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Flow") TArray<FName> ConfiguredVariants;
    // Converted chooser rules travel inside the cooked data asset, not external files.
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Chooser", meta=(DisplayName="Dense Databases")) TObjectPtr<UChooserTable> DenseTable;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Chooser", meta=(DisplayName="Sparse Databases")) TObjectPtr<UChooserTable> SparseTable;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Chooser", meta=(DisplayName="Traversal Animations")) TObjectPtr<UChooserTable> TraversalTable;
    UPROPERTY(EditAnywhere, AdvancedDisplay, Category="Chooser") bool bTraversalUsesCMC = false;
    // Serialized legacy data is retained only for lossless one-time migration.
    UPROPERTY() FString DenseChooser;
    UPROPERTY() FString SparseChooser;
    UPROPERTY() FString TraversalChooser;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation") TMap<TSoftObjectPtr<UPoseSearchDatabase>, TSoftObjectPtr<UPoseSearchDatabase>> DatabaseOverrides;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Animation") TMap<TSoftObjectPtr<UAnimMontage>, TSoftObjectPtr<UAnimMontage>> TraversalOverrides;
    // Typed soft references ensure resources mentioned by serialized chooser rules cook.
    UPROPERTY() TArray<TSoftObjectPtr<UPoseSearchDatabase>> Databases;
    UPROPERTY() TArray<TSoftObjectPtr<UAnimMontage>> TraversalMontages;
    UFUNCTION(BlueprintPure, Category="GASP") FSoftObjectPath ResolveDatabase(FSoftObjectPath Source) const;
    UFUNCTION(BlueprintPure, Category="GASP") FSoftObjectPath ResolveTraversal(FSoftObjectPath Source) const;
    bool ValidateForMesh(const USkeletalMesh* Target, FString& Error) const;
};
