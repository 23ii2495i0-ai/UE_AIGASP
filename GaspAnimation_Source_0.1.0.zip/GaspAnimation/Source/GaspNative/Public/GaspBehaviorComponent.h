#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Dom/JsonObject.h"
#include "GaspBehaviorComponent.generated.h"
class UGaspAnimationSet;
class UAnimMontage;
class UPoseSearchDatabase;
class UInputComponent;
class USkeleton;
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FGaspBehaviorStateChanged,FName,PreviousState,FName,NewState);

// Executes reviewed graph data only. Never executes generated Blueprint or script code.
UCLASS(ClassGroup=(GASP),meta=(BlueprintSpawnableComponent))
class GASPNATIVE_API UGaspBehaviorComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UGaspBehaviorComponent();
    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime,ELevelTick TickType,FActorComponentTickFunction* ThisTickFunction) override;
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
    UFUNCTION(BlueprintCallable,Category="GASP|Behavior") bool SendEvent(FName Event);
    UFUNCTION(BlueprintCallable,Category="GASP|Behavior") bool SetVariable(FName Name,float Value);
    UFUNCTION(BlueprintCallable,Category="GASP|Behavior") bool SetBoolVariable(FName Name,bool Value);
    UFUNCTION(BlueprintPure,Category="GASP|Behavior") float GetVariable(FName Name) const;
    UFUNCTION(BlueprintPure,Category="GASP|Behavior") bool GetBoolVariable(FName Name) const;
    UFUNCTION(BlueprintPure,Category="GASP|Behavior") bool IsStateActive(FName State) const;
    UFUNCTION(BlueprintPure,Category="GASP|Behavior") TArray<FName> GetUnboundExternalVariables() const;
    UPROPERTY(BlueprintAssignable,Category="GASP|Behavior") FGaspBehaviorStateChanged OnStateChanged;
    UFUNCTION(BlueprintPure,Category="GASP|Behavior") bool IsEnabled() const {return bEnabled;}
    UFUNCTION(BlueprintPure,Category="GASP|Behavior") bool AllowsMovement() const;
    UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="GASP|Behavior") FName CurrentState;
    UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="GASP|Behavior") float StateTime=0;
    UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="GASP|Behavior") FString LastError;
    UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="GASP|Behavior") int32 TransitionCount=0;
    void BindInputs(UInputComponent* Input);
    bool HandlesKey(FName Key) const;
    bool GetDatabaseOverride(TArray<UPoseSearchDatabase*>& Databases) const;
    float GetBlendSeconds() const;
    static bool ValidateDefinition(const UGaspAnimationSet* Set,const USkeleton* Skeleton,FString& Error);
private:
    TSharedPtr<FJsonObject> Graph;
    TMap<FName,TSharedPtr<FJsonObject>> States;
    TMap<FName,double> Variables;
    TSet<FName> UnboundExternalVariables;
    TArray<FName> ActivePath;
    TMap<FName,double> ActiveTimes;
    TWeakObjectPtr<UGaspAnimationSet> LoadedSet;
    TWeakObjectPtr<UInputComponent> BoundInput;
    TSet<FString> BoundKeys;
    UPROPERTY() TObjectPtr<UAnimMontage> ActiveMontage;
    bool bEnabled=false,bFinished=false,bInterrupted=false,bTransitioning=false;
    void Configure();
    bool Enter(FName State,const TSharedPtr<FJsonObject>& Transition=nullptr);
    bool Evaluate(const FString& Event);
    bool TestCondition(const TSharedPtr<FJsonObject>& Condition) const;
    void RunActions(const TSharedPtr<FJsonObject>& Object,const TCHAR* Field);
    void HandleKey(FName Key,bool bPressed);
    void OnMontageEnded(UAnimMontage* Montage,bool bInterrupted);
    double Value(const FString& Name) const;
    void SyncBlueprintVariables();
    bool ReadBlueprintVariable(FName Name,double& OutValue) const;
    bool WriteBlueprintVariable(FName Name,double Value) const;
};
