#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "GaspMontageBlendOutNotifyState.generated.h"

UENUM()
enum class EGaspBlendOutCondition : uint8 { Always, WithInput, Falling };

UCLASS(meta=(DisplayName="GASP Native Montage Blend Out"))
class GASPNATIVE_API UGaspMontageBlendOutNotifyState : public UAnimNotifyState
{
    GENERATED_BODY()
public:
    UPROPERTY(Category="GASP", EditAnywhere) EGaspBlendOutCondition Condition = EGaspBlendOutCondition::Always;
    UPROPERTY(Category="GASP", EditAnywhere) float BlendOutTime = .2f;
    UPROPERTY(Category="GASP", EditAnywhere) FName BlendProfile;
    virtual void NotifyTick(USkeletalMeshComponent* Mesh, UAnimSequenceBase* Animation,
        float FrameDeltaTime, const FAnimNotifyEventReference& EventReference) override;
};
