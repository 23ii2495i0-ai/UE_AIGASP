#pragma once
#include "CoreMinimal.h"
#include "Dom/JsonObject.h"
#include "Chooser.h"

// Port of godot/scripts/chooser.gd. Data is exported, never inferred from asset names.
class GASPNATIVE_API FGaspChooser
{
public:
    bool Load(const FString& Filename);
    bool LoadText(const FString& Text);
    void LoadTable(UChooserTable* Table, bool UsesCMC = false) { NativeTable=Table; bUsesCMC=UsesCMC; Document.Reset(); }
    TArray<FSoftObjectPath> Evaluate(const TMap<FString, double>& Context, TMap<FString, double>& Outputs) const;
    bool IsValid() const { return NativeTable.IsValid() || Document.IsValid(); }
    bool UsesCharacterMovementMode() const { return NativeTable.IsValid() ? bUsesCMC : Document && Document->GetBoolField(TEXT("movement_mode_is_cmc")); }
private:
    TWeakObjectPtr<UChooserTable> NativeTable;
    bool bUsesCMC = false;
    TSharedPtr<FJsonObject> Document;
    void EvaluateTable(const FString& Table, const TMap<FString, double>& Context,
        TMap<FString, double>& Outputs, TArray<FSoftObjectPath>& Results, TSet<FString>& Active) const;
};
