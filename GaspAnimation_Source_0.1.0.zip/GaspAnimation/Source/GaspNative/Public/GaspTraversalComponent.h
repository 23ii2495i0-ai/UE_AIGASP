#pragma once
#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"
#include "Engine/HitResult.h"
#include "Components/ActorComponent.h"
#include "GaspChooser.h"
#include "GaspTraversalComponent.generated.h"

class AGaspNativeCharacter;
class UAnimMontage;
UENUM(BlueprintType)
enum class EGaspTraversalAction : uint8 { None, Hurdle, Vault, Mantle };

USTRUCT(BlueprintType)
struct FGaspTraversalResult
{
    GENERATED_BODY()
    UPROPERTY(Category="GASP", BlueprintReadOnly) EGaspTraversalAction Action = EGaspTraversalAction::None;
    UPROPERTY(Category="GASP", BlueprintReadOnly) bool bHasFrontLedge = false;
    UPROPERTY(Category="GASP", BlueprintReadOnly) bool bHasBackLedge = false;
    UPROPERTY(Category="GASP", BlueprintReadOnly) bool bHasBackFloor = false;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector FrontLedge = FVector::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector FrontNormal = FVector::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector BackLedge = FVector::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector BackNormal = FVector::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector BackFloor = FVector::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadOnly) float ObstacleHeight = 0;
    UPROPERTY(Category="GASP", BlueprintReadOnly) float ObstacleDepth = 0;
    UPROPERTY(Category="GASP", BlueprintReadOnly) float BackLedgeHeight = 0;
    UPROPERTY(Category="GASP", BlueprintReadOnly) TObjectPtr<UAnimMontage> Montage;
    UPROPERTY(Category="GASP", BlueprintReadOnly) float StartTime = 0;
    UPROPERTY(Category="GASP", BlueprintReadOnly) float PlayRate = 1;
    UPROPERTY(Category="GASP", BlueprintReadOnly) TObjectPtr<UPrimitiveComponent> HitComponent;
};

UCLASS(ClassGroup=Animation, meta=(BlueprintSpawnableComponent))
class GASPNATIVE_API UGaspTraversalComponent : public UActorComponent
{
    GENERATED_BODY()
public:
    UGaspTraversalComponent();
    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type Reason) override;
    UFUNCTION(Category="GASP", BlueprintCallable) bool TryTraversal();
    UPROPERTY(Category="GASP", BlueprintReadOnly) bool bDoingTraversal = false;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FGaspTraversalResult LastResult;
private:
    FGaspChooser Chooser;
    TWeakObjectPtr<class UGaspAnimationSet> LoadedSet;
    UPROPERTY() TArray<TObjectPtr<UObject>> MontageAssets;
    TWeakObjectPtr<AActor> IgnoredActor;
    bool bAddedIgnore = false;
    uint32 Generation = 0;
    bool Trace(FHitResult& Hit, const FVector& Start, const FVector& End, float Radius, float HalfHeight, ECollisionChannel Channel) const;
    void FinishTraversal(uint32 ExpectedGeneration);
    void RestoreCollision();
    void UpdateWarpTargets(const FGaspTraversalResult& Result);
};
