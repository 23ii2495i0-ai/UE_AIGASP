#pragma once
#include "GaspNativeAnimInstance.h"
#include "GaspCppAnimInstance.generated.h"

// Native base with a C++ proxy; Blueprint children inherit the same proxy implementation.
UCLASS(Transient, Blueprintable)
class GASPNATIVE_API UGaspCppAnimInstance : public UGaspNativeAnimInstance
{
    GENERATED_BODY()
public:
    virtual FAnimInstanceProxy* CreateAnimInstanceProxy() override;
    virtual void DestroyAnimInstanceProxy(FAnimInstanceProxy* Proxy) override;
protected:
    virtual void EnumerateGraphNodes(TArray<FGaspGraphNode>& Nodes) override;
    virtual bool HasMotionGraph() const override;
    virtual void SubmitDatabases(const TArray<UPoseSearchDatabase*>& Databases, EPoseSearchInterruptMode Mode) override;
    virtual FPoseSearchBlueprintResult ReadMotionResult() const override;
};
