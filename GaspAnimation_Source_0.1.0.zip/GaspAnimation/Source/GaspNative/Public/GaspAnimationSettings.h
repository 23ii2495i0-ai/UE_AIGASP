#pragma once
#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "GaspAnimationSettings.generated.h"

class UGaspAnimationSet;

UCLASS(Config=Game, DefaultConfig, meta=(DisplayName="GASP Animation"))
class GASPNATIVE_API UGaspAnimationSettings : public UDeveloperSettings
{
    GENERATED_BODY()
public:
    virtual FName GetCategoryName() const override { return TEXT("Plugins"); }
    UPROPERTY(Config, EditAnywhere, Category="Runtime") TSoftObjectPtr<UGaspAnimationSet> DefaultAnimationSet;
    UPROPERTY(Config, EditAnywhere, Category="AI", meta=(ToolTip="Python interpreter with your training/inference dependencies. Empty uses the engine Python for authoring scripts.")) FString PythonExecutable;
    UPROPERTY(Config, EditAnywhere, Category="AI", meta=(ToolTip="External workspace for models, datasets, checkpoints and logs. Kept outside the distributable plugin.")) FDirectoryPath AIWorkspace;
    UPROPERTY(Config, EditAnywhere, Category="AI") FString ModelServiceEndpoint=TEXT("http://127.0.0.1:8765/generate");
    UPROPERTY(Config, EditAnywhere, Category="AI") bool bEnableAIByDefault=false;
};
