#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "GaspFoleyNotify.generated.h"
class USoundBase;

// Same fallback used by the sample when no AC_FoleyEvents component is present.
UCLASS(NotBlueprintable)
class GASPNATIVE_API UGaspFoleyNotify : public UAnimNotify
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, Category="Foley") TObjectPtr<USoundBase> Sound;
    UPROPERTY(EditAnywhere, Category="Foley") float VolumeMultiplier = 1;
    UPROPERTY(EditAnywhere, Category="Foley") float PitchMultiplier = 1;
    UPROPERTY(EditAnywhere, Category="Foley") FString DisplayName;
    virtual FString GetNotifyName_Implementation() const override { return DisplayName; }
    virtual void Notify(USkeletalMeshComponent* Mesh, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& Reference) override;
};

UCLASS(NotBlueprintable)
class GASPNATIVE_API UGaspEarlyTransitionNotify : public UAnimNotifyState
{
    GENERATED_BODY()
public:
    UPROPERTY(EditAnywhere, Category="Transition") bool bAlways = false;
    UPROPERTY(EditAnywhere, Category="Transition") bool bToLoop = false;
    UPROPERTY(EditAnywhere, Category="Transition") uint8 GaitNotEqual = 0;
    virtual void NotifyTick(USkeletalMeshComponent* Mesh, UAnimSequenceBase* Animation, float DeltaTime, const FAnimNotifyEventReference& Reference) override;
};
