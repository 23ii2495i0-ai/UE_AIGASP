#pragma once
#include "CoreMinimal.h"
#include "Animation/AnimNodeBase.h"
#include "Animation/AnimNodeSpaceConversions.h"
#include "BoneControllers/AnimNode_OrientationWarping.h"
#include "BoneControllers/AnimNode_ModifyBone.h"
#include "BoneControllers/AnimNode_Steering.h"
#include "AnimNode_GaspSampleWarp.generated.h"

// Each BlendStack sample owns its warping state, as in the UE 5.5 sample graph.
USTRUCT(BlueprintInternalUseOnly)
struct GASPNATIVE_API FAnimNode_GaspSampleWarp : public FAnimNode_Base
{
    GENERATED_BODY()
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=Links, meta=(DisplayPriority=0)) FPoseLink Source;
    virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
    virtual void CacheBones_AnyThread(const FAnimationCacheBonesContext& Context) override;
    virtual void Update_AnyThread(const FAnimationUpdateContext& Context) override;
    virtual void Evaluate_AnyThread(FPoseContext& Output) override;
    virtual void GatherDebugData(FNodeDebugData& DebugData) override;
private:
    bool bPassThrough = false;
    UPROPERTY() FAnimNode_ConvertLocalToComponentSpace ToComponent;
    UPROPERTY() FAnimNode_OrientationWarping Orientation;
    UPROPERTY() FAnimNode_ModifyBone ResetRoot;
    UPROPERTY() FAnimNode_Steering Steering;
    UPROPERTY() FAnimNode_Steering TurnSteering;
    UPROPERTY() FAnimNode_ConvertComponentToLocalSpace ToLocal;
};
