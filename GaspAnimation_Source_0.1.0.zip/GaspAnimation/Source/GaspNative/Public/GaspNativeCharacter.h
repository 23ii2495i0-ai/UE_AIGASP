#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GaspNativeCharacter.generated.h"

class UAnimInstance;

class UMotionWarpingComponent;
class USpringArmComponent;
class UCameraComponent;
class UGaspTraversalComponent;
class UGaspAnimationSet;
class UGaspActionFlowComponent;
class UGaspBehaviorComponent;

UENUM(BlueprintType)
enum class EGaspGait : uint8 { Walk, Run, Sprint };

UCLASS()
class GASPNATIVE_API AGaspNativeCharacter : public ACharacter
{
    GENERATED_BODY()
public:
    AGaspNativeCharacter();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void SetupPlayerInputComponent(UInputComponent* Input) override;
    virtual void Landed(const FHitResult& Hit) override;
    virtual void OnJumped_Implementation() override;
    virtual float TakeDamage(float DamageAmount,const FDamageEvent& DamageEvent,AController* EventInstigator,AActor* DamageCauser) override;
    UPROPERTY(Category="GASP", VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UMotionWarpingComponent> MotionWarping;
    UPROPERTY(Category="GASP", VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UGaspTraversalComponent> Traversal;
    UPROPERTY(Category="GASP", VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UGaspActionFlowComponent> ActionFlow;
    UPROPERTY(Category="GASP", VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UGaspBehaviorComponent> Behavior;
    UPROPERTY(Category="GASP", VisibleAnywhere, BlueprintReadOnly) TObjectPtr<USpringArmComponent> CameraBoom;
    UPROPERTY(Category="GASP", VisibleAnywhere, BlueprintReadOnly) TObjectPtr<UCameraComponent> Camera;
    UPROPERTY(Category="GASP", BlueprintReadOnly) EGaspGait Gait = EGaspGait::Run;
    // Axis input before movement locking/consumption, for reviewed behavior conditions.
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector2D RawMoveInput=FVector2D::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadWrite) bool bWantsToSprint = false;
    UPROPERTY(Category="GASP", BlueprintReadWrite) bool bWantsToWalk = false;
    UPROPERTY(Category="GASP", BlueprintReadWrite) bool bWantsToStrafe = true;
    UPROPERTY(Category="GASP", BlueprintReadWrite) bool bWantsToAim = false;
    UPROPERTY(Category="GASP", BlueprintReadOnly) FVector LandVelocity = FVector::ZeroVector;
    UPROPERTY(Category="GASP", BlueprintReadOnly) float JustLandedTime = 0.f;
    UPROPERTY(Category="GASP", EditDefaultsOnly) TSoftClassPtr<UAnimInstance> AnimationClass;
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="GASP") TObjectPtr<UGaspAnimationSet> AnimationSetOverride;
    UFUNCTION(BlueprintCallable, Category="GASP") bool ApplyAnimationSet(UGaspAnimationSet* Resources);
    float DirectionalSpeed(const FVector& Speeds) const;
    bool CanSprint() const;
    bool IsAimAllowed() const;
private:
    bool bJumpHeld = false;
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);
    void JumpPressed();
    void JumpReleased();
    void SprintPressed();
    void SprintReleased();
    void WalkPressed();
    void CrouchPressed();
    void AimPressed();
    void AimReleased();
    void AttackPressed();
    void HitPressed();
    void DodgePressed();
    void StrafePressed();
};

