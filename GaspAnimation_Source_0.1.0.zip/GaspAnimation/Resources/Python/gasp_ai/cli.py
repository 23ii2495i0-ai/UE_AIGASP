import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from .config import load_config
from .contracts import Task
from .paths import configure_legacy
from .registry import create_provider, create_trainer


def initialize(args):
    workspace = args.workspace.resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    path = workspace / "gasp_ai.json"
    if path.exists():
        raise FileExistsError(f"Config already exists: {path}")
    deployment = json.loads(args.deployment.read_text(encoding="utf-8-sig")) if args.deployment else {}
    base = Path(deployment.get("base", workspace / "models/base"))
    run = Path(deployment.get("run", workspace / "models/adapters"))
    dataset_root = args.dataset_root.resolve() if args.dataset_root else workspace / "datasets"
    config = {"version": 1, "workspace": str(workspace)}
    if args.deployment:
        config["deployment"] = str(args.deployment.resolve())
    for task in Task:
        config[task.value] = {
            "task": task.value, "provider": "builtin", "base_model": str(base),
            "adapter": str(run / task.value / "adapter"),
            "output_dir": str(workspace / "training" / task.value), "trainer": "lora_sft",
            "datasets": {split: str(dataset_root / task.value / (split + ".jsonl")) for split in ("train", "validation", "test")},
            "options": {"stages": [task.value], "max_new_tokens": 512}, "training": {"steps": 2000},
        }
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"config": str(path), "generator": "resource-free classification/configuration planning", "selector": "catalog-bound resource selection"}


def main(argv=None):
    parser = argparse.ArgumentParser(description="GASP AI: independent generator and selector interfaces")
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init");init.add_argument("--workspace", type=Path, required=True);init.add_argument("--deployment", type=Path);init.add_argument("--dataset-root", type=Path)
    for name in ("doctor", "check", "train", "infer", "serve"):
        item = commands.add_parser(name);item.add_argument("--config", type=Path, required=True)
        if name in ("check", "train", "infer"):
            item.add_argument("--task", choices=[task.value for task in Task], required=True)
        if name == "train":item.add_argument("--dry-run", action="store_true")
        if name == "infer":
            item.add_argument("--request", required=True);item.add_argument("--catalog", type=Path);item.add_argument("--configuration", type=Path);item.add_argument("--output", type=Path)
        if name == "serve":item.add_argument("--port", type=int, default=8767)
    args = parser.parse_args(argv)
    if args.command == "init":
        result = initialize(args)
    else:
        config, specs = load_config(args.config)
        workspace = Path(config.get("workspace", args.config.resolve().parent))
        if not workspace.is_absolute():workspace = args.config.resolve().parent / workspace
        os.environ["GASP_AI_WORKSPACE"] = str(workspace.resolve())
        if args.command == "doctor":
            result = {"python": sys.executable, "workspace": str(workspace), "models": {
                task.value: {"provider": spec.provider, "base_exists": (spec.base_model / "config.json").is_file(),
                "adapter_exists": (spec.adapter / "adapter_model.safetensors").is_file(),
                "datasets": {key: value.is_file() for key, value in spec.datasets.items()}, "output": str(spec.output_dir)} for task, spec in specs.items()},
                "dependencies": {name: importlib.util.find_spec(name) is not None for name in ("torch", "transformers", "peft", "accelerate")}}
        elif args.command in ("check", "train"):
            spec = specs[Task(args.task)]
            result = create_trainer(spec).train(spec, dry_run=getattr(args, "dry_run", False), check_only=args.command == "check")
        elif args.command == "infer":
            configure_legacy()
            from split_protocol import generator_messages, selector_messages, validate_generator, merge
            spec = specs[Task(args.task)]
            catalog = json.loads(args.catalog.read_text(encoding="utf-8-sig")) if args.catalog else None
            configuration = json.loads(args.configuration.read_text(encoding="utf-8-sig")) if args.configuration else None
            if isinstance(configuration, dict) and configuration.get("task") == "generator" and "prediction" in configuration:
                configuration = configuration["prediction"]
            if spec.task == Task.SELECTOR and (catalog is None or configuration is None):
                raise ValueError("Selector inference requires --catalog and the immutable generator --configuration")
            provider = create_provider(spec)
            runtime = None
            if provider is None:
                from .runtime import create_builtin_runtime
                runtime = create_builtin_runtime(args.config)
                prompt_version = runtime.generator_prompt_version
            else:
                prompt_config = spec.adapter / "prompt_config.json"
                metadata = json.loads(prompt_config.read_text(encoding="utf-8")) if prompt_config.is_file() else {}
                prompt_version = int(spec.options.get("prompt_version", metadata.get("prompt_version", 1)))
            messages = generator_messages(args.request, prompt_version) if spec.task == Task.GENERATOR else selector_messages(catalog, args.request, configuration)
            if runtime is not None:
                prediction = runtime.predict(args.task, messages)
            else:
                from .runtime import provider_batch
                prediction = json.loads(provider_batch(provider, args.task, [messages])[0])
            if spec.task == Task.GENERATOR:validate_generator(prediction)
            else:merge(catalog, configuration, prediction)
            result = {"task": args.task, "prediction": prediction, "requires_human_review": True}
            if args.output:
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        else:
            if not 1 <= args.port <= 65535:raise ValueError("Invalid service port")
            if not config.get("deployment"):raise ValueError("The compatibility pipeline service requires an evaluated deployment manifest")
            deployment = Path(config["deployment"])
            if not deployment.is_absolute():deployment = args.config.resolve().parent / deployment
            backend = configure_legacy()
            subprocess.run([sys.executable, str(backend / "ai/configuration/runtime/serve_split.py"), "--deployment", str(deployment), "--providers-config", str(args.config.resolve()), "--port", str(args.port)], check=True)
            return
    print(json.dumps(result, ensure_ascii=False, indent=2))
