from importlib import import_module, metadata
from .contracts import Task

_providers = {task: {} for task in Task}
_trainers = {}


def register_provider(task: Task | str, name: str, factory):
    _providers[Task(task)][name] = factory


def register_trainer(name: str, factory):
    _trainers[name] = factory


def _find(name, registry, group):
    if name in registry:
        return registry[name]
    if ":" in name:
        module, attribute = name.split(":", 1)
        return getattr(import_module(module), attribute)
    matches = list(metadata.entry_points(group=group, name=name))
    if len(matches) != 1:
        raise ValueError(f"Unknown or ambiguous extension {group}:{name}")
    return matches[0].load()


def create_provider(spec):
    if spec.provider == "huggingface_lora":
        from .providers import HuggingFaceLoRA
        return HuggingFaceLoRA(spec)
    if spec.provider == "builtin":
        return None
    factory = _find(spec.provider, _providers[spec.task], f"gasp_ai.{spec.task.value}_providers")
    provider = factory(spec)
    if not callable(getattr(provider, "predict_batch", None)):
        raise TypeError("Provider must implement predict_batch(messages, *, stage)")
    return provider


def create_trainer(spec):
    if spec.trainer == "lora_sft":
        from .training import LoRASFTTrainer
        return LoRASFTTrainer()
    return _find(spec.trainer, _trainers, "gasp_ai.trainers")(spec)
