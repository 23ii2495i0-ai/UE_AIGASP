from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Protocol, Sequence


class Task(str, Enum):
    GENERATOR = "generator"
    SELECTOR = "selector"


@dataclass(frozen=True)
class ModelSpec:
    task: Task
    provider: str
    base_model: Path
    adapter: Path
    output_dir: Path
    datasets: dict[str, Path] = field(default_factory=dict)
    options: dict[str, Any] = field(default_factory=dict)
    training: dict[str, Any] = field(default_factory=dict)
    trainer: str = "lora_sft"


class Predictor(Protocol):
    def predict_batch(self, messages: Sequence[list[dict]], *, stage: str) -> Sequence[str | dict]: ...


class Trainer(Protocol):
    def train(self, spec: ModelSpec, *, dry_run: bool = False, check_only: bool = False) -> dict: ...
