import json
import os
from pathlib import Path
from .config import load_config
from .contracts import Task
from .paths import configure_legacy
from .registry import create_provider


def attach_runtime(runtime, config_path):
    _, specs = load_config(config_path)
    overrides = {}
    for task, spec in specs.items():
        provider = create_provider(spec)
        if provider is None:
            continue
        stages = spec.options.get("stages", [task.value])
        allowed = {"generator", "behavior"} if task == Task.GENERATOR else {"selector"}
        if not set(stages) <= allowed:
            raise ValueError(f"Provider stages cross generator/selector boundary: {stages}")
        for stage in stages:
            overrides[stage] = provider
    runtime.task_providers = overrides
    return {task.value: spec.provider for task, spec in specs.items()}


def provider_batch(provider, stage, messages):
    result = list(provider.predict_batch(messages, stage=stage))
    if len(result) != len(messages):
        raise ValueError("Provider returned a different batch size")
    return [json.dumps(value, ensure_ascii=False) if isinstance(value, dict) else str(value) for value in result]


def create_builtin_runtime(config_path):
    config, specs = load_config(config_path)
    workspace = Path(config.get("workspace", Path(config_path).resolve().parent))
    if not workspace.is_absolute():
        workspace = Path(config_path).resolve().parent / workspace
    os.environ["GASP_AI_WORKSPACE"] = str(workspace.resolve())
    generator, selector = specs[Task.GENERATOR], specs[Task.SELECTOR]
    if generator.base_model != selector.base_model:
        raise ValueError("The legacy shared-base backend requires the same base; select independent huggingface_lora providers for distinct bases")
    configure_legacy()
    from split_runtime import SplitRuntime
    runtime = SplitRuntime(generator.base_model, generator.adapter, selector.adapter)
    attach_runtime(runtime, config_path)
    return runtime
