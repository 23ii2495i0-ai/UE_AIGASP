"""Optional independent model backend; heavyweight imports occur only on first prediction."""
class HuggingFaceLoRA:
    def __init__(self, spec):
        self.spec = spec
        self.model = self.tokenizer = None

    def predict_batch(self, messages, *, stage):
        import torch
        if self.model is None:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            from peft import PeftModel
            device = self.spec.options.get("device", "cuda" if torch.cuda.is_available() else "cpu")
            dtype = torch.bfloat16 if device.startswith("cuda") else torch.float32
            self.tokenizer = AutoTokenizer.from_pretrained(self.spec.base_model, local_files_only=True, trust_remote_code=False)
            base = AutoModelForCausalLM.from_pretrained(self.spec.base_model, local_files_only=True, trust_remote_code=False, torch_dtype=dtype)
            self.model = PeftModel.from_pretrained(base, self.spec.adapter).to(device).eval()
        result = []
        for conversation in messages:
            encoded = self.tokenizer.apply_chat_template(conversation, add_generation_prompt=True, return_tensors="pt").to(self.model.device)
            with torch.inference_mode():
                output = self.model.generate(encoded, attention_mask=torch.ones_like(encoded), do_sample=False,
                    max_new_tokens=int(self.spec.options.get("max_new_tokens", 512)), pad_token_id=self.tokenizer.eos_token_id)
            result.append(self.tokenizer.decode(output[0, encoded.shape[-1]:], skip_special_tokens=True))
        return result
