import json
from pathlib import Path
from .contracts import ModelSpec, Task


def load_config(path: str | Path) -> tuple[dict, dict[Task, ModelSpec]]:
    path = Path(path).resolve()
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if data.get("version") != 1:
        raise ValueError("Unsupported AI interface config version")
    def resolve(value):
        result = Path(value).expanduser()
        return result.resolve() if result.is_absolute() else (path.parent / result).resolve()
    specs = {}
    for task in Task:
        item = data.get(task.value)
        if not isinstance(item, dict) or item.get("task", task.value) != task.value:
            raise ValueError(f"Missing or mismatched {task.value} model configuration")
        specs[task] = ModelSpec(task, item.get("provider", "builtin"), resolve(item["base_model"]),
            resolve(item["adapter"]), resolve(item["output_dir"]),
            {name: resolve(value) for name, value in item.get("datasets", {}).items()},
            item.get("options", {}), item.get("training", {}), item.get("trainer", "lora_sft"))
    if specs[Task.GENERATOR].output_dir == specs[Task.SELECTOR].output_dir:
        raise ValueError("Generator and selector must have independent training output directories")
    if specs[Task.GENERATOR].adapter == specs[Task.SELECTOR].adapter:
        raise ValueError("Generator and selector adapters must be explicitly separate")
    return data, specs
