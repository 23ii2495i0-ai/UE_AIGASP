import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from .paths import configure_legacy


def legacy_trainer():
    path = configure_legacy() / "ai/configuration/training/model_train.py"
    module_spec = importlib.util.spec_from_file_location("gasp_legacy_model_train", path)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    return path, module


class LoRASFTTrainer:
    def plan(self, spec):
        script, module = legacy_trainer()
        if not {"train", "validation", "test"} <= set(spec.datasets):
            raise ValueError(f"{spec.task.value}: train, validation and test datasets are required")
        for path in spec.datasets.values():
            if not path.is_file():
                raise FileNotFoundError(path)
        config = copy.deepcopy(module.SETTINGS)
        unknown = set(spec.training) - set(config)
        if unknown:
            raise ValueError(f"Unknown training options: {sorted(unknown)}")
        config.update(spec.training)
        config.update(task=spec.task.value, base_model=str(spec.base_model), output_dir=str(spec.output_dir), output_is_task_directory=True)
        config["tasks"] = {spec.task.value: {key: str(value) for key, value in spec.datasets.items()}}
        # The same protocol validation used by actual training runs, with no GPU/model load.
        prepared = module.prepare(config, spec.task.value)
        return script, config, {key: len(value) for key, value in prepared.items()}

    def train(self, spec, *, dry_run=False, check_only=False):
        script, config, counts = self.plan(spec)
        plans = spec.output_dir.parent / "training_plans"
        plans.mkdir(parents=True, exist_ok=True)
        path = plans / f"{spec.task.value}.json"
        path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        command = [sys.executable, str(script), "--config", str(path), "--task", spec.task.value]
        if check_only:
            command.append("--check")
        report = {"task": spec.task.value, "command": command, "output_dir": str(spec.output_dir), "datasets": counts, "dry_run": dry_run}
        if not dry_run:
            env = dict(os.environ, GASP_AI_USE_CURRENT_PYTHON="1")
            subprocess.run(command, check=True, env=env)
        return report
