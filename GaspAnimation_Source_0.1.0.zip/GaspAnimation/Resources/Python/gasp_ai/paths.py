import os
import sys
from pathlib import Path


def backend_dir() -> Path:
    explicit = os.environ.get("GASP_AI_BACKEND")
    path = Path(explicit) if explicit else Path(__file__).resolve().parents[1] / "anim_config"
    if not (path / "ai/project_paths.py").is_file():
        raise FileNotFoundError(f"AI backend not found: {path}; install from the plugin Resources/Python directory")
    return path


def configure_legacy() -> Path:
    backend = backend_dir()
    for path in (backend, backend / "ai"):
        if str(path) not in sys.path:
            sys.path.insert(0, str(path))
    from project_paths import configure_imports
    configure_imports()
    return backend
