"""Versioned, data-only behavior graph. No generated code is executed.

v2 adds hierarchical groups, bounded expression trees, and explicit local actions.
A successful validation is structural validation, not proof of requested behavior.
"""
import math,re
import json

BUILTINS={'speed','falling','crouched','state_time','finished','interrupted'}
BUILTINS_V3=BUILTINS|{'vertical_speed','move_input','gait','animation_phase'}
PLAYERS={'locomotion','mm','sequence','montage','group'}
OPS={'eq','ne','lt','le','gt','ge'}
ROLES={'idle','walk','run','sprint','crouch','crouch_idle','crouch_move','jump','jump_start','jump_fall','jump_land','jump_land_run'}
IDENT=re.compile(r'^[A-Za-z_][A-Za-z0-9_]{0,63}$')
MAX_DEPTH=8
MAX_CONDITION_NODES=128


def _scalar(value):
    return type(value) in (int,float,bool) and math.isfinite(value) and abs(value)<=3.4028234663852886e38


def _id(value):
    return isinstance(value,str) and value.lower()!='none' and bool(IDENT.fullmatch(value))


def _validate_graph(graph,catalog,mesh,roles=()):
    errors=[]
    def check(ok,message):
        if not ok:errors.append('状态机：'+message)
        return ok
    if not isinstance(graph,dict):return ['状态机必须为对象']
    version=graph.get('version')
    v3=type(version) is int and version==3
    fields={'version','entry','variables','inputs','states','transitions'}|({'handlers','variable_sources'} if v3 else set())
    check(set(graph)==fields,'状态图字段不符合协议版本')
    check(type(version) is int and version in (1,2,3),'版本必须为1、2或3')
    v2=type(version) is int and version>=2
    builtins=BUILTINS_V3 if v3 else BUILTINS
    variables=graph.get('variables');states=graph.get('states');edges=graph.get('transitions');inputs=graph.get('inputs')
    if not isinstance(variables,dict) or not isinstance(states,list) or not isinstance(edges,list) or not isinstance(inputs,list):return errors+['状态机数组或变量格式无效']
    check(len(variables)<=64 and 1<=len(states)<=32 and len(edges)<=128 and len(inputs)<=64,'超过变量/状态/连接/输入数量限制')
    for k,v in variables.items():check(_id(k) and k.lower() not in builtins and _scalar(v),'无效或保留变量名/值：'+str(k))
    if v3:
        sources=graph.get('variable_sources')
        if check(isinstance(sources,dict) and set(sources)==set(variables),'variable_sources必须覆盖全部变量'):
            for name,source in sources.items():
                check(isinstance(source,dict) and set(source)=={'scope','source'} and source.get('scope') in ('internal','external') and isinstance(source.get('source'),str) and bool(source['source'].strip()),'变量必须明确内部/外部及接入来源：'+name)
    check(len({str(k).lower() for k in variables})==len(variables),'变量名大小写冲突')
    assets={a['id']:a for a in catalog.get('assets',[]) if isinstance(a,dict) and isinstance(a.get('id'),str)}
    skeleton=assets.get(mesh,{}).get('skeleton')
    def actions(value,context):
        if not check(isinstance(value,list) and len(value)<=32,context+'动作须为最多32项数组'):return
        for action in value:
            if not check(isinstance(action,dict),context+'动作必须为对象'):continue
            op=action.get('op')
            if op in ('set','add'):
                check(set(action)=={'op','var','value'} and action.get('var') in variables and _scalar(action.get('value')),context+'赋值/累加动作需声明变量与有限数值')
            elif op=='jump':
                value=action.get('velocity')
                check(set(action)=={'op','velocity'} and type(value) in (int,float) and math.isfinite(value) and 1<=value<=2000,context+'jump需要1..2000的起跳速度')
            else:check(False,context+'未知动作：'+str(op))
    def predicate(value):
        return (isinstance(value,dict) and set(value)=={'var','op','value'} and
                isinstance(value.get('var'),str) and value['var'] in builtins|set(variables) and
                isinstance(value.get('op'),str) and value['op'] in OPS and _scalar(value.get('value')))
    def condition(value,depth=1,budget=None):
        if budget is None:budget=[0]
        budget[0]+=1
        if not check(depth<=MAX_DEPTH and budget[0]<=MAX_CONDITION_NODES,'condition超过8层或128节点限制'):return
        if not check(isinstance(value,dict),'condition必须为对象'):return
        if set(value)=={'all'} or set(value)=={'any'}:
            children=next(iter(value.values()))
            if check(isinstance(children,list) and 1<=len(children)<=MAX_CONDITION_NODES,'condition all/any必须为非空数组'):
                for child in children:condition(child,depth+1,budget)
        elif set(value)=={'not'}:condition(value['not'],depth+1,budget)
        else:check(predicate(value),'condition叶子必须引用已声明变量或内置变量')
    names=[];by_name={}
    for state in states:
        if not check(isinstance(state,dict),'状态必须为对象'):continue
        base={'id','player','resources','database_role','loop','allow_movement','lock_until_finished','min_duration','blend_seconds'}
        extensions={'parent','initial','on_entry','on_exit','on_complete'} if v2 else set()
        check(set(state)<=base|extensions,'未知状态字段或v1使用了v2字段')
        name=state.get('id');valid_id=check(_id(name),'状态ID只支持英文、数字、下划线')
        if valid_id:names.append(name);by_name[name]=state
        mode=state.get('player');check(isinstance(mode,str) and mode in (PLAYERS if v2 else PLAYERS-{'group'}),'未知播放器：'+str(mode))
        for key in ('loop','allow_movement','lock_until_finished'):check(type(state.get(key)) is bool,'状态需显式设置布尔字段 '+key)
        for key,maximum in [('min_duration',60),('blend_seconds',2)]:
            value=state.get(key);check(type(value) in (int,float) and math.isfinite(value) and 0<=value<=maximum,'无效状态时间 '+key)
        paths=state.get('resources');role=state.get('database_role','')
        check(isinstance(role,str),'database_role必须为字符串')
        if not check(isinstance(paths,list) and len(paths)<=8 and all(isinstance(p,str) for p in paths),'resources必须为最多8项路径数组'):paths=[]
        check(len(paths)==len(set(paths)),'resources不可重复')
        if mode in ('locomotion','group'):check(not paths and not role,'locomotion/group不直接绑定资源')
        elif mode=='mm':check((isinstance(role,str) and bool(role) and role in roles and not paths) or (not role and 1<=len(paths)<=8),'mm需要有效database_role或1..8个数据库')
        elif mode in ('sequence','montage'):check(len(paths)==1 and not role,'sequence/montage需要且只能绑定一个资源')
        check(not(state.get('loop') and state.get('lock_until_finished')),'循环状态不能锁定至动画结束')
        if mode=='montage':check(not state.get('loop'),'蒙太奇循环暂不支持，请使用循环sequence')
        for path in paths:
            asset=assets.get(path,{})
            expected={'mm':'database','sequence':'sequence','montage':'montage'}.get(mode)
            check(asset.get('kind')==expected and bool(skeleton) and asset.get('skeleton')==skeleton,'资源未选中、类型错误或骨架不匹配：'+path)
            if mode=='sequence':check(not asset.get('additive') and type(asset.get('num_frames',2)) in (int,float) and asset.get('num_frames',2)>1,'独立状态不能播放加性或单帧姿势')
        if mode in ('mm','locomotion','group'):
            check(not state.get('lock_until_finished'),'MM/group没有固定结束事件，不能锁定到结束')
        if v2:
            if 'parent' in state:check(_id(state['parent']),'parent必须为有效组ID')
            if mode=='group':
                check(_id(state.get('initial')),'group需要有效initial子状态ID')
                check(state.get('loop') is False,'group必须loop=false')
            else:check('initial' not in state,'只有group可设置initial')
            for key in ('on_entry','on_exit','on_complete'):
                if key in state:actions(state[key],name or '状态')
            if state.get('on_complete'):
                check(mode in ('sequence','montage') and not state.get('loop'),'只有非循环sequence/montage可使用on_complete')
    check(len(names)==len(set(n.lower() for n in names)),'状态ID重复或大小写冲突')
    entry=graph.get('entry');check(isinstance(entry,str) and entry in by_name,'入口状态不存在')
    # Each parent chain is bounded and only group nodes may own children.
    ancestry={}
    for name,state in by_name.items():
        chain=[];node=name
        while node in by_name:
            if node in chain:check(False,'parent存在循环：'+name);break
            chain.append(node)
            if len(chain)>MAX_DEPTH:check(False,'parent嵌套超过8层：'+name);break
            parent=by_name[node].get('parent')
            if parent is None:break
            if not isinstance(parent,str) or parent not in by_name:check(False,'parent不存在：'+name);break
            check(by_name[parent].get('player')=='group','parent必须指向group：'+name)
            node=parent
        ancestry[name]=set(chain)
        if state.get('player')=='group':
            initial=state.get('initial')
            check(isinstance(initial,str) and initial in by_name and by_name[initial].get('parent')==name,'group.initial必须为直接子状态：'+name)
    for binding in inputs:
        if not check(isinstance(binding,dict),'输入必须为对象'):continue
        expected={'key','phase','event','set'}
        check(expected<=set(binding)<=expected|({'actions'} if v2 else set()),'输入字段必须为key/phase/event/set，可选v2 actions')
        check(_id(binding.get('key')),'输入需UE键名，如RightMouseButton')
        check(binding.get('phase') in ('pressed','released'),'输入阶段必须为pressed/released')
        check(_id(binding.get('event')),'输入事件ID无效')
        sets=binding.get('set')
        if check(isinstance(sets,dict),'输入set必须为变量对象'):
            for key,value in sets.items():check(key in variables and _scalar(value),'输入赋值需引用已声明变量')
        if 'actions' in binding:actions(binding['actions'],'输入')
    bindings=[(str(b.get('key','')).lower(),str(b.get('phase'))) for b in inputs if isinstance(b,dict)]
    check(len(bindings)==len(set(bindings)),'相同按键阶段不能重复绑定')
    if v3:
        handlers=graph.get('handlers')
        if check(isinstance(handlers,list) and len(handlers)<=128,'handlers必须为最多128项数组'):
            for handler in handlers:
                if not check(isinstance(handler,dict) and set(handler)=={'from','event','condition','actions','priority'},'内部事件字段无效'):continue
                check(handler['from'] in by_name or handler['from']=='*','内部事件来源不存在')
                check(_id(handler['event']),'内部事件必须由非空事件触发')
                condition(handler['condition'])
                check(type(handler['priority']) is int and -1000<=handler['priority']<=1000,'内部事件priority无效')
                actions(handler['actions'],'内部事件')
                check(bool(handler['actions']),'内部事件不能没有动作')
    for edge in edges:
        if not check(isinstance(edge,dict),'连接必须为对象'):continue
        expected={'from','to','event','all','priority','interrupt'}
        check(expected<=set(edge)<=expected|({'condition','actions'} if v2 else set()),'连接字段无效或v1使用了v2字段')
        check(isinstance(edge.get('from'),str) and (edge['from'] in by_name or edge['from']=='*'),'连接来源不存在')
        check(isinstance(edge.get('to'),str) and edge['to'] in by_name,'连接目标不存在')
        check(isinstance(edge.get('event'),str) and (not edge['event'] or _id(edge['event'])),'连接事件无效')
        check(type(edge.get('priority')) is int and -1000<=edge['priority']<=1000,'priority范围为-1000..1000')
        check(type(edge.get('interrupt')) is bool,'interrupt必须为布尔值')
        conditions=edge.get('all')
        if check(isinstance(conditions,list) and len(conditions)<=16,'all需为最多16项条件数组'):
            for c in conditions:check(predicate(c),'无效条件或未声明变量')
        check(bool(edge.get('event')) or bool(conditions) or 'condition' in edge,'禁止无事件且无条件的自动连接')
        if 'condition' in edge:condition(edge['condition'])
        if 'actions' in edge:actions(edge['actions'],'连接')
    # Reachability models group entry and inherited outgoing edges; a direct edge
    # to a child also activates its ancestors, but never unrelated siblings.
    reachable={entry} if isinstance(entry,str) and entry in by_name else set()
    for _ in range(len(by_name)+1):
        previous=set(reachable)
        for name in list(reachable):
            reachable.update(ancestry.get(name,()))
            state=by_name.get(name,{})
            if state.get('player')=='group' and isinstance(state.get('initial'),str):reachable.add(state['initial'])
        for edge in edges:
            if isinstance(edge,dict) and isinstance(edge.get('from'),str) and (edge['from'] in reachable or edge['from']=='*') and isinstance(edge.get('to'),str):reachable.add(edge['to'])
        if reachable==previous:break
    unreachable=[name for name in names if name not in reachable]
    check(not unreachable,'存在从入口不可达的状态：'+', '.join(unreachable))
    return errors


def validate_graph(graph,catalog,mesh,roles=()):
    try:return _validate_graph(graph,catalog,mesh,roles)
    except (TypeError,KeyError,AttributeError,ValueError,OverflowError,RecursionError):return ['状态机包含无效字段类型，禁止应用']


def default_graph():
    return dict(version=1,entry='Locomotion',variables={},inputs=[],states=[dict(id='Locomotion',player='locomotion',resources=[],loop=True,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2)],transitions=[])

def explicit_parent_groups(request):
    groups={}
    for match in re.finditer(r'(?<![A-Za-z0-9_])([A-Za-z_][A-Za-z0-9_]*)\s*为父状态[，,]\s*包含\s*([^。\n]+)',request):
        # Only the literal child list belongs here. Initial/entry/MM clauses
        # after it are not additional children (nor is the group its own child).
        tail=match.group(2);children=[];offset=0
        while child:=re.match(r'[A-Za-z_][A-Za-z0-9_]*',tail[offset:]):
            children.append(child[0]);offset+=child.end()
            separator=re.match(r'(?:[ \t]*(?:、|，|,|/|和|与|及|and\b)[ \t]*|[ \t]+)',tail[offset:])
            if not separator:break
            offset+=separator.end()
        if children:groups[match.group(1)]=children
    return groups


def explicit_layout_errors(request,graph):
    """Check explicit named Chinese group declarations, without guessing intent."""
    errors=[]
    states={s.get('id'):s for s in graph.get('states',[]) if isinstance(s,dict)}
    for name,children in explicit_parent_groups(request).items():
        group=states.get(name,{})
        if group.get('player')!='group':errors.append(name+' 必须是 group 父状态')
        for child in children:
            if states.get(child,{}).get('parent')!=name:errors.append(child+' 必须存在并设置 parent='+name)
    return errors


def graph_example_messages(stage='layout'):
    # Small complete demonstrations keep graph grammar separate from animation semantics.
    layout=dict(locomotion_roles=['idle','run'],entry='Travel',variables={'Held':False,'Rounds':0,'bHit':False},inputs=[dict(key='LeftMouseButton',phase='pressed',event='Attack',set={}),dict(key='RightMouseButton',phase='pressed',event='BraceOn',set={'Held':True}),dict(key='RightMouseButton',phase='released',event='BraceOff',set={'Held':False})],states=[dict(id='Travel',player='locomotion',resources=[],loop=True,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2),dict(id='Combat',player='group',resources=[],initial='Strike',loop=False,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2,on_entry=[dict(op='set',var='Rounds',value=0)]),dict(id='Strike',parent='Combat',player='sequence',resources=['sample_strike'],loop=False,allow_movement=False,lock_until_finished=True,min_duration=0,blend_seconds=.2,on_complete=[dict(op='add',var='Rounds',value=1)]),dict(id='Finish',parent='Combat',player='sequence',resources=['sample_finish'],loop=False,allow_movement=False,lock_until_finished=True,min_duration=0,blend_seconds=.2)])
    if stage=='layout':
        request='只提取状态、变量、按键，不输出连接。移动idle/run。入口Travel使用MM。Combat组默认Strike，进入组Rounds清零。Strike播放sample_strike，不循环禁止移动锁定结束，完成Rounds加1；Finish播放sample_finish，不循环禁止移动锁定结束。变量Held和外部bHit初始false。左键Attack；右键按下Held=true并BraceOn，松开Held=false并BraceOff。'
        output=layout
    else:
        request='只输出Strike的出边。Strike自然结束，若Rounds>=2或bHit=true进入Finish，否则重复Strike。同时必须finished=true。这是自动条件边，无按键事件。'
        def edge(to,tree):return dict({'from':'Strike','to':to,'event':'','all':[dict(var='finished',op='eq',value=True)],'condition':tree,'priority':0,'interrupt':False})
        advance={'any':[dict(var='Rounds',op='ge',value=2),dict(var='bHit',op='eq',value=True)]}
        output={'transitions':[edge('Finish',advance),edge('Strike',{'not':advance})]}
    return [{'role':'user','content':request},{'role':'assistant','content':json.dumps(output,separators=(',',':'))}]


def layout_format_example():
    """A format-only demonstration without unrelated gameplay logic."""
    state=dict(id='Rest',player='locomotion',resources=[],loop=True,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2)
    return [dict(role='user',content='Layout only. One locomotion state Rest, entry Rest. Idle MM category. No variables, no inputs, no actions.'),dict(role='assistant',content=json.dumps(dict(locomotion_roles=['idle'],entry='Rest',variables={},inputs=[],states=[state]),separators=(',',':')))]


def generation_schema(aliases,stage='full',state_ids=None,variable_names=None,source=None,version=2):
    def obj(props,required=None):return dict(type='object',properties=props,required=list(props) if required is None else required,additionalProperties=False)
    def array(item,maximum=64,minimum=0):return dict(type='array',items=item,maxItems=maximum,minItems=minimum)
    def enum(values):return dict(type='string',enum=list(values))
    ident=dict(type='string',pattern='^[A-Za-z_][A-Za-z0-9_]{0,63}$')
    scalar=dict(anyOf=[dict(type='number'),dict(type='boolean')])
    variables=dict(type='object',additionalProperties=scalar)
    writable=enum(variable_names) if variable_names else ident
    readable=enum(sorted((BUILTINS_V3 if version==3 else BUILTINS)|set(variable_names))) if variable_names is not None else ident
    predicate=obj(dict(var=readable,op=enum(sorted(OPS)),value=scalar))
    action=dict(anyOf=[obj(dict(op=enum(['set','add']),var=writable,value=scalar)),obj(dict(op=enum(['jump']),velocity=dict(type='number',minimum=1,maximum=2000)))])
    action_array=array(action,32)
    state_props=dict(id=ident,player=enum(sorted(PLAYERS)),resources=array(enum(aliases),8),database_role=enum(['']+sorted(ROLES)),loop=dict(type='boolean'),allow_movement=dict(type='boolean'),lock_until_finished=dict(type='boolean'),min_duration=dict(type='number',minimum=0,maximum=60),blend_seconds=dict(type='number',minimum=0,maximum=2),parent=ident,initial=ident,on_entry=action_array,on_exit=action_array,on_complete=action_array)
    required_state=['id','player','resources','loop','allow_movement','lock_until_finished','min_duration','blend_seconds']
    leaf_props={k:v for k,v in state_props.items() if k!='initial'}
    leaf_props['player']=enum(sorted(PLAYERS-{'group'}))
    group_props={k:v for k,v in state_props.items() if k!='on_complete'}
    # lm-format-enforcer 0.11.3 serializes boolean enums as Python False/True.
    # Keep JSON booleans in the grammar; semantic validation enforces false.
    group_props.update(player=enum(['group']),resources=array(enum(aliases),0),database_role=enum(['']))
    state={'anyOf':[obj(leaf_props,required=required_state),obj(group_props,required=required_state+['initial'])]}
    binding=obj(dict(key=ident,phase=enum(['pressed','released']),event=ident,set=variables,actions=action_array),required=['key','phase','event','set'])
    condition={'$ref':'#/$defs/condition'}
    defs={'condition':dict(anyOf=[predicate,obj({'all':array(condition,128,1)}),obj({'any':array(condition,128,1)}),obj({'not':condition})])}
    edge_props={'from':enum([source]) if source else enum(list(state_ids)+['*']) if state_ids else dict(type='string'),'to':enum(state_ids) if state_ids else ident,'event':dict(type='string'), 'all':array(predicate,16),'priority':dict(type='integer',minimum=-1000,maximum=1000),'interrupt':dict(type='boolean'),'condition':condition,'actions':action_array}
    edge=obj(edge_props,required=['from','to','event','all','priority','interrupt'])
    layout_props=dict(locomotion_roles=array(enum(['idle','walk','run','sprint','crouch','jump']),6,1),entry=ident,variables=variables,inputs=array(binding),states=array(state,32,1))
    if stage=='layout':return obj(layout_props)
    if stage=='transitions':return dict(obj(dict(transitions=array(edge,128))),**{'$defs':defs})
    graph=obj(dict(version=dict(type='integer',enum=[2]),entry=ident,variables=variables,inputs=array(binding),states=array(state,32,1),transitions=array(edge,128)))
    return dict(obj(dict(locomotion_roles=layout_props['locomotion_roles'],graph=graph)),**{'$defs':defs})


GRAPH_SYSTEM='''You generate a reviewed DATA-ONLY Unreal behavior state machine, protocol version 2. No Python/code. Output only JSON required by the current stage. Carefully follow the user's exact state names, counts, keys, conditions and resource names; never invent extra transitions.
Layout stage emits locomotion_roles,entry,variables,inputs,states ONLY. locomotion_roles is ordered subset idle,walk,run,sprint,crouch,jump containing idle (these are MM DATABASE categories, NOT custom state IDs). Variables are identifiers with initial numeric/bool values; external conditions such as bHit default false and are supplied by Blueprint. Internal counters use actions. Builtin read-only speed,falling,crouched,state_time,finished,interrupted must not be declared or assigned.
Each state: id,player,resources,loop,allow_movement,lock_until_finished,min_duration,blend_seconds. Optional parent,initial,database_role,on_entry,on_exit,on_complete. player=group resources=[] requires initial of direct child; parent points to a group. Nested groups at most 8 levels. locomotion resources=[] uses native MM chooser. mm uses database_role (a locomotion role) OR selected database aliases. sequence uses ONE selected nonadditive sequence alias. montage uses ONE selected montage alias, never loop. Use EXACT aliases from palette, never sample_strike/sample_finish unless supplied. group/MM/loop states cannot lock_until_finished or have on_complete. Default blend_seconds=0.2 and min_duration=0. Group loop=false, no completion. Sequence loop is from user intent, not guessed from resource.
Actions are arrays: {op:set|add,var:declared variable,value:number/bool} or {op:jump,velocity:1..2000}. on_complete runs ONCE after natural nonloop animation completion; NOT on interrupted or looping animation. Input actions run BEFORE event evaluation. Entry jump requests real vertical launch, permitting extra air jumps; no damage/hit detection logic.
Inputs: key exact UE name e.g. LeftMouseButton/RightMouseButton/SpaceBar/H, phase pressed/released,event identifier,set dictionary of variable values, optional actions. Never omit explicitly requested set assignments.
Transitions stage emits {transitions:[...]}, ONLY outgoing edges of specified source. Each edge has from,to,event,all,priority,interrupt, optional condition/actions. An edge from parent group applies to descendants. Use event empty string for automatic tick conditions. all is an AND list of {var,op,value}; supported op eq/ne/lt/le/gt/ge. Optional condition is a recursive tree {all:[...]}/{any:[...]}/{not:tree} or predicate; combine with all using AND. Never emit an automatic edge with empty all and no condition. For animation ending: event="", all=[{var:finished,op:eq,value:true}], plus extra conditions. For external interruption use interrupted, not finished. For input edge use EXACT event string from inputs. Source=* is only for explicitly requested global transitions. Highest numeric priority wins; equal priority deeper source wins then document order. interrupt=true bypasses source lock/min duration. Self-edge reenters and restarts clip. Group edges must not be copied into children. If the user does not request outgoing edges from a source return transitions=[].
Never replace conditions by empty all. Never use a completion edge on group/MM/loop. Never infer gameplay features not requested.'''
