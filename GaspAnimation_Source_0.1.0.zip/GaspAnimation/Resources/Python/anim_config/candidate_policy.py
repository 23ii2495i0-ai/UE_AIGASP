"""Explicit authoring constraints; these never infer animation roles or resource IDs."""
import re

def selection_policy(request):
    limit=None
    match=re.search(r'(?:每[类种个](?:动作|动画|插槽|槽位)?|每个(?:动作|插槽|槽位)|各[类种](?:动作|动画)?)[^。；;\n]{0,12}?(?:选|保留|最多|至多|限制为)?\s*([一二两三四五六七八九十]|\d+)\s*(?:段|个|条)',request)
    if match and re.search(r'不要|不只|不限制|不限',match[0]):match=None
    if match:
        value=match[1];limit=int(value) if value.isdigit() else {'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10}[value]
        if not 1<=limit<=64:raise ValueError('每类候选数量必须为 1..64')
    overrides={}
    # Expand shared limits before parsing individual roles (行走、跑步各最多4段).
    aliases=r'待机|行走|走路|跑步|奔跑|冲刺|下蹲|蹲伏|蹲行|跳跃|idle|walk|run|sprint|crouch|jump'
    grouped=r'((?:'+aliases+r')(?:(?:、|和|与|及|，|,)\s*(?:'+aliases+r'))+)\s*各\s*((?:最多|至多|保留|选择|选)(?:保留)?\s*(?:[一二两三四五六七八九十]|\d+)\s*(?:段|个|条))'
    role_request=re.sub(grouped,lambda m:'；'.join(role+m[2] for role in re.findall(aliases,m[1],re.I)),request,flags=re.I)
    for role,aliases in {'idle':'待机|idle','walk':'行走|走路|walk','run':'跑步|奔跑|run','sprint':'冲刺|sprint','crouch':'下蹲|蹲伏|蹲行|crouch','jump':'跳跃|jump'}.items():
        specific=re.search(r'(?:'+aliases+r')[^。；;，,、\n]{0,6}?(?:保留|选择|选|最多|至多)\s*([一二两三四五六七八九十]|\d+)\s*(?:段|个|条)',role_request,re.I)
        if specific:
            number=specific[1];number=int(number) if number.isdigit() else {'一':1,'二':2,'两':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10}[number]
            if not 1<=number<=64:raise ValueError('每类候选数量必须为 1..64')
            overrides[role]=number
    for role,aliases in {'crouch_idle':'crouch_idle|CrouchIdle|蹲姿待机','crouch_move':'crouch_move|CrouchMove|蹲姿移动'}.items():
        match=re.search(r'(?:'+aliases+r')\s*[：:]?\s*(?:最多|至多|保留|选)\s*(\d+)\s*段',request,re.I)
        if match:
            value=int(match[1])
            if not 1<=value<=64:raise ValueError('每类候选数量必须为 1..64')
            overrides[role]=value
    return dict(max_candidates_per_role=limit,max_candidates_by_role=overrides,
                review_uncertain=any(s in request for s in ('无法确认','待人工检查','不强行绑定','uncertain','manual review')),
                require_cardinal_directions=bool(re.search(r'wasd|四[向个方向]|前后左右|不同方向',request,re.I)),
                index_jump=bool(re.search(r'motion\s*matching|运动匹配|\bmm\b',request,re.I) and re.search(r'数据库|database',request,re.I)))

def direction(asset):
    tokens=set(re.findall(r'[a-z]+',asset.get('name','').lower()))
    for label,aliases in [('forward_left',{'fl','lf'}),('forward_right',{'fr','rf'}),('back_left',{'bl','lb'}),('back_right',{'br','rb'})]:
        if tokens&aliases:return label
    for label,aliases in [('forward',{'f','forward','front'}),('back',{'b','back','backward'}),('left',{'l','ll','left'}),('right',{'r','rl','right'})]:
        if tokens&aliases:return label
    return None

def semantic_exclusion(asset):
    tokens=set(re.findall(r'[a-z]+',re.sub(r'([a-z])([A-Z])',r'\1 \2',asset.get('name','')).lower()))
    tokens.update(re.findall(r'[a-z]+',asset.get('name','').lower()))
    if asset.get('additive') is True:return 'additive_animation'
    if tokens&{'ao','add','additive','lookat','lookatpoi','lean','pose','poses','base'}:return 'pose_or_additive_not_locomotion'
    if tokens&{'traversal','vault','mantle','hurdle','climb','catch'}:return 'traversal_not_requested_action'
    if asset.get('num_frames') is not None and asset['num_frames']<=1:return 'single_frame_pose'
    return None

def category_conflict(asset,role):
    if role in ('jump_start','jump_fall','jump_land','jump_land_run'):
        from landing_policy import phase_asset_matches
        return not phase_asset_matches(asset,role)
    words=set(re.findall(r'[a-z]+',asset.get('name','').lower()))
    if role in ('crouch_idle','crouch_move'):
        if not words&{'crouch','crouched','crouching'}:return True
        if words&{'jump','jumping','dodge','roll','turn','start','stop','transition'}:return True
        if role=='crouch_idle':return 'idle' not in words
        return bool(words&{'idle'}) or not bool(words&{'loop','walk','walking','move','moving','locomotion'})
    if role in ('idle','walk','run','sprint') and words&{'crouch','crouched','crouching'}:return True
    if role in ('idle','walk','run','sprint','crouch') and words&{'jump','jumping','dodge','roll'}:return True
    return False
