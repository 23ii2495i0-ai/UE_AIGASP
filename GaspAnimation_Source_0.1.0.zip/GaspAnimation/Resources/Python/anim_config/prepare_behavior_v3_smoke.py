"""Isolated execution fixture from reviewed IR; NOT a model-generation result.

Existing jump clips are explicit timing stand-ins. Never saved to the user's BP.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import prepare_behavior_smoke as base
from behavior_requirements import compile_requirements

REQUEST='Travel 为父状态，包含 Rest、Stroll、Jog。\nSky 为父状态，包含 Ascend、Descend。\nSwingA SwingB Flinch'
IR=dict(version=1,topology=dict(entry='Travel',groups=[dict(id='Travel',children=['Rest','Stroll','Jog'],initial='Rest',source_lines=[0]),dict(id='Sky',children=['Ascend','Descend'],initial='Ascend',source_lines=[1])],standalone=['SwingA','SwingB','Flinch']),
        locomotion=dict(group='Travel',idle='Rest',walk='Stroll',run='Jog'),jump=dict(group='Sky',rise='Ascend',fall='Descend',counter='Count',max_jumps=2),combo=dict(attacks=['SwingA','SwingB'],hit='Flinch',buffer='Buffered'),external_variables=[],unsupported=[],settings=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=.25,window_end=.65,jump_velocity=500))


def definition(paths):
    graph,_=compile_requirements(IR,REQUEST,dict(SwingA=[paths['action']],SwingB=[paths['action']],Flinch=[paths['hurt']]))
    graph['variables'].update(ExternalReady=False,ProbeCount=0,BufferWrites=0)
    graph['variable_sources'].update(ExternalReady=dict(scope='external',source='test Blueprint SetBoolVariable'),ProbeCount=dict(scope='internal',source='test probe counter'),BufferWrites=dict(scope='internal',source='test instrumented buffer writes'))
    for handler in graph['handlers']:
        if handler['from']=='SwingA' and handler['event']=='Attack':handler['actions'].append(dict(op='add',var='BufferWrites',value=1))
    graph['handlers'].append(dict({'from':'SwingA','event':'ExternalProbe','condition':{'not':dict(var='ExternalReady',op='eq',value=True)},'actions':[dict(op='add',var='ProbeCount',value=1)],'priority':20}))
    return graph


if __name__=='__main__':
    base.FOLDER='/Game/Native/Generated/BehaviorV3QualityFixture'
    base.definition=definition
    base.prepare('behavior_v3')
