import unittest
from unified_explicit_edges import compile_edges,condition

class ExplicitEdgeTests(unittest.TestCase):
    def test_arbitrary_states_and_compound_expression(self):
        edges=compile_edges('Alpha 到 Beta：move_input > 0.01 且 gait == 0。',['Alpha','Beta'],{'move_input','gait'})
        self.assertEqual(edges[0]['all'],[dict(var='move_input',op='gt',value=.01),dict(var='gait',op='eq',value=0)])
        self.assertEqual(edges[0]['from'],'Alpha')

    def test_mixed_natural_language_is_not_dropped(self):
        self.assertIsNone(compile_edges('A 到 B：speed > 0。\n落地后返回A。',['A','B'],{'speed'}))

    def test_code_and_unknown_identifiers_are_rejected(self):
        for text in ['f() > 0','x.y == 1','unknown == 1']:
            with self.assertRaises(ValueError):condition(text,{'speed'})

    def test_nested_or_not_and_negative_value(self):
        result=condition('not (speed < -1 or falling == true)',{'speed','falling'})
        self.assertEqual(result['not']['any'][0]['value'],-1)

if __name__=='__main__':unittest.main()
