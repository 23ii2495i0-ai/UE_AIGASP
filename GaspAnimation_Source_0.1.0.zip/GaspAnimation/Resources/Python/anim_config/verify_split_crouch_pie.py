"""Isolated real PIE probe; no asset or Blueprint writes, bounded 90 seconds."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import json,time,traceback
from pathlib import Path
import unreal

ROOT=_gasp_workspace
OUT=ROOT/'artifacts/anim_config/verification/split_crouch/pie_result.json'
LES=unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
UES=unreal.get_editor_subsystem(unreal.UnrealEditorSubsystem)
START=time.monotonic()
CASES=[('standing_idle',False,0,0,'Idle','PSD_idle'),
       ('crouched_idle',True,0,0,'CrouchIdle','PSD_crouch_idle'),
       ('crouched_WA',True,1,-1,'CrouchMove','PSD_crouch_move'),
       ('crouched_WD',True,1,1,'CrouchMove','PSD_crouch_move'),
       ('crouched_stop',True,0,0,'CrouchIdle','PSD_crouch_idle'),
       ('stand_moving',False,1,0,'Run','PSD_run'),
       ('crouch_while_moving',True,1,0,'CrouchMove','PSD_crouch_move'),
       ('stand_stop',False,0,0,'Idle','PSD_idle')]
S=dict(phase='starting',pawn=None,case=0,elapsed=0,results=[],handle=None,frames=0)

def finish(error=None):
    result=dict(origin='deterministic_fixture_actual_target_BP_not_model_generation',cases=S['results'],error=error,
                passed=not error and len(S['results'])==len(CASES) and all(x['passed'] for x in S['results']))
    OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    unreal.unregister_slate_post_tick_callback(S['handle'])
    LES.editor_request_end_play()
    unreal.SystemLibrary.quit_editor()

def tick(dt):
    try:
        if time.monotonic()-START>90:finish('90 second deadline');return
        world=UES.get_game_world()
        if not world:return
        if not S['pawn']:
            old=unreal.GameplayStatics.get_player_pawn(world,0)
            if not old:return
            pawn=old
            if 'BP_CusGaspNativeCharacter' not in pawn.get_class().get_name():
                raise RuntimeError('Probe map must spawn the actual target Blueprint')
            pc=unreal.GameplayStatics.get_player_controller(world,0)
            pawn.disable_input(pc)
            pawn.mesh.set_editor_property('visibility_based_anim_tick_option',unreal.VisibilityBasedAnimTickOption.ALWAYS_TICK_POSE_AND_REFRESH_BONES)
            S['pawn']=pawn
        p=S['pawn'];case=CASES[S['case']];name,crouch,x,y,expected,db=case
        if S['elapsed']==0:
            if crouch:p.crouch()
            else:p.un_crouch()
            p.character_movement.stop_movement_immediately()
            p.set_actor_location(unreal.Vector(500,-750,90),False,True)
        p.set_editor_property('raw_move_input',unreal.Vector2D(x,y))
        if x or y:
            scale=(x*x+y*y)**.5;p.add_movement_input(unreal.Vector(x/scale,y/scale,0),1,False)
        S['elapsed']+=dt;S['frames']+=1
        if S['elapsed']<1.2:return
        b=p.get_editor_property('behavior');anim=p.mesh.get_anim_instance()
        state=str(b.get_editor_property('current_state'));selected=str(anim.get_editor_property('selected_database'))
        current=[str(a.get_name()) for a in anim.get_editor_property('current_databases')]
        S['results'].append(dict(case=name,state=state,selected_database=selected,current_databases=current,
            expected=expected,expected_database=db,behavior_enabled=b.is_enabled(),
            passed=b.is_enabled() and state==expected and db in current and selected==db))
        S['case']+=1;S['elapsed']=0
        if S['case']==len(CASES):finish()
    except Exception:finish(traceback.format_exc())

S['handle']=unreal.register_slate_post_tick_callback(tick)
LES.editor_request_begin_play()
