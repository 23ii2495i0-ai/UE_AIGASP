import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'ai'))
from project_paths import configure_imports
configure_imports()
from protocol import messages,compile_prediction
from test_config_tool import CAT
import config_tool
class ModelProtocolTests(unittest.TestCase):
 def pred(self):return {'roles':['run'],'bindings':{'run':'a1'},'blend_seconds':.2,'reject':None}
 def test_semantic_intent_compiles_without_rule_keyword(self):
  p=compile_prediction(CAT,'保持慢跑节奏赶路','/Game/X',self.pred(),{'trained':True})
  self.assertEqual(config_tool.validate(p,CAT),[]);self.assertEqual(p['states'][0]['resource'],CAT['assets'][1]['id'])
 def test_hallucinated_alias_rejected(self):
  p=self.pred();p['bindings']['run']='a100'
  with self.assertRaises(ValueError):compile_prediction(CAT,'run','/Game/X',p,{})
 def test_reject_is_blocking(self):
  p=self.pred();p['reject']='unsupported';plan=compile_prediction(CAT,'run and jump','/Game/X',p,{})
  self.assertTrue(config_tool.validate(plan,CAT))
 def test_alias_roundtrip(self):
  m,ids=messages(CAT,'run');self.assertEqual(ids['a1'],CAT['assets'][1]['id']);self.assertNotIn('/Game/Run.Run',m[-1]['content'])
 def test_invalid_model_ir_cannot_execute(self):
  p=self.pred();p['code']='print(1)'
  with self.assertRaises(ValueError):compile_prediction(CAT,'run','/Game/X',p,{})
if __name__=='__main__':unittest.main()
