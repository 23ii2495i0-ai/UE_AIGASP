"""Rebuild clip-labelled source bags; train/validate/test share the exact sparse window policy."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,os,subprocess,sys,time,zipfile
from collections import Counter
from pathlib import Path
import numpy as np
import torch
from torch import nn
import train_pose_content as progress
from pose_content_model import parse_bvh,bvh_positions,PoseNet
from gltf_motion import load_glb,sample,duration
from pose_temporal import SCHEMA,window_times,features,padded_bag
from train_pose_expanded import SMPL_BONES
from motion_labels import ROLES,with_jump
from review_selection import load_review

ROOT=_LAYOUT_REPO;BASE=ROOT/'artifacts/anim_config'
OUT=BASE/'models/pose/experiments/temporal_v3_jump'
EXPANSION=False


def prepare(review=None):
    OUT.mkdir(parents=True,exist_ok=True);rows=[];xs=[];masks=[];labels=[];parts=[];ids=[]
    def add(ident,label,part,windows,source):
        if review is not None and ident not in review:return
        kind=source['kind'];annotation=source.get('annotation',source.get('animation',str(source.get('class_id',''))))
        label=with_jump('CMU' if kind=='CMU' else 'HumanAct12' if kind=='HumanAct12' else kind,annotation,label)
        if review is not None:label=review[ident]
        if label=='unknown':return
        x,mask=padded_bag(windows);xs.append(x);masks.append(mask);labels.append(ROLES.index(label));parts.append(part);ids.append(ident)
        rows.append(dict(id=ident,class_id=ROLES.index(label),class_name=label,split=part,windows=int(mask.sum()),source=source))
    cmu=BASE/'models/pose/experiments/cmu_humanact12';manifest=json.loads((cmu/'dataset_manifest.json').read_text(encoding='utf-8'))
    clean,aliases,duplicates=progress.clean_rows(manifest['files']);split=json.loads((cmu/'run_v2/split_manifest.json').read_text(encoding='utf-8'))
    for i,row in enumerate(clean):
        if review is not None and row['id'] not in review:continue
        p=cmu/'source'/row['download']['path'];raw=p.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=row['download']['sha256']:raise ValueError('CMU source changed')
        nodes,data,dt=parse_bvh(raw.decode('utf-8'));windows=[]
        for times in window_times(dt,(len(data)-1)*dt):
            # Only evaluate neighbouring keyed poses needed for interpolation, not the full animation.
            phase=times/dt;lo=np.floor(phase).astype(int);hi=np.minimum(lo+1,len(data)-1)
            p0=bvh_positions(nodes,data,lo);p1=bvh_positions(nodes,data,hi)
            positions=p0+(p1-p0)*(phase-lo)[:,None,None]
            windows.append(features(positions,times))
        add(row['id'],row['role'],split['subjects'][row['subject']],windows,dict(kind='CMU',annotation=row['annotation'],sha256=row['download']['sha256'],subject=row['subject']))
        if i%30==0:progress.status('准备统一时间窗口',current=i,total=1680)
    human_dir=cmu/'humanact12';meta=json.loads((human_dir/'manifest.json').read_text(encoding='utf-8'));archive=human_dir/'joints.npz'
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=meta['arrays_sha256']:raise ValueError('HumanAct12 arrays changed')
    human=np.load(archive,allow_pickle=False);positions=human['positions'];offsets=human['offsets'];ys=human['labels']
    for i,y in enumerate(ys):
        label={1:'walk',2:'run',10:'attack'}.get(int(y),'other');p=positions[offsets[i]:offsets[i+1]][:,SMPL_BONES]
        # Release timing is uncertain. Keep uncertainty explicit, do not invent ground-truth FPS.
        windows=[]
        for fps in (15.,30.):
            phase=np.linspace(0,len(p)-1,16);sampled=np.stack([np.stack([np.interp(phase,np.arange(len(p)),p[:,b,a]) for a in range(3)],axis=-1) for b in range(11)],axis=1)
            windows.append(features(sampled,phase/fps))
        add('humanact12:'+str(i),label,'train',windows,dict(kind='HumanAct12',class_id=int(y),timing='15/30 FPS hypotheses; unknown actual FPS',arrays_sha256=meta['arrays_sha256']))
        if i%100==0:progress.status('准备统一时间窗口',current=len(rows),total=1680)
    combat=BASE/'models/pose/experiments/combat_v1';meta=json.loads((combat/'run_v1/dataset_manifest.json').read_text(encoding='utf-8'));cache={}
    for row in meta['files']:
        key=(row['archive'],row['member'])
        if key not in cache:
            with zipfile.ZipFile(combat/'source'/row['archive']) as z:raw=z.read(row['member'])
            if hashlib.sha256(raw).hexdigest()!=row['glb_sha256']:raise ValueError('GLB source changed')
            cache[key]=load_glb(raw)
        doc,binary=cache[key];animation=next(a for a in doc['animations'] if a['name']==row['animation']);start,end=duration(doc,binary,animation)
        windows=[features(sample(doc,binary,animation,t),t) for t in window_times(start,end)]
        add(row['id'],row['role'],row['part'],windows,dict(kind='CC0 authored',animation=row['animation'],archive=row['archive'],sha256=row['glb_sha256']))
    if EXPANSION:
        folder=BASE/'models/pose/datasets/expansion_v4'
        extra=json.loads((folder/'cleaning_report.json').read_text(encoding='utf-8'));bags=np.load(folder/'cleaned_bags.npz',allow_pickle=False)
        for row in extra['rows']:
            if row['status']!='retained':continue
            index=row['array_index'];label=row['label'];mask=bags['mask'][index]
            xs.append(bags['x'][index]);masks.append(mask);labels.append(ROLES.index(label));parts.append('train');ids.append(row['id'])
            rows.append(dict(id=row['id'],class_id=ROLES.index(label),class_name=label,split='train',windows=int(mask.sum()),source=row))
    # Source clips, not augmented windows, are the unit of supervision and evaluation.
    if len(set(ids))!=len(ids):raise ValueError('Duplicate clip IDs')
    arrays=dict(x=np.array(xs),mask=np.array(masks),y=np.array(labels),part=np.array(parts),id=np.array(ids))
    signatures={}
    for x,m,part in zip(arrays['x'],arrays['mask'],arrays['part']):
        digest=hashlib.sha256(x[m].tobytes()).hexdigest()
        if digest in signatures and signatures[digest]!=part:raise ValueError('Duplicate content across splits')
        signatures[digest]=part
    np.savez_compressed(OUT/'training_bags.npz',**arrays)
    for part in ('train','validation','test'):
        (OUT/f'{part}.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows if r['split']==part),encoding='utf-8')
    counts={p:dict(Counter(r['class_name'] for r in rows if r['split']==p)) for p in ('train','validation','test')}
    if EXPANSION:
        prior=BASE/'models/pose/experiments/temporal_v3_jump'
        for part in ('validation','test'):
            frozen={r['id']:r['class_name'] for r in map(json.loads,(prior/f'{part}.jsonl').read_text(encoding='utf-8').splitlines())}
            current={r['id']:r['class_name'] for r in rows if r['split']==part}
            if frozen!=current:raise ValueError('Previous evaluation partition changed: '+part)
    config=dict(path=str(OUT),train='train.jsonl',val='validation.jsonl',test='test.jsonl',names=dict(enumerate(ROLES)),format='clip labels with numerical sparse motion; NOT YOLO box format',feature_schema=SCHEMA,counts=counts,activation_allowed=False)
    # JSON is valid YAML; this file is a human-readable dataset entry point, not a YOLO loader input.
    (OUT/'data.yaml').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'dataset_manifest.json').write_text(json.dumps(dict(config=config,clips=rows,shortages=[f"hit: {counts['train'].get('hit',0)} train / {counts['validation'].get('hit',0)} validation / {counts['test'].get('hit',0)} test independent clips; insufficient for deployment acceptance"]),ensure_ascii=False,indent=2),encoding='utf-8')
    print('TEMPORAL_DATA_READY',counts,flush=True)
    return arrays,counts


class BagNet(nn.Module):
    def __init__(self,channels,classes=len(ROLES)):
        super().__init__();self.window=PoseNet(features=channels,classes=classes)
    def forward(self,x,mask):
        b,w,t,c=x.shape;logits=self.window(x.reshape(b*w,t,c)).reshape(b,w,-1)
        # A labelled clip can contain idle intervals; do not label every window as an attack.
        return logits.masked_fill(~mask[:,:,None],-1e4).amax(1)


def metrics(probs,y):
    pred=probs.argmax(1);conf=np.zeros((len(ROLES),len(ROLES)),int)
    for a,b in zip(y,pred):conf[a,b]+=1
    recall={r:float(conf[i,i]/conf[i].sum()) if conf[i].sum() else None for i,r in enumerate(ROLES)}
    return dict(n=len(y),accuracy=float(np.mean(pred==y)),balanced_accuracy=float(np.mean([r for r in recall.values() if r is not None])),recall=recall,support={r:int(conf[i].sum()) for i,r in enumerate(ROLES)},confusion=conf.tolist(),accepted=0,coverage=0.,accepted_precision=None)


def main():
    global OUT,EXPANSION
    parser=argparse.ArgumentParser();parser.add_argument('--epochs',type=int,default=300);parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--review-csv',type=Path,default=BASE/'models/pose/review/cleaned/人工审核.csv');parser.add_argument('--accept-retained',action='store_true');args=parser.parse_args()
    EXPANSION=os.environ.get('GASP_POSE_EXPANSION')=='1'
    if EXPANSION:OUT=BASE/'models/pose/experiments/expanded_combat_v4'
    if not 1<=args.epochs<=1000:raise ValueError('Epochs must be 1..1000')
    OUT.mkdir(parents=True,exist_ok=True);number=1
    while (OUT/f'run_v{number}').exists():number+=1
    run=OUT/f'run_v{number}';run.mkdir()
    progress.STATUS.write_text(json.dumps(dict(stage='准备修正后的姿态训练',complete=False,epoch=0,epochs=args.epochs,pid=os.getpid(),updated_at=time.time(),run=str(run))),encoding='utf-8')
    if os.name=='nt' and os.environ.get('GASP_POSE_PROGRESS_OPENED')!='1':subprocess.Popen([str(Path(sys.executable).with_name('pythonw.exe')),str(Path(__file__).resolve().parents[1]/'ui/PoseTrainProgress.py')],cwd=ROOT)
    try:
        review,excluded=load_review(args.review_csv,args.accept_retained)
        (run/'review_snapshot.csv').write_bytes(args.review_csv.read_bytes())
        (run/'review_policy.json').write_text(json.dumps(dict(accept_retained=args.accept_retained,selected=len(review),excluded=excluded,review_sha256=hashlib.sha256(args.review_csv.read_bytes()).hexdigest()),indent=2),encoding='utf-8')
        data,counts=prepare(review)
        unused=sorted(set(review)-set(map(str,data['id'])))
        policy_path=run/'review_policy.json';policy=json.loads(policy_path.read_text(encoding='utf-8'));policy['unused_review_ids']=unused;policy['prepared_clips']=len(data['id']);policy_path.write_text(json.dumps(policy,indent=2),encoding='utf-8')
        if unused:print('REVIEW_NOT_USED_NO_NUMERIC_LOADER',unused,flush=True)
        if args.prepare_only:progress.status('数据审核完成',complete=True);return
        torch.manual_seed(42);np.random.seed(42);torch.set_num_threads(4);device='cuda' if torch.cuda.is_available() else 'cpu'
        sets={p:np.flatnonzero(data['part']==p) for p in ('train','validation','test')};valid=data['x'][sets['train']][data['mask'][sets['train']]]
        mean=valid.mean((0,1));std=np.maximum(valid.std((0,1)),.03)
        x=torch.tensor((data['x']-mean)/std,device=device);mask=torch.tensor(data['mask'],device=device);y=torch.tensor(data['y'],dtype=torch.long,device=device)
        model=BagNet(x.shape[-1]).to(device);optimizer=torch.optim.AdamW(model.parameters(),lr=.0005,weight_decay=.05)
        freq=np.bincount(data['y'][sets['train']],minlength=len(ROLES))
        if np.any(freq==0):raise ValueError('Every configured class must have training clips')
        prob=1/freq[data['y'][sets['train']]];prob/=prob.sum()
        best=-1;best_state=None;best_epoch=0
        for epoch in range(1,args.epochs+1):
            model.train();losses=[];order=np.random.choice(sets['train'],len(sets['train']),replace=True,p=prob)
            for at in range(0,len(order),32):
                batch=order[at:at+32];optimizer.zero_grad(set_to_none=True)
                loss=nn.functional.cross_entropy(model(x[batch]+torch.randn_like(x[batch])*.015,mask[batch]),y[batch]);loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step();losses.append(loss.item())
            model.eval()
            with torch.inference_mode():v=model(x[sets['validation']],mask[sets['validation']]).softmax(-1).cpu().numpy()
            score=metrics(v,data['y'][sets['validation']])['balanced_accuracy']
            if score>best:best=score;best_epoch=epoch;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
            progress.status('统一窗口专项训练中',epoch=epoch,epochs=args.epochs,loss=float(np.mean(losses)),best_validation_balanced=best,validation_balanced=score)
            if epoch%10==0:print('TEMPORAL_TRAIN',epoch,round(score,4),flush=True)
        model.load_state_dict(best_state);model.eval()
        with torch.inference_mode():probs=model(x,mask).softmax(-1).cpu().numpy()
        test=sets['test'];new=np.array([':' in ident for ident in data['id']])
        report=dict(feature_schema=SCHEMA,roles=ROLES,epochs=args.epochs,best_epoch=best_epoch,counts=counts,activation_allowed=False,threshold=1.01,validation=metrics(probs[sets['validation']],data['y'][sets['validation']]),test=metrics(probs[test],data['y'][test]),fixed_cmu_test=metrics(probs[(data['part']=='test')&~new],data['y'][(data['part']=='test')&~new]),new_authored_test=metrics(probs[(data['part']=='test')&new],data['y'][(data['part']=='test')&new]),limitations=[f"Only {counts['train'].get('hit',0)} independent hit training clips; no reliable hit acceptance",'Prior test has been inspected; regression only, not a fresh blind test','Uncertain HumanAct12 timing','No labelled UE-domain acceptance'])
        np.savez_compressed(run/'weights.npz',**{k:v.numpy() for k,v in best_state.items()},normalization_mean=mean,normalization_std=std)
        report['weights_sha256']=hashlib.sha256((run/'weights.npz').read_bytes()).hexdigest();report['training_bags_sha256']=hashlib.sha256((OUT/'training_bags.npz').read_bytes()).hexdigest()
        (run/'evaluation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        (run/'predictions.jsonl').write_text(''.join(json.dumps(dict(id=str(i),split=str(p),label=ROLES[int(label)],prediction=ROLES[int(prob.argmax())],scores=dict(zip(ROLES,map(float,prob)))))+'\n' for i,p,label,prob in zip(data['id'],data['part'],data['y'],probs)),encoding='utf-8')
        progress.status('统一窗口训练与评测完成',complete=True,test=report['test'],fixed_cmu_test=report['fixed_cmu_test'],report=str(run/'evaluation.json'))
        print('TEMPORAL_COMPLETE',json.dumps(report),flush=True)
    except Exception as exc:progress.status('失败',error=str(exc),complete=False);raise


if __name__=='__main__':main()
