"""Offline v2 inference requires exact shared-window UE samples; old uniform samples are rejected."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import torch
from scipy.spatial.transform import Rotation
from pose_content_model import BONES
from pose_temporal import SCHEMA,features,padded_bag
from motion_window_policy import POLICY,sparse_windows
from train_pose_temporal import BagNet,ROLES


def ue_bag(samples):
    if samples.get('status')!='sampled' or samples.get('window_policy')!=POLICY:raise ValueError('Requires new -Temporal UE samples; uniform v1 samples cannot recover short events')
    times=sparse_windows(0.,samples['duration']);frames=samples['frames'];positions=[]
    for frame in frames:
        local=np.array([frame['positions_root_cm'][b] for b in BONES])
        # Restore component-space position before extracting global root/body dynamics.
        world=Rotation.from_quat(frame['root_rotation']).apply(local)+frame['root_position_cm']
        positions.append(world[:,[0,2,1]])  # UE Z-up -> source Y-up; distances/reflection invariant.
    original=np.array([f['time'] for f in frames]);positions=np.array(positions);windows=[]
    for requested in times:
        indices=[int(np.argmin(abs(original-t))) for t in requested]
        if not np.allclose(original[indices],requested,atol=1e-6,rtol=0):raise ValueError('Missing exact requested time samples')
        windows.append(features(positions[indices],requested))
    return padded_bag(windows)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True);parser.add_argument('--catalog',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    report=json.loads((args.run/'evaluation.json').read_text(encoding='utf-8'));path=args.run/'weights.npz'
    if report['feature_schema']!=SCHEMA or hashlib.sha256(path.read_bytes()).hexdigest()!=report['weights_sha256']:raise ValueError('Weight/schema mismatch')
    roles=tuple(report['roles'])
    if roles not in (ROLES,ROLES[:-1]):raise ValueError('Unsupported class mapping')
    weights=np.load(path,allow_pickle=False);model=BagNet(len(weights['normalization_mean']),classes=len(roles));model.load_state_dict({k:torch.from_numpy(weights[k]) for k in model.state_dict()});model.eval();results=[]
    for asset in json.loads(args.catalog.read_text(encoding='utf-8'))['assets']:
        if asset['kind']=='mesh':continue
        row=dict(id=asset['id'],semantic_role='unknown',usable_for_auto_binding=False,reason='UE_domain_not_validated')
        try:
            x,mask=ue_bag(asset.get('motion_samples',{}));x=(x-weights['normalization_mean'])/weights['normalization_std']
            with torch.inference_mode():prob=model(torch.tensor(x[None]),torch.tensor(mask[None])).softmax(-1).numpy()[0]
            row['experimental_scores']=dict(zip(roles,map(float,prob)))
        except (ValueError,KeyError,TypeError) as exc:row['reason']=str(exc)
        results.append(row)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(dict(feature_schema=SCHEMA,activation_allowed=False,assets=results),ensure_ascii=False,indent=2),encoding='utf-8')
    print('TEMPORAL_OFFLINE',len(results),'assets; automatic binding disabled')


if __name__=='__main__':main()
