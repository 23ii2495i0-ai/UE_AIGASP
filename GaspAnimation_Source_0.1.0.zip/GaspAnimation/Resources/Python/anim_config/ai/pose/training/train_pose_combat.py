"""Five-class combat-focused experiment; sparse numerical input, no online activation."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,os,subprocess,sys,time,zipfile
from collections import Counter
from pathlib import Path
import numpy as np
import train_pose_content as trainer
from pose_content_model import PoseNet,encode
from gltf_motion import load_glb,duration,sample

ROOT=_LAYOUT_REPO
OUT=ROOT/'artifacts/anim_config/models/pose/experiments/combat_v1'
ROLES=('walk','run','attack','other','hit')
# Author-authored animation identifiers supply supervision only; never classifier inputs.
QUAT_ATTACK={'Punch_Cross','Punch_Jab','Sword_Attack','Melee_Hook','Sword_Heavy_Combo','Sword_Regular_A','Sword_Regular_B','Sword_Regular_C','Sword_Regular_Combo','Zombie_Scratch'}
HIT={'Hit_Chest','Hit_Head','Hit_Knockback','Hit_A','Hit_B'}
VAL={'Hit_Knockback','Punch_Cross'}
TEST={'Hit_A','Hit_B','Sword_Heavy_Combo','Melee_1H_Attack_Stab','Melee_Unarmed_Attack_Kick'}
# Related combo components, recoveries and rig variants must stay on one side of a split.
def partition(name):
    if name.startswith('Sword_Heavy_'):return 'test'
    if name.startswith('Sword_Regular_'):return 'validation'
    if name in TEST:return 'test'
    if name in VAL:return 'validation'
    return 'train'


def role(name):
    if name in HIT:return 'hit'
    if name in QUAT_ATTACK or ('_Attack_' in name and name.startswith('Melee_')) or name=='Melee_Block_Attack':return 'attack'
    if name in {'Walk_Loop','Walk_Formal_Loop','Walk_Carry_Loop','Walking_A','Walking_B','Walking_C','Walking_Backwards'}:return 'walk'
    if name in {'Jog_Fwd_Loop','Sprint_Loop','Running_A','Running_B','Running_HoldingBow','Running_HoldingRifle','Running_Strafe_Left','Running_Strafe_Right'}:return 'run'
    # Ambiguous firearm/spell activation and static/death poses are not combat supervision.
    if any(x in name for x in ('TPose','T-Pose','_Pose','EXPERIMENTAL','Ranged_','Pistol_','Spell_')):return None
    return 'other'


def prepare():
    source=ROOT/'artifacts/anim_config/models/pose/experiments/expanded_v1/run_v2'
    report=json.loads((source/'evaluation.json').read_text(encoding='utf-8'));path=source/'training_arrays.npz'
    if hashlib.sha256(path.read_bytes()).hexdigest()!=report['training_arrays_sha256']:raise ValueError('Baseline arrays changed')
    previous=np.load(path,allow_pickle=False)
    xs=list(previous['x']);ys=list(previous['y']);parts=list(previous['part']);ids=list(previous['id']);subjects=list(previous['subject'])
    rows=[];seen={};skipped=[]
    for archive in sorted((OUT/'source').glob('*.zip')):
        if not archive.with_suffix('.json').exists():continue
        metadata=json.loads(archive.with_suffix('.json').read_text(encoding='utf-8'))
        if hashlib.sha256(archive.read_bytes()).hexdigest()!=metadata['sha256']:raise ValueError('Archive changed')
        with zipfile.ZipFile(archive) as z:
            members=[n for n in z.namelist() if n.endswith('_Standard.glb') or ('/gltf/Rig_Medium/' in n and n.endswith('.glb'))]
            for member in members:
                blob=z.read(member);doc,binary=load_glb(blob)
                for animation in doc['animations']:
                    name=animation['name'];label=role(name)
                    if label is None:skipped.append(name);continue
                    start,end=duration(doc,binary,animation)
                    if end-start<=.01:skipped.append(name);continue
                    times=np.linspace(start,end,16);positions=sample(doc,binary,animation,times)
                    features=encode(positions,times)
                    fingerprint=hashlib.sha256(np.round(features,5).tobytes()).hexdigest()
                    ident=archive.stem+':'+name;part=partition(name)
                    if fingerprint in seen:
                        old_label,old_part=seen[fingerprint]
                        if old_label!=label or old_part!=part:raise ValueError('Conflicting duplicate motion')
                        continue
                    seen[fingerprint]=(label,part)
                    rows.append(dict(id=ident,animation=name,role=label,part=part,archive=archive.name,member=member,source=metadata,glb_sha256=hashlib.sha256(blob).hexdigest(),duration=end-start))
                    # Preserve source clip grouping across all augmentations; no extra independent clips.
                    variants=[(start,end,1.,False)]
                    if part=='train':
                        variants += [(start,end,speed,mirror) for speed in (.8,1.,1.2) for mirror in (False,True) if (speed,mirror)!=(1.,False)]
                    for begin,finish,speed,mirror in variants:
                        t=np.linspace(begin,finish,16);p=positions.copy()
                        if mirror:
                            p=p[:,[0,1,2,4,3,6,5,8,7,10,9]];p[:,:,0]*=-1
                        xs.append(encode(p,(t-t[0])/speed));ys.append(ROLES.index(label));parts.append(part);ids.append(ident)
                        # Clip-group split, not performer-disjoint: author identity is not a performer ID.
                        subjects.append('clip_group:'+ident)
                    trainer.status('准备攻击与受击专项数据',current=len(rows),total=200)
    data=dict(x=np.array(xs),y=np.array(ys),part=np.array(parts),id=np.array(ids),subject=np.array(subjects))
    # The original test clips are preserved verbatim; new held-out clips are reported separately.
    signatures={}
    for x,part in zip(data['x'],data['part']):
        digest=hashlib.sha256(x.tobytes()).hexdigest()
        if digest in signatures and signatures[digest]!=part:raise ValueError('Feature leakage across splits')
        signatures[digest]=part
    np.savez_compressed(OUT/'training_arrays.npz',**data)
    manifest=dict(files=rows,skipped=skipped,roles=ROLES,base=str(source),base_arrays_sha256=report['training_arrays_sha256'],source_clips={p:dict(Counter(r['role'] for r in rows if r['part']==p)) for p in ('train','validation','test')},limitations=['Only five independent authored hit animations; augmentation is not new evidence','Clip-disjoint, NOT performer/author-disjoint','No labeled UE-domain validation','Block-hit is a defensive negative, not passive injury'])
    (OUT/'dataset_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (OUT/'split_manifest.json').write_text(json.dumps(dict(policy='Fixed existing arrays plus explicit authored clip groups; no alternate rigs or root-motion copies',counts={p:dict(Counter(ROLES[int(y)] for y,part in zip(data['y'],data['part']) if part==p)) for p in ('train','validation','test')},source_clips=manifest['source_clips']),indent=2),encoding='utf-8')
    print('COMBAT_DATA_READY',json.dumps(manifest['source_clips']),flush=True)
    return len(previous['x'])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--epochs',type=int,default=1000);parser.add_argument('--prepare-only',action='store_true');args=parser.parse_args()
    if not 1<=args.epochs<=1000:raise ValueError('Epochs must be 1..1000')
    OUT.mkdir(parents=True,exist_ok=True);number=1
    while (OUT/f'run_v{number}').exists():number+=1
    trainer.DATA=OUT;trainer.RUN=OUT/f'run_v{number}';trainer.ROLES=ROLES;trainer.PoseNet=lambda:PoseNet(classes=len(ROLES))
    base_metrics=trainer.metrics
    def supported_metrics(probs,labels,threshold):
        result=base_metrics(probs,labels,threshold)
        present=[r for i,r in enumerate(ROLES) if np.any(labels==i)]
        result['balanced_accuracy']=float(np.mean([result['recall'][r] for r in present]))
        result['support']={r:int(np.sum(labels==i)) for i,r in enumerate(ROLES)}
        for r in ROLES:
            if r not in present:result['recall'][r]=None
        return result
    trainer.metrics=supported_metrics
    trainer.STATUS.write_text(json.dumps(dict(stage='准备专项训练',complete=False,epoch=0,epochs=args.epochs,updated_at=time.time(),pid=os.getpid(),run=str(trainer.RUN))),encoding='utf-8')
    if os.name=='nt' and os.environ.get('GASP_POSE_PROGRESS_OPENED')!='1':subprocess.Popen([str(Path(sys.executable).with_name('pythonw.exe')),str(Path(__file__).resolve().parents[1]/'ui/PoseTrainProgress.py')],cwd=ROOT)
    try:
        original_count=prepare()
        if args.prepare_only:return
        trainer.train(args.epochs)
        # Evaluate immutable original test and new authored combat examples separately.
        import torch
        path=trainer.RUN/'evaluation.json';result=json.loads(path.read_text(encoding='utf-8'))
        data=np.load(trainer.RUN/'training_arrays.npz',allow_pickle=False);weights=np.load(trainer.RUN/'weights.npz',allow_pickle=False);model=PoseNet(classes=len(ROLES))
        model.load_state_dict({k:torch.from_numpy(weights[k]) for k in weights.files if not k.startswith('normalization_')});model.eval()
        with torch.inference_mode():probs=model(torch.tensor((data['x']-weights['normalization_mean'])/weights['normalization_std'])).softmax(-1).numpy()
        for name,mask in [('fixed_cmu_test',(data['part']=='test')&(np.arange(len(data['x']))<original_count)),('new_authored_test',(data['part']=='test')&(np.arange(len(data['x']))>=original_count))]:
            result[name]=trainer.metrics(probs[mask],data['y'][mask],result['threshold'])
        result['limitations']=json.loads((OUT/'dataset_manifest.json').read_text())['limitations']+['Fixed CMU test is reused regression evidence, not new blind evaluation','Hit holdout is only two clips; cannot establish robust passive-hit recognition']
        result['activation_allowed']=False;path.write_text(json.dumps(result,indent=2),encoding='utf-8')
        trainer.status('专项训练与评测完成',complete=True,report=str(path),test=result['test'],fixed_cmu_test=result['fixed_cmu_test'],new_authored_test=result['new_authored_test'])
        print('COMBAT_EVALUATION',json.dumps({k:result[k] for k in ('fixed_cmu_test','new_authored_test')}),flush=True)
    except Exception as exc:trainer.status('失败',complete=False,error=str(exc));raise


if __name__=='__main__':main()
