"""Build, train and evaluate a sparse pose classifier with subject/session disjoint splits."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,random,time,shutil,os,sys,subprocess
from pathlib import Path
from collections import Counter
import numpy as np
import torch
from pose_content_model import ROLES,FEATURE_SCHEMA,SAMPLES,parse_bvh,bvh_positions,encode,PoseNet
ROOT=_LAYOUT_REPO;DATA=ROOT/'artifacts/anim_config/models/pose/experiments/cmu_humanact12'
STATUS=DATA/'training_status.json'
RUN=DATA/'run_v2'


def status(stage,**fields):
    previous=json.loads(STATUS.read_text(encoding='utf-8')) if STATUS.exists() else {}
    previous.update(stage=stage,updated_at=time.time(),**fields)
    temp=STATUS.with_suffix('.new');temp.write_text(json.dumps(previous,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(STATUS)


def clean_rows(rows):
    parents={r['subject']:r['subject'] for r in rows}
    def root(s):
        while parents[s]!=s:s=parents[s]
        return s
    seen={}
    for row in rows:
        digest=row['download']['sha256']
        if digest in seen:
            other=seen[digest]
            if row['role']!=other['role']:raise ValueError('Conflicting labels for identical content')
            a,b=root(row['subject']),root(other['subject']);parents[max(a,b)]=min(a,b)
        else:seen[digest]=row
    result=[dict(r,original_subject=r['subject'],subject=root(r['subject'])) for r in seen.values()]
    return result,{s:root(s) for s in parents},len(rows)-len(result)


def split_subjects(rows):
    subjects=sorted({r['subject'] for r in rows})
    for seed in range(1000):
        order=subjects.copy();random.Random(seed).shuffle(order)
        nt=max(1,round(len(order)*.2));nv=max(1,round(len(order)*.2))
        groups={s:('test' if i<nt else 'validation' if i<nt+nv else 'train') for i,s in enumerate(order)}
        counts={part:Counter(r['role'] for r in rows if groups[r['subject']]==part) for part in ('train','validation','test')}
        totals=Counter(r['role'] for r in rows)
        if all(counts['train'][r]>=max(10,int(totals[r]*.45)) and counts['validation'][r]>=max(4,int(totals[r]*.12)) and counts['test'][r]>=max(4,int(totals[r]*.12)) for r in ROLES):return groups,seed,counts
    raise ValueError('Insufficient class coverage for disjoint subject/session split')


def prepare():
    status('准备数据',current=0)
    source=DATA/'dataset_manifest.json';manifest=json.loads(source.read_text(encoding='utf-8'));rows,subject_aliases,duplicates=clean_rows(manifest['files'])
    groups,seed,counts=split_subjects(rows);xs=[];ys=[];parts=[];ids=[];subjects=[];errors=[]
    seen={}
    for row in rows:
        digest=row['download']['sha256'];part=groups[row['subject']]
        if digest in seen and seen[digest]!=part:raise ValueError('Identical source content leaks across splits')
        seen[digest]=part
    for i,row in enumerate(rows):
        path=DATA/'source'/row['download']['path']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=row['download']['sha256']:raise ValueError('Source hash mismatch')
        try:
            nodes,values,dt=parse_bvh(path.read_text(encoding='utf-8'))
            # The CMU BVH conversion inserts a synthetic T-pose in frame one. Never train on it.
            if len(values)<SAMPLES+1:raise ValueError('Too few real frames')
            ranges=[(1,len(values)-1)]
            duration=(len(values)-2)*dt
            if groups[row['subject']]=='train':
                for window in (1.,2.):
                    if duration>window*1.5:
                        width=int(window/dt)
                        ranges.extend((int(start),int(start)+width) for start in np.linspace(1,len(values)-width-1,3))
            for start,end in ranges:
                indices=np.rint(np.linspace(start,end,SAMPLES)).astype(int)
                if len(set(indices))!=SAMPLES:continue
                p=bvh_positions(nodes,values,indices)
                xs.append(encode(p,indices*dt));ys.append(ROLES.index(row['role']));parts.append(groups[row['subject']]);ids.append(row['id']);subjects.append(row['subject'])
        except (ValueError,KeyError) as exc:errors.append(dict(id=row['id'],error=str(exc)))
        if (i+1)%40==0:print('POSE_PREPARE',i+1,'/',len(rows),flush=True)
        status('准备数据',current=i+1,total=len(rows),deduplicated=duplicates)
    if errors:raise ValueError('Preparation failed: '+json.dumps(errors[:5]))
    np.savez_compressed(DATA/'training_arrays.npz',x=np.array(xs),y=np.array(ys),part=np.array(parts),id=np.array(ids),subject=np.array(subjects))
    split=dict(seed=seed,subjects=groups,subject_aliases=subject_aliases,exact_duplicates_removed=duplicates,clip_counts={k:dict(v) for k,v in counts.items()},source_manifest_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),features=FEATURE_SCHEMA,samples=SAMPLES)
    (DATA/'split_manifest.json').write_text(json.dumps(split,indent=2),encoding='utf-8')
    print('POSE_DATA_READY',len(xs),split['clip_counts'],flush=True)


def metrics(probs,labels,threshold):
    pred=probs.argmax(1);accepted=(probs.max(1)>=threshold)&(pred!=ROLES.index('other'))
    confusion=np.zeros((len(ROLES),len(ROLES)),dtype=int)
    for a,b in zip(labels,pred):confusion[a,b]+=1
    recalls=[float(confusion[i,i]/max(1,confusion[i].sum())) for i in range(len(ROLES))]
    return dict(n=len(labels),accuracy=float((pred==labels).mean()),balanced_accuracy=float(np.mean(recalls)),recall=dict(zip(ROLES,recalls)),confusion=confusion.tolist(),accepted=int(accepted.sum()),coverage=float(accepted.mean()),accepted_precision=float((pred[accepted]==labels[accepted]).mean()) if accepted.any() else None)


def train(epochs):
    torch.manual_seed(42);np.random.seed(42);torch.set_num_threads(4)
    data=np.load(DATA/'training_arrays.npz',allow_pickle=False);x=data['x'];y=data['y'];part=data['part']
    sets={k:np.flatnonzero(part==k) for k in ('train','validation','test')}
    if any(set(data['subject'][sets[a]])&set(data['subject'][sets[b]]) for a,b in (('train','test'),('train','validation'),('validation','test'))):raise ValueError('Subject leakage')
    mean=x[sets['train']].mean((0,1));std=np.maximum(x[sets['train']].std((0,1)),.02)
    x=(x-mean)/std;device='cuda' if torch.cuda.is_available() else 'cpu'
    model=PoseNet().to(device);tx=torch.tensor(x,device=device);ty=torch.tensor(y,dtype=torch.long,device=device)
    frequencies=np.bincount(y[sets['train']],minlength=len(ROLES));weights=torch.tensor(1/np.maximum(frequencies,1),dtype=torch.float32,device=device);weights/=weights.mean()
    loss_fn=torch.nn.CrossEntropyLoss(weight=weights);optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.02)
    best=-1;best_state=None;best_epoch=0;started=time.perf_counter()
    status('训练中',epoch=0,epochs=epochs,device=device,run=str(RUN))
    for epoch in range(1,epochs+1):
        model.train();order=np.random.permutation(sets['train']);losses=[]
        for start in range(0,len(order),64):
            batch=order[start:start+64];values=tx[batch]+torch.randn_like(tx[batch])*.025
            optimizer.zero_grad(set_to_none=True);loss=loss_fn(model(values),ty[batch]);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);optimizer.step();losses.append(loss.detach().item())
        model.eval()
        with torch.inference_mode():probs=model(tx[sets['validation']]).softmax(-1).cpu().numpy()
        score=metrics(probs,y[sets['validation']],1.)['balanced_accuracy']
        if score>best:
            best=score;best_epoch=epoch;best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        if epoch%10==0:print('POSE_TRAIN',epoch,'loss',round(float(np.mean(losses)),4),'val_balanced',round(score,4),flush=True)
        status('训练中',epoch=epoch,epochs=epochs,loss=float(np.mean(losses)),validation_balanced=score,best_validation_balanced=best)
    status('独立评测',epoch=epochs)
    model.load_state_dict(best_state);model.eval()
    with torch.inference_mode():validation=model(tx[sets['validation']]).softmax(-1).cpu().numpy();test=model(tx[sets['test']]).softmax(-1).cpu().numpy()
    threshold=1.01
    for candidate in np.linspace(.5,.99,50):
        result=metrics(validation,y[sets['validation']],float(candidate))
        if result['accepted']>=10 and result['accepted_precision']>=.9:threshold=float(candidate);break
    out=RUN;out.mkdir(exist_ok=True)
    # Plain NPZ arrays avoid loading remote or pickled executable model objects.
    np.savez_compressed(out/'weights.npz',**{k:v.numpy() for k,v in best_state.items()},normalization_mean=mean,normalization_std=std)
    report=dict(schema=1,roles=ROLES,feature_schema=FEATURE_SCHEMA,samples=SAMPLES,epochs=epochs,best_epoch=best_epoch,seed=42,torch_version=torch.__version__,device=device,seconds=round(time.perf_counter()-started,3),threshold=threshold,
        validation=metrics(validation,y[sets['validation']],threshold),test=metrics(test,y[sets['test']],threshold),
        limitations=['CMU subject/session disjoint does not guarantee independent human identities','CMU annotation mapping is clip-level weak supervision','No labeled passive hit class','idle/crouch/sprint not trained','No labeled UE-domain evaluation'],
        activation_allowed=False,weights_sha256=hashlib.sha256((out/'weights.npz').read_bytes()).hexdigest(),split_sha256=hashlib.sha256((DATA/'split_manifest.json').read_bytes()).hexdigest(),training_arrays_sha256=hashlib.sha256((DATA/'training_arrays.npz').read_bytes()).hexdigest())
    (out/'evaluation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    for filename in ('dataset_manifest.json','split_manifest.json','training_arrays.npz'):shutil.copy2(DATA/filename,out/filename)
    status('训练与评测完成',complete=True,report=str(out/'evaluation.json'),validation=report['validation'],test=report['test'],activation_allowed=False)
    print('POSE_TRAIN_COMPLETE',json.dumps({k:report[k] for k in ('best_epoch','validation','test','activation_allowed')}),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--epochs',type=int,default=100);p.add_argument('--prepare-only',action='store_true');p.add_argument('--run',type=Path);a=p.parse_args()
    DATA.mkdir(parents=True,exist_ok=True)
    if a.run:
        RUN=a.run.resolve()
        if (RUN/'evaluation.json').exists():raise ValueError('Choose a new run directory; existing evaluated weights are preserved')
    else:
        number=2
        while (DATA/f'run_v{number}'/'evaluation.json').exists():number+=1
        RUN=DATA/f'run_v{number}'
    STATUS.write_text(json.dumps(dict(stage='启动中',complete=False,epoch=0,epochs=a.epochs,updated_at=time.time(),pid=__import__('os').getpid(),run=str(RUN))),encoding='utf-8')
    try:
        if os.name=='nt' and os.environ.get('GASP_POSE_PROGRESS_OPENED')!='1':
            pythonw=Path(sys.executable).with_name('pythonw.exe')
            subprocess.Popen([str(pythonw if pythonw.exists() else sys.executable),str(Path(__file__).resolve().parents[1]/'ui/PoseTrainProgress.py')],cwd=ROOT)
        prepare()
        if not a.prepare_only:train(a.epochs)
        else:status('数据准备完成',complete=True)
    except Exception as exc:
        status('失败',complete=False,error=str(exc));raise
