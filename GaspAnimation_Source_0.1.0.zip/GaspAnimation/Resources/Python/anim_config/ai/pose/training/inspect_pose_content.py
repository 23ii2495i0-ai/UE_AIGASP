"""Evaluate trained pose content on UE samples without activating unvalidated domain bindings."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json
from pathlib import Path
import numpy as np
import torch
from pose_content_model import PoseNet,ROLES,FEATURE_SCHEMA,encode_ue


def main():
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--catalog',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    report=json.loads((a.run/'evaluation.json').read_text(encoding='utf-8'))
    weights=a.run/'weights.npz'
    roles=tuple(report['roles'])
    if hashlib.sha256(weights.read_bytes()).hexdigest()!=report['weights_sha256'] or report['feature_schema']!=FEATURE_SCHEMA or roles not in (ROLES,ROLES+('hit',)):raise ValueError('Model hash/schema mismatch')
    data=np.load(weights,allow_pickle=False);model=PoseNet(classes=len(roles))
    model.load_state_dict({key:torch.tensor(data[key]) for key in model.state_dict()},strict=True);model.eval()
    catalog=json.loads(a.catalog.read_text(encoding='utf-8'));results=[];inputs=[];indices=[]
    for asset in catalog['assets']:
        if asset['kind']=='mesh':continue
        row=dict(id=asset['id'],semantic_role='unknown',confidence=None,usable_for_auto_binding=False)
        try:
            inputs.append(encode_ue(asset.get('motion_samples',{})));indices.append(len(results));row['reason']='ue_domain_not_validated'
        except (ValueError,KeyError,TypeError) as exc:row['reason']=str(exc)
        results.append(row)
    if inputs:
        x=(np.array(inputs)-data['normalization_mean'])/data['normalization_std']
        with torch.inference_mode():probs=model(torch.tensor(x)).softmax(-1).numpy()
        for index,prob in zip(indices,probs):
            best=int(prob.argmax());role=roles[best];accepted=role!='other' and float(prob[best])>=report['threshold']
            results[index].update(evaluation_proposal=role if accepted else 'unknown',model_scores={r:round(float(v),5) for r,v in zip(roles,prob)},passes_source_threshold=accepted)
    summary=dict(total=len(results),numerically_evaluated=len(inputs),unknown=len(results),source_threshold_passed=sum(r.get('passes_source_threshold',False) for r in results))
    out=dict(schema=1,model_sha256=report['weights_sha256'],activation_allowed=False,uses_asset_names=False,summary=summary,assets=results)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary))
if __name__=='__main__':main()
