"""Add author-provided HumanAct12 as training only; keep the previous CMU test fixed."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from collections import Counter
import numpy as np
from pose_content_model import encode,SAMPLES,ROLES
import train_pose_content as trainer
ROOT=_LAYOUT_REPO
BASE=ROOT/'artifacts/anim_config/models/pose/experiments/cmu_humanact12'
OUT=ROOT/'artifacts/anim_config/models/pose/experiments/expanded_v1'
# SMPL-24 ordering mapped to the same anatomical landmarks as the UE/BVH sampler.
SMPL_BONES=(0,9,15,20,21,7,8,4,5,18,19)


def resample_motion(motion):
    x=np.asarray(motion,dtype=np.float64)
    if x.ndim!=3 or x.shape[1:]!=(24,3) or len(x)<2 or not np.isfinite(x).all():raise ValueError('Invalid SMPL-24 motion')
    times=np.linspace(0,len(x)-1,SAMPLES)
    selected=x[:,SMPL_BONES,:]
    p=np.empty((SAMPLES,len(SMPL_BONES),3))
    for bone in range(len(SMPL_BONES)):
        for axis in range(3):p[:,bone,axis]=np.interp(times,np.arange(len(x)),selected[:,bone,axis])
    return p,times


def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    trainer.status('准备扩充数据：保留原 CMU 测试集',epoch=0,complete=False)
    old=BASE/'run_v2';report=json.loads((old/'evaluation.json').read_text(encoding='utf-8'))
    archive=old/'training_arrays.npz'
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=report['training_arrays_sha256']:raise ValueError('Baseline arrays changed')
    baseline=np.load(archive,allow_pickle=False)
    # Published descriptions reveal these contain attacks; do not label them as negative examples.
    excluded={'88_06','56_04'}
    keep=np.array([str(i) not in excluded for i in baseline['id']])
    if np.any((baseline['part']=='test')&~keep):raise ValueError('This expansion must not alter the fixed test set')
    xs=list(baseline['x'][keep]);ys=list(baseline['y'][keep]);parts=list(baseline['part'][keep]);ids=list(baseline['id'][keep]);subjects=list(baseline['subject'][keep])
    # Oversample the existing source domain without calling duplicated windows new clips.
    train=keep&(baseline['part']=='train')
    xs.extend(baseline['x'][train]);ys.extend(baseline['y'][train]);parts.extend(baseline['part'][train]);ids.extend(baseline['id'][train]);subjects.extend(baseline['subject'][train])
    human_dir=BASE/'humanact12';human_manifest=json.loads((human_dir/'manifest.json').read_text(encoding='utf-8'))
    human_path=human_dir/'joints.npz'
    if hashlib.sha256(human_path.read_bytes()).hexdigest()!=human_manifest['arrays_sha256']:raise ValueError('HumanAct12 arrays changed')
    human=np.load(human_path,allow_pickle=False);seen={};counts=Counter();duplicates=0
    human_positions=human['positions'];human_offsets=human['offsets'];human_labels=human['labels']
    for i,label in enumerate(human_labels):
        motion=human_positions[human_offsets[i]:human_offsets[i+1]]
        role={1:'walk',2:'run',10:'attack'}.get(int(label),'other')
        digest=hashlib.sha256(motion.tobytes()).hexdigest()
        if digest in seen:
            if seen[digest]!=role:raise ValueError('Conflicting external motion labels')
            duplicates+=1;continue
        seen[digest]=role;counts[role]+=1;p,phase=resample_motion(motion)
        # The archive has no timing metadata. These are timing augmentations, NOT asserted true FPS.
        for fps in (13.,15.,20.,30.):
            xs.append(encode(p,phase/fps));ys.append(ROLES.index(role));parts.append('train');ids.append(f'humanact12:{i}');subjects.append('humanact12_training_only')
        if i%50==0:trainer.status('准备扩充数据',current=i,total=len(human_labels),external_clips=sum(counts.values()),epochs=150,epoch=0)
    arrays=dict(x=np.array(xs),y=np.array(ys),part=np.array(parts),id=np.array(ids),subject=np.array(subjects))
    if not np.isfinite(arrays['x']).all():raise ValueError('Nonfinite expanded features')
    # No exact feature content may occur in both training and held-out data.
    signatures={}
    for x,part in zip(arrays['x'],arrays['part']):
        h=hashlib.sha256(x.tobytes()).hexdigest()
        if h in signatures and signatures[h]!=part:raise ValueError('Feature duplication across splits')
        signatures[h]=part
    np.savez_compressed(OUT/'training_arrays.npz',**arrays)
    baseline_split=json.loads((old/'split_manifest.json').read_text(encoding='utf-8'))
    split=dict(baseline_split,baseline_run='run_v2',test_policy='Exactly the same 54 CMU clips as run_v2; external data training only',
               excluded_negative_labels=sorted(excluded),humanact12_training_clips=dict(counts),humanact12_duplicates_removed=duplicates,
               timing_policy='External FPS not provided: 13/15/20/30 FPS timing augmentation; do not claim measured duration',
               counts={part:dict(Counter(ROLES[int(y)] for y,p in zip(arrays['y'],arrays['part']) if p==part)) for part in ('train','validation','test')})
    (OUT/'split_manifest.json').write_text(json.dumps(split,indent=2),encoding='utf-8')
    manifest=dict(cmu_source_manifest_sha256=hashlib.sha256((old/'dataset_manifest.json').read_bytes()).hexdigest(),humanact12=human_manifest,
                  real_external_clips=sum(counts.values()),cmu_unique_clips=308,temporal_augmentation_not_new_independent_data=True)
    (OUT/'dataset_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    trainer.status('扩充数据准备完成',current=len(human_labels),total=len(human_labels),external_clips=sum(counts.values()),training_examples=len(xs))
    print('EXPANDED_DATA_READY',sum(counts.values()),dict(counts),split['counts'],flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--epochs',type=int,default=150);parser.add_argument('--run',type=Path);args=parser.parse_args()
    if args.run:
        run=args.run.resolve()
        if (run/'evaluation.json').exists():raise ValueError('Expanded experiment already evaluated; choose a new experiment')
    else:
        number=1
        while (OUT/f'run_v{number}'/'evaluation.json').exists():number+=1
        run=OUT/f'run_v{number}'
    trainer.DATA=OUT;trainer.RUN=run
    trainer.STATUS.write_text(json.dumps(dict(stage='准备扩充训练',complete=False,epoch=0,epochs=args.epochs,updated_at=time.time(),pid=os.getpid(),run=str(run))),encoding='utf-8')
    if os.name=='nt' and os.environ.get('GASP_POSE_PROGRESS_OPENED')!='1':subprocess.Popen([str(Path(sys.executable).with_name('pythonw.exe')),str(Path(__file__).resolve().parents[1]/'ui/PoseTrainProgress.py')],cwd=ROOT)
    try:
        prepare();trainer.train(args.epochs)
        path=run/'evaluation.json';report=json.loads(path.read_text(encoding='utf-8'))
        report['limitations']=['Fixed CMU test reused only as regression evaluation, not a new blind test','HumanAct12 used for training only; no exposed performer IDs','External frame rate absent; augmented rather than treated as ground truth','No passive hit/idle/crouch/sprint classifier','No labeled UE-domain evaluation']
        report['expansion_source']=str(OUT/'dataset_manifest.json');path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    except Exception as exc:trainer.status('失败',complete=False,error=str(exc));raise


if __name__=='__main__':main()
