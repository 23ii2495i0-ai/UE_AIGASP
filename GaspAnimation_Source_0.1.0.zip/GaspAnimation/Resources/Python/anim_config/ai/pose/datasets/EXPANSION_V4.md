# 姿态数据扩充 V4

新增数据放在 `artifacts/anim_config/models/pose/datasets/expansion_v4`。

来源：ACCAD / Ohio State University Male2 BVH，CC BY 3.0，署名 Open Motion Project, ACCAD / The Ohio State University；Quaternius Ultimate Animated Character、LowPoly Animated Knight、Ultimate Platformer Pack，作者明确提供 CC0。

原始下载、来源链接与文件哈希保留在 source。作者标签用于离线监督；没有声称经过用户逐条人工确认。训练模型只输入数字姿态，不输入文件名。

检查 196 个独立候选动作，保留 145：攻击 42、受击 2、行走 16、跑步 17、跳跃 5、其他 63。排除 3 个重复、48 个混合或未明确分类动作。额外四个 Ultimate Character 外观及 Platformer Gun 外观共用原动作，不重复计入。没有发现静止动作通过此轮过滤。格挡、闪避、躲避是其他类别，不是受击。受击新增 RecieveHit、HitReact 两个独立作者动作；平台人物为风格化双足角色。

`review/` 下按标签提供原始 BVH 和立即可播放的 Blender 单动作文件。`cleaning_report.json` 是最终取舍清单，包含排除原因；保留文件不等于自动入训。

处理顺序：fetch_pose_expansion.py；fetch_combat_animations.py --expansion；Blender 运行 inspect_expansion_blender.py、extract_expansion_blender.py；prepare_pose_expansion.py。ACCAD BVH 原始地址：https://accad.osu.edu/sites/accad.osu.edu/files/Male2_bvh.zip 。训练前验证数字有限、骨骼有效、关键点移动、动作重复；训练阶段检查跨分区重复。FBX 按源时间采样 65 个姿态，随后插值到公共稀疏窗口；不把这些采样/插值当成新增数据。

重训：环境变量 GASP_POSE_EXPANSION=1，运行 pose/training/train_pose_temporal.py --epochs 1000 --accept-retained。沿用上一轮用户已保留的审核清单，新增数据全部仅用于训练；原验证、测试 ID 与标签逐项锁定检查。输出到 experiments/expanded_combat_v4，新模型不自动上线。窗口显示所有六类召回率及支持数量。结果只作为已查看测试集上的回归比较。

受击训练数据从 2 增至 4，验证仅 1、测试仅 2，仍然严重不足，不能据此声称解决受击识别。攻击从 175 增至 217；新增独立动作总数比原始下载角色数更有意义。继续扩大受击数据需要更多有明确许可的独立反应片段，或用户自有可用于训练的动画。Mixamo 不作为训练来源，其附加条款限制机器学习用途。
