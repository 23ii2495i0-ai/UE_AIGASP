"""Pinned CMU BVH subset; labels come from the published annotation index, not asset names."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import hashlib,json,re,urllib.request,random,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=_LAYOUT_REPO
OUT=ROOT/'artifacts/anim_config/models/pose/experiments/cmu_humanact12/source'
REV='09a07f54f3bbb58797325f009282d0b2048a2871'
BASE=f'https://raw.githubusercontent.com/una-dinosauria/cmu-mocap/{REV}/'

def label(text):
    text=text.lower().strip()
    if re.fullmatch(r'boxing|punch/strike|punch(?:ing)?(?: and kick| kick)?|kicking|front kick|kick|(?:left_)?punch_sequence\d*|(?:left_)?front_kicking\d*',text):return 'attack'
    if re.search(r'jump|kick|punch|dance|basket|vignette|then| to | and |squat|stretch|crouch|wound|hurt|limp|sneak|duck|stumble|start|stop',text):return None
    if re.search(r'\b(?:run|running|jog)\b',text) or text.startswith('running'):return 'run'
    if re.search(r'\bwalk(?:ing)?\b',text):return 'walk'
    return None

def fetch(path,expected=None):
    dest=OUT/path;dest.parent.mkdir(parents=True,exist_ok=True)
    for attempt in range(3):
        try:
            if dest.exists():data=dest.read_bytes()
            else:
                data=urllib.request.urlopen(BASE+path,timeout=60).read()
                dest.write_bytes(data)
            blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            if expected and blob!=expected:raise ValueError('Git blob hash mismatch: '+path)
            return dict(path=path,url=BASE+path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=blob)
        except Exception:
            if attempt==2:raise
            time.sleep(1)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    for name in ('README.md','READMEFIRST.txt','cmu-mocap-index-text.txt'):fetch(name)
    tree=json.load(urllib.request.urlopen(f'https://api.github.com/repos/una-dinosauria/cmu-mocap/git/trees/{REV}?recursive=1',timeout=60))
    if tree.get('truncated'):raise ValueError('Incomplete source tree')
    files={Path(e['path']).stem:e for e in tree['tree'] if e['path'].endswith('.bvh')}
    rows=[];other=[]
    for line in (OUT/'cmu-mocap-index-text.txt').read_text(encoding='utf-8').splitlines():
        m=re.match(r'^(\d+_\d+)\s+(.+)',line)
        if not m or m[1] not in files:continue
        ident,description=m.groups();role=label(description)
        row=dict(id=ident,subject=ident.split('_')[0],annotation=description,role=role,source=files[ident])
        if role:rows.append(row)
        elif re.search(r'dance|jump|golf|basketball|wash|swim|climb|cartwheel|sit|throw',description,re.I):row['role']='other';other.append(row)
    rng=random.Random(42);selected=[]
    for role,cap in (('walk',100),('run',90),('attack',80),('other',100)):
        candidates=[r for r in rows if r['role']==role] if role!='other' else other
        rng.shuffle(candidates);selected.extend(candidates[:cap])
    def download(row):
        meta=fetch(row['source']['path'],row['source']['sha'])
        return dict(row,download=meta)
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=[]
        for row in pool.map(download,selected):
            results.append(row)
            if len(results)%20==0:print('MOTION_DOWNLOAD',len(results),'/',len(selected),flush=True)
    manifest=dict(schema=1,repository='una-dinosauria/cmu-mocap',revision=REV,
                  original='http://mocap.cs.cmu.edu/',terms='READMEFIRST.txt',
                  label_source='cmu-mocap-index-text.txt',label_policy='conservative annotation mapping; multi-action clips excluded from known classes',
                  limitations=['No explicit passive hit labels','idle/crouch/sprint lack adequate independent subject coverage'],files=results)
    (OUT.parent/'dataset_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DOWNLOAD_COMPLETE',len(results),{r:sum(x['role']==r for x in results) for r in ('walk','run','attack','other')})
if __name__=='__main__':main()
