"""Author-hosted ACCAD CC-BY and Quaternius CC0 motion sources, with hashes."""
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/'project_paths.py').is_file())))
from project_paths import REPO
import hashlib,json,re,urllib.request

OUT=REPO/'artifacts/anim_config/models/pose/datasets/expansion_v4/source'


def listing(folder):
    raw=urllib.request.urlopen('https://drive.google.com/drive/folders/'+folder,timeout=60).read().decode()
    text=raw.replace('\\x22','"').replace('\\x5b','[').replace('\\x5d',']').replace('\\/','/')
    rows=re.findall(r'\["([\w-]{20,})",\["[\w-]+"\],"([^"]+)","([^"]+)"',text)
    return list(dict.fromkeys(rows))


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    rows=listing('1zn_PeKyQwPhgAggaoJZJFpLB2DQrr86U')
    print('AUTHOR_FBX_FILES',rows,flush=True)
    (OUT/'quaternius_fbx_listing.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    for ident,name,mime in rows:
        if name not in ('BaseCharacter.fbx','Elf.fbx','Goblin_Male.fbx','Ninja_Male.fbx','Wizard.fbx'):continue
        path=OUT/'quaternius_ultimate'/name;path.parent.mkdir(exist_ok=True)
        url=f'https://drive.usercontent.google.com/download?id={ident}&export=download&confirm=t'
        if not path.exists():
            raw=urllib.request.urlopen(url,timeout=60).read()
            if not raw.startswith(b'Kaydara FBX Binary') and not raw.lstrip().startswith(b'; FBX'):raise ValueError('Expected FBX: '+name+' '+repr(raw[:80]))
            path.write_bytes(raw)
        print('FETCH_FBX',name,path.stat().st_size,flush=True)
    manifest=dict(quaternius=dict(page='https://quaternius.com/packs/ultimatedanimatedcharacter.html',license='CC0',folder='1zn_PeKyQwPhgAggaoJZJFpLB2DQrr86U'),accad=dict(page='https://accad.osu.edu/research/motion-lab/mocap-system-and-data',license='CC BY 3.0',attribution='Open Motion Project, ACCAD / The Ohio State University'),files={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.suffix.lower() in ('.fbx','.zip')})
    (OUT/'source_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')


if __name__=='__main__':main()
