"""Clean new author-labelled motions; preserve previous evaluation partitions."""
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/'project_paths.py').is_file())))
from project_paths import REPO,configure_imports
configure_imports()
import json,hashlib,re,zipfile
from pathlib import Path
from collections import Counter
import numpy as np
from pose_content_model import parse_bvh,bvh_positions
from pose_temporal import features,window_times,padded_bag
OUT=REPO/'artifacts/anim_config/models/pose/datasets/expansion_v4'

def accad_label(name):
    if '_Extended_' in name or '_Form_' in name:return 'unknown'
    action=Path(name).stem.split('_',2)[-1]
    if re.search(r'Jab|Cross|Hook|Uppercut|Backfist|Kick|kick|Roundhouse|Crescent|Capoeira',action):return 'attack'
    if action in ('Walk','WalkBackwards','WalkWithBox') or action.startswith('WalkTurn'):return 'walk'
    if action in ('Run','RunBackwards','RunWithBox','RunChangeDirection') or action.startswith('RunTurn'):return 'run'
    if any(word in action for word in ('To','Extended','Form','Hop','Leap','Jump')):return 'unknown'
    return 'other'

def main():
    rows=[];xs=[];masks=[];seen={}
    def add(row,positions,times,windows):
        p=np.asarray(positions);t=np.asarray(times)
        if not np.isfinite(p).all() or not np.isfinite(t).all():row['status']='invalid'
        elif np.max(np.linalg.norm(p-p[:1],axis=-1))<1e-5:row['status']='static'
        elif row['label']=='unknown':row['status']='mixed_unlabelled'
        else:
            # Scale/root/rotation-invariant motion signature; skin variants never form new examples.
            signature=hashlib.sha256(np.round(windows[0][:,:55],3).tobytes()).hexdigest()
            if signature in seen:row.update(status='duplicate',duplicate_of=seen[signature])
            else:
                row['status']='retained';seen[signature]=row['id'];x,m=padded_bag(windows);row['array_index']=len(xs);xs.append(x);masks.append(m)
        rows.append(row)
    with zipfile.ZipFile(OUT/'source/accad_male2.zip') as z:
        for name in sorted(z.namelist()):
            if not name.endswith('.bvh'):continue
            raw=z.read(name);nodes,data,dt=parse_bvh(raw.decode());end=(len(data)-1)*dt;windows=[]
            for t in window_times(0,end):
                phase=t/dt;lo=np.floor(phase).astype(int);hi=np.minimum(lo+1,len(data)-1)
                p=bvh_positions(nodes,data,lo);q=bvh_positions(nodes,data,hi);windows.append(features(p+(q-p)*(phase-lo)[:,None,None],t))
            idx=np.linspace(0,len(data)-1,65).astype(int);p=bvh_positions(nodes,data,idx);label=accad_label(name)
            target=OUT/'review'/label/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
            add(dict(id='accad_male2:'+Path(name).stem,label=label,split='train',source='ACCAD Male2',file=str(target),sha256=hashlib.sha256(raw).hexdigest(),annotation=Path(name).stem,license='CC BY 3.0',attribution='Open Motion Project, ACCAD / The Ohio State University'),p,idx*dt,windows)
    for row in json.loads((OUT/'fbx_landmarks.json').read_text()):
        p=np.array(row.pop('positions'));t=np.array(row.pop('times'));windows=[]
        for times in window_times(t[0],t[-1]):
            sampled=np.stack([np.stack([np.interp(times,t,p[:,b,a]) for a in range(3)],-1) for b in range(11)],1)
            windows.append(features(sampled,times))
        row['license']='CC0';row['timing']='FBX source seconds, 65 evaluation poses';add(row,p,t,windows)
    np.savez_compressed(OUT/'cleaned_bags.npz',x=np.array(xs),mask=np.array(masks))
    report=dict(rows=rows,status_counts=dict(Counter(r['status'] for r in rows)),retained_counts=dict(Counter(r['label'] for r in rows if r['status']=='retained')),split_policy='All new sources train-only; existing validation and test unchanged. No claim of a new blind evaluation.',limitations=['Only two new independently authored hit reactions; hit remains severely underrepresented.','Platformer character is stylized biped; not evidence of UE domain performance.','Author category labels, not independently human-verified semantics.'])
    (OUT/'cleaning_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
