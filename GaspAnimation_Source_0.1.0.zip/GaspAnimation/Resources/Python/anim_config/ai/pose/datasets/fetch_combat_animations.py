"""Fetch the author's free CC0 Quaternius animation archives (no paid uploads)."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse, hashlib, http.cookiejar, json, re, urllib.parse, urllib.request, zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT = _LAYOUT_REPO
OUT = ROOT / 'artifacts/anim_config/models/pose/experiments/combat_v1/source'


def main():
    global OUT
    parser = argparse.ArgumentParser(); parser.add_argument('--inspect', action='store_true'); parser.add_argument('--expansion',action='store_true'); args = parser.parse_args()
    if args.expansion:OUT=ROOT/'artifacts/anim_config/models/pose/datasets/expansion_v4/source'
    OUT.mkdir(parents=True, exist_ok=True)
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    sources = [('quaternius', 'universal-animation-library'), ('quaternius', 'universal-animation-library-2'), ('kaylousberg', 'kaykit-character-animations')]
    if args.expansion:sources=[('quaternius','lowpoly-animated-knight'),('quaternius','ultimate-platformer-pack')]
    for author, slug in sources:
        url = 'https://' + author + '.itch.io/' + slug
        if (OUT / (slug + '.zip')).exists() and (OUT / (slug + '.json')).exists():
            print('CACHED', slug, flush=True); continue
        page = opener.open(url, timeout=60).read().decode()
        (OUT / (slug + '.html')).write_text(page, encoding='utf-8')
        if args.inspect:
            print(slug, re.findall(r'title="([^"]+\.zip)"', page), flush=True)
            continue
        token = re.search(r'name="csrf_token" value="([^"]+)"', page)[1]
        request = urllib.request.Request(url + '/download_url', data=urllib.parse.urlencode({'csrf_token': token}).encode(), headers={'Referer': url, 'X-Requested-With': 'XMLHttpRequest'})
        reply = json.load(opener.open(request, timeout=60))
        download_page = opener.open(reply['url'], timeout=60).read().decode()
        (OUT / (slug + '_download.html')).write_text(download_page, encoding='utf-8')
        uploads = re.findall(r'data-upload_id="(\d+)"', download_page)
        if len(uploads) != 1:
            raise ValueError('Expected exactly one free upload')
        download_token = re.search(r'name="csrf_token" value="([^"]+)"', download_page)[1]
        request = urllib.request.Request(url + '/file/' + uploads[0], data=urllib.parse.urlencode({'csrf_token': download_token}).encode(), headers={'Referer': reply['url'], 'X-Requested-With': 'XMLHttpRequest'})
        file_reply = json.load(opener.open(request, timeout=60))
        archive = OUT / (slug + '.zip')
        if not archive.exists():
            partial = archive.with_suffix('.partial')
            with opener.open(file_reply['url'], timeout=60) as response, partial.open('wb') as stream:
                size = int(response.headers.get('Content-Length', 0)); done = 0
                while block := response.read(1024 * 1024):
                    stream.write(block); done += len(block)
                    print('COMBAT_DOWNLOAD', slug, done, '/', size, flush=True)
                if size and size != done: raise ValueError('Incomplete archive')
            partial.replace(archive)
        with zipfile.ZipFile(archive) as z:
            print(slug, z.namelist()[:80], flush=True)
        manifest = dict(author=author, page=url, license='CC0', upload_id=uploads[0], sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
        archive.with_suffix('.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')


if __name__ == '__main__': main()
