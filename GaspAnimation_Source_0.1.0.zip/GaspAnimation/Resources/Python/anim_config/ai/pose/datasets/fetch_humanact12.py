"""Download the author-linked HumanAct12 release; read numeric pickle using an allowlist."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import hashlib,io,json,pickle,tarfile,time,urllib.request
from pathlib import Path
import numpy as np
ROOT=_LAYOUT_REPO
OUT=ROOT/'artifacts/anim_config/models/pose/experiments/cmu_humanact12/humanact12'
STATUS=ROOT/'artifacts/anim_config/models/pose/experiments/cmu_humanact12/training_status.json'
URL='https://drive.usercontent.google.com/download?id=1130gHSvNyJmii7f6pv5aY5IyQIWc3t7R&export=download&confirm=t'


def status(stage,**fields):
    data=dict(stage=stage,complete=False,epoch=0,epochs=150,updated_at=time.time(),**fields)
    p=STATUS.with_suffix('.download');p.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');p.replace(STATUS)


class NumericUnpickler(pickle.Unpickler):
    def find_class(self,module,name):
        allowed={('numpy','ndarray'),('numpy','dtype')}
        allowed|={(m,n) for m in ('numpy.core.multiarray','numpy._core.multiarray') for n in ('_reconstruct','scalar')}
        allowed|={(m,'_frombuffer') for m in ('numpy.core.numeric','numpy._core.numeric')}
        if (module,name) not in allowed:raise ValueError('Blocked pickle global: '+module+'.'+name)
        return super().find_class(module,name)


def load_numeric(data):return NumericUnpickler(io.BytesIO(data)).load()


def main():
    OUT.mkdir(parents=True,exist_ok=True);archive=OUT/'HumanAct12Poses.tar.gz'
    if not archive.exists():
        temp=archive.with_suffix('.partial');done=0;tick=time.monotonic()
        with urllib.request.urlopen(URL,timeout=60) as response,temp.open('wb') as stream:
            size=int(response.headers.get('Content-Length',0))
            while block:=response.read(1024*1024):
                stream.write(block);done+=len(block)
                if time.monotonic()-tick>1:
                    status(f'下载 HumanAct12：{done/1e6:.1f} / {size/1e6:.1f} MB',download_bytes=done,download_total=size);tick=time.monotonic()
            if size and done!=size:raise ValueError('Incomplete archive')
        temp.replace(archive)
    status('校验和读取 HumanAct12 骨骼数据')
    with tarfile.open(archive,'r:gz') as tar:
        candidates=[m for m in tar.getmembers() if m.name.endswith('/humanact12poses.pkl') or m.name=='humanact12poses.pkl']
        if len(candidates)!=1 or not candidates[0].isfile() or candidates[0].size>512*1024*1024:raise ValueError('Unexpected dataset archive')
        raw=tar.extractfile(candidates[0]).read();data=load_numeric(raw)
    if not isinstance(data,dict) or not {'joints3D','y'}<=set(data):raise ValueError('Invalid HumanAct12 schema')
    joints=data['joints3D'];labels=data['y'];offsets=[0];blocks=[]
    if len(joints)!=len(labels):raise ValueError('Label count mismatch')
    short=[]
    for i,(motion,label) in enumerate(zip(joints,labels)):
        x=np.asarray(motion,dtype=np.float32)
        if x.ndim!=3 or x.shape[1:]!=(24,3) or not 2<=len(x)<=10000 or not np.isfinite(x).all() or not 0<=int(label)<12:raise ValueError('Invalid numeric motion '+str(i))
        if len(x)<16:short.append(i)
        blocks.append(x);offsets.append(offsets[-1]+len(x))
    np.savez_compressed(OUT/'joints.npz',positions=np.concatenate(blocks),offsets=np.array(offsets),labels=np.array(labels,dtype=np.int64))
    manifest=dict(source_url=URL,author_link='https://github.com/Mathux/ACTOR/blob/master/prepare/download_datasets.sh',dataset_author='https://github.com/EricGuo5513/action-to-motion',
                  archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),payload_sha256=hashlib.sha256(raw).hexdigest(),arrays_sha256=hashlib.sha256((OUT/'joints.npz').read_bytes()).hexdigest(),
                  count=len(labels),frames=offsets[-1],short_motion_ids=short,short_motion_policy='Interpolate existing time axis to 16 samples; do not claim extra independent frames',label_counts={str(i):int(sum(int(v)==i for v in labels)) for i in range(12)},keys=list(data),
                  limitations=['Release does not expose reliable performer IDs; use as training-only, no actor-disjoint HumanAct12 accuracy claim','boxing maps to active attack, not passive hit','Preserve upstream dataset terms; code license is not a substitute for data terms'])
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    status('HumanAct12 下载完成，准备扩充训练',download_clips=len(labels))
    print('HUMANACT12_READY',json.dumps(manifest))


if __name__=='__main__':
    try:main()
    except Exception as exc:status('失败',error=str(exc));raise
