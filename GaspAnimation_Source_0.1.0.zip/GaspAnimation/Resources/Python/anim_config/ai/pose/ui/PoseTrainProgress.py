"""Visible, read-only progress monitor for pose training. Closing it never cancels training."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,time,os,sys
from pathlib import Path
ROOT=_LAYOUT_REPO
STATUS=ROOT/'artifacts/anim_config/models/pose/experiments/cmu_humanact12/training_status.json'


def snapshot():
    try:return json.loads(STATUS.read_text(encoding='utf-8'))
    except (OSError,ValueError):return dict(stage='等待训练启动',epoch=0,epochs=100,complete=False)


def main():
    if '--snapshot' in sys.argv:print(json.dumps(snapshot(),ensure_ascii=False,indent=2));return
    import tkinter as tk
    from tkinter import ttk,messagebox
    window=tk.Tk();window.title('GASP 姿态识别训练进度');window.geometry('820x560');window.minsize(780,520)
    frame=ttk.Frame(window,padding=22);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='姿态内容识别 · 训练与独立评测',font=('Microsoft YaHei UI',16)).pack(anchor='w')
    ttk.Label(frame,text='每秒刷新。关闭本窗口不会停止训练；完成或失败时弹窗提示。').pack(anchor='w',pady=10)
    stage=ttk.Label(frame,font=('Microsoft YaHei UI',12));stage.pack(anchor='w',pady=8)
    bar=ttk.Progressbar(frame,maximum=100);bar.pack(fill='x',pady=8)
    detail=ttk.Label(frame,wraplength=710,justify='left');detail.pack(anchor='w',pady=8)
    footer=ttk.Label(frame,text='训练完成不代表已上线；未通过动作识别及 UE 域验证时，保持禁用自动绑定。',wraplength=710);footer.pack(anchor='w',pady=12)
    ttk.Button(frame,text='打开训练结果目录',command=lambda:os.startfile(str(STATUS.parent))).pack(anchor='e')
    notified=None
    def refresh():
        nonlocal notified
        s=snapshot();phase=s.get('stage','未知');epoch=s.get('epoch',0);epochs=s.get('epochs',100)
        preparing='准备' in phase and 'current' in s and 'total' in s
        if preparing:
            stage.config(text=f"{phase}  |  {s['current']} / {s['total']} 段")
            bar['maximum']=max(1,s['total']);bar['value']=s['current']
        else:
            stage.config(text=f"{phase}  |  {epoch} / {epochs} 轮")
            bar['maximum']=epochs;bar['value']=epoch
        lines=[]
        if preparing:lines.append(f"片段 {s.get('current',0)} / {s.get('total','?')}；剔除重复文件 {s.get('deduplicated',0)}")
        if preparing and 'external_clips' in s:lines.append(f"新增数据已处理 {s['external_clips']} 段（插值和时间增强不算新增独立样本）")
        if 'loss' in s:lines.append(f"训练损失 {s['loss']:.4f}；最佳验证集平衡准确率 {s.get('best_validation_balanced',0):.1%}")
        if s.get('complete') and 'test' in s:
            test=s['test'];precision=test.get('accepted_precision');value='无接受结果' if precision is None else f'{precision:.1%}'
            for role,name in [('walk','行走'),('run','跑步'),('other','其他')]:
                recall=test.get('recall',{}).get(role)
                if recall is not None:lines.append(f"{name}召回率 {recall:.1%}（测试 {test.get('support',{}).get(role,'?')} 段）")
            lines.append(f"测试总体准确率 {test['accuracy']:.1%}；攻击召回率 {test['recall']['attack']:.1%}\n接受结果正确率 {value}；接受覆盖率 {test['coverage']:.1%}（{test['accepted']} / {test['n']} 条）")
            if test['recall'].get('hit') is not None:
                lines.append(f"受击召回率 {test['recall']['hit']:.1%}（测试仅 {test.get('support',{}).get('hit','?')} 段，尚不足以验证泛化）")
            if test['recall'].get('jump') is not None:
                lines.append(f"跳跃召回率 {test['recall']['jump']:.1%}（{test.get('support',{}).get('jump','?')} 段）")
            if 'fixed_cmu_test' in s:
                fixed=s['fixed_cmu_test'];lines.append(f"原固定测试集攻击召回率 {fixed['recall']['attack']:.1%}；新增动画测试见结果报告")
            lines.append('已完成。当前为实验模型，尚未上线。')
        if 'error' in s:lines.append('错误：'+s['error'])
        if time.time()-s.get('updated_at',time.time())>120 and not s.get('complete'):lines.append('超过两分钟没有更新，请检查训练日志；不据此断言训练已退出。')
        detail.config(text='\n'.join(lines))
        key=(s.get('pid'),phase)
        if (s.get('complete') or phase=='失败') and notified!=key:
            notified=key;window.bell();window.deiconify();window.lift()
            (messagebox.showerror if phase=='失败' else messagebox.showinfo)('姿态识别训练'+('失败' if phase=='失败' else '完成'),'\n'.join(lines) or phase)
        window.after(1000,refresh)
    refresh();window.mainloop()


if __name__=='__main__':main()
