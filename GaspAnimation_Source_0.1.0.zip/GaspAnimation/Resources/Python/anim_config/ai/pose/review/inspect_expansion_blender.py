"""Inspect original CC0 FBX takes in a separate background Blender process."""
import bpy,json,sys,zipfile
from pathlib import Path
root=Path(sys.argv[sys.argv.index('--')+1]);rows=[]
for archive in (root/'source').glob('*.zip'):
    if archive.name=='accad_male2.zip':continue
    with zipfile.ZipFile(archive) as z:
        for member in z.namelist():
            if member.lower().endswith('.fbx') and ('character' in member.lower() or 'player' in member.lower()):
                target=root/'source/quaternius_ultimate'/(archive.stem+'_'+Path(member).name)
                target.write_bytes(z.read(member))
for path in sorted((root/'source/quaternius_ultimate').glob('*.fbx')):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.fbx(filepath=str(path),use_anim=True)
    rows.append(dict(file=path.name,bones=[[b.name for b in o.pose.bones] for o in bpy.data.objects if o.type=='ARMATURE'],fps=bpy.context.scene.render.fps,actions=[dict(name=a.name,range=list(a.frame_range)) for a in bpy.data.actions]))
(root/'fbx_inspection.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('INSPECTION',json.dumps(rows))
