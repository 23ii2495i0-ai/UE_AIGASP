"""Run in background Blender; inspect isolated FBX files without changing the user's scene."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import bpy,json,sys,zipfile
from pathlib import Path
from mathutils import Vector

args=sys.argv[sys.argv.index('--')+1:];source=Path(args[0]);out=Path(args[1]);out.mkdir(parents=True,exist_ok=True)
rows=[]
with zipfile.ZipFile(source) as z:
    for member in z.namelist():
        if not member.lower().endswith('.fbx'):continue
        path=out/Path(member).name;path.write_bytes(z.read(member))
        bpy.ops.wm.read_factory_settings(use_empty=True)
        bpy.ops.import_scene.fbx(filepath=str(path),use_anim=True)
        arms=[o for o in bpy.data.objects if o.type=='ARMATURE']
        actions=list(bpy.data.actions)
        ranges=[tuple(a.frame_range) for a in actions]
        start=min((r[0] for r in ranges),default=1);end=max((r[1] for r in ranges),default=1)
        takes=[]
        for action in actions:
            for arm in arms:
                arm.animation_data_create();arm.animation_data.action=action
                if action.slots:arm.animation_data.action_slot=action.slots[0]
            first,last=tuple(action.frame_range);transforms=[]
            for index in range(33):
                frame=first+(last-first)*index/32
                bpy.context.scene.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update()
                transforms.append([list((o.matrix_world@b.matrix).translation) for o in arms for b in o.pose.bones])
            movement=max(((Vector(a)-Vector(b)).length for frame in transforms[1:] for a,b in zip(frame,transforms[0])),default=0)
            takes.append(dict(action=action.name,frame_range=[first,last],max_joint_displacement=movement,has_motion=movement>1e-6))
            if movement>1e-6:
                # Save an immediately playable review scene with the reference mesh bound to this take.
                if not any(o.type=='MESH' for o in bpy.data.objects):
                    model=out/'characterMedium.fbx'
                    before=set(bpy.data.objects);bpy.ops.import_scene.fbx(filepath=str(model),use_anim=False)
                    imported=[o for o in bpy.data.objects if o not in before]
                    for arm in [o for o in imported if o.type=='ARMATURE']:
                        arm.animation_data_create();arm.animation_data.action=action
                        if action.slots:arm.animation_data.action_slot=action.slots[0]
                bpy.context.scene.frame_start=int(first);bpy.context.scene.frame_end=int(last);bpy.context.scene.frame_set(int(first))
                bpy.ops.wm.save_as_mainfile(filepath=str((out/(path.stem+'_playable.blend')).resolve()))
        row=dict(member=member,file=str(path),armatures=len(arms),bones=sum(len(o.pose.bones) for o in arms),actions=takes,frame_range=[start,end],has_motion=any(t['has_motion'] for t in takes))
        rows.append(row)
(out/'audit.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('FBX_AUDIT',json.dumps(rows))
