"""Apply confirmed retained files and explicit human CSV decisions before training."""
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/'project_paths.py').is_file())))
from project_paths import configure_imports
configure_imports()
import csv
from pathlib import Path
from motion_labels import ROLES


def load_review(path,accept_retained=False):
    selected={};excluded=[];pending=[]
    with Path(path).open(encoding='utf-8-sig',newline='') as stream:
        for row in csv.DictReader(stream):
            ident=row.get('training_id') or row['id'];decision=row.get('review_decision','').strip().lower()
            label=(row.get('corrected_label','').strip() or row['label']).lower()
            if decision in ('reject','剔除','删除','不通过') or row['status'] in ('duplicate','static','invalid') or not Path(row['file']).is_file():
                excluded.append(ident);continue
            if label not in ROLES:excluded.append(ident);continue
            if decision not in ('','pass','通过','保留'):raise ValueError('Unknown review decision: '+decision)
            if not decision and not accept_retained:pending.append(ident);continue
            if ident in selected and selected[ident]!=label:raise ValueError('Conflicting reviewed labels: '+ident)
            selected[ident]=label
    if pending:raise ValueError(f'{len(pending)} rows have no explicit decision; confirm retained files with --accept-retained')
    if not selected:raise ValueError('No reviewed motions remain')
    return selected,excluded
