"""Extract sparse world landmarks and playable per-take review scenes from CC0 FBX."""
import bpy,json,sys,hashlib
from pathlib import Path
root=Path(sys.argv[sys.argv.index('--')+1]);rows=[]
for filename in ['BaseCharacter.fbx','lowpoly-animated-knight_KnightCharacter.fbx','ultimate-platformer-pack_Character.fbx']:
    path=root/'source/quaternius_ultimate'/filename
    bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(path),use_anim=True)
    arm=next(o for o in bpy.data.objects if o.type=='ARMATURE');fps=bpy.context.scene.render.fps/bpy.context.scene.render.fps_base
    hand='Palm' if 'Palm.L' in arm.pose.bones else 'Fist'
    bones=['Hips','Torso','Head',hand+'.L',hand+'.R','Foot.L','Foot.R','LowerLeg.L','LowerLeg.R','LowerArm.L','LowerArm.R']
    for action in list(bpy.data.actions):
        name=action.name.split('|')[-1];lower=name.lower()
        # Mixed attack/locomotion remains unlabelled, never silently assigned to locomotion.
        if ('run' in lower or 'jump' in lower) and ('attack' in lower or 'shoot' in lower):label='unknown'
        elif lower in ('recievehit','hitreact'):label='hit'
        elif lower in ('punch','swordslash','shoot_onehanded','idle_shoot'):label='attack'
        elif lower.startswith('walk'):label='walk'
        elif lower.startswith('run'):label='run'
        elif lower.startswith('jump'):label='jump'
        else:label='other'
        arm.animation_data_create();arm.animation_data.action=action
        if action.slots:arm.animation_data.action_slot=action.slots[0]
        first,last=map(float,action.frame_range);times=[];positions=[]
        # 65 uniformly spaced poses, independent of source frame count; later windows interpolate.
        for i in range(65):
            frame=first+(last-first)*i/64;bpy.context.scene.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update()
            times.append((frame-first)/fps)
            points=[]
            for bone in bones:
                p=(arm.matrix_world@arm.pose.bones[bone].matrix).translation
                points.append([p.x,p.z,-p.y]) # Blender Z-up to the shared Y-up convention.
            positions.append(points)
        target=root/'review'/label/(path.stem+'_'+name+'.blend');target.parent.mkdir(parents=True,exist_ok=True)
        bpy.context.scene.frame_start=int(first);bpy.context.scene.frame_end=int(last);bpy.context.scene.frame_set(int(first))
        bpy.ops.wm.save_as_mainfile(filepath=str(target.resolve()))
        rows.append(dict(id='quaternius_legacy:'+path.stem+':'+name,label=label,times=times,positions=positions,file=str(target),source=str(path),animation=name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),fps=fps,split='train'))
(root/'fbx_landmarks.json').write_text(json.dumps(rows),encoding='utf-8')
print('EXTRACTED_TAKES',len(rows))
