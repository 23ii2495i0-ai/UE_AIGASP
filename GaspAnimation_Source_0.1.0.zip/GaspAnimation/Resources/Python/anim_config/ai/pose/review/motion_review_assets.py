"""Write self-contained, single-animation glTF assets for manual data inspection."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import copy,json,struct
import numpy as np


def glb_bytes(document,binary):
    text=json.dumps(document,separators=(',',':'),ensure_ascii=False).encode();text+=b' '*((-len(text))%4)
    binary+=b'\0'*((-len(binary))%4)
    return struct.pack('<4sII',b'glTF',2,28+len(text)+len(binary))+struct.pack('<II',len(text),0x4e4f534a)+text+struct.pack('<II',len(binary),0x004e4942)+binary


def single_animation(doc,binary,animation):
    d=copy.deepcopy(doc);d['animations']=[copy.deepcopy(animation)];used=set()
    for mesh in d.get('meshes',[]):
        for primitive in mesh['primitives']:
            used.update(primitive['attributes'].values())
            if 'indices' in primitive:used.add(primitive['indices'])
            for target in primitive.get('targets',[]):used.update(target.values())
    for skin in d.get('skins',[]):
        if 'inverseBindMatrices' in skin:used.add(skin['inverseBindMatrices'])
    for sampler in d['animations'][0]['samplers']:used.update((sampler['input'],sampler['output']))
    accessors=sorted(used);amap={old:new for new,old in enumerate(accessors)}
    views={d['accessors'][i]['bufferView'] for i in accessors}
    views.update(i['bufferView'] for i in d.get('images',[]) if 'bufferView' in i)
    vmap={old:new for new,old in enumerate(sorted(views))};new_binary=bytearray();new_views=[]
    for i in sorted(views):
        v=copy.deepcopy(d['bufferViews'][i]);offset=v.get('byteOffset',0);chunk=binary[offset:offset+v['byteLength']]
        new_binary.extend(b'\0'*((-len(new_binary))%4));v['byteOffset']=len(new_binary);v['buffer']=0;new_binary.extend(chunk);new_views.append(v)
    new_accessors=[copy.deepcopy(d['accessors'][i]) for i in accessors]
    for a in new_accessors:a['bufferView']=vmap[a['bufferView']]
    for mesh in d.get('meshes',[]):
        for primitive in mesh['primitives']:
            primitive['attributes']={k:amap[v] for k,v in primitive['attributes'].items()}
            if 'indices' in primitive:primitive['indices']=amap[primitive['indices']]
            for target in primitive.get('targets',[]):
                for key in target:target[key]=amap[target[key]]
    for skin in d.get('skins',[]):
        if 'inverseBindMatrices' in skin:skin['inverseBindMatrices']=amap[skin['inverseBindMatrices']]
    for sampler in d['animations'][0]['samplers']:
        sampler['input']=amap[sampler['input']];sampler['output']=amap[sampler['output']]
    for image in d.get('images',[]):
        if 'bufferView' in image:image['bufferView']=vmap[image['bufferView']]
    d.update(accessors=new_accessors,bufferViews=new_views,buffers=[dict(byteLength=len(new_binary))])
    return glb_bytes(d,bytes(new_binary))


SMPL_PARENTS=(-1,0,0,0,1,2,3,4,5,6,7,8,9,9,9,12,13,14,16,17,18,19,20,21)


def skeleton_preview(positions,name,fps=15.):
    """Keep original joint positions; sticks are visualization, not new motion samples."""
    p=np.asarray(positions,dtype=np.float32).copy();p-=p[0,0].copy()
    if p.ndim!=3 or p.shape[1:]!=(24,3) or len(p)<2:raise ValueError('Invalid SMPL preview')
    scale=float(np.median(np.linalg.norm(p[:,15]-p[:,7],axis=1)));radius=max(.002,scale*.012)
    binary=bytearray();views=[];accessors=[]
    def add(data,kind,component=5126):
        data=np.asarray(data,dtype='<f4' if component==5126 else '<u2');binary.extend(b'\0'*((-len(binary))%4));start=len(binary);binary.extend(data.tobytes());vi=len(views);views.append(dict(buffer=0,byteOffset=start,byteLength=data.nbytes))
        a=dict(bufferView=vi,componentType=component,count=len(data),type=kind)
        if component==5126:a.update(min=np.atleast_1d(data.min(axis=0)).tolist(),max=np.atleast_1d(data.max(axis=0)).tolist())
        accessors.append(a);return len(accessors)-1
    vertices=np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],dtype=np.float32)
    indices=np.array([0,2,4,2,1,4,1,3,4,3,0,4,2,0,5,1,2,5,3,1,5,0,3,5],dtype=np.uint16)
    pos=add(vertices,'VEC3');ind=add(indices,'SCALAR',5123)
    # A narrow rectangular bone along +Z, reused by every joint pair.
    bone=np.array([[x,y,z] for z in (0,1) for x,y in ((-1,-1),(1,-1),(1,1),(-1,1))],dtype=np.float32)
    bi=add(np.array([0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,1,5,6,1,6,2,2,6,7,2,7,3,3,7,4,3,4,0],dtype=np.uint16),'SCALAR',5123);bp=add(bone,'VEC3')
    meshes=[dict(primitives=[dict(attributes=dict(POSITION=pos),indices=ind,material=0)]),dict(primitives=[dict(attributes=dict(POSITION=bp),indices=bi,material=0)])]
    times=add(np.arange(len(p),dtype=np.float32)/fps,'SCALAR');nodes=[];samplers=[];channels=[]
    def animate(node,path,values,kind):
        value=add(values,kind);sampler=len(samplers);samplers.append(dict(input=times,output=value,interpolation='LINEAR'));channels.append(dict(sampler=sampler,target=dict(node=node,path=path)))
    for j in range(24):
        node=len(nodes);nodes.append(dict(name=f'joint_{j}',mesh=0,translation=p[0,j].tolist(),scale=[radius]*3));animate(node,'translation',p[:,j],'VEC3')
    for j,parent in enumerate(SMPL_PARENTS):
        if parent<0:continue
        direction=p[:,j]-p[:,parent];length=np.linalg.norm(direction,axis=1);u=direction/np.maximum(length[:,None],1e-8)
        q=np.stack([-u[:,1],u[:,0],np.zeros(len(u)),1+u[:,2]],axis=1);bad=np.linalg.norm(q,axis=1)<1e-6;q[bad]=[1,0,0,0];q/=np.maximum(np.linalg.norm(q,axis=1)[:,None],1e-8)
        node=len(nodes);nodes.append(dict(name=f'bone_{parent}_{j}',mesh=1,translation=p[0,parent].tolist()))
        animate(node,'translation',p[:,parent],'VEC3');animate(node,'rotation',q,'VEC4');animate(node,'scale',np.stack([np.full(len(p),radius*.45),np.full(len(p),radius*.45),length],axis=1),'VEC3')
    d=dict(asset=dict(version='2.0',generator='GASP numerical motion review'),scene=0,scenes=[dict(nodes=list(range(len(nodes))))],nodes=nodes,meshes=meshes,materials=[dict(doubleSided=True,pbrMetallicRoughness=dict(baseColorFactor=[.12,.4,.85,1],metallicFactor=0,roughnessFactor=.8))],animations=[dict(name=name,samplers=samplers,channels=channels)],buffers=[dict(byteLength=len(binary))],bufferViews=views,accessors=accessors,extras=dict(original_joint_positions=True,display_fps=fps,actual_fps_unknown=True,preview_only=True))
    return glb_bytes(d,bytes(binary))
