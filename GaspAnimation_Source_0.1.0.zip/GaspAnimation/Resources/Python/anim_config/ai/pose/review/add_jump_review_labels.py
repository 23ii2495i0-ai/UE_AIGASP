"""Migrate existing review folders in place, preserving human CSV decisions and original splits."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import csv,json,shutil
from collections import Counter
from clean_motion_dataset import OUT,LABELS
from motion_labels import ROLES,with_jump


def main():
    root=(OUT/'cleaned').resolve();report_path=root/'cleaning_report.json';csv_path=root/'人工审核.csv'
    report=json.loads(report_path.read_text(encoding='utf-8'))
    with csv_path.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream);fields=reader.fieldnames;records=list(reader)
    by_id={r['id']:r for r in records};changes=[]
    for row in report['rows']:
        record=by_id[row['id']]
        if record.get('corrected_label','').strip() or record.get('review_decision','').strip():continue
        label=with_jump(row['source'],row['source_label'],row['label'])
        if label==row['label']:continue
        before=row['label'];path=__import__('pathlib').Path(row['file']).resolve()
        if not path.is_relative_to(root):raise ValueError('Review source outside expected folder')
        relative=path.relative_to(root);target=root/relative.parts[0]/LABELS[label]/__import__('pathlib').Path(*relative.parts[2:])
        if target.exists():raise ValueError('Destination exists: '+str(target))
        target.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(path),str(target))
        row.update(label=label,file=str(target));record.update(label=label,file=str(target));changes.append(dict(id=row['id'],previous=before,label=label))
    report['by_label']={k:dict(Counter(r['status'] for r in report['rows'] if r['label']==k)) for k in LABELS}
    report['roles']=ROLES;report['jump_label_changes']=changes
    report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with csv_path.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader();writer.writerows(records)
    (root/'跳跃标注说明.txt').write_text('jump 是独立类别。起跳、腾空、落地子片段暂统一归 jump，需人工核对上下文。\n腾空攻击仍归 attack；跑跳混合、篮球跳投等不明确片段转 unknown 待复核。\nHumanAct12 跳跃仅用于训练，原分组不变，不能把增强副本放入验证或测试。\n审核表 corrected_label 支持 jump；未启动新训练。\n',encoding='utf-8')
    print('JUMP_LABELS',len(changes),report['by_label'].get('jump'))


if __name__=='__main__':main()
