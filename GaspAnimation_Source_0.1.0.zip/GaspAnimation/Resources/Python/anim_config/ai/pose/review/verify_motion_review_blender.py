"""Background Blender smoke check: review exports must import and actually animate."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import bpy,json,sys
from pathlib import Path
from mathutils import Vector

root=Path(sys.argv[sys.argv.index('--')+1]).resolve();data=json.loads((root/'cleaning_report.json').read_text(encoding='utf-8'));results=[]
targets=[('HumanAct12','attack'),('universal-animation-library','hit'),('kaykit-character-animations','hit'),('Kenney','run')]
for source,label in targets:
    row=next(r for r in data['rows'] if r['source']==source and r['label']==label and r['status']=='moving');path=Path(row['file'])
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if path.suffix=='.blend':bpy.ops.wm.open_mainfile(filepath=str(path),load_ui=False,use_scripts=False)
    else:bpy.ops.import_scene.gltf(filepath=str(path))
    actions=list(bpy.data.actions);start=min(a.frame_range[0] for a in actions);end=max(a.frame_range[1] for a in actions)
    poses=[]
    for index in range(17):
        frame=start+(end-start)*index/16;bpy.context.scene.frame_set(int(frame),subframe=frame-int(frame));bpy.context.view_layer.update()
        poses.append([list((o.matrix_world@b.matrix).translation) for o in bpy.data.objects if o.type=='ARMATURE' for b in o.pose.bones]+[list(o.matrix_world.translation) for o in bpy.data.objects if o.type=='MESH'])
    displacement=max(((Vector(p)-Vector(q)).length for pose in poses[1:] for p,q in zip(pose,poses[0])),default=0)
    results.append(dict(id=row['id'],file=str(path),actions=len(actions),frame_range=[start,end],max_displacement=displacement,moves=displacement>1e-6))
(root/'blender_verification.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('BLENDER_REVIEW_VERIFY',json.dumps(results))
if not all(r['moves'] for r in results):raise RuntimeError('Review asset did not animate')
