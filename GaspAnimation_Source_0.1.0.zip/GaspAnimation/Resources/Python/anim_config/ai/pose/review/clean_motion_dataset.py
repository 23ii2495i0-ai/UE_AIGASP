"""Non-destructive motion audit and per-label Blender review export; no automatic retraining."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,csv,hashlib,json,re,shutil,zipfile
from collections import Counter
from pathlib import Path
import numpy as np
from pose_content_model import parse_bvh,bvh_positions
from gltf_motion import load_glb,sample,duration,accessor
from motion_review_assets import single_animation,skeleton_preview
from motion_labels import with_jump

ROOT=_LAYOUT_REPO;BASE=ROOT/'artifacts/anim_config';OUT=BASE/'models/pose/review'
LABELS={'walk':'walk_行走','run':'run_跑步','attack':'attack_攻击','hit':'hit_受击','jump':'jump_跳跃','other':'other_其他','unknown':'unknown_未标注'}


def motion_quality(positions,track_changes=True):
    p=np.asarray(positions,dtype=np.float64)
    if p.ndim!=3 or p.shape[-1]!=3 or len(p)<2 or not np.isfinite(p).all():return dict(status='invalid',reason='invalid_or_nonfinite_positions')
    scale=float(np.median(np.linalg.norm(p.max(axis=1)-p.min(axis=1),axis=1)))
    if scale<=1e-8:return dict(status='invalid',reason='degenerate_skeleton')
    displacement=float(np.max(np.linalg.norm(p-p[0],axis=-1))/scale)
    relative=p-p[:,:1];articulation=float(np.max(np.linalg.norm(relative-relative[0],axis=-1))/scale)
    if displacement<=1e-5 and not track_changes:status='static'
    elif articulation<.003:status='low_motion'
    else:status='moving'
    return dict(status=status,normalized_displacement=displacement,normalized_articulation=articulation,track_changes=bool(track_changes),scale=scale)


def audit_times(start,end):
    # Include jittered times to avoid mistaking exact loop periods for a static sequence.
    if end<start:raise ValueError('Invalid animation range')
    if end==start:return np.array([start,start])
    return np.unique(np.r_[np.linspace(start,end,65),start+(end-start)*np.random.default_rng(42).random(17)])


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=OUT/'cleaned');args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    rows=[];seen={}
    def save(ident,label,split,source,quality,payload,extension,original_label=None,training_id=None):
        label=with_jump(source,original_label or label,label)
        digest=hashlib.sha256(payload).hexdigest();status=quality['status'];duplicate=seen.get(digest)
        if duplicate:status='duplicate'
        else:seen[digest]=ident
        category={'moving':'01_按标签检查','low_motion':'02_小幅运动待复核','static':'03_已过滤静止','invalid':'04_解析异常待复核','duplicate':'05_重复资源'}[status]
        folder=out/category/LABELS[label]/source;folder.mkdir(parents=True,exist_ok=True)
        filename=re.sub(r'[^\w.-]+','_',ident)+extension;path=folder/filename;path.write_bytes(payload)
        rows.append(dict(id=ident,training_id=training_id or ident,label=label,source_label=original_label or label,split=split,source=source,status=status,file=str(path),sha256=digest,duplicate_of=duplicate,quality=quality,review_decision='',corrected_label=''))
    cmu=BASE/'models/pose/experiments/cmu_humanact12';manifest=json.loads((cmu/'dataset_manifest.json').read_text(encoding='utf-8'));split=json.loads((cmu/'run_v2/split_manifest.json').read_text(encoding='utf-8'))
    # Include every downloaded source, even clips excluded by the previous training recipe.
    for i,row in enumerate(manifest['files']):
        path=cmu/'source'/row['download']['path'];raw=path.read_bytes();label=row['role'];quality=None
        try:
            if hashlib.sha256(raw).hexdigest()!=row['download']['sha256']:raise ValueError('Source hash mismatch')
            nodes,data,dt=parse_bvh(raw.decode('utf-8'));indices=np.unique(np.rint(audit_times(1,len(data)-1)).astype(int));p=bvh_positions(nodes,data,indices)
            changes=bool(np.max(np.ptp(data[1:],axis=0))>1e-5);quality=motion_quality(p,changes)
            if row['id'] in {'88_06','56_04'}:label='unknown';quality['label_warning']='Previous other label contains attack/mixed actions; requires manual relabel'
        except Exception as exc:quality=dict(status='invalid',reason=str(exc))
        group=split['subject_aliases'].get(row['subject'],row['subject']);save(row['id'],label,split['subjects'].get(group,'excluded'),'CMU',quality,raw,'.bvh',row['annotation'])
        if i%50==0:print('CLEAN_CMU',i,'/',len(manifest['files']),flush=True)
    human_dir=cmu/'humanact12';human=np.load(human_dir/'joints.npz',allow_pickle=False);positions=human['positions'];offsets=human['offsets'];labels=human['labels']
    human_names=('warm_up','walk','run','jump','drink','lift_dumbbell','sit','eat','steer','phone','boxing','throw')
    for i,y in enumerate(labels):
        p=positions[offsets[i]:offsets[i+1]];label={1:'walk',2:'run',10:'attack'}.get(int(y),'other');quality=motion_quality(p,False)
        payload=skeleton_preview(p,f'{i:04}_{human_names[int(y)]}')
        save(f'{i:04}_{human_names[int(y)]}',label,'train','HumanAct12',quality,payload,'.glb',human_names[int(y)],'humanact12:'+str(i))
        if i%200==0:print('CLEAN_HUMAN',i,'/',len(labels),flush=True)
    combat=BASE/'models/pose/experiments/combat_v1';meta=json.loads((combat/'run_v1/dataset_manifest.json').read_text(encoding='utf-8'));known={(r['archive'],r['member'],r['animation']):r for r in meta['files']}
    for archive in sorted((combat/'source').glob('*.zip')):
        if archive.stem=='kenney-protagonists':continue
        with zipfile.ZipFile(archive) as z:
            members=[n for n in z.namelist() if n.endswith('_Standard.glb') or ('/gltf/Rig_Medium/' in n and n.endswith('.glb'))]
            for member in members:
                doc,binary=load_glb(z.read(member))
                for animation in doc['animations']:
                    name=animation['name'];row=known.get((archive.name,member,name));label=row['role'] if row else 'unknown';part=row['part'] if row else 'excluded'
                    payload=single_animation(doc,binary,animation)
                    try:
                        start,end=duration(doc,binary,animation);p=sample(doc,binary,animation,audit_times(start,end))
                        changes=False
                        for sampler in animation['samplers']:
                            v=accessor(doc,binary,sampler['output']);changes|=bool(np.max(np.ptp(v,axis=0))>1e-6)
                        quality=motion_quality(p,changes)
                    except Exception as exc:quality=dict(status='invalid',reason=str(exc))
                    save(archive.stem+':'+Path(member).stem+':'+name,label,part,archive.stem,quality,payload,'.glb',name,archive.stem+':'+name)
    # FBX audit explicitly checks each take: default Targeting Pose is NOT the motion clip.
    fbx_report=OUT/'kenney_audit/audit.json'
    if fbx_report.exists():
        for row in json.loads(fbx_report.read_text(encoding='utf-8')):
            if row['member'].startswith('Model/'):
                folder=out/'00_参考模型不用于训练';folder.mkdir(exist_ok=True);shutil.copy2(row['file'],folder/Path(row['file']).name);continue
            name=Path(row['file']).stem;label='run' if name=='run' else 'other';quality=dict(status='moving' if row['has_motion'] else 'static',takes=row['actions'])
            playable=OUT/'kenney_audit'/f'{name}_playable.blend';path=playable if playable.exists() else Path(row['file'])
            save('kenney:'+name,label,'not_used_in_training','Kenney',quality,path.read_bytes(),path.suffix,name)
    counts=Counter(r['status'] for r in rows)
    report=dict(total=len(rows),counts=dict(counts),by_label={k:dict(Counter(r['status'] for r in rows if r['label']==k)) for k in LABELS},training_paused_for_manual_review=True,thresholds=dict(static_normalized_displacement=1e-5,low_motion_articulation=.003),rows=rows)
    (out/'cleaning_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'人工审核.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        keys=('id','training_id','label','source_label','split','source','status','file','review_decision','corrected_label');writer=csv.DictWriter(stream,fieldnames=keys,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    (out/'README_人工排查.txt').write_text('先检查 01_按标签检查，再检查 02_小幅运动待复核。03 中是数值静止片段，04 是解析异常，05 是重复资源。\n标签是现有监督标签，不代表已经人工验真；unknown 必须人工标注。\n人工审核.csv 的 review_decision 填 pass/reject，corrected_label 可填 walk/run/attack/hit/jump/other。未审核不用于新一轮训练。\n每个 GLB 只保留一个动作；导入 Blender 后时间轴播放即可。HumanAct12 是关节点线预览，没有角色表面；15 FPS 仅供显示，原包帧率未知。\nCMU 为骨架 BVH，不带皮肤。Kenney .blend 已选好实际动作；原 FBX 默认 Targeting Pose 会静止。\n小幅运动、待机和仅根移动不自动删除，请人工决定。原始压缩包和已有训练结果均保留。\n',encoding='utf-8')
    print('MOTION_CLEAN_COMPLETE',json.dumps(dict(total=len(rows),counts=dict(counts)),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
