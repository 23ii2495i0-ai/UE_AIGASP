"""Sparse skeletal content classifier: numerical joints only, no names or catalog IDs."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import re
import numpy as np
import torch
from torch import nn
from scipy.spatial.transform import Rotation

ROLES=('walk','run','attack','other')
BONES=('pelvis','spine','head','hand_l','hand_r','foot_l','foot_r','knee_l','knee_r','elbow_l','elbow_r')
BVH_BONES=('Hips','Spine1','Head','LeftHand','RightHand','LeftFoot','RightFoot','LeftLeg','RightLeg','LeftForeArm','RightForeArm')
PAIRS=tuple((a,b) for a in range(len(BONES)) for b in range(a))
SAMPLES=16
FEATURE_SCHEMA='sparse_pair_distance_v1'


def parse_bvh(text):
    hierarchy,motion=text.split('MOTION',1)
    tokens=re.findall(r'[{}]|[^\s{}]+',hierarchy);at=0;nodes=[];channels=0
    def node(parent):
        nonlocal at,channels
        kind=tokens[at];at+=1
        name=tokens[at];at+=1
        if kind=='End':name=f'end_{len(nodes)}'
        if tokens[at]!='{':raise ValueError('Invalid BVH hierarchy')
        at+=1;idx=len(nodes);nodes.append(dict(name=name,parent=parent,offset=np.zeros(3),channels=[],start=channels))
        while tokens[at]!='}':
            token=tokens[at]
            if token=='OFFSET':nodes[idx]['offset']=np.array(tokens[at+1:at+4],dtype=np.float64);at+=4
            elif token=='CHANNELS':
                n=int(tokens[at+1]);nodes[idx]['channels']=tokens[at+2:at+2+n];nodes[idx]['start']=channels;channels+=n;at+=n+2
            elif token in ('JOINT','End'):node(idx)
            else:raise ValueError('Unknown BVH token '+token)
        at+=1
    if tokens[0]=='HIERARCHY':at=1
    node(-1)
    match=re.search(r'Frames:\s*(\d+)\s+Frame Time:\s*([\d.eE+-]+)\s*',motion)
    if not match:raise ValueError('Missing BVH frame header')
    count=int(match[1]);dt=float(match[2]);data=np.fromstring(motion[match.end():],sep=' ',dtype=np.float64)
    if data.size!=count*channels:raise ValueError('BVH channel count mismatch')
    return nodes,data.reshape(count,channels),dt


def bvh_positions(nodes,data,indices):
    values=data[indices];n=len(indices);rotations=[];positions=[]
    for node in nodes:
        offset=np.broadcast_to(node['offset'],(n,3)).copy();angles=[];axes=[]
        for j,channel in enumerate(node['channels']):
            v=values[:,node['start']+j]
            if channel.endswith('position'):offset[:,'XYZ'.index(channel[0])]+=v
            elif channel.endswith('rotation'):angles.append(v);axes.append(channel[0])
            else:raise ValueError('Unsupported channel')
        local=Rotation.from_euler(''.join(axes),np.array(angles).T,degrees=True).as_matrix() if axes else np.broadcast_to(np.eye(3),(n,3,3))
        parent=node['parent']
        if parent<0:positions.append(offset);rotations.append(local)
        else:
            positions.append(positions[parent]+np.einsum('nij,nj->ni',rotations[parent],offset))
            rotations.append(rotations[parent]@local)
    names={node['name']:i for i,node in enumerate(nodes)}
    missing=set(BVH_BONES)-set(names)
    if missing:raise ValueError('Missing BVH bones '+str(missing))
    return np.stack([positions[names[b]] for b in BVH_BONES],axis=1)


def encode(positions,times):
    p=np.asarray(positions,dtype=np.float64);times=np.asarray(times,dtype=np.float64)
    if p.shape!=(SAMPLES,len(BONES),3) or times.shape!=(SAMPLES,) or not np.isfinite(p).all() or not np.isfinite(times).all() or np.any(np.diff(times)<=0):raise ValueError('Invalid sparse motion samples')
    # Median articulated leg + torso length: invariant to unit scale, root translation and facing.
    length=lambda a,b:np.linalg.norm(p[:,a]-p[:,b],axis=1)
    scale=np.median((length(0,7)+length(7,5)+length(0,8)+length(8,6))/2+length(0,1)+length(1,2))
    if scale<=1e-8:raise ValueError('Degenerate skeleton')
    distances=np.stack([length(a,b)/scale for a,b in PAIRS],axis=1)
    # Physical time is retained: walking and running cannot be distinguished by phase alone.
    dt=np.diff(times);velocity=np.diff(distances,axis=0)/dt[:,None]
    velocity=np.concatenate([velocity[:1],velocity],axis=0)
    duration=np.full((SAMPLES,1),times[-1]-times[0])
    return np.concatenate([distances,velocity,duration],axis=1).astype(np.float32)


def encode_ue(samples):
    if samples.get('status')!='sampled':raise ValueError('Animation has no valid sparse samples')
    frames=samples['frames']
    if len(frames)!=SAMPLES:raise ValueError('Classifier requires exactly 16 samples')
    return encode([[frame['positions_root_cm'][b] for b in BONES] for frame in frames],[frame['time'] for frame in frames])


class PoseNet(nn.Module):
    def __init__(self,features=len(PAIRS)*2+1,classes=len(ROLES)):
        super().__init__()
        self.encoder=nn.Sequential(nn.Conv1d(features,64,3,padding=1),nn.GELU(),nn.Dropout(.2),nn.Conv1d(64,64,3,padding=1),nn.GELU(),nn.Conv1d(64,48,3,padding=1),nn.GELU())
        self.head=nn.Linear(96,classes)
    def forward(self,x,embedding=False):
        h=self.encoder(x.transpose(1,2));h=torch.cat([h.mean(-1),h.amax(-1)],dim=1)
        return h if embedding else self.head(h)
