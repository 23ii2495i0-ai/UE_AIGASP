"""Experimental numeric-pose assistance; immutable intent and selected catalog only."""
import hashlib,json,re,os
from pathlib import Path
import numpy as np
import torch
from project_paths import REPO
from inspect_pose_temporal import ue_bag
from train_pose_temporal import BagNet
from protocol import compact_catalog
from candidate_policy import semantic_exclusion,direction
RUN=Path(os.environ.get('GASP_POSE_MODEL', REPO/'artifacts/anim_config/models/pose/experiments/expanded_combat_v4/run_v1'))
ALIASES={'idle':{'idle','idling'},'walk':{'walk','walking'},'run':{'run','running','jog','jogging'},'sprint':{'sprint','sprinting'},'crouch':{'crouch','crouching','crouched'},'attack':{'attack','punch','kick','strike','slash','shoot','melee'},'hit':{'hit','hurt','damage','reaction','react','receive','recieve'}}
def words(asset):
    name=re.sub(r'([a-z])([A-Z])',r'\1 \2',asset.get('name',''))
    return set(re.findall('[a-z]+',name.lower()))|{str(t).lower() for t in asset.get('tags',[])}

ALIASES.update(jump={'jump','jumping','leap','hop','跳跃'},dodge={'dodge','dodging','roll','rolling','evade','闪避','翻滚'})
def name_roles(asset):
    w=words(asset);roles={r for r,v in ALIASES.items() if w&v}
    for role,labels in {'jump':('跳跃','起跳'),'dodge':('闪避','躲闪','翻滚')}.items():
        if any(label in asset.get('name','') for label in labels):roles.add(role)
    if roles&{'jump','dodge'}:roles.difference_update({'idle','walk','run','sprint','crouch'})
    if w&{'block','dodge','duck','death','die'}:roles.discard('hit')
    if 'hit' in roles:roles.discard('attack')
    if 'crouch' in roles:roles.difference_update({'idle','walk','run','sprint'})
    if roles&{'walk','run','sprint'}:roles.discard('idle')
    return roles
def variant_ok(asset,filters):
    w=words(asset);required=({'rifle'} if filters.get('weapon')=='rifle' else set())|{k for k in ('injured','aim') if filters.get(k)}
    return required<=w and (bool(required) or not w&{'rifle','injured','aim'})
class PoseAssistant:
    def __init__(self):
        self.enabled = (RUN/'evaluation.json').is_file() or (RUN/'weights.npz').is_file()
        self.sha = None
        if not self.enabled:
            return
        torch.set_num_threads(4)
        report=json.loads((RUN/'evaluation.json').read_text());path=RUN/'weights.npz'
        if hashlib.sha256(path.read_bytes()).hexdigest()!=report['weights_sha256']:raise ValueError('Pose weights changed')
        self.roles=report['roles'];w=np.load(path,allow_pickle=False);self.mean=w['normalization_mean'];self.std=w['normalization_std']
        self.model=BagNet(len(self.mean),classes=len(self.roles));self.model.load_state_dict({k:torch.from_numpy(w[k]) for k in self.model.state_dict()});self.model.eval();self.sha=report['weights_sha256']
    def scores(self,asset):
        try:
            x,m=ue_bag(asset.get('motion_samples',{}))
            with torch.inference_mode():p=self.model(torch.tensor(((x-self.mean)/self.std)[None]),torch.tensor(m[None])).softmax(-1).numpy()[0]
            return dict(zip(self.roles,map(float,p))),None
        except (ValueError,KeyError,TypeError) as e:return {},str(e)
    def select(self,catalog,configuration,original,policy=None):
        if not getattr(self, 'enabled', True):
            return original, {}, [{'pose_assistance': 'disabled', 'reason': 'optional_model_not_installed'}]
        policy=policy or {}
        _,ids=compact_catalog(catalog);aliases={v:k for k,v in ids.items()};meshes=[a for a in catalog['assets'] if a['kind']=='mesh']
        if len(meshes)!=1:return original,{},[]
        evidence=[];ranked={r:[] for r in configuration['slots']}
        for a in catalog['assets']:
            if a['kind'] not in ('sequence','database') or a.get('skeleton')!=meshes[0]['skeleton']:continue
            scores,reason=self.scores(a) if a['kind']=='sequence' else ({},'database_not_sampled')
            names=name_roles(a);top=sorted(scores,key=scores.get,reverse=True);pose=top[0] if top else None
            confident=bool(len(top)>1 and scores[pose]>=(.85 if pose=='hit' else .75) and scores[pose]-scores[top[1]]>=.25)
            row=dict(id=a['id'],name_roles=sorted(names),pose_scores=scores,pose_reason=reason,candidates=[])
            exclusion=semantic_exclusion(a)
            if exclusion:
                row['review_reason']=exclusion;evidence.append(row);continue
            for role,kind in configuration['slots'].items():
                airborne=role=='jump' and policy.get('index_jump')
                if role in ('hit','attack') and words(a)&{'block','dodge','duck','death','die'}:continue
                # A jump trigger must not cycle through landing/falling-only clips.
                if role=='jump' and words(a)&{'land','landing','fall','falling','loop','loops','apex','down','end'}:
                    if not (airborne and a.get('loop') is True and not words(a)&{'land','landing'}):continue
                if not variant_ok(a,configuration['filters']):continue
                if kind=='action' and not airborne and (a['kind']!='sequence' or a.get('loop') is not False):continue
                named=role in names;learned=confident and pose==role and not names
                selected=ids.get(original['bindings'].get(role))==a['id']
                # Explicit names for another action cannot be overridden by a text alias or pose score.
                if names and not named:continue
                if policy.get('review_uncertain') and not named:
                    row['review_reason']='unconfirmed_category';continue
                if policy.get('review_uncertain') and named and role in scores and confident and pose!=role and pose!='other':
                    row['review_reason']='name_pose_disagreement';continue
                if not (named or learned or selected):continue
                value=(.65 if named else .5 if selected else 0.)+.35*scores.get(role,0.)
                ranked[role].append((value,a));row['candidates'].append(dict(role=role,score=value,source='name+pose' if named and scores else 'name' if named else 'selector' if selected else 'pose_experimental'))
            evidence.append(row)
        result=dict(bindings={},issues={});candidates={}
        for role,items in ranked.items():
            def preference(item):
                a=item[1];w=words(a)
                primary=a['kind']=='database' or (a.get('loop') is True and not (role=='crouch' and w&{'idle','idles'}))
                return (not primary,direction(a)!='forward',-item[0],a['id'])
            items.sort(key=preference)
            primary=next((a for _,a in items if configuration['slots'][role]=='action' or a['kind']=='database' or a.get('loop') is True),None)
            if primary is None:result['bindings'][role]=None;result['issues'][role]='missing';continue
            chosen=[primary]+[a for _,a in items if a['id']!=primary['id'] and a['kind']=='sequence' and primary['kind']=='sequence']
            # Cover the cardinal directions before spending capacity on duplicate clips or transitions.
            diverse=[primary];seen={direction(primary)}
            for a in chosen[1:]:
                d=direction(a)
                if d and d not in seen and a.get('loop') is True:diverse.append(a);seen.add(d)
            if role=='crouch':
                idle=next((a for a in chosen if a.get('loop') is True and words(a)&{'idle','idles'}),None)
                if idle and idle not in diverse:diverse.append(idle)
            chosen=diverse+[a for a in chosen if a not in diverse]
            limit=policy.get('max_candidates_by_role',{}).get(role,policy.get('max_candidates_per_role'))
            if limit is not None:chosen=chosen[:limit]
            result['bindings'][role]=aliases[primary['id']];candidates[role]=[a['id'] for a in chosen]
        return result,candidates,evidence
