"""Shared sparse temporal sampling and dynamics features for offline motion classification."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import numpy as np
from pose_content_model import PAIRS
from motion_window_policy import sparse_windows

SCHEMA='sparse_dynamics_bag_v2'
MAX_WINDOWS=9
SAMPLES=16


def window_times(start,end):
    return [np.array(times) for times in sparse_windows(start,end)]


def features(positions,times,up_axis=1):
    p=np.asarray(positions,dtype=np.float64);t=np.asarray(times,dtype=np.float64)
    if p.shape!=(16,11,3) or t.shape!=(16,) or not np.isfinite(p).all() or np.any(np.diff(t)<=0):raise ValueError('Invalid temporal pose')
    length=lambda a,b:np.linalg.norm(p[:,a]-p[:,b],axis=1)
    scale=np.median((length(0,7)+length(7,5)+length(0,8)+length(8,6))/2+length(0,1)+length(1,2))
    if scale<1e-8:raise ValueError('Degenerate skeleton')
    def velocity(x):
        v=np.diff(x,axis=0)/np.diff(t).reshape((-1,)+(1,)*(x.ndim-1))
        return np.concatenate([v[:1],v],axis=0)
    p=p/scale;relative=p-p[:,0:1]
    distances=np.stack([np.linalg.norm(p[:,a]-p[:,b],axis=1) for a,b in PAIRS],axis=1)
    height=relative[:,:,up_axis]
    local_speed=np.linalg.norm(velocity(relative),axis=-1)
    world_speed=np.linalg.norm(velocity(p),axis=-1)
    root_velocity=velocity(p[:,0]);horizontal=np.delete(root_velocity,up_axis,axis=1)
    root=np.stack([np.linalg.norm(horizontal,axis=1),root_velocity[:,up_axis]],axis=1)
    torso=relative[:,2];tilt=(torso[:,up_axis]/np.maximum(np.linalg.norm(torso,axis=1),1e-6))[:,None]
    # No duration channel: prevent learning source/clip length as an action label.
    result=np.concatenate([distances,velocity(distances),height,velocity(height),local_speed,world_speed,root,tilt],axis=1)
    if not np.isfinite(result).all():raise ValueError('Nonfinite dynamics')
    return result.astype(np.float32)


def padded_bag(windows):
    if not 1<=len(windows)<=MAX_WINDOWS:raise ValueError('Invalid window count')
    x=np.zeros((MAX_WINDOWS,*windows[0].shape),dtype=np.float32);mask=np.zeros(MAX_WINDOWS,dtype=bool)
    x[:len(windows)]=windows;mask[:len(windows)]=True
    return x,mask
