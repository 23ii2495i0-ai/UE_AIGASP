"""Sample embedded glTF animations at sparse timestamps, with full hierarchical TRS."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json, struct
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

MAPS = (
    ('pelvis','spine_03','Head','hand_l','hand_r','foot_l','foot_r','calf_l','calf_r','lowerarm_l','lowerarm_r'),
    ('hips','chest','head','hand.l','hand.r','foot.l','foot.r','lowerleg.l','lowerleg.r','lowerarm.l','lowerarm.r'),
)


def load_glb(blob):
    magic,version,size=struct.unpack_from('<4sII',blob)
    if magic!=b'glTF' or version!=2 or size!=len(blob): raise ValueError('Invalid GLB header')
    at=12;document=None;binary=None
    while at<len(blob):
        count,kind=struct.unpack_from('<II',blob,at);at+=8
        chunk=blob[at:at+count];at+=count
        if len(chunk)!=count: raise ValueError('Truncated GLB')
        if kind==0x4e4f534a: document=json.loads(chunk)
        elif kind==0x004e4942: binary=chunk
    if document is None or binary is None or document.get('extensionsRequired'): raise ValueError('Unsupported GLB layout')
    if len(document.get('buffers',[]))!=1 or 'uri' in document['buffers'][0]: raise ValueError('Expected embedded buffer')
    return document,binary


def accessor(doc,blob,index):
    a=doc['accessors'][index]
    if a['componentType']!=5126 or 'sparse' in a or a.get('normalized'): raise ValueError('Expected dense float accessor')
    columns={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']];v=doc['bufferViews'][a['bufferView']]
    if v.get('buffer',0)!=0: raise ValueError('External buffer')
    offset=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',columns*4)
    end=offset+max(0,a['count']-1)*stride+columns*4
    if stride<columns*4 or end>len(blob) or end>v.get('byteOffset',0)+v['byteLength']: raise ValueError('Accessor outside buffer')
    result=np.ndarray((a['count'],columns),dtype='<f4',buffer=blob,offset=offset,strides=(stride,4)).astype(np.float64)
    if not np.isfinite(result).all(): raise ValueError('Nonfinite animation values')
    return result


def duration(doc,blob,animation):
    times=[accessor(doc,blob,s['input'])[:,0] for s in animation['samplers']]
    return min(t[0] for t in times),max(t[-1] for t in times)


def sample(doc,blob,animation,times):
    times=np.asarray(times,dtype=np.float64);n=len(times);nodes=doc['nodes']
    translations=[np.tile(x.get('translation',[0,0,0]),(n,1)) for x in nodes]
    rotations=[np.tile(x.get('rotation',[0,0,0,1]),(n,1)) for x in nodes]
    scales=[np.tile(x.get('scale',[1,1,1]),(n,1)) for x in nodes]
    for channel in animation['channels']:
        target=channel['target'];i=target['node'];path=target['path'];s=animation['samplers'][channel['sampler']]
        if path not in ('translation','rotation','scale'): raise ValueError('Unsupported animation target')
        keys=accessor(doc,blob,s['input'])[:,0];values=accessor(doc,blob,s['output'])
        if len(keys)!=len(values) or len(keys)==0 or np.any(np.diff(keys)<=0): raise ValueError('Invalid key times')
        query=np.clip(times,keys[0],keys[-1]);method=s.get('interpolation','LINEAR')
        if method=='STEP': result=values[np.maximum(0,np.searchsorted(keys,query,side='right')-1)]
        elif method=='LINEAR':
            if len(keys)==1: result=np.tile(values[0],(n,1))
            elif path=='rotation': result=Slerp(keys,Rotation.from_quat(values))(query).as_quat()
            else: result=np.stack([np.interp(query,keys,values[:,axis]) for axis in range(values.shape[1])],axis=1)
        else: raise ValueError('Unsupported interpolation '+method)
        {'translation':translations,'rotation':rotations,'scale':scales}[path][i]=result
    parents={}
    for i,node in enumerate(nodes):
        for child in node.get('children',[]):
            if child in parents: raise ValueError('Multiple node parents')
            parents[child]=i
    cache={};visiting=set()
    def world(i):
        if i in cache:return cache[i]
        if i in visiting:raise ValueError('Cyclic glTF hierarchy')
        visiting.add(i);node=nodes[i]
        if 'matrix' in node: matrix=np.tile(np.array(node['matrix']).reshape(4,4,order='F'),(n,1,1))
        else:
            matrix=np.tile(np.eye(4),(n,1,1));matrix[:,:3,:3]=Rotation.from_quat(rotations[i]).as_matrix()*scales[i][:,None,:];matrix[:,:3,3]=translations[i]
        if i in parents:matrix=world(parents[i])@matrix
        visiting.remove(i);cache[i]=matrix;return matrix
    names={node.get('name'):i for i,node in enumerate(nodes)}
    mapping=next((m for m in MAPS if set(m)<=names.keys()),None)
    if mapping is None:raise ValueError('Unknown anatomical joint map')
    return np.stack([world(names[b])[:,:3,3] for b in mapping],axis=1)
