"""Shared conservative source-label mapping; asset identifiers never become model inputs."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import re

ROLES=('walk','run','attack','other','hit','jump')
JUMP_ACTIONS={'Jump_Full_Long','Jump_Full_Short','Jump_Start','Jump_Loop','Jump_Land','Jump_Idle','NinjaJump_Start','NinjaJump_Idle_Loop','NinjaJump_Land'}


def with_jump(source,annotation,current):
    if current in ('attack','hit'):return current
    if source=='HumanAct12':return 'jump' if annotation in ('jump','3') else current
    if source=='Kenney':return 'jump' if annotation.lower()=='jump' else current
    if source=='CMU':
        if re.fullmatch(r'jump|forward jump|long jump forward|box jump|180 degree jump|jump turn|jumpturn|furtherjumpturn|jumpforward|jumpsmallforward|jump sideways|jump off ledge|jump/hop on uneven terrain',annotation,re.I):return 'jump'
        if re.search(r'jump|hop|leap',annotation,re.I) and 'jumping jacks' not in annotation.lower():return 'unknown'
    elif annotation in JUMP_ACTIONS:return 'jump'
    return current
