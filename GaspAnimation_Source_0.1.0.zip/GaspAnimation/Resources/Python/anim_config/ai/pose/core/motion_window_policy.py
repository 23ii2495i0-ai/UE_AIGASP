"""Dependency-free policy shared by UE sampling and model training."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import math

POLICY='bounded_075_150_v2'


def sparse_windows(start,end):
    if not all(math.isfinite(v) for v in (start,end)) or end<=start:raise ValueError('Invalid motion interval')
    if end-start<=2.:return [[start+(end-start)*i/15 for i in range(16)]]
    return [[begin+width*i/15 for i in range(16)] for width,count in ((.75,4),(1.5,5)) for begin in (start+(end-start-width)*j/(count-1) for j in range(count))]
