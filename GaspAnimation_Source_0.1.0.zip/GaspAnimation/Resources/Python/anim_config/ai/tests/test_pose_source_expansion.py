"""Conservative source-label regression checks for expanded combat data."""
from pathlib import Path
import sys,unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project_paths import configure_imports
configure_imports()
from prepare_pose_expansion import accad_label

class ExpansionLabels(unittest.TestCase):
    def test_defense_is_not_hit(self):
        for name in ['Male2_E11_BlockLeftHigh.bvh','Male2_E19_DodgeLeft.bvh','Male2_E21_DuckLeft.bvh']:
            self.assertEqual(accad_label(name),'other')
    def test_same_prefix_is_not_same_semantics(self):
        self.assertEqual(accad_label('Male2_E1_JabLeft.bvh'),'attack')
        self.assertEqual(accad_label('Male2_E1_TurnAroundRight.bvh'),'other')
    def test_transitions_are_not_pure_classes(self):
        for name in ['Male2_C19_RunToJumpToWalk.bvh','Male2_B17_WalkToHopToWalk.bvh','Male2_Extended_1.bvh']:
            self.assertEqual(accad_label(name),'unknown')
    def test_pure_actions(self):
        self.assertEqual(accad_label('Male2_G9_RoundhouseRightT2.bvh'),'attack')
        self.assertEqual(accad_label('Male2_B3_Walk.bvh'),'walk')
        self.assertEqual(accad_label('Male2_C3_Run.bvh'),'run')
if __name__=='__main__':unittest.main()
