import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project_paths import configure_imports
configure_imports()
from hybrid_selection import PoseAssistant
from flow_schema import validate_runtime
class HybridTests(unittest.TestCase):
    def setUp(self):
        self.model=PoseAssistant.__new__(PoseAssistant)
        self.model.scores=lambda a:({'walk':.01,'run':.01,'attack':.02,'other':.01,'hit':.94,'jump':.01},None)
        self.config=dict(slots={'run':'locomotion','hit':'action'},filters={})
        self.catalog={'assets':[dict(id='mesh',kind='mesh',skeleton='s'),dict(id='run1',name='Run_Loop_F',kind='sequence',skeleton='s',loop=True),dict(id='run2',name='Run_Stop',kind='sequence',skeleton='s',loop=False),dict(id='hit1',name='Opaque_001',kind='sequence',skeleton='s',loop=False),dict(id='block',name='Melee_Block_Hit',kind='sequence',skeleton='s',loop=False)]}
        self.original=dict(bindings={'run':None,'hit':None},issues={'run':'ambiguous','hit':'missing'})
    def test_multiple_motion_and_pose_only_hit(self):
        result,candidates,evidence=self.model.select(self.catalog,self.config,self.original)
        self.assertEqual(candidates['run'],['run1','run2'])
        self.assertEqual(candidates['hit'],['hit1'])
        self.assertEqual(result['issues'],{})
    def test_skeleton_and_variants_never_bypassed(self):
        self.catalog['assets'][3]['skeleton']='foreign';self.catalog['assets'][1]['name']='Run_Rifle'
        result,candidates,_=self.model.select(self.catalog,self.config,self.original)
        self.assertNotIn('hit',candidates);self.assertIsNone(result['bindings']['run'])
    def test_wrong_playback_is_not_hit(self):
        self.catalog['assets'][3]['loop']=True
        result,candidates,_=self.model.select(self.catalog,self.config,self.original)
        self.assertNotIn('hit',candidates)
    def test_jump_and_dodge_candidates(self):
        from hybrid_selection import name_roles
        self.assertEqual(name_roles(dict(name='Jump_F_Start_Run')),{'jump'})
        self.config['slots'].update(jump='action',dodge='action')
        self.catalog['assets'].extend([dict(id='jump',name='角色跳跃',kind='sequence',skeleton='s',loop=False),dict(id='dodge',name='Dodge_Roll',kind='sequence',skeleton='s',loop=False),dict(id='land',name='Jump_Land',kind='sequence',skeleton='s',loop=False)])
        result,candidates,_=self.model.select(self.catalog,self.config,self.original)
        self.assertEqual(candidates['jump'],['jump'])
        self.assertEqual(candidates['dodge'],['dodge'])
        self.assertNotIn('dodge',candidates['hit'])
    def test_candidate_validation_rejects_invented_asset(self):
        flow=dict(version=1,filters={},actions={'hit':'hit1'},action_candidates={'hit':['hit1','invented']},policy={},blend_seconds=.2)
        self.assertTrue(validate_runtime(flow,self.catalog,'mesh'))
    def test_limits_and_cardinal_diversity(self):
        self.config=dict(slots={'run':'locomotion'},filters={})
        self.catalog['assets']=[self.catalog['assets'][0]]+[dict(id=suffix,name='Run_Loop_'+suffix,kind='sequence',skeleton='s',loop=True) for suffix in ('F','B','LL','RL','F2')]
        original=dict(bindings={'run':None},issues={'run':'ambiguous'})
        _,candidates,_=self.model.select(self.catalog,self.config,original,{'max_candidates_per_role':4})
        self.assertEqual(candidates['run'],['F','B','LL','RL'])
        _,candidates,_=self.model.select(self.catalog,self.config,original,{'max_candidates_per_role':1})
        self.assertEqual(candidates['run'],['F'])
    def test_stance_and_nonlocomotion_cannot_leak(self):
        from hybrid_selection import name_roles
        self.assertEqual(name_roles(dict(name='M_Neutral_Crouch_Idle_Loop')),{'crouch'})
        self.catalog['assets'].extend([dict(id=n,name=n,kind='sequence',skeleton='s',loop=True) for n in ('Traversal_Climb_Run','Run_Lean_Pose_Base','Crouch_Walk_Loop')])
        _,candidates,evidence=self.model.select(self.catalog,self.config,self.original)
        self.assertEqual(candidates['run'],['run1','run2'])
        self.assertTrue(any(e.get('review_reason') for e in evidence))
    def test_airborne_loop_is_only_legal_for_indexed_jump(self):
        config=dict(slots={'jump':'action'},filters={})
        self.catalog['assets'].append(dict(id='air',name='Jump_Loop_Fall',kind='sequence',skeleton='s',loop=True))
        original=dict(bindings={'jump':None},issues={'jump':'missing'})
        _,candidates,_=self.model.select(self.catalog,config,original)
        self.assertNotIn('jump',candidates)
        _,candidates,_=self.model.select(self.catalog,config,original,{'index_jump':True,'max_candidates_per_role':1})
        self.assertEqual(candidates['jump'],['air'])
if __name__=='__main__':unittest.main()
