
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import unittest
import numpy as np
from pose_temporal import features,window_times,padded_bag


class TemporalTests(unittest.TestCase):
    def pose(self):
        rng=np.random.default_rng(1);p=np.tile(rng.normal(size=(11,3)),(16,1,1));p[:,2,1]+=3
        return p,np.linspace(0,1,16)
    def test_long_clip_windows_are_bounded(self):
        windows=window_times(1,46)
        self.assertEqual(len(windows),9)
        self.assertTrue(all(len(t)==16 and np.all(np.diff(t)>0) and t[-1]-t[0]<=1.5+1e-6 for t in windows))
        self.assertAlmostEqual(windows[-1][-1],46)
    def test_unit_and_translation_invariance(self):
        p,t=self.pose();np.testing.assert_allclose(features(p,t),features(p*100+[3,5,7],t),atol=1e-6)
    def test_rigid_recoil_survives_encoding(self):
        p,t=self.pose();moving=p.copy();moving[:,:,0]+=t[:,None]
        self.assertFalse(np.allclose(features(p,t),features(moving,t)))
    def test_mask_excludes_padding(self):
        p,t=self.pose();x,mask=padded_bag([features(p,t)])
        self.assertEqual(mask.sum(),1);self.assertEqual(x.shape[0],9)


if __name__=='__main__':unittest.main()
