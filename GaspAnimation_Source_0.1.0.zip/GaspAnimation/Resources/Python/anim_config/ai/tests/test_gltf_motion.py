
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np
from gltf_motion import MAPS,accessor,sample
from train_pose_combat import partition,role


class SparseGltfTest(unittest.TestCase):
    def test_parent_rotation_scale_translation(self):
        nodes=[dict(name=name,translation=[1,0,0]) for name in MAPS[0]]
        nodes.append(dict(name='world',translation=[10,20,30],rotation=[0,0,np.sqrt(.5),np.sqrt(.5)],scale=[2,2,2],children=list(range(11))))
        actual=sample(dict(nodes=nodes),b'',dict(channels=[]),[0,1])
        np.testing.assert_allclose(actual,np.tile([10,22,30],(2,11,1)),atol=1e-6)

    def test_animation_interpolation(self):
        keys=np.array([0,2],dtype='<f4');positions=np.array([[0,0,0],[2,4,6]],dtype='<f4');binary=keys.tobytes()+positions.tobytes()
        nodes=[dict(name=name) for name in MAPS[0]]
        doc=dict(nodes=nodes,accessors=[dict(componentType=5126,type='SCALAR',count=2,bufferView=0),dict(componentType=5126,type='VEC3',count=2,bufferView=1)],bufferViews=[dict(byteOffset=0,byteLength=8),dict(byteOffset=8,byteLength=24)])
        animation=dict(channels=[dict(sampler=0,target=dict(node=0,path='translation'))],samplers=[dict(input=0,output=1)])
        actual=sample(doc,binary,animation,[0,1,2])
        np.testing.assert_allclose(actual[:,0],[[0,0,0],[1,2,3],[2,4,6]])

    def test_accessor_rejects_out_of_bounds(self):
        doc=dict(accessors=[dict(componentType=5126,type='VEC3',count=2,bufferView=0)],bufferViews=[dict(byteLength=8)])
        with self.assertRaises(ValueError):accessor(doc,b'\0'*32,0)

    def test_action_family_stays_together(self):
        self.assertEqual(partition('Sword_Regular_B_Rec'),partition('Sword_Regular_Combo'))
        self.assertEqual(partition('Hit_A'),partition('Hit_B'))
        self.assertEqual(role('Melee_Block_Hit'),'other')
        self.assertEqual(role('Hit_Head'),'hit')
        self.assertEqual(role('Melee_Unarmed_Attack_Kick'),'attack')


if __name__=='__main__':unittest.main()
