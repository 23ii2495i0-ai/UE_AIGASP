import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project_paths import configure_imports
configure_imports()
from split_runtime import complete_json_object

class JsonGenerationTests(unittest.TestCase):
    def test_nested_and_escaped_strings(self):
        self.assertTrue(complete_json_object(' \n{"slots":{"idle":"locomotion"},"text":"} \\\" {"}'))

    def test_partial_objects_do_not_stop(self):
        for text in ('', '{', '{"slots":{}', '{"text":"}"', '[]', 'null'):
            self.assertFalse(complete_json_object(text),text)

    def test_stops_before_a_second_response(self):
        text='{"slots":{"idle":"locomotion"}}\n\n{"slots":{}}'
        first=next(i for i in range(len(text)+1) if complete_json_object(text[:i]))
        self.assertEqual(text[:first],'{"slots":{"idle":"locomotion"}}')

if __name__=='__main__':unittest.main()
