import sys,tempfile,csv,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project_paths import configure_imports
configure_imports()
from review_selection import load_review


class ReviewTests(unittest.TestCase):
    def test_explicit_reject_and_label_override(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);asset=root/'clip.glb';asset.write_bytes(b'preview');path=root/'review.csv'
            keys=['id','training_id','label','corrected_label','review_decision','status','file']
            with path.open('w',newline='',encoding='utf-8-sig') as stream:
                writer=csv.DictWriter(stream,fieldnames=keys);writer.writeheader()
                for ident,decision,corrected in [('a','pass','jump'),('b','reject',''),('c','','')]:writer.writerow(dict(id=ident,training_id=ident,label='other',corrected_label=corrected,review_decision=decision,status='moving',file=str(asset)))
            with self.assertRaises(ValueError):load_review(path)
            selected,excluded=load_review(path,True)
            self.assertEqual(selected,{'a':'jump','c':'other'});self.assertIn('b',excluded)


if __name__=='__main__':unittest.main()
