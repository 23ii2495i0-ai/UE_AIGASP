
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import unittest
import numpy as np
from clean_motion_dataset import motion_quality,audit_times
from motion_review_assets import skeleton_preview,single_animation
from gltf_motion import load_glb,accessor


class CleaningTests(unittest.TestCase):
    def positions(self):
        return np.tile(np.random.default_rng(2).normal(size=(24,3)),(8,1,1)).astype(np.float32)
    def test_static_and_in_place_movement(self):
        p=self.positions();self.assertEqual(motion_quality(p,False)['status'],'static')
        p[:,20,0]+=np.linspace(0,1,8)
        self.assertEqual(motion_quality(p,True)['status'],'moving')
    def test_root_only_is_manual_review(self):
        p=self.positions();p[:,:,0]+=np.linspace(0,1,8)[:,None]
        self.assertEqual(motion_quality(p,True)['status'],'low_motion')
    def test_single_key_pose_is_static_not_parse_error(self):
        t=audit_times(0.,0.);self.assertEqual(len(t),2)
        p=self.positions()[:2];self.assertEqual(motion_quality(p,False)['status'],'static')
    def test_human_preview_contains_actual_joint_motion(self):
        p=self.positions();p[:,20,0]+=np.arange(8)
        doc,binary=load_glb(skeleton_preview(p,'test'))
        self.assertEqual(len(doc['animations']),1)
        channel=next(c for c in doc['animations'][0]['channels'] if c['target']==dict(node=20,path='translation'))
        sampler=doc['animations'][0]['samplers'][channel['sampler']]
        values=accessor(doc,binary,sampler['output'])
        np.testing.assert_allclose(values[:,0],p[:,20,0]-p[0,0,0],atol=1e-6)
        blob=single_animation(doc,binary,doc['animations'][0]);rebuilt,rebuilt_binary=load_glb(blob)
        self.assertEqual(len(rebuilt['animations']),1)
        for sampler in rebuilt['animations'][0]['samplers']:
            self.assertTrue(np.isfinite(accessor(rebuilt,rebuilt_binary,sampler['output'])).all())


if __name__=='__main__':unittest.main()
