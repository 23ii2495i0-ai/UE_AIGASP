"""CPU numerical equivalence test for full vs assistant-only output projection."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import torch
from transformers import Qwen2Config,Qwen2ForCausalLM
from peft import LoraConfig,get_peft_model
from assistant_loss import assistant_inputs
torch.manual_seed(42)
cfg=Qwen2Config(vocab_size=43,hidden_size=32,intermediate_size=64,num_hidden_layers=2,num_attention_heads=4,num_key_value_heads=2,attention_dropout=0)
model=get_peft_model(Qwen2ForCausalLM(cfg),LoraConfig(r=2,lora_alpha=4,lora_dropout=0,target_modules=['q_proj','v_proj'],task_type='CAUSAL_LM'))
ids=torch.randint(0,43,(2,24));mask=torch.ones_like(ids);mask[1,21:]=0
labels=ids.clone();labels[0,:15]=-100;labels[1,:18]=-100;labels[1,21:]=-100
inputs={'input_ids':ids,'attention_mask':mask,'labels':labels}
dense=model(**inputs).loss;dense.backward()
grads={k:v.grad.clone() for k,v in model.named_parameters() if v.grad is not None}
model.zero_grad(set_to_none=True)
reduced=model(**assistant_inputs(inputs)).loss;reduced.backward()
torch.testing.assert_close(dense,reduced,atol=1e-6,rtol=1e-5)
maximum=0
for k,v in model.named_parameters():
    if k in grads:
        torch.testing.assert_close(grads[k],v.grad,atol=1e-6,rtol=1e-5)
        maximum=max(maximum,(grads[k]-v.grad).abs().max().item())
print({'dense_loss':dense.item(),'assistant_loss':reduced.item(),'max_gradient_error':maximum,'full_positions':24,'retained_positions':len(assistant_inputs(inputs)['logits_to_keep'])})
