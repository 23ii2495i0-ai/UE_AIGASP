
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import unittest
import numpy as np
import torch
from motion_labels import ROLES,with_jump
from train_pose_temporal import BagNet,metrics


class JumpTests(unittest.TestCase):
    def test_sources_and_combat_boundary(self):
        self.assertEqual(with_jump('HumanAct12','3','other'),'jump')
        self.assertEqual(with_jump('CMU','forward jump','other'),'jump')
        self.assertEqual(with_jump('Kenney','jump','other'),'jump')
        self.assertEqual(with_jump('CC0 authored','Jump_Land','other'),'jump')
        self.assertEqual(with_jump('CC0 authored','Melee_1H_Attack_Jump_Chop','attack'),'attack')
        self.assertEqual(with_jump('CMU','walk, jump, drink','other'),'unknown')
    def test_six_class_head_and_metrics(self):
        model=BagNet(157);model.eval()
        with torch.inference_mode():out=model(torch.zeros(1,9,16,157),torch.ones(1,9,dtype=torch.bool))
        self.assertEqual(out.shape,(1,len(ROLES)))
        result=metrics(np.eye(6)[[5,5]],np.array([5,5]))
        self.assertEqual(result['recall']['jump'],1.)
        self.assertIsNone(result['recall']['attack'])


if __name__=='__main__':unittest.main()
