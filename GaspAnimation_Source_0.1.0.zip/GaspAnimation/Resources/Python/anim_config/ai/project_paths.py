"""Project paths and direct-script import support for the organised AI tools."""
import sys
import os
from pathlib import Path

AI=Path(__file__).resolve().parent
def workspace():
    explicit=os.environ.get('GASP_AI_WORKSPACE') or os.environ.get('GASP_REPO')
    if explicit:return Path(explicit).expanduser().resolve()
    for parent in AI.parents:
        if (parent/'unreal/GaspNative.uproject').is_file():return parent
    for parent in AI.parents:
        if any(parent.glob('*.uproject')):return parent/'Saved/GaspAnimationAI'
    return Path.home()/'GaspAnimationAI'
REPO=workspace()


def configure_imports():
    folders=[AI,AI.parent,AI.parent.parent]+sorted({p.parent for p in AI.rglob('*.py')})
    for path in folders:
        if str(path) not in sys.path:sys.path.append(str(path))
