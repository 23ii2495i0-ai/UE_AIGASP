"""Fetch public, pinned model/data snapshots; do not download motion datasets with restricted terms."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,hashlib,urllib.request,sys
from pathlib import Path
ROOT=_LAYOUT_REPO;OUT=ROOT/'artifacts/anim_config';OUT.mkdir(parents=True,exist_ok=True)

def fetch(url,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not path.exists():
        with urllib.request.urlopen(url,timeout=60) as r:path.write_bytes(r.read())
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    import huggingface_hub as hub
    api=hub.HfApi()
    model='Qwen/Qwen2.5-1.5B-Instruct';info=api.model_info(model);rev=info.sha
    print('BASE_MODEL',model,rev,flush=True)
    model_dir=OUT/'models/configuration/base_model'
    hub.snapshot_download(model,revision=rev,local_dir=model_dir,allow_patterns=['*.json','*.safetensors','*.txt','*.md','LICENSE','*.model'])
    data='NousResearch/hermes-function-calling-v1';d=api.dataset_info(data);dr=d.sha
    data_dir=OUT/'models/configuration/sources/external/hermes'
    files={}
    for name in ['README.md','json-mode-singleturn.json']:
        url=f'https://huggingface.co/datasets/{data}/resolve/{dr}/{name}'
        files[name]={'url':url,'sha256':fetch(url,data_dir/name)}
    manifest={'base_model':{'repo':model,'revision':rev,'license':'Apache-2.0','path':str(model_dir)},'external':{'repo':data,'revision':dr,'declared_license':'Apache-2.0','files':files,'purpose':'auxiliary general JSON generation, not UE animation labels'},'excluded':[{'name':'BABEL','reason':'non-commercial license; no automatic ingestion','url':'https://babel.is.tue.mpg.de/license.html'},{'name':'AMASS','reason':'non-commercial license; no automatic ingestion','url':'https://github.com/nghorbani/amass/blob/master/LICENSE.txt'},{'name':'HumanML3D','reason':'motion source licensing needs separate review; not downloaded','url':'https://github.com/EricGuo5513/HumanML3D'}]}
    (OUT/'sources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print('FETCH_COMPLETE',flush=True)
if __name__=='__main__':main()
