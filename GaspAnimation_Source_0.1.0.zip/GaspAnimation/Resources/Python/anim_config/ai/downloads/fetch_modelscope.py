"""Pinned downloads from author repositories on ModelScope; verify SHA256 before use."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import urllib.request,urllib.parse,json,hashlib,time,argparse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=_LAYOUT_REPO;OUT=ROOT/'artifacts/anim_config';OUT.mkdir(parents=True,exist_ok=True)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def download(entry,repo='Qwen/Qwen2.5-1.5B-Instruct',destination=None):
 directory=Path(destination) if destination else OUT/'models/configuration/base_model'
 path=directory/entry['Path']
 if not path.resolve().is_relative_to(directory.resolve()):raise ValueError('Download path escapes destination')
 path.parent.mkdir(parents=True,exist_ok=True)
 expected=entry['Sha256']
 if path.exists() and sha(path)==expected:return
 url='https://modelscope.cn/api/v1/models/'+repo+'/repo?'+urllib.parse.urlencode({'Revision':entry['Revision'],'FilePath':entry['Path']})
 temp=path.with_suffix(path.suffix+'.partial');start=temp.stat().st_size if temp.exists() else 0
 req=urllib.request.Request(url,headers={'Range':f'bytes={start}-'} if start else {})
 with urllib.request.urlopen(req,timeout=120) as r:
  append=start and r.status==206
  if not append:start=0
  count=start;mark=count//(128*1024*1024)
  with temp.open('ab' if append else 'wb') as f:
   while True:
    b=r.read(4*1024*1024)
    if not b:break
    f.write(b);count+=len(b)
    if count//(128*1024*1024)>mark:mark=count//(128*1024*1024);print(entry['Path'],count,'/',entry['Size'],flush=True)
 if temp.stat().st_size!=entry['Size'] or sha(temp)!=expected:raise RuntimeError('Checksum mismatch '+entry['Path'])
 temp.replace(path);print('VERIFIED',entry['Path'],flush=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--refresh',action='store_true');args=p.parse_args()
 saved=OUT/'sources.json'
 if saved.exists() and not args.refresh:
  manifest=json.loads(saved.read_text(encoding='utf-8'))
  entries=manifest['base_model']['files']
  with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(download,entries))
  print('PINNED_MODEL_VERIFIED',flush=True);return
 url='https://modelscope.cn/api/v1/models/Qwen/Qwen2.5-1.5B-Instruct/repo/files?Revision=master&Recursive=true'
 meta=json.load(urllib.request.urlopen(url,timeout=30))
 entries=[x for x in meta['Data']['Files'] if x['Path'].endswith(('.json','.safetensors','.txt','.md')) or x['Path']=='LICENSE']
 manifest={'base_model':{'repo':'Qwen/Qwen2.5-1.5B-Instruct','source':'https://modelscope.cn/models/Qwen/Qwen2.5-1.5B-Instruct','license':'Apache-2.0','files':entries},'external':[],'excluded':[{'name':'AMASS/BABEL','reason':'Non-commercial terms; not ingested'}]}
 (OUT/'sources.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(download,entries))
 print('MODEL_DOWNLOAD_COMPLETE',flush=True)
if __name__=='__main__':main()
