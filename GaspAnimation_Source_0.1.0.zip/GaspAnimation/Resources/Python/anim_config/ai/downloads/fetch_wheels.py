
from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,urllib.request,time
from pathlib import Path
from packaging.tags import sys_tags
from packaging.utils import parse_wheel_filename
out=Path('artifacts/anim_config/models/shared/wheels');out.mkdir(parents=True,exist_ok=True)
compatible=set(sys_tags())
for package,version in [('transformers','4.57.6'),('peft','0.18.1'),('accelerate','1.12.0'),('huggingface-hub','0.36.2'),('safetensors','0.8.0'),('tokenizers','0.22.2'),('regex','2026.9.29')]:
 u='https://pypi.org/pypi/'+package+('/'+version if version else '')+'/json';meta=json.load(urllib.request.urlopen(u,timeout=20))
 entry=next(x for x in meta['urls'] if x['filename'].endswith('.whl') and parse_wheel_filename(x['filename'])[3]&compatible)
 p=out/entry['filename']
 if p.exists() and p.stat().st_size!=entry['size']:p.unlink()
 if not p.exists():
  started=time.time();print('WHEEL_START',p.name,flush=True)
  with urllib.request.urlopen(entry['url'].replace('https://files.pythonhosted.org','https://mirrors.aliyun.com/pypi'),timeout=30) as r,p.open('wb') as f:
   while True:
    b=r.read(1024*1024)
    if not b:break
    f.write(b)
  print('WHEEL_DONE',p.name,p.stat().st_size,round(time.time()-started,2),flush=True)
 import hashlib
 if hashlib.sha256(p.read_bytes()).hexdigest()!=entry['digests']['sha256']:raise ValueError('Bad wheel hash')

