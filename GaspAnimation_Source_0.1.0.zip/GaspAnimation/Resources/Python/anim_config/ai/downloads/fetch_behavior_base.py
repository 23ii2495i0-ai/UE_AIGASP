"""Independent author-hosted baseline; never rewrites active model pointers."""
import json,urllib.request
from concurrent.futures import ThreadPoolExecutor
from fetch_modelscope import ROOT,download


def main():
    repo='Qwen/Qwen3-4B-Instruct-2507'
    dest=ROOT/'artifacts/anim_config/models/configuration/behavior_bases/Qwen3-4B-Instruct-2507'
    dest.mkdir(parents=True,exist_ok=True);manifest=dest/'modelscope_sources.json'
    if manifest.exists():meta=json.loads(manifest.read_text(encoding='utf-8'))
    else:
        data=json.load(urllib.request.urlopen('https://modelscope.cn/api/v1/models/'+repo+'/repo/files?Revision=master&Recursive=true',timeout=30))
        files=[f for f in data['Data']['Files'] if f['Path'].endswith(('.json','.safetensors','.txt','.jinja'))]
        if not files or not any(f['Path'].endswith('.safetensors') for f in files):raise ValueError('No model weights in author repository')
        meta=dict(repo=repo,source='https://modelscope.cn/models/'+repo,files=files,purpose='independent untrained extraction baseline; not deployed')
        manifest.write_text(json.dumps(meta,indent=2),encoding='utf-8')
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda entry:download(entry,repo,dest),meta['files']))
    print('BEHAVIOR_BASE_VERIFIED',flush=True)


if __name__=='__main__':main()
