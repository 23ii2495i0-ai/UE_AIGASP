"""Fetch author-declared Apache-2.0 structured data, pin files and audit duplicates."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,hashlib,urllib.request,urllib.parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=_LAYOUT_REPO;OUT=ROOT/'artifacts/anim_config/models/configuration/sources/bulk'
API='https://modelscope.cn/api/v1/datasets/NousResearch/hermes-function-calling-v1/repo'
def main():
 OUT.mkdir(parents=True,exist_ok=True);manifest=OUT/'sources.json'
 if manifest.exists():entries=json.loads(manifest.read_text())['files']
 else:
  meta=json.load(urllib.request.urlopen(API+'/tree?Revision=master&Root=',timeout=60))
  entries=[x for x in meta['Data']['Files'] if x['Path'].endswith('.json') and x['Path']!='dataset_infos.json' or x['Path']=='README.md']
  manifest.write_text(json.dumps({'author_repo':'NousResearch/hermes-function-calling-v1','declared_license':'Apache-2.0','upstream':'https://huggingface.co/datasets/NousResearch/hermes-function-calling-v1','files':entries},indent=2),encoding='utf-8')
 def fetch(e):
  p=OUT/e['Path'];digest=lambda:hashlib.sha256(p.read_bytes()).hexdigest()
  if p.exists() and digest()==e['Sha256']:return
  url=API+'?'+urllib.parse.urlencode({'Revision':e['Revision'],'FilePath':e['Path']})
  with urllib.request.urlopen(url,timeout=120) as r:p.write_bytes(r.read())
  if digest()!=e['Sha256']:raise RuntimeError('SHA mismatch '+p.name)
  print('VERIFIED',p.name,p.stat().st_size,flush=True)
 with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(fetch,entries))
 print('BULK_DOWNLOAD_COMPLETE',flush=True)
if __name__=='__main__':main()
