"""Download author-hosted JSON auxiliary data with revision and SHA provenance."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import hashlib,json,urllib.request,argparse
from pathlib import Path
ROOT=_LAYOUT_REPO
OUT=ROOT/'artifacts/anim_config/models/configuration/sources/external/hermes'

def main():
 p=argparse.ArgumentParser();p.add_argument('--refresh',action='store_true');args=p.parse_args()
 OUT.mkdir(parents=True,exist_ok=True)
 api='https://modelscope.cn/api/v1/datasets/NousResearch/hermes-function-calling-v1/repo'
 saved=OUT/'provenance.json'
 if saved.exists() and not args.refresh:
  entries=[f['metadata'] for f in json.loads(saved.read_text(encoding='utf-8'))['files']]
 else:
  listing=json.load(urllib.request.urlopen(api+'/tree?Revision=master&Root=',timeout=60))
  entries=listing['Data']['Files']
 files=[]
 for name in ['README.md','json-mode-singleturn.json']:
  entry=next(x for x in entries if x['Path']==name)
  url=api+'?Revision='+entry['Revision']+'&FilePath='+name
  path=OUT/name
  expected=entry.get('Sha256')
  if not path.exists() or (expected and hashlib.sha256(path.read_bytes()).hexdigest()!=expected):
   with urllib.request.urlopen(url,timeout=120) as response:path.write_bytes(response.read())
  digest=hashlib.sha256(path.read_bytes()).hexdigest()
  if expected and digest!=expected:raise RuntimeError('Checksum mismatch: '+name)
  files.append({'path':name,'url':url,'metadata':entry,'sha256':digest})
 (OUT/'provenance.json').write_text(json.dumps({'author_repo':'NousResearch/hermes-function-calling-v1','declared_license':'Apache-2.0','purpose':'JSON auxiliary only, not UE animation annotations','files':files},indent=2),encoding='utf-8')
 print('EXTERNAL_DATA_VERIFIED',flush=True)
if __name__=='__main__':main()
