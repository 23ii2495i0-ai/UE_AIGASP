# AI 程序入口

## 配置生成与资源选择

- `configuration/runtime/`：编辑器在线服务、生成器/选择器协议、候选资源分批选择。
- `configuration/training/`：Qwen LoRA 训练及训练损失实现。
- `configuration/datasets/`：合成配置训练集构建与数据检查。
- `configuration/evaluation/`：独立、串联评测及发布门槛。
- `configuration/ui/`：配置模型的可见进度窗口。

当前在线版本使用一个 Qwen2.5-1.5B-Instruct 基座和两套独立 LoRA：generator 生成配置，selector 挑选资源。共享基座、按阶段切换适配器，选择阶段使用 selector。基座和权重位于 `artifacts/anim_config/models/configuration/`；活动指针仍为 `artifacts/anim_config/active_model.json`。

多状态配置协议支持五类移动槽和 hit/attack/jump/dodge 四类动作槽；扩展模型独立训练、评测后发布。跳跃由角色实际起跳触发，闪避翻滚为特殊状态，详见 `unreal/MULTISTATE_CONFIG.md`。姿态模型的分类数量与配置槽位数量分别管理。

## 骨骼姿态识别

- `pose/core/`：骨骼读取、稀疏采样、数值特征和类别定义。
- `pose/datasets/`：CMU、HumanAct12、CC0 作者动画下载。
- `pose/review/`：静止/重复过滤、单动作导出、Blender 验证、跳跃标签整理。
- `pose/training/`：训练与离线推理；保留基线、扩充、战斗和时序版本以重现历史实验。
- `pose/ui/`：姿态训练可见进度窗口。

最新六类定义为 walk/run/attack/other/hit/jump。训练入口 `pose/training/train_pose_temporal.py`。2026-10-21 按用户明确要求，expanded_combat_v4/run_v1 已作为实验辅助接入 UE 名称选择流程；生成结果支持每类多个候选。移动候选交给 MM 数据库，攻击/受击候选轮换。受击训练仍仅4段，不代表通过 UE 识别质量验收。流程与限制见 [HYBRID_UE.md](pose/HYBRID_UE.md)；不能把文本选择器的测试结果当成姿态识别正确率。

## 公共部分

- `downloads/`：语言模型和公共辅助数据、离线安装包下载。
- `shared/requirements.txt`：Python 依赖。
- `tests/`：AI 模块测试；外围协议测试仍在 `tools/anim_config/test_*.py`。
- `project_paths.py`：统一定位仓库与脚本直接运行的导入路径。

直接运行各脚本的完整新路径；项目根目录的“查看训练进度.bat”和“查看姿态训练进度.bat”继续可用。目录迁移记录在 `artifacts/anim_config/organization_manifest.json`。
