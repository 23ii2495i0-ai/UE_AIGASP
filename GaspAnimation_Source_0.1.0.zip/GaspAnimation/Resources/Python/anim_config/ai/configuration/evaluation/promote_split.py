"""Publish a paired model only after fixed per-task, end-to-end and native playback gates."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json
from pathlib import Path
THRESHOLDS={'json_valid':.98,'protocol_valid':.98,'exact':.85}

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--native-report',type=Path,required=True);p.add_argument('--base',type=Path,required=True);a=p.parse_args()
    reports={};hashes={};configs={};prompts={}
    for task in ('generator','selector'):
        r=json.loads((a.run/task/'test_metrics.json').read_text(encoding='utf-8'))
        if r['task']!=task or r['n']<100 or any(r['metrics'].get(k,0)<v for k,v in THRESHOLDS.items()):raise ValueError(f"{task} failed fixed gate: n={r['n']}, metrics={r['metrics']}")
        reports[task]=r['metrics'];hashes[task]=hashlib.sha256((a.run/task/'adapter/adapter_model.safetensors').read_bytes()).hexdigest()
        configs[task]=hashlib.sha256((a.run/task/'adapter/adapter_config.json').read_bytes()).hexdigest()
        prompt=a.run/task/'adapter/prompt_config.json';prompts[task]=hashlib.sha256(prompt.read_bytes()).hexdigest() if prompt.exists() else None
    pipeline=json.loads((a.run/'pipeline_metrics.json').read_text(encoding='utf-8'))
    if pipeline.get('adapter_sha256')!=hashes:raise ValueError('Paired evaluation does not match current adapter weights')
    if pipeline['n']<100 or pipeline['metrics']['exact']<.75 or pipeline['metrics']['protocol_valid']<.98:raise ValueError('End-to-end paired-model gate failed')
    native=json.loads(a.native_report.read_text(encoding='utf-8-sig'))
    required={'flow_native_graph','flow_saved_policy','flow_attack_locked','flow_montage_slot_active','flow_hit_interrupt','flow_previous_resumed','flow_natural_completion','flow_mm_recovered','flow_sprint_blocks_aim','flow_hit_returns_mm'}
    prompt_config=a.run/'generator/adapter/prompt_config.json'
    if prompt_config.exists() and json.loads(prompt_config.read_text(encoding='utf-8')).get('prompt_version')==3:
        required.update({'flow_jump_grounded_rejected','flow_jump_physics','flow_jump_event','flow_jump_landed_exit','flow_dodge_airborne_rejected','flow_dodge_started','flow_hit_interrupts_dodge'})
    if native.get('failures')!=0 or not required<={r['name'] for r in native['checks'] if r.get('passed')}:raise ValueError('Native playback gate failed or incomplete')
    manifest={'protocol':'generator_selector_v1','flow_protocol':2,'runtime_flow_version':1,'base':str(a.base.resolve()),'run':str(a.run.resolve()),'adapter_sha256':hashes,'adapter_config_sha256':configs,'prompt_sha256':prompts,'test':reports,'pipeline':pipeline['metrics'],'thresholds':THRESHOLDS,'requires_human_review':True,'native_report':str(a.native_report.resolve()),'native_report_sha256':hashlib.sha256(a.native_report.read_bytes()).hexdigest()}
    (a.run/'split_deployment.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('SPLIT_PROMOTION_PASS')
if __name__=='__main__':main()
