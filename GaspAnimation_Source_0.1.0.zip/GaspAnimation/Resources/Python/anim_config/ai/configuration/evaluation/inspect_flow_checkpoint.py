"""Offline diagnostic only: inspect an unpromoted V2 checkpoint; never import assets."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,json,hashlib
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
from peft import PeftModel
from flow_protocol import messages,validate_ir,compile_flow
from train import parse_json
ROOT=_LAYOUT_REPO;ART=ROOT/'artifacts/anim_config'
def main():
 p=argparse.ArgumentParser();p.add_argument('--catalog',required=True);p.add_argument('--request',required=True);p.add_argument('--output',required=True);p.add_argument('--adapter',default=str(ART/'models/configuration/runs/flow_v2_lora/adapter'));a=p.parse_args()
 catalog=json.loads(Path(a.catalog).read_text(encoding='utf-8-sig'));request=Path(a.request).read_text(encoding='utf-8-sig')
 tokenizer=AutoTokenizer.from_pretrained(ART/'models/configuration/base_model',local_files_only=True,trust_remote_code=False)
 base=AutoModelForCausalLM.from_pretrained(ART/'models/configuration/base_model',local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda')
 model=PeftModel.from_pretrained(base,a.adapter);model.eval()
 msgs,_=messages(catalog,request);ids=tokenizer.apply_chat_template(msgs,add_generation_prompt=True,return_tensors='pt').to('cuda')
 with torch.inference_mode():out=model.generate(ids,attention_mask=torch.ones_like(ids),max_new_tokens=384,do_sample=False,pad_token_id=tokenizer.eos_token_id)
 raw=tokenizer.decode(out[0,ids.shape[-1]:],skip_special_tokens=True)
 result={'evaluation_only':True,'request':request,'raw':raw,'adapter_sha256':hashlib.sha256((Path(a.adapter)/'adapter_model.safetensors').read_bytes()).hexdigest()}
 try:
  pred=parse_json(raw);result['prediction']=pred;validate_ir(catalog,pred)
  metrics_file=Path(a.adapter).parent/'test_metrics.json'
  exact=json.loads(metrics_file.read_text(encoding='utf-8'))['metrics']['exact'] if metrics_file.exists() else 0
  result['plan']=compile_flow(catalog,request,'/Game/DiagnosticOnly',pred,{'evaluation_only':True,'trained':True,'heldout_exact':exact})
  result['ir_valid']=True
 except (ValueError,KeyError,TypeError) as e:result['ir_valid']=False;result['error']=str(e)
 target=Path(a.output);target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('OFFLINE_DIAGNOSTIC_SAVED',target,'ir_valid=',result['ir_valid'])
if __name__=='__main__':main()
