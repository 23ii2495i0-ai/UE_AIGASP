"""Schema/reference/shape audit of labeled data, not an NL correctness proof."""
import argparse,collections,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from behavior_requirements import extraction_messages,compile_requirements,validate_generated_symbols


def audit(directory):
    import jsonschema
    defaults=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=.25,window_end=.65,jump_velocity=500)
    report={};ids={};requests={}
    for split in ('train','validation','test'):
        rows=[json.loads(line) for line in (directory/(split+'.jsonl')).read_text(encoding='utf-8').splitlines()];names=set();texts=set();shapes=collections.Counter()
        if len(rows)%6:raise ValueError('Incomplete staged request')
        for i in range(0,len(rows),6):
            chunk=rows[i:i+6];targets={r['stage']:r['target'] for r in chunk};request=chunk[0]['request'];texts.add(request)
            if len(targets)!=6 or any(r['request']!=request for r in chunk):raise ValueError('Mixed/incomplete request stages')
            for row in chunk:jsonschema.validate(row['target'],extraction_messages(row['stage'],request,row['reviewed'])[0])
            topology=dict(targets['topology'],standalone=sorted(targets['combo']['policy']['attacks']+[targets['combo']['policy']['hit']]) if targets['combo']['policy'] else [])
            declared={n for g in topology['groups'] for n in [g['id']]+g['children']}
            if topology['entry'] not in declared:topology['standalone'].append(topology['entry'])
            ir=dict(version=1,topology=topology,**{k:targets[k]['policy'] for k in ('locomotion','jump','combo')},**targets['dependencies'],settings={k:defaults[k] if v is None else v for k,v in targets['settings'].items()})
            validate_generated_symbols(ir,request);compile_requirements(ir,request)
            names.update(declared|set(topology['standalone']));loc=ir['locomotion']
            shapes['jump_or_combo' if ir['jump'] or ir['combo'] else 'ungrouped' if not topology['groups'] else f"group_walk{bool(loc['walk'])}_run{bool(loc['run'])}"]+=1
        report[split]=dict(requests_checked=len(rows)//6,current_schema_valid=True,targets_compile=True,shapes=dict(shapes));ids[split]=names;requests[split]=texts
    report['train_test_state_id_overlap']=sorted(ids['train']&ids['test'])
    report['train_test_request_overlap']=len(requests['train']&requests['test'])
    if report['train_test_state_id_overlap'] or report['train_test_request_overlap']:raise ValueError('Training/test overlap')
    report['scope']='label schema/reference integrity only; not source-language meaning, model quality, material or playback acceptance'
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();result=audit(a.data_dir);a.output.write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
