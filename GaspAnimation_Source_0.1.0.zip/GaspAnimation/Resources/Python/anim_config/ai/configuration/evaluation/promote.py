"""Explicitly promote an evaluated prototype; never serve an unevaluated checkpoint."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,json,hashlib
from pathlib import Path
ROOT=_LAYOUT_REPO
def main():
 p=argparse.ArgumentParser();p.add_argument('--run',default=str(ROOT/'artifacts/anim_config/models/configuration/runs/initial_lora'));p.add_argument('--min-exact',type=float,default=.7);a=p.parse_args();r=Path(a.run)
 report=json.loads((r/'training_report.json').read_text(encoding='utf-8'));base=json.loads((r/'baseline_validation.json').read_text(encoding='utf-8'))['metrics'];val=json.loads((r/'adapted_validation.json').read_text(encoding='utf-8'))['metrics'];test=json.loads((r/'test_metrics.json').read_text(encoding='utf-8'))['metrics']
 if test['n']<60 or test['json_valid']<.98 or test['exact']<a.min_exact or val['exact']<base['exact']:raise RuntimeError('Prototype promotion criteria not met')
 if 'ir_valid' in test and test['ir_valid']<.98:raise RuntimeError('Flow IR validity below 98%')
 adapter=r/'adapter/adapter_model.safetensors';digest=hashlib.sha256(adapter.read_bytes()).hexdigest()
 deployment={'base_model':report['base_model'],'adapter_sha256':digest,'method':report['method'],'optimizer_steps':report['steps'],'examples_consumed':report['steps']*report['gradient_accumulation'],'prototype':True,'requires_human_review':True,'validation':val,'test':test,'synthetic_test':True,'sources':str(ROOT/'artifacts/anim_config/sources.json'),'promotion_min_exact':a.min_exact}
 deployment['flow_protocol']=2 if 'policy' in test else 1
 deployment['complex_flow_runtime']=False
 (r/'deployment.json').write_text(json.dumps(deployment,indent=2),encoding='utf-8');print('PROMOTED_PROTOTYPE',json.dumps(deployment),flush=True)
if __name__=='__main__':main()
