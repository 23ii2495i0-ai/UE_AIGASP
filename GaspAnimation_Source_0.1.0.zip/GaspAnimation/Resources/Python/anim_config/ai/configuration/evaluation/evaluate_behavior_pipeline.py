"""End-to-end model->IR->graph evaluation against independent expected labels.

Material blocking is reported separately; missing combat content never passes
application acceptance merely because extraction succeeded.
"""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import sys,json,argparse,urllib.request,urllib.error,copy,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from behavior_requirements import semantic_audit,validate_topology
from config_tool import validate

ROOT=_gasp_workspace


def expected_original():
    return dict(topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run'],initial='Idle'),dict(id='Air',children=['Rise','Fall'],initial='Rise')]),locomotion=dict(group='Ground',idle='Idle',walk='Walk',run='Run'),jump=dict(group='Air',rise='Rise',fall='Fall',counter='JumpCount',max_jumps=2),combo=dict(attacks=['Attack1','Attack2'],hit='Hit',buffer='Queued'),external_variables=[],unsupported=[],settings=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=.25,window_end=.65,jump_velocity=500))


def normalized_topology(topology):
    return dict(entry=topology['entry'],groups=sorted([dict(id=g['id'],children=sorted(g['children']),initial=g['initial']) for g in topology['groups']],key=lambda g:g['id']))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--catalog',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--endpoint',default='http://127.0.0.1:8766/generate');parser.add_argument('--requests',type=int,default=4);parser.add_argument('--include-original',action='store_true');parser.add_argument('--data-dir',type=Path);parser.add_argument('--destination-prefix',default='/Game/Native/Generated/BehaviorIRProbe_');parser.add_argument('--counterfactual',action='store_true');parser.add_argument('--case-ids', help='Comma separated frozen regression IDs');parser.add_argument('--freeze-only',action='store_true');parser.add_argument('--case-file',type=Path);args=parser.parse_args()
    catalog=json.loads(args.catalog.read_text(encoding='utf-8-sig'));args.output.mkdir(parents=True,exist_ok=True)
    data=args.data_dir or ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v1'
    rows=[json.loads(line) for line in (data/'test.jsonl').read_text(encoding='utf-8').splitlines()]
    cases=[]
    if args.include_original:cases.append(dict(id='original_user_request',request=(ROOT/'artifacts/anim_config/verification/behavior_repair/request.txt').read_text(encoding='utf-8-sig'),expected=expected_original()))
    if args.include_original:
        expected=expected_original();expected['combo']=None
        request='\n'.join(['Ground 为父状态，包含 Idle、Walk、Run。默认子状态 Idle，入口 Ground。','使用 Motion Matching：Idle 待机，Walk 走路，Run 跑步；根据移动输入和步态切换，停止输入返回 Idle。','Air 为父状态，包含 Rise、Fall。默认子状态 Rise。','支持二段跳。内部计数 JumpCount 初始0，只在 JumpCount < 2 时允许实际起跳并加1；落地后清零。','根据垂直速度在 Rise 和 Fall 之间切换，落地返回 Ground。','不配置攻击或受击，不需要战斗素材。'])
        cases.append(dict(id='original_movement_jump',request=request,expected=expected))
    if args.include_original and data.name in ('behavior_requirements_v4','behavior_requirements_v5'):
        expected=expected_original();expected.update(topology=dict(entry='Move',groups=[]),locomotion=dict(group='Move',idle='Move',walk=None,run=None),jump=None,combo=None)
        cases.append(dict(id='minimal_single_mm',request='只需要一个状态 Move，入口 Move，不设父组，不添加其他状态或变量。Move 使用待机 Motion Matching；不配置跳跃、攻击或受击。',expected=expected))
    if args.counterfactual:
        request='\n'.join(['Main 为父状态，包含 Wait、Step、Dash。默认子状态 Wait，入口 Main。','使用 Motion Matching：Wait 是待机，Step 是走路，Dash 是跑步；根据移动输入和步态选择，停止返回 Wait。','Flight 为父状态，包含 Up、Down。默认子状态 Up。','Up 是上升，Down 是下降，根据真实垂直速度切换。','内部跳跃计数 AirCount 初始0；只在 AirCount < 3 时允许实际起跳并加1，落地后清零。','连招依次经过 SlashA → SlashB；受击使用 Pain。内部缓存 Buffered 初始false。','仅在连招窗口内缓存一次输入，重复按键不重复缓存。进入下一段、退出攻击或受击打断时清空，受击结束按地面或空中返回，不恢复攻击。','Blends in seconds: ground 0.31, attacks 0.17, hit 0.08.','Normalized combo window: 0.2 to 0.8. Jump launch velocity: 750.'])
        expected=dict(topology=dict(entry='Main',groups=[dict(id='Main',children=['Wait','Step','Dash'],initial='Wait'),dict(id='Flight',children=['Up','Down'],initial='Up')]),locomotion=dict(group='Main',idle='Wait',walk='Step',run='Dash'),jump=dict(group='Flight',rise='Up',fall='Down',counter='AirCount',max_jumps=3),combo=dict(attacks=['SlashA','SlashB'],hit='Pain',buffer='Buffered'),external_variables=[],unsupported=[],settings=dict(move_blend=.31,attack_blend=.17,hit_blend=.08,window_start=.2,window_end=.8,jump_velocity=750))
        cases.append(dict(id='counterfactual_numeric',request=request,expected=expected))
    if data.name in ('behavior_requirements_v3','behavior_requirements_v4','behavior_requirements_v5'):
        # Handwritten after training, independent of the dataset templates and
        # opaque WordXX identifiers. Keep failures; never add a graph fallback.
        request='\n'.join(['入口是 hub。hub 为父状态，包含 s2、s0、s1；初始子状态是 s1。','三者内部使用 Motion Matching：s2 表示跑步，s0 表示待机，s1 表示走路。按移动输入和步态选择，停止输入返回 s0。','airbox 为父状态，包含 u1、u0；初始子状态是 u1。u0 对应上升，u1 对应下降，取决于真实垂直速度。','内部跳跃计数 n 初始0；仅当 n < 3 时允许实际起跳且同时加1，落地清零。','连招顺序 a0 → a1，受击状态 hit0。内部缓存 q 初始false。','只在非末段连招窗口内缓存一次输入，窗口前后不缓存；重复按键不重复写入。完成时有缓存才进下一段，否则回地面组。进入下一段、退出攻击和受击打断均清空 q。受击结束按真实地面/空中状态返回，不续接攻击。','Blends in seconds: ground 0.37, attacks 0.14, hit 0.06.','Normalized combo window: 0.18 to 0.78. Jump launch velocity: 730.'])
        expected=dict(topology=dict(entry='hub',groups=[dict(id='hub',children=['s0','s1','s2'],initial='s1'),dict(id='airbox',children=['u0','u1'],initial='u1')]),locomotion=dict(group='hub',idle='s0',walk='s1',run='s2'),jump=dict(group='airbox',rise='u0',fall='u1',counter='n',max_jumps=3),combo=dict(attacks=['a0','a1'],hit='hit0',buffer='q'),external_variables=[],unsupported=[],settings=dict(move_blend=.37,attack_blend=.14,hit_blend=.06,window_start=.18,window_end=.78,jump_velocity=730))
        cases.append(dict(id='short_ids_fresh_v3',request=request,expected=expected))
    defaults=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=.25,window_end=.65,jump_velocity=500)
    for start in range(0,min(len(rows),args.requests*6),6):
        chunk=rows[start:start+6];targets={r['stage']:r['target'] for r in chunk}
        expected=dict(topology=targets['topology'],**{k:targets[k]['policy'] for k in ('locomotion','jump','combo')},**targets['dependencies'],settings={k:defaults[k] if v is None else v for k,v in targets['settings'].items()})
        cases.append(dict(id=chunk[0]['id'].split('_')[0],request=chunk[0]['request'],expected=expected))
    if args.case_file:
        cases=json.loads(args.case_file.read_text(encoding='utf-8'))['cases']
    if args.case_ids:
        selected=args.case_ids.split(',');known={case['id']:case for case in cases}
        if len(selected)!=len(set(selected)):raise ValueError('Duplicate selected case IDs')
        unknown=set(selected)-known.keys()
        if unknown:raise ValueError(f'Unknown case IDs: {sorted(unknown)}')
        cases=[known[key] for key in selected]
    if not cases:raise ValueError('Empty evaluation suite')
    if len({case['id'] for case in cases})!=len(cases):raise ValueError('Duplicate evaluation case IDs')
    frozen=dict(kind='frozen_end_to_end_requirements',automatic_retraining=False,cases=cases)
    frozen_text=json.dumps(frozen,ensure_ascii=False,indent=2)
    (args.output/'cases.json').write_text(frozen_text,encoding='utf-8')
    suite_sha256=hashlib.sha256(frozen_text.encode('utf-8')).hexdigest()
    if args.freeze_only:return
    results=[]
    for case in cases:
        # The Main/Wait/Step/Dash probe was observed during v2 development.
        # Reusing it later is a regression, never a new heldout result.
        development=case['id'].startswith('original_') or case['id'] in ('counterfactual_numeric','minimal_single_mm') or (case['id']=='short_ids_fresh_v3' and data.name!='behavior_requirements_v3')
        item=dict(id=case['id'],split='development_original_or_runtime_probe' if development else 'heldout',requirements_exact=False,application_accepted=False)
        payload=dict(catalog=catalog,request=case['request'],destination=args.destination_prefix+case['id'],behavior_mode=True)
        try:
            request=urllib.request.Request(args.endpoint,json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode(),{'Content-Type':'application/json'})
            with urllib.request.urlopen(request,timeout=1800) as response:result=json.load(response)
            plan=result['plan'];ir=plan['model_info']['behavior_requirements'];validate_topology(ir['topology'],case['request'])
            expected=case['expected'];fields={key:ir[key]==expected[key] for key in ('locomotion','jump','combo','external_variables','unsupported','settings')}
            fields['topology']=normalized_topology(ir['topology'])==normalized_topology(expected['topology'])
            audit=semantic_audit(ir,case['request'],plan['behavior_graph'])
            invalid_fixture=any('/ActionFlowFixture/' in path or 'playbacktest' in path.lower() for state in plan['behavior_graph']['states'] for path in state['resources'])
            errors=validate(plan,catalog)
            manual=bool(plan['model_info']['behavior_generation'].get('requirements_edited_manually'))
            item.update(requirements_exact=all(fields.values()) and not manual,fields=fields,compiled_equivalence=not audit,manually_edited=manual,fixture_bound=invalid_fixture,validation_errors=errors,application_accepted=not errors,model=result.get('model',{}))
            (args.output/(case['id']+'_plan.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
            # Independent expected labels can drive the later real UE smoke.
            (args.output/(case['id']+'_expected.json')).write_text(json.dumps(expected,ensure_ascii=False,indent=2),encoding='utf-8')
        except urllib.error.HTTPError as error:item['error']=error.read().decode('utf-8',errors='replace')
        except (ValueError,KeyError,TypeError) as error:item['error']=str(error)
        # Classify observed evidence, not a speculative root cause. Strict
        # server rejection needs its preserved stage trace for diagnosis.
        item['observed_layer']=('generation_rejected_requires_trace' if 'error' in item else
            'requirements_mismatch' if not item['requirements_exact'] else
            'compiler_mismatch' if not item['compiled_equivalence'] else
            'resource_or_application_block' if not item['application_accepted'] else 'accepted')
        item['suite_sha256']=suite_sha256
        results.append(item);print('BEHAVIOR_PIPELINE',case['id'],item['requirements_exact'],item['application_accepted'],flush=True)
        heldout=[r for r in results if r['split']=='heldout']
        (args.output/'report.json').write_text(json.dumps(dict(kind='end_to_end_expected_label_comparison',planned_n=len(cases),completed=len(results)==len(cases),data_manifest=json.loads((data/'manifest.json').read_text(encoding='utf-8')),n=len(results),requirements_exact=sum(r['requirements_exact'] for r in results),heldout_n=len(heldout),heldout_requirements_exact=sum(r['requirements_exact'] for r in heldout),application_accepted=sum(r['application_accepted'] for r in results),cases=results),ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__':main()
