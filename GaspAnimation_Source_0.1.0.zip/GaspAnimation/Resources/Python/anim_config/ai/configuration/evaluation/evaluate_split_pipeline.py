"""End-to-end evaluation uses GENERATED slots, never teacher-forced selector configuration."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,json,hashlib
from pathlib import Path
from split_runtime import SplitRuntime
from split_protocol import generator_messages,selector_messages,validate_generator,score

def main():
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--test',type=Path,required=True);p.add_argument('--batch-size',type=int,default=8);a=p.parse_args()
    if a.batch_size<1:raise ValueError('batch size must be positive')
    rt=SplitRuntime(a.base,a.run/'generator/adapter',a.run/'selector/adapter')
    results=[];rows=[json.loads(line) for line in a.test.read_text(encoding='utf-8').splitlines() if line.strip()]
    for start in range(0,len(rows),a.batch_size):
        batch=rows[start:start+a.batch_size];ready=[]
        raws=rt.predict_batch('generator',[generator_messages(r['request'],rt.generator_prompt_version) for r in batch])
        for row,raw in zip(batch,raws):
            try:g=json.loads(raw);validate_generator(g);ready.append((row,g))
            except (ValueError,TypeError,KeyError) as e:results.append({'id':row['id'],'exact':False,'protocol_valid':False,'generator_exact':False,'selector_exact':False,'error':str(e)})
        if ready:
            selections=rt.predict_batch('selector',[selector_messages(r['catalog'],r['request'],g) for r,g in ready])
            for (row,g),raw in zip(ready,selections):
                try:
                    s=json.loads(raw);gs=score('generator',{'target':row['configuration']},g);ss=score('selector',dict(row,configuration=g),s)
                    item={'id':row['id'],'generator_exact':gs['exact'],'selector_exact':ss['exact'],'protocol_valid':gs['protocol_valid'] and ss['protocol_valid'],'exact':gs['exact'] and ss['exact']}
                except (ValueError,TypeError,KeyError) as e:item={'id':row['id'],'exact':False,'protocol_valid':False,'generator_exact':False,'selector_exact':False,'error':str(e)}
                results.append(item)
        print('PIPELINE_EVAL',len(results),'/',len(rows),flush=True)
    keys=['generator_exact','selector_exact','protocol_valid','exact']
    report={'n':len(results),'batch_size':a.batch_size,'test_sha256':hashlib.sha256(a.test.read_bytes()).hexdigest(),'adapter_sha256':{t:hashlib.sha256((a.run/t/'adapter/adapter_model.safetensors').read_bytes()).hexdigest() for t in ('generator','selector')},'metrics':{k:sum(r[k] for r in results)/len(results) for k in keys},'cases':results}
    (a.run/'pipeline_metrics.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(report['metrics'])
if __name__=='__main__':main()
