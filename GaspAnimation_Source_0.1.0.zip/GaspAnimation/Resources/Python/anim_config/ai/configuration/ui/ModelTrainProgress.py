"""Read-only progress window for the current formal training; never starts training."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json
import re
import time
from pathlib import Path

ROOT = _LAYOUT_REPO
JOBS = [
    ('选择器', 'artifacts/anim_config/models/configuration/datasets/formal_split_v1/selector_recovery.log',
     'artifacts/anim_config/models/configuration/runs/formal_split_v1/selector', 2000),
    ('生成器', 'artifacts/anim_config/models/configuration/datasets/semantic_split_v2/generator_training.log',
     'artifacts/anim_config/models/configuration/runs/formal_split_release_v1/generator', 1500),
]


def read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError):
        return None


def snapshot():
    jobs = []
    for name, filename, directory, total in JOBS:
        log, run = ROOT / filename, ROOT / directory
        # Tqdm logs can be large; only read the latest 64 KiB.
        try:
            with log.open('rb') as stream:
                stream.seek(max(0, log.stat().st_size - 65536))
                tail = stream.read().decode('utf-8', errors='replace')
            age = max(0, time.time() - log.stat().st_mtime)
        except OSError:
            tail, age = '', None
        progress = re.findall(r'(\d+)\s*/\s*' + str(total) + r'\s*\[', tail)
        step = int(progress[-1]) if progress else 0
        report = read_json(run / 'training_report.json')
        metrics = read_json(run / 'test_metrics.json')
        # A completed evaluation must refer to the same weights as training.
        complete = bool(report and metrics and report.get('adapter_sha256') == metrics.get('adapter_sha256'))
        if complete:
            step = total
            state = '训练及独立评测完成'
        elif 'Traceback (most recent call last)' in tail:
            state = '发生错误，请查看日志'
        elif report:
            state = '训练完成，正在生成式评测'
            step = total
        elif not log.exists():
            state = '等待前一任务完成后启动'
        elif 'GENERATIVE_EVAL' in tail:
            state = '正在生成式评测'
        elif step:
            state = '正在训练'
        else:
            state = '加载数据和模型'
        stale = age is not None and age > 600 and not complete
        if stale:
            state += '（日志超过 10 分钟未更新，需检查进程）'
        jobs.append(dict(name=name, step=step, total=total, state=state,
                         log=str(log), run=str(run), complete=complete,
                         stale=stale, log_age_seconds=age,
                         metrics=metrics.get('metrics', {}) if complete else {}))
    return jobs


def main():
    import sys
    if '--snapshot' in sys.argv:
        print(json.dumps(snapshot(), ensure_ascii=False, indent=2))
        return
    import os
    import tkinter as tk
    from tkinter import ttk, messagebox
    window = tk.Tk()
    window.title('GASP 模型训练进度')
    window.geometry('740x440')
    window.minsize(680, 420)
    frame = ttk.Frame(window, padding=22)
    frame.pack(fill='both', expand=True)
    ttk.Label(frame, text='生成器 + 选择器 · 正式训练', font=('Microsoft YaHei UI', 16)).pack(anchor='w')
    ttk.Label(frame, text='每 3 秒刷新。关闭此窗口不会停止训练；重新打开可继续查看。').pack(anchor='w', pady=(6, 12))
    panels = []
    for name, filename, directory, total in JOBS:
        group = ttk.LabelFrame(frame, text=name, padding=12)
        group.pack(fill='x', pady=6)
        label = ttk.Label(group)
        label.pack(anchor='w')
        bar = ttk.Progressbar(group, maximum=total)
        bar.pack(fill='x', pady=6)
        ttk.Button(group, text='打开日志目录', command=lambda p=ROOT/filename: os.startfile(str(p.parent))).pack(anchor='e')
        panels.append((label, bar))
    footer = ttk.Label(frame, text='训练完成 ≠ 已替换模型。还须通过串联评测和 UE 应用验证。', wraplength=680)
    footer.pack(anchor='w', pady=12)
    notified = False
    error_notified = set()

    def refresh():
        nonlocal notified
        jobs = snapshot()
        for job, (label, bar) in zip(jobs, panels):
            label.config(text=f"{job['state']}  |  {job['step']} / {job['total']} 步")
            bar['value'] = job['step']
            if '发生错误' in job['state'] and job['name'] not in error_notified:
                error_notified.add(job['name'])
                window.bell()
                messagebox.showerror('训练错误', job['name'] + '训练出现错误，请查看对应日志。')
        if all(job['complete'] for job in jobs):
            results = '；'.join(f"{j['name']}完全匹配率 {j['metrics'].get('exact', 0):.1%}" for j in jobs)
            footer.config(text=results + '。尚未代表已通过发布验证或替换编辑器模型。')
            if not notified:
                notified = True
                window.bell()
                window.deiconify()
                window.lift()
                messagebox.showinfo('两项训练及独立评测完成', results + '\n下一步仍须串联评测、UE 验证和发布。')
        window.after(3000, refresh)

    refresh()
    window.mainloop()


if __name__ == '__main__':
    main()
