"""Cover every selected asset within each inference budget; preserve global ambiguity."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import copy
from protocol import compact_catalog
from split_protocol import selector_messages, merge


def partition(catalog, request, configuration, token_count, budget=4096):
    meshes = [a for a in catalog['assets'] if a['kind'] == 'mesh']
    if len(meshes) != 1:
        raise ValueError('请指定一个骨骼网格体后重新生成。')
    if len({a['id'] for a in catalog['assets']}) != len(catalog['assets']):
        raise ValueError('候选清单包含重复资源 ID。')
    chunks, current = [], list(meshes)
    for asset in catalog['assets']:
        if asset['kind'] == 'mesh':
            continue
        trial = dict(catalog, assets=current + [asset])
        if len(current) >= 128 or token_count(selector_messages(trial, request, configuration)) > budget:
            if len(current) == 1:
                raise ValueError('需求或单项资源元数据超出模型输入预算，请缩短描述或资源标签。')
            chunks.append(dict(catalog, assets=current))
            current = list(meshes)
        current.append(asset)
        if token_count(selector_messages(dict(catalog, assets=current), request, configuration)) > budget:
            raise ValueError('需求或单项资源元数据超出模型输入预算，请缩短描述或资源标签。')
    if current:
        chunks.append(dict(catalog, assets=current))
    return chunks


def checked_selection(chunk,configuration,selection):
    """Reject invalid model output locally; numeric/name assistance may still inspect real assets."""
    try:
        merge(chunk,configuration,selection)
        return selection,None
    except (ValueError,TypeError,KeyError) as exc:
        return dict(bindings={r:None for r in configuration['slots']},issues={r:'unsupported' for r in configuration['slots']}),str(exc)


def combine(catalog, configuration, chunks, selections):
    if len(chunks) != len(selections) or not chunks:
        raise ValueError('候选分批结果不完整，禁止使用部分结果。')
    _, full_ids = compact_catalog(catalog)
    aliases = {path: alias for alias, path in full_ids.items()}
    candidates = {slot: set() for slot in configuration['slots']}
    problems = {slot: set() for slot in configuration['slots']}
    for chunk, selection in zip(chunks, selections):
        _, ids = compact_catalog(chunk)
        selection=copy.deepcopy(selection)
        assets={a['id']:a for a in chunk['assets']}
        # Invalid playback types must remain unresolved, never bind an unsafe clip.
        if isinstance(selection,dict) and isinstance(selection.get('bindings'),dict) and isinstance(selection.get('issues'),dict):
            for slot,alias in list(selection['bindings'].items()):
                if alias not in ids or slot not in configuration['slots']:
                    continue
                asset=assets[ids[alias]]
                wrong_type=(configuration['slots'][slot]=='locomotion' and asset['kind']=='sequence' and not asset.get('loop')) or (configuration['slots'][slot]=='action' and (asset['kind']!='sequence' or asset.get('loop')))
                if wrong_type:
                    selection['bindings'][slot]=None
                    selection['issues'][slot]='unsupported'
        merge(chunk, configuration, selection)
        for slot, alias in selection['bindings'].items():
            if alias is not None:
                candidates[slot].add(ids[alias])
            else:
                problems[slot].add(selection['issues'][slot])
    bindings, issues = {}, {}
    for slot, paths in candidates.items():
        reason = next((r for r in ('mesh', 'unsupported', 'ambiguous') if r in problems[slot]), None)
        if len(paths) > 1:
            reason = reason or 'ambiguous'
        if reason or not paths:
            bindings[slot] = None
            issues[slot] = reason or 'missing'
        else:
            bindings[slot] = aliases[next(iter(paths))]
    result = dict(bindings=bindings, issues=issues)
    merge(catalog, configuration, result)
    return result
