"""V2 motion matching planning IR; explicit runtime capability gating."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json
from protocol import compact_catalog,compile_prediction
ROLES=['idle','walk','run','sprint','crouch']
ACTIONS=('hit','attack','jump','dodge')
SYSTEM='''Plan Motion Matching configuration. Return JSON only with exact keys roles,bindings,blend_seconds,filters,actions,policy,reject. roles is an ordered subset of idle,walk,run,sprint,crouch. bindings maps every requested role to selected compatible looping asset alias or null. Never invent assets. filters: optional weapon="rifle", injured=true, aim=true; only if requested. actions: optional hit or attack mapped to compatible nonloop sequence alias or null. policy optional keys: sprint_aim="block" when sprint forbids aiming; hit_interrupts="all" when hit interrupts actions; attack_exit="finished" when attack must finish; after_hit="locomotion" or "previous" only as requested. Default filters/actions/policy are empty objects; default blend_seconds=0.2, allowed 0..2. Name/tag metadata indicates role and variant. Prefer requested rifle/injured/aim variant if specified. reject=null unless missing,ambiguous,mesh,unsupported. Missing or ambiguous asset bindings are null. Do not guess arbitrary gameplay events. These policies are developer plans, not executable UE code.'''
def messages(catalog,request):
 assets,ids=compact_catalog(catalog)
 return [{'role':'system','content':SYSTEM},{'role':'user','content':json.dumps({'request':request,'assets':assets},ensure_ascii=False,separators=(',',':'))}],ids
def validate_ir(catalog,p):
 if not isinstance(p,dict) or set(p)!={'roles','bindings','blend_seconds','filters','actions','policy','reject'}:raise ValueError('Invalid flow fields')
 roles=p['roles'];bindings=p['bindings'];actions=p['actions'];filters=p['filters'];policy=p['policy']
 if not isinstance(roles,list) or roles!=[r for r in ROLES if r in roles]:raise ValueError('Invalid ordered roles')
 if not isinstance(bindings,dict) or set(bindings)!=set(roles):raise ValueError('Invalid bindings')
 if type(p['blend_seconds']) not in (float,int) or not 0<=p['blend_seconds']<=2:raise ValueError('Invalid blend')
 if not isinstance(filters,dict) or set(filters)-{'weapon','injured','aim'}:raise ValueError('Unknown filter')
 if ('weapon' in filters and filters['weapon']!='rifle') or any(type(v)!=bool or not v for k,v in filters.items() if k!='weapon'):raise ValueError('Invalid filter value')
 if not isinstance(actions,dict) or set(actions)-set(ACTIONS):raise ValueError('Unknown action')
 options={'sprint_aim':['block'],'hit_interrupts':['all'],'attack_exit':['finished'],'after_hit':['locomotion','previous']}
 if not isinstance(policy,dict) or any(k not in options or v not in options[k] for k,v in policy.items()):raise ValueError('Unknown policy')
 if 'attack_exit' in policy and 'attack' not in actions or any(k in policy for k in ('hit_interrupts','after_hit')) and 'hit' not in actions:raise ValueError('Policy requires action')
 if p['reject'] not in (None,'missing','ambiguous','mesh','unsupported'):raise ValueError('Unknown rejection')
 _,ids=compact_catalog(catalog);assets={a['id']:a for a in catalog['assets']};meshes=[a for a in catalog['assets'] if a['kind']=='mesh']
 if len(meshes)!=1:
  if p['reject']!='mesh':raise ValueError('Exactly one mesh required')
  return
 for key,alias in {**bindings,**actions}.items():
  if alias is None:
   if not p['reject']:raise ValueError('Unresolved resource without rejection')
   continue
  if alias not in ids:raise ValueError('Invented alias')
  a=assets[ids[alias]]
  if a['kind'] not in ('sequence','database') or a['skeleton']!=meshes[0]['skeleton']:raise ValueError('Incompatible resource')
  if key in bindings and a['kind']=='sequence' and not a.get('loop'):raise ValueError('Locomotion must loop')
  if key in actions and (a['kind']!='sequence' or a.get('loop')):raise ValueError('Action needs nonloop sequence')
def compile_flow(catalog,request,destination,p,info):
 validate_ir(catalog,p)
 # Reuse only validated locomotion bindings for v1; never silently discard complex policy.
 basic={k:p[k] for k in ('roles','bindings','blend_seconds','reject')}
 metadata=dict(info,flow_ir=p,flow_protocol=2)
 plan=compile_prediction(catalog,request,destination,basic,metadata)
 if p['filters'] or p['actions'] or p['policy']:
  plan['issues'].append({'severity':'error','code':'flow_runtime_unavailable','message':'V2 已生成配置流草案。条件过滤、动作锁定、打断与恢复尚需接入 C++ 执行层，当前禁止应用；请审阅 model_info.flow_ir。'})
 return plan
def simulate_policy(p,current,event,finished=False,previous='locomotion'):
 """Offline policy oracle, not a UE runtime implementation."""
 policy=p['policy']
 if event=='hit' and 'hit' in p['actions'] and policy.get('hit_interrupts')=='all':return 'hit'
 if current=='attack' and policy.get('attack_exit')=='finished' and not finished:return 'attack'
 if current=='hit' and finished:return previous if policy.get('after_hit')=='previous' else 'locomotion'
 if event=='aim' and current=='sprint' and policy.get('sprint_aim')=='block':return 'sprint'
 return event
