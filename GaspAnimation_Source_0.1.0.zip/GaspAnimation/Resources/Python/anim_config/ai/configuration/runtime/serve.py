"""Loopback-only inference service for the trained LoRA adapter (no rule fallback)."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,json,threading,time,hashlib,os
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import torch
from transformers import AutoTokenizer,AutoModelForCausalLM
from peft import PeftModel
from protocol import messages,compile_prediction
from train import parse_json
ROOT=_LAYOUT_REPO;ART=ROOT/'artifacts/anim_config'
def main():
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--adapter',default=str(ART/'models/configuration/runs/initial_lora/adapter'));a=p.parse_args()
 adapter=Path(a.adapter)
 if not (adapter/'adapter_model.safetensors').exists():raise RuntimeError('Trained adapter is missing; no rule or base-model fallback')
 deployment_file=adapter.parent/'deployment.json'
 if not deployment_file.exists():raise RuntimeError('No evaluated deployment manifest; run promote.py first')
 deployment=json.loads(deployment_file.read_text(encoding='utf-8'))
 protocol=deployment.get('flow_protocol',1)
 tokenizer=AutoTokenizer.from_pretrained(ART/'models/configuration/base_model',local_files_only=True,trust_remote_code=False)
 base=AutoModelForCausalLM.from_pretrained(ART/'models/configuration/base_model',local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda')
 model=PeftModel.from_pretrained(base,adapter);model.eval();model.config.use_cache=True
 digest=hashlib.sha256((adapter/'adapter_model.safetensors').read_bytes()).hexdigest()
 if digest!=deployment['adapter_sha256']:raise RuntimeError('Adapter checksum differs from evaluated deployment')
 info={'application':'gasp-animation-config-model','base':'Qwen2.5-1.5B-Instruct','adapter':str(adapter.resolve()),'adapter_sha256':digest,'trained':True,'device':torch.cuda.get_device_name(),'prototype':True,'requires_human_review':True,'heldout_exact':deployment['test']['exact'],'flow_protocol':protocol,'complex_flow_runtime':False};lock=threading.Lock()
 class Handler(BaseHTTPRequestHandler):
  def respond(self,status,body):
   data=json.dumps(body,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def do_GET(self):
   if self.path=='/health':self.respond(200,info)
   else:self.respond(404,{'error':'not found'})
  def do_POST(self):
   if self.headers.get('Host') not in (f'127.0.0.1:{a.port}',f'localhost:{a.port}'):self.respond(403,{'error':'invalid host'});return
   if self.path=='/shutdown':
    self.respond(200,{'stopping':True});threading.Thread(target=self.server.shutdown,daemon=True).start();return
   if self.path!='/generate':self.respond(404,{'error':'not found'});return
   try:
    n=int(self.headers.get('Content-Length','0'))
    if not 0<n<=1024*1024:raise ValueError('Request too large or empty')
    data=json.loads(self.rfile.read(n));catalog=data['catalog'];request=data['request'];destination=data['destination']
    if protocol==2:
     from flow_protocol import messages as flow_messages
     msgs,_=flow_messages(catalog,request)
    else:msgs,_=messages(catalog,request)
    ids=tokenizer.apply_chat_template(msgs,add_generation_prompt=True,return_tensors='pt').to('cuda')
    if ids.shape[-1]>4096:raise ValueError('Selection/request exceeds initial model context budget')
    started=time.time()
    with lock,torch.inference_mode():
     output=model.generate(ids,attention_mask=torch.ones_like(ids),max_new_tokens=384 if protocol==2 else 192,do_sample=False,pad_token_id=tokenizer.eos_token_id)
    raw=tokenizer.decode(output[0,ids.shape[-1]:],skip_special_tokens=True);prediction=parse_json(raw)
    if protocol==2:
     from flow_protocol import compile_flow
     plan=compile_flow(catalog,request,destination,prediction,info)
    else:plan=compile_prediction(catalog,request,destination,prediction,info)
    self.respond(200,{'plan':plan,'prediction':prediction,'seconds':time.time()-started,'model':info})
   except Exception as e:self.respond(422,{'error':str(e),'model':info})
 server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);print('MODEL_SERVER_READY',json.dumps(info),flush=True)
 try:server.serve_forever()
 finally:server.server_close()
if __name__=='__main__':main()
