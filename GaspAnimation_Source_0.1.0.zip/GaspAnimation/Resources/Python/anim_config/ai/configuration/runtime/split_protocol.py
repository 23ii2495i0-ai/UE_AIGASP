"""Independent resource-free generator and catalog-bound selector contracts."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import copy
import json
import re
from flow_protocol import ROLES, ACTIONS, validate_ir, compile_flow
from protocol import compact_catalog
from flow_schema import validate_runtime
from candidate_policy import selection_policy

GENERATOR_SYSTEM = '''Return only JSON with keys roles,slots,blend_seconds,filters,policy,reject. Generate a Motion Matching configuration from developer text WITHOUT seeing any resource catalog. roles is an ordered subset of idle,walk,run,sprint,crouch. slots maps each requested locomotion role to "locomotion" and optional hit/attack to "action". No asset IDs, paths, bindings or availability decisions. filters optionally weapon="rifle",injured=true,aim=true. policy optionally sprint_aim="block",hit_interrupts="all",attack_exit="finished",after_hit="previous" or "locomotion" as requested. blend_seconds defaults 0.2, range 0..2. reject is null or "unsupported" for unsupported semantics. Never reject because resources are missing: resource selection is a separate task.'''
SELECTOR_SYSTEM = '''Return only JSON with keys bindings,issues. Bind EVERY slot in the supplied immutable configuration using ONLY the selected catalog aliases. bindings maps slot name to alias or null. issues maps ONLY unresolved slot names to missing,ambiguous,mesh or unsupported. Do not alter configuration, filters, policies or blend. Require one mesh and compatible rig. Locomotion uses looping sequences or databases; actions use nonloop sequences. Match role and requested variants from text and metadata. With no filters use plain/neutral locomotion, not rifle/injured/aim variants. Do not invent resources or choose arbitrarily among equal matches.'''
GENERATOR_GUIDANCE = '''
Semantic guide / 语义说明:
idle = standing still, stopped, no movement input, 原地待命或静止站姿.
Exception: explicit reference/bind/T-pose while stopped (停止移动时使用参考姿势) uses the host's reference-idle option, NOT an idle animation resource slot. Only request idle when an actual idle animation is wanted.
walk = ordinary slow walking pace, 步行或缓步.
run = regular running or jogging, 常规跑速、小跑.
sprint = maximum speed, dash, burst of speed, 疾驰/疾跑/爆发全速. Do not collapse sprint into run when both requested.
crouch = low stance with bent knees, 蹲姿或曲膝低位行进.
hit is PASSIVE receiving damage: 被击中、挨打、受创、遭受伤害. attack is ACTIVE striking an opponent: 攻击、进攻、挥击、出招. 挥击 does NOT mean hit.
Generate only explicitly requested movement roles. A policy mentioning sprint does not by itself request a sprint animation slot.
hit_interrupts=all means damage reactions supersede any current action, regardless of completion; it requires a hit slot, not an attack slot.
attack_exit=finished means an attack cannot be exited before its clip ends; this requires an attack slot, not a hit slot.
after_hit=previous means resume the interrupted behavior from its saved position; after_hit=locomotion means hand control back to Motion Matching locomotion.
A rule about reacting to damage implies hit even without a separate 'add hit' clause. A rule about completing an attack implies attack. Never invent other actions or policies that were not requested.
sprint_aim=block means aiming is disallowed during sprint; this does not imply filters.aim=true. filters.aim=true only when movement animations themselves use aiming variants.
'''

def validate_generator(p):
    if not isinstance(p, dict) or set(p) != {'roles','slots','blend_seconds','filters','policy','reject'}:
        raise ValueError('Invalid generator fields')
    if not isinstance(p['roles'],list) or any(not isinstance(r,str) for r in p['roles']):
        raise ValueError('生成器的动作类别列表格式无效，请重新生成。')
    unsupported=set(p['roles'])-set(ROLES)
    if isinstance(p['slots'],dict):unsupported.update(set(p['slots'])-set(ROLES)-set(ACTIONS))
    if unsupported:
        names=', '.join(sorted(unsupported))
        raise ValueError('当前配置生成器尚不支持的移动类别：'+names+'。跳跃请使用 jump:action 槽位；支持待机、行走、跑步、冲刺、蹲伏、攻击、受击、跳跃和闪避。')
    if not isinstance(p['slots'], dict) or p['slots'] != {**{r:'locomotion' for r in p['roles']}, **{r:'action' for r in ACTIONS if r in p['slots']}}:
        raise ValueError('Invalid typed slots')
    if p['reject'] not in (None, 'unsupported'):
        raise ValueError('Generator cannot decide resource availability')
    # Reuse policy grammar with unresolved placeholders, without any asset input.
    validate_ir({'assets':[]}, dict(roles=p['roles'], bindings={r:None for r in p['roles']},
        blend_seconds=p['blend_seconds'], filters=p['filters'], policy=p['policy'],
        actions={r:None for r in p['slots'] if r not in p['roles']}, reject='mesh'))
    return p

def generator_messages(request,prompt_version=1):
    if prompt_version not in (1,2,3):raise ValueError('Unknown generator prompt version')
    system=GENERATOR_SYSTEM+(GENERATOR_GUIDANCE if prompt_version>=2 else '')
    if prompt_version==3:
        system=system.replace('optional hit/attack to "action"','optional hit/attack/jump/dodge to "action"')
        system+='\nJump / 跳跃 is a nonloop action slot named jump, never a locomotion role. Dodge / 闪避 / 翻滚 is a nonloop action slot named dodge. Include every explicitly requested supported slot. These actions return to locomotion on completion; jump physics comes from the character movement component. Never infer invulnerability, extra jumps or damage from an animation slot.'
    messages=[{'role':'system','content':system}]
    if prompt_version==3:
        messages.extend([
            {'role':'user','content':'配置走、跑、跳跃、蹲伏、攻击、受击和闪避翻滚。'},
            {'role':'assistant','content':json.dumps(dict(roles=['walk','run','crouch'],slots={'walk':'locomotion','run':'locomotion','crouch':'locomotion','hit':'action','attack':'action','jump':'action','dodge':'action'},blend_seconds=.2,filters={},policy={},reject=None),ensure_ascii=False)},
            {'role':'user','content':'Configure idle, sprint and jump. Hit interrupts everything, then return to movement.'},
            {'role':'assistant','content':json.dumps(dict(roles=['idle','sprint'],slots={'idle':'locomotion','sprint':'locomotion','hit':'action','jump':'action'},blend_seconds=.2,filters={},policy={'hit_interrupts':'all','after_hit':'locomotion'},reject=None),ensure_ascii=False)},
        ])
    messages.append({'role':'user','content':request})
    return messages

def validate_action_coverage(request,configuration):
    """Reject explicit missing new actions; never add slots or bind resources."""
    patterns={'jump':r'跳跃|起跳|走跑跳蹲|\bjump(?:ing)?\b',
              'dodge':r'闪避|躲闪|翻滚|\bdodg(?:e|ing)\b|\bevasive roll\b'}
    for role,pattern in patterns.items():
        for clause in re.split(r'[；;。\n]',request.lower()):
            if not re.search(pattern,clause):continue
            if re.search(r'不要|不需要|禁止|不含|无需|without|do not|no jumping|no dodge',clause):continue
            if role not in configuration['slots'] and configuration['reject'] is None:
                raise ValueError('模型遗漏明确要求的动作 '+role+'；请重新生成或检查生成器权重，不能应用缺失状态的配置。')

def selector_messages(catalog, request, configuration):
    validate_generator(configuration)
    assets, _ = compact_catalog(catalog)
    return [{'role':'system','content':SELECTOR_SYSTEM}, {'role':'user','content':json.dumps(
        {'request':request,'configuration':configuration,'selected_assets':assets},ensure_ascii=False,separators=(',',':'))}]

def merge(catalog, configuration, selection):
    validate_generator(configuration)
    if not isinstance(selection,dict) or set(selection) != {'bindings','issues'}:
        raise ValueError('Selector may only bind slots and report issues')
    bindings, issues = selection['bindings'], selection['issues']
    if not isinstance(bindings,dict) or set(bindings) != set(configuration['slots']) or not isinstance(issues,dict):
        raise ValueError('Selector slots do not match immutable configuration')
    if set(issues) != {k for k,v in bindings.items() if v is None} or any(v not in ('missing','ambiguous','mesh','unsupported') for v in issues.values()):
        raise ValueError('Each unresolved slot needs exactly one issue')
    p = {k:copy.deepcopy(configuration[k]) for k in ('roles','blend_seconds','filters','policy','reject')}
    p['bindings'] = {r:bindings[r] for r in p['roles']}
    p['actions'] = {r:bindings[r] for r in configuration['slots'] if r not in p['roles']}
    if issues and p['reject'] is None:
        p['reject'] = next((r for r in ('mesh','unsupported','ambiguous','missing') if r in issues.values()))
    validate_ir(catalog,p)
    return p

def compile_split(catalog, request, destination, configuration, selection, model_info):
    validate_action_coverage(request,configuration)
    indexed_jump='jump' in configuration['slots'] and selection_policy(request)['index_jump']
    if indexed_jump:
        if not isinstance(selection,dict) or set(selection)!={'bindings','issues'} or not isinstance(selection['bindings'],dict) or set(selection['bindings'])!=set(configuration['slots']) or not isinstance(selection['issues'],dict):
            raise ValueError('Indexed selection must bind exactly the requested slots')
        if set(selection['issues'])!={k for k,v in selection['bindings'].items() if v is None} or any(r not in ('missing','ambiguous','mesh','unsupported') for r in selection['issues'].values()):
            raise ValueError('Invalid indexed selection issues')
        # A looping airborne clip is legal for a DB, but never for the frozen montage contract.
        ground_configuration=copy.deepcopy(configuration);ground_configuration['slots'].pop('jump')
        ground_selection=copy.deepcopy(selection);alias=ground_selection['bindings'].pop('jump')
        ground_selection['issues'].pop('jump',None)
        p=merge(catalog,ground_configuration,ground_selection)
        _,selected_ids=compact_catalog(catalog);assets={a['id']:a for a in catalog['assets']}
        if alias is not None:
            a=assets.get(selected_ids.get(alias));meshes=[a for a in catalog['assets'] if a['kind']=='mesh']
            if not a or a['kind'] not in ('sequence','database') or len(meshes)!=1 or a.get('skeleton')!=meshes[0].get('skeleton'):
                raise ValueError('Indexed jump must be a selected compatible animation or database')
    else:p=merge(catalog,configuration,selection)
    plan=compile_flow(catalog,request,destination,p,dict(model_info,task_protocol='generator_selector_v1'))
    _,ids=compact_catalog(catalog)
    flow={'version':1,'filters':copy.deepcopy(p['filters']),'actions':{k:ids.get(v) for k,v in p['actions'].items()},'policy':copy.deepcopy(p['policy']),'blend_seconds':p['blend_seconds']}
    if indexed_jump:
        plan['issues']=[i for i in plan['issues'] if i['code']!='empty_intent']
        # Keep the frozen learned contract, but honor the explicit UE authoring target.
        # The generated runtime owns an indexed airborne DB, not a montage slot.
        plan['model_info']['generator_configuration']=copy.deepcopy(configuration)
        plan['model_info']['runtime_projection']={'jump':'motion_matching_database'}
        p['roles'].append('jump');p['bindings']['jump']=alias
        plan['intent_roles']=list(p['roles'])
        for state in plan['states']:state['when']['MovementMode']=0
        plan['states'].append(dict(id='jump',resource=ids.get(alias),when={'MovementMode':1}))
        if alias is None:plan['issues'].append({'severity':'error','code':'missing_resource','role':'jump','message':'没有确认可用于空中 MM 数据库的资源。'})
        plan['transitions']=[dict({'from':a['id'],'to':b['id']},blend_seconds=p['blend_seconds']) for a in plan['states'] for b in plan['states'] if a!=b]
        plan['issues'].append({'severity':'warning','code':'indexed_jump','message':'跳跃按要求加入空中 Motion Matching 数据库。若只选起跳短片段，无法覆盖完整的起跳、滞空和落地三个阶段。'})
    errors=validate_runtime(flow,catalog,plan['target_mesh'],plan['states'])
    plan['runtime_flow']=flow
    plan['issues']=[i for i in plan['issues'] if i['code']!='flow_runtime_unavailable']
    for error in errors:plan['issues'].append({'severity':'error','code':'runtime_binding_invalid','message':error})
    return plan

def score(task, row, prediction):
    target = row['target']
    fields = ('roles','slots','blend_seconds','filters','policy','reject') if task=='generator' else ('bindings','issues')
    valid = True
    try:
        if task=='generator': validate_generator(prediction)
        else: merge(row['catalog'],row['configuration'],prediction)
    except (ValueError,TypeError,KeyError): valid=False
    result={k:isinstance(prediction,dict) and prediction.get(k)==target[k] for k in fields}
    result['protocol_valid']=valid
    result['exact']=valid and prediction==target
    return result
