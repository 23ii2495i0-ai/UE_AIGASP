"""Shared learned intent / resource-selection protocol. No model output is executed."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,sys
from pathlib import Path
sys.path.insert(0,str(_LAYOUT_REPO/'tools/anim_config'))
import config_tool as core
SYSTEM='''You configure Unreal animation resources. Return one JSON object only: {"roles":[...],"bindings":{"role":"asset_id or null"},"blend_seconds":0.2,"reject":null}. Supported roles: idle,walk,run,sprint,crouch. Interpret Chinese or English intent, including synonyms. Bind only selected sequences/databases matching the unique mesh skeleton and requested action. Never invent IDs. A sequence must loop. If missing, ambiguous, multiple/no mesh, or unsupported behavior, use null bindings and reject="missing"/"ambiguous"/"mesh"/"unsupported". Unsupported: jumping, traversal, aiming, strafing, turning. Default blend_seconds=0.2 unless requested. Do not generate UE paths or explanations.'''
ROLES=list(core.ROLES)
def compact_catalog(catalog):
 rigs={};ids={};assets=[]
 for i,a in enumerate(catalog['assets']):
  alias=f'a{i}';ids[alias]=a['id'];sk=a.get('skeleton','');rig=rigs.setdefault(sk,f's{len(rigs)}')
  row={'id':alias,'kind':a['kind'],'name':a.get('name',a['id'].rsplit('/',1)[-1]),'rig':rig}
  for k in ('loop','tags'):
   if k in a:row[k]=a[k]
  assets.append(row)
 return assets,ids

def messages(catalog,request):
 assets,ids=compact_catalog(catalog)
 return [{'role':'system','content':SYSTEM},{'role':'user','content':json.dumps({'request':request,'assets':assets},ensure_ascii=False,separators=(',',':'))}],ids

def compile_prediction(catalog,request,destination,prediction,model_info):
 if not isinstance(prediction,dict) or set(prediction)!={'roles','bindings','blend_seconds','reject'}:raise ValueError('Model returned invalid intent fields')
 roles=prediction['roles'];bindings=prediction['bindings'];rate=prediction['blend_seconds']
 if not isinstance(roles,list) or len(roles)!=len(set(roles)) or not all(r in ROLES for r in roles):raise ValueError('Invalid model roles')
 if not isinstance(bindings,dict) or set(bindings)!=set(roles):raise ValueError('Bindings must match model roles')
 if type(rate) not in (int,float) or not 0<=rate<=2:raise ValueError('Invalid blend seconds')
 if prediction['reject'] not in (None,'missing','ambiguous','mesh','unsupported'):raise ValueError('Invalid rejection reason')
 _,ids=compact_catalog(catalog);assets={a['id']:a for a in catalog['assets']}
 # Compile the learned intent through the existing deterministic UE configuration compiler.
 plan=core.generate(catalog,' '.join(roles),destination)
 plan.update(request=request,provider='local_model',intent_roles=roles,model_info=model_info)
 plan['issues']=[i for i in plan['issues'] if i['code'] not in ('rule_scope','missing_resource','ambiguous_resource','unknown_intent')]
 review='请检查动作需求、资源绑定和衔接策略后再应用。'
 if 'heldout_exact' in model_info:review+=' 合成保留集完整匹配率 '+str(round(model_info['heldout_exact']*100,1))+'%，不等于真实项目正确率。'
 plan['issues'].append({'severity':'warning','code':'model_review','message':review})
 meshes=[a for a in catalog['assets'] if a['kind']=='mesh'];mesh=meshes[0] if len(meshes)==1 else None
 for state in plan['states']:
  alias=bindings[state['id']]
  if alias is not None and alias not in ids:raise ValueError('Model invented an asset ID')
  path=ids.get(alias);resource=assets.get(path)
  if path and (not mesh or resource['kind'] not in ('sequence','database') or resource.get('skeleton')!=mesh.get('skeleton')):raise ValueError('Model selected an incompatible resource')
  state['resource']=path
  if not path:plan['issues'].append({'severity':'error','code':'missing_resource','role':state['id'],'message':'Model could not uniquely bind this role'})
 for edge in plan['transitions']:edge['blend_seconds']=rate
 if prediction['reject'] is not None:plan['issues'].append({'severity':'error','code':'model_rejected','message':'Model rejected request: '+prediction['reject']})
 if not roles:plan['issues'].append({'severity':'error','code':'empty_intent','message':'No supported model intent'})
 return plan
