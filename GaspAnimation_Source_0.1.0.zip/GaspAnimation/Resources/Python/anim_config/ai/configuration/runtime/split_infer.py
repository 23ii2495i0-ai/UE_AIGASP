"""Run two independent adapters sequentially; never modify the daily model service."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse
import json
from pathlib import Path
from split_protocol import generator_messages,selector_messages,validate_generator,compile_split
from split_runtime import SplitRuntime

def main():
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--generator',required=True);p.add_argument('--selector',required=True);p.add_argument('--catalog',required=True);p.add_argument('--request',required=True,help='UTF-8 text file');p.add_argument('--destination',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    runtime=SplitRuntime(a.base,a.generator,a.selector)
    request=Path(a.request).read_text(encoding='utf-8-sig');catalog=json.loads(Path(a.catalog).read_text(encoding='utf-8-sig'))
    g=runtime.predict('generator',generator_messages(request,runtime.generator_prompt_version));validate_generator(g)
    s=runtime.predict('selector',selector_messages(catalog,request,g))
    # Training alone is not promotion. Results are review-only until separately approved.
    plan=compile_split(catalog,request,a.destination,g,s,{'evaluation_only':True,'generator_adapter':a.generator,'selector_adapter':a.selector})
    Path(a.output).write_text(json.dumps({'configuration':g,'selection':s,'plan':plan},ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
