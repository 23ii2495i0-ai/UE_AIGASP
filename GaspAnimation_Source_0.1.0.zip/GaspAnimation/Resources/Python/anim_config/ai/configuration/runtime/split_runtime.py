"""One frozen base, two independently trained adapters. No rule fallback."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json
import re
import hashlib
from contextlib import nullcontext
from pathlib import Path
from split_protocol import generator_messages,selector_messages,validate_generator,validate_action_coverage,compile_split
from catalog_batches import partition,combine,checked_selection
from candidate_policy import selection_policy,direction

def complete_json_object(text):
    """Return true only once a full JSON object has been generated."""
    try:
        value,end=json.JSONDecoder().raw_decode(text.lstrip())
        return isinstance(value,dict)
    except json.JSONDecodeError:
        return False

def cached_tokenizer_data(runtime,tokenizer,build):
    cache=getattr(runtime,'_enforcer_tokenizer_cache',None)
    if cache is None:runtime._enforcer_tokenizer_cache=cache={}
    key=id(tokenizer)
    if key not in cache:cache[key]=build(tokenizer)
    return cache[key]

class SplitRuntime:
    def __init__(self,base,generator,selector,behavior_adapter=None,behavior_base=None,behavior_base_adapter=None):
        if behavior_adapter and behavior_base:raise ValueError('Select a behavior adapter or an independent base, not both')
        if behavior_base_adapter and not behavior_base:raise ValueError('Independent adapter requires its independent base')
        import torch
        from transformers import AutoModelForCausalLM,AutoTokenizer
        from peft import PeftModel
        self.torch=torch
        cfg=Path(generator)/'prompt_config.json'
        self.generator_prompt_version=json.loads(cfg.read_text(encoding='utf-8'))['prompt_version'] if cfg.exists() else 1
        if self.generator_prompt_version not in (1,2,3):raise ValueError('Unsupported generator prompt')
        if cfg.exists():
            expected=json.loads(cfg.read_text(encoding='utf-8')).get('system_prompt_sha256')
            actual=hashlib.sha256(generator_messages('',self.generator_prompt_version)[0]['content'].encode()).hexdigest()
            if expected and expected!=actual:raise ValueError('Generator prompt differs from evaluated training protocol')
            expected_messages=json.loads(cfg.read_text(encoding='utf-8')).get('prompt_messages_sha256')
            actual_messages=hashlib.sha256(json.dumps(generator_messages('',self.generator_prompt_version),ensure_ascii=False,sort_keys=True).encode()).hexdigest()
            if expected_messages and expected_messages!=actual_messages:raise ValueError('Generator examples differ from evaluated training protocol')
        # Use the prompt paired with the evaluated adapter; old deployments stay reproducible.
        self.adapter_prompt_version=self.generator_prompt_version
        self.tokenizer=AutoTokenizer.from_pretrained(base,local_files_only=True,trust_remote_code=False)
        model=AutoModelForCausalLM.from_pretrained(base,local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda')
        self.model=PeftModel.from_pretrained(model,generator,adapter_name='generator')
        self.model.load_adapter(selector,adapter_name='selector');self.model.eval();self.model.config.use_cache=True
        self.behavior_adapter=bool(behavior_adapter)
        if behavior_adapter:
            from behavior_requirements import prompt_fingerprint
            metadata=json.loads((Path(behavior_adapter)/'behavior_prompt_config.json').read_text(encoding='utf-8'))
            if metadata.get('protocol')!='requirement_ir_v1' or metadata.get('prompt_sha256')!=prompt_fingerprint():raise ValueError('Behavior extraction adapter prompt/protocol mismatch')
            self.model.load_adapter(behavior_adapter,adapter_name='behavior_requirements')
        self.behavior_model=None
        self.behavior_quantized=False
        if behavior_base:
            self.behavior_tokenizer=AutoTokenizer.from_pretrained(behavior_base,local_files_only=True,trust_remote_code=False)
            metadata={}
            if behavior_base_adapter:
                from behavior_requirements import prompt_fingerprint
                metadata=json.loads((Path(behavior_base_adapter)/'behavior_prompt_config.json').read_text(encoding='utf-8'))
                if metadata.get('protocol')!='requirement_ir_v1' or metadata.get('prompt_sha256')!=prompt_fingerprint() or metadata.get('base_config_sha256')!=hashlib.sha256((Path(behavior_base)/'config.json').read_bytes()).hexdigest():raise ValueError('Independent adapter base/prompt/protocol mismatch')
            quantization=metadata.get('base_quantization')
            if quantization not in (None,'nf4_double_bfloat16'):raise ValueError('Unsupported independent base quantization')
            load=dict(local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa')
            if quantization:
                from transformers import BitsAndBytesConfig
                load.update(quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.bfloat16),device_map={'':'cuda'})
            self.behavior_model=AutoModelForCausalLM.from_pretrained(behavior_base,**load).eval();self.behavior_quantized=bool(quantization)
            if behavior_base_adapter:
                self.behavior_model=PeftModel.from_pretrained(self.behavior_model,behavior_base_adapter).eval()
        self.independent_behavior_adapter=bool(behavior_base_adapter)
        from hybrid_selection import PoseAssistant
        self.pose_assistant=PoseAssistant()
    def predict(self,task,msg):
        self.last_prediction_raw=None
        raw=self.predict_batch(task,[msg])[0]
        self.last_prediction_raw=dict(task=task,text=raw)
        diagnostic=_LAYOUT_REPO/'artifacts/anim_config/models/configuration/logs'/('latest_'+task+'_output.txt')
        diagnostic.parent.mkdir(parents=True,exist_ok=True)
        diagnostic.write_text(raw,encoding='utf-8')
        try:
            value=json.loads(raw)
        except json.JSONDecodeError as error:
            timeout=getattr(self,'last_decode_timeout',None)
            if timeout:
                raise ValueError(f'{task} 模型生成超时（{timeout["seconds"]}秒，{timeout["tokens"]} token）；原始输出：{diagnostic}') from error
            reason='空输出' if not raw.strip() else 'JSON未完成或格式无效'
            raise ValueError(f'{task} 模型{reason}（{len(raw)}字符）；原始输出：{diagnostic}；{error}') from error
        if not isinstance(value,dict):raise ValueError(task+' 模型必须输出JSON对象')
        return value
    def prediction_backend(self,task):
        independent=getattr(self,'behavior_model',None)
        if independent is not None and not getattr(self,'behavior_quantized',False):
            selected,parked=(independent,self.model) if task=='behavior' else (self.model,independent)
            # Only one base resides on the 12GB GPU. Keep all extraction stages
            # together; restore the legacy model when MM resource selection starts.
            if next(selected.parameters()).device.type!='cuda':
                parked.to('cpu');self.torch.cuda.empty_cache();selected.to('cuda')
        return (independent,self.behavior_tokenizer) if task=='behavior' and independent is not None else (self.model,self.tokenizer)
    def predict_batch(self,task,messages):
        provider=getattr(self,'task_providers',{}).get(task)
        if provider is not None:
            from gasp_ai.runtime import provider_batch
            return provider_batch(provider,task,messages)
        return self._predict_batch_builtin(task,messages)
    def _predict_batch_builtin(self,task,messages):
        import time
        from transformers import StoppingCriteria,StoppingCriteriaList
        model,tokenizer=self.prediction_backend(task)
        if task!='behavior':self.model.set_adapter(task)
        elif getattr(self,'behavior_adapter',False):self.model.set_adapter('behavior_requirements')
        encoded=[tokenizer.apply_chat_template(msg,add_generation_prompt=True,tokenize=True) for msg in messages]
        prefix=''
        if prefix:encoded=[row+tokenizer.encode(prefix,add_special_tokens=False) for row in encoded]
        width=max(map(len,encoded))
        if width>(16384 if task=='behavior' else 4096):raise ValueError('Request/catalog exceeds model input budget')
        ids=self.torch.tensor([[tokenizer.eos_token_id]*(width-len(row))+row for row in encoded],device='cuda')
        mask=self.torch.tensor([[0]*(width-len(row))+[1]*len(row) for row in encoded],device='cuda')
        runtime=self
        kwargs={}
        from schema_decode_compat import strict_empty_arrays
        with strict_empty_arrays():
            if task=='behavior':
                try:
                    from lmformatenforcer import JsonSchemaParser
                    from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn,build_token_enforcer_tokenizer_data
                except ImportError as error:
                    raise ValueError('状态机约束解码依赖缺失，请用模型环境安装 tools/anim_config/ai/shared/requirements.txt') from error
                # Tokenizer vocabulary preparation is independent of each node's
                # schema. Rebuilding it per stage can exhaust the decode budget
                # before the model has generated its first token.
                prepared=time.monotonic()
                data=cached_tokenizer_data(self,tokenizer,build_token_enforcer_tokenizer_data)
                kwargs['prefix_allowed_tokens_fn']=build_transformers_prefix_allowed_tokens_fn(data,JsonSchemaParser(self.behavior_schema))
                print('BEHAVIOR_PREPARE',round(time.monotonic()-prepared,1),'seconds',flush=True)
            # Only actual generation consumes the decode time allowance.
            started=time.monotonic()
            class JsonComplete(StoppingCriteria):
                def __call__(self,input_ids,scores,**kwargs):
                    decoded=[prefix+tokenizer.decode(row[width:],skip_special_tokens=True) for row in input_ids]
                    count=input_ids.shape[-1]-width
                    getattr(runtime,'progress',{}).update(phase='decode',tokens=count)
                    timed_out=task=='behavior' and time.monotonic()-started>120
                    if timed_out:
                        runtime.last_decode_timeout=dict(tokens=count,seconds=round(time.monotonic()-started,1))
                    if task=='behavior' and (count%256==0 or timed_out):
                        print('BEHAVIOR_DECODE',count,'tokens',round(time.monotonic()-started,1),'seconds',flush=True)
                        (_LAYOUT_REPO/'artifacts/anim_config/models/configuration/logs/latest_behavior_partial.txt').write_text(decoded[0],encoding='utf-8')
                    finished=[complete_json_object(text) or timed_out for text in decoded]
                    return runtime.torch.tensor(finished,dtype=runtime.torch.bool,device=input_ids.device)
            # Release unused allocator blocks between stages so the editor can
            # coexist with inference on Windows instead of retaining peak KV memory.
            self.torch.cuda.empty_cache()
            free,total=self.torch.cuda.mem_get_info()
            print('MODEL_MEMORY',task,'free_mb',free//1048576,'allocated_mb',self.torch.cuda.memory_allocated()//1048576,flush=True)
            if task=='behavior' and free<768*1048576:
                raise ValueError('显存余量不足768MB，请暂停UE实时视口或关闭其他GPU程序后重试；未开始本阶段推理')
            progress=getattr(self,'progress',{})
            progress.update(phase='prefill',tokens=0,input_tokens=width)
            def measured_prefix(batch_id,sent):
                before=time.monotonic()
                result=original_prefix(batch_id,sent)
                elapsed=time.monotonic()-before
                if elapsed>1:print('CONSTRAINT_SECONDS',round(elapsed,2),flush=True)
                return result
            original_prefix=kwargs.get('prefix_allowed_tokens_fn')
            if original_prefix:kwargs['prefix_allowed_tokens_fn']=measured_prefix
            with (model.disable_adapter() if task=='behavior' and model is self.model and not getattr(self,'behavior_adapter',False) and hasattr(model,'disable_adapter') else nullcontext()),self.torch.inference_mode():
                self.last_decode_timeout=None
                out=model.generate(ids,attention_mask=mask,max_new_tokens=getattr(self,'behavior_max_tokens',8192) if task=='behavior' else 512,do_sample=False,pad_token_id=tokenizer.eos_token_id,stopping_criteria=StoppingCriteriaList([JsonComplete()]),**kwargs)
            result=[prefix+tokenizer.decode(row[width:],skip_special_tokens=True) for row in out]
            del out,ids,mask
            self.torch.cuda.empty_cache()
            return result
    def generate(self,catalog,request,destination,info):
        messages=generator_messages(request,self.generator_prompt_version)
        generator_retries=[]
        for attempt in range(3):
            try:
                g=self.predict('generator',messages);validate_generator(g)
                validate_action_coverage(request,g)
                break
            except ValueError as error:
                if attempt==2:raise ValueError('生成器输出未通过协议检查：'+str(error)) from error
                generator_retries.append(str(error))
                messages.append({'role':'user','content':'上一轮输出未通过协议检查：'+str(error)+'. 请根据原始需求重新输出唯一完整 JSON，严格使用 roles, slots, blend_seconds, filters, policy, reject 六个字段。候选数量、方向覆盖和资源选择由后续选择器与宿主处理，不要输出 candidates 或 unresolved_issues。保留原始需求明确要求的全部状态，包括 jump:action（若需要跳跃）。不要输出说明或第二份 JSON。'})
        count=lambda msg:len(self.tokenizer.apply_chat_template(msg,add_generation_prompt=True,tokenize=True))
        chunks=partition(catalog,request,g,count)
        selections=[]
        for start in range(0,len(chunks),4):
            batch=chunks[start:start+4]
            for raw in self.predict_batch('selector',[selector_messages(c,request,g) for c in batch]):
                try:selections.append(json.loads(raw))
                except json.JSONDecodeError:selections.append({'invalid_json':raw})
            print('CATALOG_SELECTION',len(selections),'/',len(chunks),flush=True)
        rejected=[];checked=[]
        for index,(chunk,selection) in enumerate(zip(chunks,selections)):
            value,error=checked_selection(chunk,g,selection);checked.append(value)
            if error:rejected.append(dict(batch=index+1,error=error,prediction=selection))
        s=combine(catalog,g,chunks,checked)
        constraints=selection_policy(request)
        s,candidates,evidence=self.pose_assistant.select(catalog,g,s,constraints)
        plan=compile_split(catalog,request,destination,g,s,dict(info,catalog_batches=len(chunks),generator_reject=g['reject']))
        for state in plan['states']:
            if state['id'] in candidates:state['resources']=candidates[state['id']]
        plan['runtime_flow']['action_candidates']={r:candidates[r] for r in plan['runtime_flow']['actions'] if r in candidates}
        plan['model_info']['generator_prompt_version']=self.generator_prompt_version
        plan['model_info']['generator_protocol_retries']=generator_retries
        plan['model_info']['adapter_prompt_version']=self.adapter_prompt_version
        if self.adapter_prompt_version!=3:
            plan['issues'].append({'severity':'warning','code':'expanded_prompt_unvalidated','message':'跳跃/闪避使用扩展提示词；当前适配器尚未针对新槽位重训评测，请核对需求和资源绑定。'})
        plan['model_info']['hybrid_selection']={'experimental':True,'pose_weights_sha256':self.pose_assistant.sha,'evidence':evidence}
        plan['model_info']['selection_constraints']=constraints
        if constraints.get('max_candidates_per_role'):
            plan['issues'].append({'severity':'warning','code':'candidate_limit','message':f"按文本要求，每类最多保留 {constraints['max_candidates_per_role']} 段；未达到数量时不会用其他类别凑数。"})
        if constraints.get('require_cardinal_directions'):
            assets={a['id']:a for a in catalog['assets']}
            for role in ('walk','run','sprint','crouch'):
                if role not in candidates:continue
                covered={direction(assets[p]) for p in candidates[role]}
                missing={'forward','back','left','right'}-covered
                if missing:plan['issues'].append({'severity':'warning','code':'direction_coverage','role':role,'message':f"{role} 缺少方向 {', '.join(sorted(missing))}；一段前向动画不能承诺覆盖 WASD 四向。"})
        if rejected:
            plan['model_info']['rejected_selector_outputs']=rejected
            plan['issues'].append({'severity':'warning','code':'selector_invalid_output','message':f"名称选择器有 {len(rejected)} 批输出未通过资源校验，已丢弃；本次候选由实际清单的名称与姿态辅助重新匹配，请重点检查。无效输出见 model_info.rejected_selector_outputs。"})
        plan['issues'].append({'severity':'warning','code':'experimental_pose','message':'已启用名称与姿态混合候选。姿态分数未经 UE 域校准，受击训练仅 4 段；请检查候选后应用。移动候选进入同一 MM 数据库，动作候选按次序轮换。'})
        if len(chunks)>1:
            plan['issues'].append({'severity':'warning','code':'catalog_batches','message':f"已完整检查 {len(catalog['assets'])} 项选中资源，分 {len(chunks)} 批选择；同类名称和姿态匹配合并到候选槽。"})
        reasons={'missing':'没有找到匹配资源','ambiguous':'存在多个匹配资源，请缩小候选范围或手动指定','unsupported':'模型未能给出符合槽位播放类型的资源，请选择循环移动动画或非循环动作动画','mesh':'资源骨架不匹配'}
        for slot,reason in s['issues'].items():
            plan['issues'].append({'severity':'error','code':'selector_unresolved','role':slot,'message':slot+'：'+reasons[reason]})
        return plan,g,s

    def behavior_mm_resources(self,catalog,request,destination,info):
        """Reuse only immutable MM selection, never extracted state/flow data."""
        import copy
        from config_tool import signature
        key=(signature(catalog),request,json.dumps(info,sort_keys=True,ensure_ascii=False))
        cache=getattr(self,'_behavior_mm_cache',None)
        if cache is None:self._behavior_mm_cache={};cache=self._behavior_mm_cache
        hit=key in cache
        if hit:plan,g,s=copy.deepcopy(cache[key])
        else:
            plan,g,s=self.generate(catalog,request,destination,info)
            if not any(i.get('severity')=='error' for i in plan.get('issues',[])) and not plan.get('model_info',{}).get('rejected_selector_outputs'):
                if len(cache)>=4:cache.pop(next(iter(cache)))
                cache[key]=copy.deepcopy((plan,g,s))
        plan['destination']=destination
        plan['model_info']['behavior_mm_resource_cache']=dict(hit=hit,scope='same immutable catalog/MM request/model info only; all requirement extraction and graph compilation remain fresh')
        return plan,g,s

    def generate_behavior(self,catalog,request,destination,info):
        return self.generate_behavior_templates(catalog,request,destination,info)

    def generate_behavior_unified(self,catalog,request,destination,info):
        from unified_generation import generate
        return generate(self,catalog,request,destination,info,_LAYOUT_REPO)

    def generate_behavior_templates(self,catalog,request,destination,info):
        from behavior_requirements import (CAPABILITIES,extraction_messages,source_identifiers,anchor_topology,validate_topology,validate_requirements,validate_generated_symbols,validate_extracted_stage,compile_requirements,resource_bindings,semantic_audit)
        from datetime import datetime
        import copy
        folder=_LAYOUT_REPO/'artifacts/anim_config/models/configuration/logs'
        folder.mkdir(parents=True,exist_ok=True)
        log=folder/('requirements_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
        trace=[];ir={'version':1}
        source_lines=[line.strip() for line in request.splitlines() if line.strip()]
        grounded_ids=source_identifiers(request)
        if not grounded_ids:raise ValueError('需求编译器目前要求显式英文状态ID；未命名状态映射尚未实现')
        def save(error=None,graph=None):
            record=dict(request=request,destination=destination,requirements=ir,stages=trace,error=error,graph=graph,capabilities=CAPABILITIES)
            text=json.dumps(record,ensure_ascii=False,indent=2);log.write_text(text,encoding='utf-8');(folder/'latest_behavior_requirements.json').write_text(text,encoding='utf-8')
        def extract(stage,names=None,override=None):
            import jsonschema
            self.behavior_schema,messages=override if override is not None else extraction_messages(stage,request,copy.deepcopy(ir))
            self.behavior_max_tokens=1024 if stage in ('topology','jump_evidence') else 768
            if stage=='jump_evidence' and getattr(self,'jump_extraction_scheme',None)=='trained_deterministic':self.behavior_max_tokens=2048
            for attempt in range(3):
                self.last_prediction_raw=None
                try:
                    result=self.predict('behavior',messages)
                    entry=dict(stage=stage,attempt=attempt+1,output=copy.deepcopy(result),raw=copy.deepcopy(self.last_prediction_raw),messages=copy.deepcopy(messages),schema=copy.deepcopy(self.behavior_schema))
                    trace.append(entry)
                    jsonschema.validate(result,self.behavior_schema)
                    if stage in ('locomotion','jump','dependencies','combo'):
                        validate_extracted_stage(stage,result,ir,request)
                    if stage=='jump' and result['policy']:
                        policy=result['policy'];groups={g['id']:g for g in ir['topology']['groups']}
                        if policy['group'] not in groups or policy['rise']==policy['fall'] or set(groups[policy['group']]['children'])!={policy['rise'],policy['fall']}:
                            raise ValueError('跳跃策略须引用已声明的空中父组及两个不同的上升/下降子状态；不得把单个地面叶子当空中父组；原文未要求跳跃时 policy 为 null')
                    break
                except (ValueError,TypeError,KeyError,RuntimeError,jsonschema.ValidationError) as error:
                    reason=error.message if isinstance(error,jsonschema.ValidationError) else str(error)
                    trace.append(dict(stage=stage+'_validation',attempt=attempt+1,error=reason,raw=copy.deepcopy(self.last_prediction_raw)));save(reason)
                    if attempt==2:raise ValueError(reason) from error
                    messages=messages+[dict(role='assistant',content=(self.last_prediction_raw or {}).get('text','{}')),dict(role='user',content='本阶段输出未通过校验：'+reason+'。请依据原始需求重新输出符合本阶段协议的唯一JSON；没有要求的功能输出 null，不得创造状态或策略。')]
            save();print('BEHAVIOR_REQUIREMENTS',stage,'EXTRACTED',flush=True)
            return result
        try:
            topology_schema,topology_messages=extraction_messages('topology',request,copy.deepcopy(ir))
            for attempt in range(3):
                raw_topology=extract('topology',override=(topology_schema,topology_messages))
                try:
                    candidate=anchor_topology(raw_topology,request);candidate['standalone']=[]
                    declared={name for group in candidate['groups'] for name in [group['id']]+group['children']}
                    if candidate['entry'] not in declared:candidate['standalone'].append(candidate['entry'])
                    names=validate_topology(candidate,request)
                    ir['topology']=candidate
                    break
                except (ValueError,TypeError,KeyError) as error:
                    trace.append(dict(stage='topology_validation',attempt=attempt+1,error=str(error)))
                    save(str(error))
                    if attempt==2:raise
                    topology_messages.extend([dict(role='assistant',content=json.dumps(raw_topology,ensure_ascii=False)),dict(role='user',content='结构校验失败：'+str(error)+'。请根据完整原始需求重新抽取 entry 和 groups。groups 只列实际父组，叶子不放入 groups；没有父组时 groups 必须为空数组。不得添加原文未要求的状态。只返回本阶段 JSON。')])
            trace.append(dict(stage='deterministic_source_mapping',raw_model_offsets=[g['source_lines'] for g in raw_topology['groups']],resolved_offsets=[g['source_lines'] for g in ir['topology']['groups']],identifiers_unchanged=True))
            for stage in ('locomotion','jump','combo'):
                if stage=='jump' and getattr(self,'jump_extraction_scheme',None):
                    if self.jump_extraction_scheme=='trained_deterministic':
                        from jump_evidence_protocol import extract_jump
                        ir[stage]=extract_jump(request,copy.deepcopy(ir),extract)
                        trace.append(dict(stage='jump_policy_compile',source='deterministic_from_model_evidence',policy=copy.deepcopy(ir[stage]),model_policy_call=False))
                        save()
                    else:
                        from jump_extraction_trial import extract_jump
                        ir[stage]=extract_jump(self.jump_extraction_scheme,request,copy.deepcopy(ir),extract)
                else:ir[stage]=extract(stage,grounded_ids if stage=='combo' else names)['policy']
            if ir['combo']:
                policy_states=ir['combo']['attacks']+[ir['combo']['hit']]
                ir['topology']['standalone']=sorted(set(ir['topology']['standalone'])|(set(policy_states)-set(names)))
            ir.update(extract('dependencies'))
            supplied=extract('settings')
            defaults=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=.25,window_end=.65,jump_velocity=500)
            assumptions={k:v for k,v in defaults.items() if supplied[k] is None}
            if ir.get('jump') and ir['jump'].get('landing'):
                from landing_policy import durations
                landing=ir['jump']['landing']
                for key,value in zip(('land_seconds','run_seconds'),durations(landing)):
                    if landing.get(key) is None:assumptions['jump.landing.'+key]=value
            ir['settings']={k:defaults[k] if supplied[k] is None else supplied[k] for k in defaults}
            symbol_defaults=validate_generated_symbols(ir,request)
            validate_requirements(ir,request)
            bindings,issues=resource_bindings(ir,catalog)
            graph,roles=compile_requirements(ir,request,bindings)
            if semantic_audit(ir,request,graph):raise ValueError('Compiler semantic audit failed')
            # Reuse the evaluated legacy MM generator/selector solely for MM
            # resource categories. It never supplies state IDs or graph rules.
            labels={'idle':'待机','walk':'行走','run':'跑步','crouch':'下蹲','jump':'跳跃'}
            from landing_policy import STAGE_ROLES
            base_roles=[r for r in roles if r not in ('crouch_idle','crouch_move')+STAGE_ROLES]
            from candidate_policy import selection_policy
            limits=selection_policy(request)
            mm_request='配置'+ '、'.join(labels[r] for r in base_roles)+'，加入 Motion Matching 数据库。'+ '；'.join(labels[r]+'最多'+str(limits['max_candidates_by_role'].get(r,limits['max_candidates_per_role'] or 4))+'段' for r in base_roles)
            plan,g,s=self.behavior_mm_resources(catalog,mm_request,destination,info)
            if 'crouch_idle' in roles:
                from split_crouch_resources import add_split_crouch_resources
                add_split_crouch_resources(plan,catalog,roles,request)
            if any(r in STAGE_ROLES for r in roles):
                from landing_policy import add_landing_resources
                add_landing_resources(plan,catalog,roles,request)
            plan.update(request=request,behavior_graph=graph)
            for variable in ir['external_variables']:issues.append(dict(severity='error',code='behavior_external_unbound',message=variable['id']+' 等待接入：'+variable['source']+'；保留初始值但不得当作已绑定。'))
            for unsupported in ir['unsupported']:issues.append(dict(severity='error',code='behavior_unsupported',message=unsupported))
            if assumptions:issues.append(dict(severity='warning',code='behavior_defaults_review',message='以下为编译器默认参数，需审阅，并非模型抽取事实：'+json.dumps(assumptions,ensure_ascii=False)))
            if symbol_defaults:issues.append(dict(severity='warning',code='behavior_symbol_defaults_review',message='原文未命名的内部变量使用约定名称，需审阅：'+json.dumps(symbol_defaults,ensure_ascii=False)))
            policy_defaults=dict(jump_input='SpaceBar' if ir['jump'] else None,attack_input='LeftMouseButton' if ir['combo'] else None,hit_input='H/native Hit' if ir['combo'] else None,attack_entry='ground only' if ir['combo'] else None,hit_scope='all requested states except Hit' if ir['combo'] else None)
            issues.append(dict(severity='warning',code='behavior_policy_defaults_review',message='固定编译策略需人工审阅，不是模型抽取事实：'+json.dumps(policy_defaults,ensure_ascii=False)))
            plan['issues'].extend(issues)
            plan['model_info']['behavior_requirements']=copy.deepcopy(ir)
            from behavior_human_review import prefill_review_quotes
            prefill_review_quotes(plan['model_info'],request)
            plan['model_info']['behavior_generation']=dict(mode='requirement_ir_compiler_v1',trained_requirement_adapter=bool(getattr(self,'behavior_adapter',False) or getattr(self,'independent_behavior_adapter',False)),trained_graph_adapter=False,graph_construction='deterministic_feature_compiler',requirements_log=str(log),capabilities=CAPABILITIES,assumptions=assumptions,policy_defaults=policy_defaults,semantic_audit='compiled_equivalence_only_not_proof_of_NL_understanding')
            if getattr(self,'jump_extraction_scheme',None):
                deterministic=self.jump_extraction_scheme=='trained_deterministic'
                plan['model_info']['behavior_generation']['jump_extraction_experiment']=dict(scheme=self.jump_extraction_scheme,evidence_is_model_extracted=True,trained_for_evidence_protocol=deterministic,maximum_policy_repairs=0 if deterministic else 1,policy_source='deterministic_from_evidence' if deterministic else 'model')
            save(graph=graph)
            return plan,g,s
        except (ValueError,TypeError,KeyError,RuntimeError) as error:
            save(str(error));raise ValueError('需求抽取/编译未通过：'+str(error)+'；审阅记录：'+str(log)) from error

    def generate_behavior_legacy(self,catalog,request,destination,info):
        from behavior_graph import GRAPH_SYSTEM,validate_graph,graph_example_messages,generation_schema,explicit_layout_errors,explicit_parent_groups,layout_format_example
        from protocol import compact_catalog
        import re
        _,ids=compact_catalog(catalog)
        aliases={v:k for k,v in ids.items()}
        words=set(re.findall(r'[a-z]+',request.lower()))
        for chinese,english in [('格挡','block guard parry'),('攻击','attack strike melee'),('受击','hit hurt reaction'),('蹲','crouch'),('跳','jump'),('闪避','dodge roll')]:
            if chinese in request:words.update(english.split())
        def rank(a):return (-len(words&set(re.findall('[a-z]+',a.get('name','').lower()))),a['id'])
        assets=sorted([a for a in catalog['assets'] if a['kind'] in ('sequence','database','montage') and not a.get('additive')],key=rank)[:48]
        palette=[dict(alias=aliases[a['id']],name=a.get('name',''),kind=a['kind'],loop=a.get('loop',False)) for a in assets]
        if not palette:raise ValueError('请先选择动画或数据库')
        import copy
        mesh=next((a['id'] for a in catalog['assets'] if a['kind']=='mesh'),None)
        if not mesh:raise ValueError('状态机需要所选骨骼网格')
        allowed={a['alias'] for a in palette}
        failures=[];trace=[]
        from datetime import datetime
        log_dir=_LAYOUT_REPO/'artifacts/anim_config/models/configuration/logs'
        log_dir.mkdir(parents=True,exist_ok=True)
        run_log=log_dir/('behavior_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
        def save_diagnostic(graph=None,errors=None):
            record=dict(request=request,destination=destination,stages=trace,failures=failures,graph=graph,errors=errors or [])
            text=json.dumps(record,ensure_ascii=False,indent=2)
            run_log.write_text(text,encoding='utf-8')
            (log_dir/'latest_behavior_stages.json').write_text(text,encoding='utf-8')
        def resolved(graph):
            graph=copy.deepcopy(graph)
            for state in graph['states']:
                state['resources']=[ids[p] if p in allowed else p for p in state.get('resources',[])]
            return graph
        def stage(name,schema,prompt,validate,examples='layout'):
            self.behavior_schema=schema
            self.behavior_max_tokens=4096 if name=='layout' else 8192 if name=='repair_graph' else 4096
            # Unrelated few-shot gameplay variables were being copied into user
            # layouts. Keep layout extraction grounded in this request alone.
            demonstrations=layout_format_example() if name=='layout' else graph_example_messages(examples)
            messages=[{'role':'system','content':GRAPH_SYSTEM}]+demonstrations+[{'role':'user','content':json.dumps(prompt,ensure_ascii=False)}]
            for attempt in range(3):
                output=None
                try:
                    output=self.predict('behavior',messages)
                    validate(output)
                    trace.append(dict(stage=name,output=copy.deepcopy(output),attempts=attempt+1))
                    save_diagnostic(output)
                    print('BEHAVIOR_STAGE',name,'PASS',flush=True)
                    return output
                except (ValueError,TypeError,KeyError,StopIteration) as error:
                    failures.append(dict(stage=name,error=str(error)))
                    save_diagnostic(output,[str(error)])
                    if attempt==2:raise ValueError('状态机生成未通过校验 ['+name+']：'+str(error)+'；完整记录：'+str(run_log)) from error
                    if output is not None:messages.append({'role':'assistant','content':json.dumps(output,ensure_ascii=False,separators=(',',':'))})
                    messages.append({'role':'user','content':'Previous output failed: '+str(error)+'. Regenerate this stage only. Read the original requirements again and fix these errors. Use only the selected aliases.'})
        def validate_layout(value):
            if not isinstance(value,dict) or set(value)!={'locomotion_roles','entry','variables','inputs','states'}:raise ValueError('Layout fields must be locomotion_roles,entry,variables,inputs,states')
            roles=value['locomotion_roles']
            if not isinstance(roles,list) or roles!=[r for r in ('idle','walk','run','sprint','crouch','jump') if r in roles] or 'idle' not in roles:raise ValueError('Invalid locomotion_roles; ordered fixed MM categories including idle')
            graph={k:v for k,v in value.items() if k!='locomotion_roles'};graph.update(version=2,transitions=[])
            errors=[e for e in validate_graph(resolved(graph),catalog,mesh,roles) if '不可达' not in e]
            errors.extend(explicit_layout_errors(request,graph))
            if errors:raise ValueError('; '.join(errors[:6]))
        layout=stage('layout',generation_schema(list(allowed),stage='layout'),dict(stage='layout',request=request,required_parent_groups=explicit_parent_groups(request),instruction='Include ALL requested states. Each required_parent_groups key MUST be player=group with initial child; every listed child MUST exist with parent set to that key. Do not copy unrelated variables or inputs. No transitions in this stage.',selected_resource_palette=palette),validate_layout)
        roles=layout.pop('locomotion_roles')
        graph=dict(layout,version=2,transitions=[])
        state_ids=[s['id'] for s in graph['states']]
        # Decompose by source so a small local model can preserve conditions and
        # completion semantics without truncating a whole long graph in one decode.
        for source in state_ids+['*']:
            def validate_edges(value):
                if not isinstance(value,dict) or set(value)!={'transitions'}:raise ValueError('Output transitions only')
                if any(e.get('from')!=source for e in value['transitions']):raise ValueError('Only edges from '+source+' are allowed in this stage')
                partial=dict(graph,transitions=value['transitions'])
                errors=[e for e in validate_graph(resolved(partial),catalog,mesh,roles) if '不可达' not in e]
                if errors:raise ValueError('; '.join(errors[:6]))
            value=stage('edges_'+source,generation_schema(list(allowed),stage='transitions',state_ids=state_ids,variable_names=list(graph['variables']),source=source),dict(stage='transitions',source=source,request=request,layout=layout),validate_edges,examples='transitions')
            graph['transitions'].extend(value['transitions'])
        errors=validate_graph(resolved(graph),catalog,mesh,roles)
        save_diagnostic(resolved(graph),errors)
        if errors:
            failures.append(dict(stage='whole_graph',error='; '.join(errors)))
            def validate_repair(value):
                if not isinstance(value,dict) or set(value)!={'transitions'}:raise ValueError('Repair requires transitions only')
                issues=validate_graph(resolved(dict(graph,transitions=value['transitions'])),catalog,mesh,roles)
                if issues:raise ValueError('; '.join(issues))
            value=stage('repair_graph',generation_schema(list(allowed),stage='transitions',state_ids=state_ids,variable_names=list(graph['variables'])),dict(stage='repair_transitions',request=request,graph=graph,validation_errors=errors,instruction='Return the complete corrected transitions array for all sources. Preserve valid edges and original requirements. Do not invent unconditional links to pass reachability.'),validate_repair,examples='transitions')
            graph['transitions']=value['transitions']
        graph=resolved(graph)
        save_diagnostic(graph)
        names={'idle':'待机','walk':'行走','run':'跑步','sprint':'冲刺','crouch':'下蹲','jump':'跳跃'}
        base_request='配置'+ '、'.join(names[r] for r in roles)+'，加入 Motion Matching 数据库。无法确认类别的待人工检查，不强行绑定。'
        # Keep capacity bounded and honor explicit limits from the original request.
        constraints=selection_policy(request)
        base_request+='每类最多保留'+str(constraints['max_candidates_per_role'] or 8)+'段。'
        for role,n in constraints['max_candidates_by_role'].items():base_request+=names[role]+'保留'+str(n)+'段。'
        if constraints['require_cardinal_directions']:base_request+='支持WASD四向。'
        plan,g,s=self.generate(catalog,base_request,destination,info)
        plan['request']=request;plan['behavior_graph']=graph
        plan['model_info']['behavior_generation']={'mode':'base_model_experimental','trained_graph_adapter':False,'retries':failures,'locomotion_request':base_request,'palette_size':len(palette),'protocol_version':2,'generation_stages':len(trace)}
        plan['issues'].append({'severity':'warning','code':'behavior_experimental','message':'状态机由基座模型实验生成，未使用专门训练的状态图适配器。请检查状态、输入、条件和资源；外部玩法事件仍需蓝图提供。'})
        return plan,g,s
