"""Editor-compatible localhost endpoint backed by independently trained generator/selector."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import AI as _LAYOUT_AI, REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,threading,time
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from split_runtime import SplitRuntime

def main():
    p=argparse.ArgumentParser();p.add_argument('--providers-config',type=Path);p.add_argument('--deployment',type=Path,required=True);p.add_argument('--port',type=int,default=8765);candidate=p.add_mutually_exclusive_group();candidate.add_argument('--experimental-behavior-adapter',type=Path);candidate.add_argument('--experimental-behavior-base',type=Path);candidate.add_argument('--behavior-extractor-deployment',type=Path);p.add_argument('--experimental-behavior-base-adapter',type=Path);p.add_argument('--experimental-jump-evidence',choices=['A','B']);a=p.parse_args()
    if (a.experimental_behavior_adapter or a.experimental_behavior_base) and a.port==8765:raise ValueError('Unevaluated behavior models must use an isolated test port')
    if a.experimental_jump_evidence and (a.port==8765 or not a.experimental_behavior_base_adapter or a.behavior_extractor_deployment):raise ValueError('Jump evidence trial requires an isolated candidate adapter; cannot change default/evaluated service')
    behavior_deployment=None
    if a.behavior_extractor_deployment:
        if a.experimental_behavior_base_adapter:raise ValueError('Do not mix evaluated manifest and candidate adapter arguments')
        from behavior_model_deployment import load_manifest
        behavior_deployment=load_manifest(a.behavior_extractor_deployment)
        a.experimental_behavior_base=Path(behavior_deployment['base']);a.experimental_behavior_base_adapter=Path(behavior_deployment['adapter'])
    d=json.loads(a.deployment.read_text(encoding='utf-8'));run=Path(d['run'])
    if d['protocol']!='generator_selector_v1' or d['runtime_flow_version']!=1:raise ValueError('Unsupported split deployment')
    for task in ('generator','selector'):
        if hashlib.sha256((run/task/'adapter/adapter_model.safetensors').read_bytes()).hexdigest()!=d['adapter_sha256'][task]:raise ValueError('Adapter differs from evaluated weights')
        if hashlib.sha256((run/task/'adapter/adapter_config.json').read_bytes()).hexdigest()!=d['adapter_config_sha256'][task]:raise ValueError('LoRA config differs from evaluated configuration')
        prompt=run/task/'adapter/prompt_config.json'
        if (hashlib.sha256(prompt.read_bytes()).hexdigest() if prompt.exists() else None)!=d['prompt_sha256'][task]:raise ValueError('Prompt version differs from evaluated configuration')
    rt=SplitRuntime(d['base'],run/'generator/adapter',run/'selector/adapter',a.experimental_behavior_adapter,a.experimental_behavior_base,a.experimental_behavior_base_adapter);lock=threading.Lock()
    provider_info=None
    if a.providers_config:
        from gasp_ai.config import load_config
        _, configured_models = load_config(a.providers_config)
        for task, spec in configured_models.items():
            if spec.provider == 'builtin' and (spec.base_model != Path(d['base']).resolve() or spec.adapter != (run/task.value/'adapter').resolve()):
                raise ValueError('Builtin service model differs from its evaluated deployment: '+task.value)
        from gasp_ai.runtime import attach_runtime
        provider_info=attach_runtime(rt,a.providers_config)
        if rt.task_providers and a.port==8765:raise ValueError('Provider overrides require an isolated review port; the evaluated default service remains unchanged')
    rt.jump_extraction_scheme=a.experimental_jump_evidence
    info={'application':'gasp-animation-config-model','base':'Qwen2.5-1.5B-Instruct','run':d['run'],'task_protocol':d['protocol'],'deployment_sha256':hashlib.sha256(a.deployment.read_bytes()).hexdigest(),'adapter_sha256':d['adapter_sha256'],'trained':True,'flow_protocol':2,'complex_flow_runtime':True,'requires_human_review':True,'heldout_exact':d['pipeline']['exact'],'test':d['test']}
    info['behavior_graph_versions']=[1,2,3]
    if provider_info:info.update(model_providers=provider_info,provider_overrides_evaluated=not bool(rt.task_providers))
    info['behavior_schema_source_sha256']=hashlib.sha256((_LAYOUT_AI.parent/'behavior_requirements.py').read_bytes()).hexdigest()
    info['behavior_runtime_source_sha256']=hashlib.sha256((_LAYOUT_AI.parent/'ai/configuration/runtime/split_runtime.py').read_bytes()).hexdigest()
    if a.experimental_jump_evidence:
        info['jump_extraction_experiment']=dict(scheme=a.experimental_jump_evidence,source_sha256=hashlib.sha256((_LAYOUT_AI.parent/'jump_extraction_trial.py').read_bytes()).hexdigest(),trained_for_evidence_protocol=False)
    info['behavior_generator']='requirement_ir_compiler_v1'
    info['unified_generator']='unified_state_v1_experimental'
    info['unified_protocol']='unified_state_v1'
    info['custom_action_names']=True
    info['unified_source_sha256']={name:hashlib.sha256((_LAYOUT_AI.parent/name).read_bytes()).hexdigest() for name in ('unified_generation.py','unified_behavior.py','schema_decode_compat.py','unified_explicit_edges.py','unified_runtime_rules.py','unified_content_rules.py')}
    if a.experimental_behavior_adapter:
        info['behavior_generator']='requirement_ir_compiler_v1_candidate_adapter_unvalidated'
        info['behavior_adapter_sha256']=hashlib.sha256((a.experimental_behavior_adapter/'adapter_model.safetensors').read_bytes()).hexdigest()
    if a.experimental_behavior_base:
        info['behavior_generator']='requirement_ir_compiler_v1_independent_base_unvalidated'
        info['behavior_base']=str(a.experimental_behavior_base.resolve())
        info['behavior_base_config_sha256']=hashlib.sha256((a.experimental_behavior_base/'config.json').read_bytes()).hexdigest()
        info['behavior_gpu_policy']='one base on GPU; park other base on CPU between extraction and resource selection'
        if a.experimental_behavior_base_adapter:
            info['behavior_generator']='requirement_ir_compiler_v1_independent_adapter_unvalidated'
            info['behavior_adapter_sha256']=hashlib.sha256((a.experimental_behavior_base_adapter/'adapter_model.safetensors').read_bytes()).hexdigest()
            info['behavior_base_quantization']='nf4_double_bfloat16' if rt.behavior_quantized else None
            if rt.behavior_quantized:info['behavior_gpu_policy']='independent NF4 base and legacy BF16 base on GPU; no quantized CPU transfer'
    if behavior_deployment:
        info['behavior_generator']='requirement_ir_compiler_v1_bounded_extractor_evaluated_combat_unverified'
        info['behavior_validation']=behavior_deployment['summary']
        info['behavior_extractor_deployment_sha256']=hashlib.sha256(a.behavior_extractor_deployment.read_bytes()).hexdigest()
    info['selection_mode']='name_pose_candidates_v1' if rt.pose_assistant.enabled else 'selector_without_optional_pose'
    info['generator_prompt_version']=rt.generator_prompt_version
    info['supported_actions']=['hit','attack','jump','dodge'] if rt.generator_prompt_version==3 else ['hit','attack']
    info['pose_weights_sha256']=rt.pose_assistant.sha
    class Handler(BaseHTTPRequestHandler):
        def respond(self,status,value):
            data=json.dumps(value,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
        def do_GET(self):
            if self.path=='/health':self.respond(200,info)
            elif self.path=='/progress':self.respond(200,dict(getattr(rt,'progress',{})))
            else:self.respond(404,{'error':'not found'})
        def do_POST(self):
            if self.headers.get('Host') not in (f'127.0.0.1:{a.port}',f'localhost:{a.port}'):self.respond(403,{'error':'invalid host'});return
            if self.path=='/shutdown':self.respond(200,{'stopping':True});threading.Thread(target=self.server.shutdown,daemon=True).start();return
            if self.path!='/generate':self.respond(404,{'error':'not found'});return
            try:
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=128*1024*1024:raise ValueError('Invalid body size')
                data=json.loads(self.rfile.read(n));start=time.time()
                if not lock.acquire(blocking=False):
                    self.respond(409,{'error':'模型服务正在生成其他请求，请等待该请求结束后重试'});return
                try:
                    rt.progress=dict(request_id=data.get('request_id',''),stage='start',phase='prepare',tokens=0,started=time.time(),running=True)
                    if data.get('behavior_protocol') not in (None,'unified_state_v1'):raise ValueError('Unknown behavior protocol')
                    generate=rt.generate_behavior_unified if data.get('behavior_protocol')=='unified_state_v1' else rt.generate_behavior if data.get('behavior_mode') is True else rt.generate
                    plan,g,s=generate(data['catalog'],data['request'],data['destination'],info)
                finally:
                    rt.progress.update(running=False,finished=time.time())
                    rt.torch.cuda.empty_cache()
                    lock.release()
                self.respond(200,{'plan':plan,'configuration':g,'selection':s,'model':info,'seconds':time.time()-start})
            except (ValueError,TypeError,KeyError,RuntimeError,ImportError) as e:self.respond(422,{'error':str(e),'model':info})
    server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);print('SPLIT_MODEL_READY',json.dumps(info),flush=True)
    try:server.serve_forever()
    finally:server.server_close()
if __name__=='__main__':main()
