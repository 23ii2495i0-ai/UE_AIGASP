"""Request a trained V2 plan and persist both its IR and gated editor draft."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,json,urllib.request,urllib.parse
from pathlib import Path
from flow_protocol import validate_ir
def main():
 p=argparse.ArgumentParser();p.add_argument('--catalog',required=True);p.add_argument('--request',required=True);p.add_argument('--output',required=True);p.add_argument('--endpoint',default='http://127.0.0.1:8766/generate');p.add_argument('--destination',default='/Game/Native/Generated/FlowDraft');a=p.parse_args()
 url=urllib.parse.urlparse(a.endpoint)
 if url.scheme!='http' or url.hostname not in ('localhost','127.0.0.1'):raise ValueError('Only a loopback model is supported')
 catalog=json.loads(Path(a.catalog).read_text(encoding='utf-8-sig'));request=Path(a.request).read_text(encoding='utf-8-sig')
 body=json.dumps({'catalog':catalog,'request':request,'destination':a.destination},ensure_ascii=False).encode()
 with urllib.request.urlopen(urllib.request.Request(a.endpoint,body,{'Content-Type':'application/json'}),timeout=120) as r:result=json.load(r)
 if result.get('model',{}).get('flow_protocol')!=2:raise ValueError('Endpoint is not the trained V2 model')
 validate_ir(catalog,result['prediction'])
 out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('FLOW_PLAN_SAVED',out,'editor_application_blocked=',any(x.get('severity')=='error' for x in result['plan']['issues']))
if __name__=='__main__':main()
