"""Split existing synthetic oracle examples; never reuse mixed adapters as split models."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse
import hashlib
import json
from pathlib import Path
from split_protocol import generator_messages, selector_messages, validate_generator, merge

def convert(row):
    p=row['target']
    g={k:p[k] for k in ('roles','blend_seconds','filters','policy')}
    g['slots']={**{r:'locomotion' for r in p['roles']},**{r:'action' for r in p['actions']}}
    g['reject']='unsupported' if p['reject']=='unsupported' else None
    validate_generator(g)
    b={**p['bindings'],**p['actions']}
    s={'bindings':b,'issues':{k:p['reject'] for k,v in b.items() if v is None}}
    merge(row['catalog'],g,s)
    common={'id':row['id'],'request':row['request'],'source':'split_synthetic_oracle_v1'}
    def finish(task,target,msg):
        return dict(common,task=task,target=target,messages=msg+[{'role':'assistant','content':json.dumps(target,ensure_ascii=False,separators=(',',':'))}])
    return (finish('generator',g,generator_messages(row['request'])),
            dict(finish('selector',s,selector_messages(row['catalog'],row['request'],g)),catalog=row['catalog'],configuration=g))

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    seen={t:set() for t in ('generator','selector')};counts={}
    for split in ('train','validation','test'):
        outputs={'generator':[],'selector':[]}
        for line in (a.source/(split+'.jsonl')).read_text(encoding='utf-8').splitlines():
            row=json.loads(line)
            if row.get('source')!='synthetic_mm_flow_oracle_v2':continue
            for task,item in zip(outputs,convert(row)):
                digest=hashlib.sha256(json.dumps(item['messages'][:-1],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
                if digest in seen[task]:continue
                seen[task].add(digest);outputs[task].append(item)
        for task,rows in outputs.items():
            out=a.output/task;out.mkdir(parents=True,exist_ok=True)
            (out/(split+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
            counts[task+'/'+split]=len(rows)
    (a.output/'manifest.json').write_text(json.dumps({'counts':counts,'source':str(a.source),'warning':'Derived synthetic labels; test is previously inspected development data, NOT a new blind benchmark. No training or deployment claimed.'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(counts))
if __name__=='__main__':main()
