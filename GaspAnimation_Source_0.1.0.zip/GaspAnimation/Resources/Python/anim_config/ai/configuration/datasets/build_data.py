"""Create explicitly synthetic domain examples plus licensed external JSON support examples."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,random,hashlib,urllib.request,urllib.parse,sys
from pathlib import Path
from protocol import messages,ROLES
ROOT=_LAYOUT_REPO;OUT=ROOT/'artifacts/anim_config'
TRAIN_PHRASES={'idle':['待机','站着休息','保持站立','原地等待','idle','stand at ease','remain stationary'],'walk':['行走','慢走','走路','用散步的速度前进','walk','walking slowly','stroll forward'],'run':['跑步','奔跑','跑动','小跑前进','run','jog forward','running'],'sprint':['冲刺','全速跑','最快速度前进','短距离疾跑','sprint','dash at full speed','sprinting'],'crouch':['蹲伏','蹲下移动','压低身体前进','低姿态移动','crouch','duck down','crouching']}
TEST_PHRASES={'idle':['让角色不动，放松地站着','等待玩家操作时站好','stay still in a relaxed standing pose'],'walk':['不着急，迈步缓缓向前','按步行速度迈步','move ahead at a leisurely pace'],'run':['让人物用正常跑速向前赶路','保持慢跑节奏赶路','move with a steady jogging gait'],'sprint':['让角色以百米赛跑的速度前进','爆发速度往前飞奔','move at maximum running speed'],'crouch':['弯下双膝压低重心活动','贴低身体向前挪动','move while keeping the knees deeply bent']}
NAMES={'idle':['IdleLoop','StandingIdle','RestPose'],'walk':['WalkLoop','Walking','SlowWalk'],'run':['RunLoop','JogCycle','FastRun'],'sprint':['SprintCycle','Sprinting','FastDash'],'crouch':['CrouchLoop','CrouchedWalk','LowWalk']}
TEST_NAMES={'idle':['RelaxedStand','AtEase'],'walk':['LeisurePace','FootstepSlow'],'run':['SteadyJog','TrotCycle'],'sprint':['FullSpeedDash','MaxSpeed'],'crouch':['KneesBent','LowPosture']}
BONES=['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03']
def make(seed,split):
 rng=random.Random(seed);family=split+'_'+str(seed);rig='/Game/'+family+'/Skeleton.Skeleton';roles=rng.sample(ROLES,1 if rng.random()<.6 else 2);roles=[r for r in ROLES if r in roles]
 mode=rng.choices(['ok','missing','ambiguous','foreign','unsupported'],[65,10,8,10,7])[0]
 assets=[{'id':'/Game/'+family+'/Mesh.Mesh','name':'Character_'+str(seed),'kind':'mesh','skeleton':rig,'bones':BONES}];path_by_role={}
 for role in ROLES:
  if role in roles and mode=='missing' and role==roles[0]:continue
  name=rng.choice(TEST_NAMES[role] if split=='test' else NAMES[role]);name=f'{name}_{rng.randrange(10000)}'
  a={'id':f'/Game/{family}/{name}.{name}','name':name,'kind':'sequence','skeleton':rig,'loop':True,'tags':[role] if rng.random()<.4 else []}
  assets.append(a);path_by_role[role]=a['id']
  if mode=='ambiguous' and role==roles[0]:b=dict(a);b['id']+='_Other';assets.append(b)
  if mode=='foreign' and role==roles[0]:b=dict(a);b['id']+='_Foreign';b['skeleton']='/Game/Foreign.Skeleton';assets.append(b)
 rng.shuffle(assets);catalog={'version':1,'assets':assets}
 phrases=TEST_PHRASES if split=='test' else TRAIN_PHRASES
 request=('配置' if rng.random()<.5 else 'Please configure ')+('，以及' if rng.random()<.5 else ' and ').join(rng.choice(phrases[r]) for r in roles)
 blend=rng.choice([.2,.2,.2,.15,.3,.35]);
 if blend!=.2:request+=rng.choice([f'，动作切换用 {blend} 秒混合',f'; blend transitions over {blend} seconds'])
 reject=None
 if mode=='missing':reject='missing'
 if mode=='ambiguous':reject='ambiguous'
 if mode=='unsupported':
  request+=rng.choice(['，需要人物从障碍顶上跨过去',' and leap over a fence']) if split=='test' else rng.choice(['，并支持跨过障碍翻越',' and jump over an obstacle'])
  roles=[];reject='unsupported'
 msgs,ids=messages(catalog,request);rev={v:k for k,v in ids.items()};bindings={r:None if (r==roles[0] and mode in ('missing','ambiguous')) else rev[path_by_role[r]] for r in roles}
 target={'roles':roles,'bindings':bindings,'blend_seconds':blend,'reject':reject}
 msgs.append({'role':'assistant','content':json.dumps(target,ensure_ascii=False,separators=(',',':'))})
 return {'id':family,'source':'synthetic_domain_v1','messages':msgs,'catalog':catalog,'request':request,'target':target,'family':family}

def external_examples():
 base=OUT/'models/configuration/sources/external/hermes';base.mkdir(parents=True,exist_ok=True)
 api='https://modelscope.cn/api/v1/datasets/NousResearch/hermes-function-calling-v1/repo/tree?Revision=master&Root='
 info=json.load(urllib.request.urlopen(api,timeout=30));files=info['Data']['Files'];source=[]
 for name in ['README.md','json-mode-singleturn.json']:
  meta=next(f for f in files if f['Path']==name)
  url='https://modelscope.cn/api/v1/datasets/NousResearch/hermes-function-calling-v1/repo?'+urllib.parse.urlencode({'Revision':'master','FilePath':name})
  p=base/name
  if not p.exists():p.write_bytes(urllib.request.urlopen(url,timeout=60).read())
  source.append({'path':name,'url':url,'metadata':meta,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 (base/'provenance.json').write_text(json.dumps({'author_repo':'NousResearch/hermes-function-calling-v1','declared_license':'Apache-2.0','files':source},indent=2),encoding='utf-8')
 rows=json.loads((base/'json-mode-singleturn.json').read_text(encoding='utf-8'));examples=[]
 for row in rows:
  conv=row.get('conversations',[]);msgs=[]
  for turn in conv:
   role={'system':'system','human':'user','gpt':'assistant'}.get(turn['from'])
   if role:msgs.append({'role':role,'content':turn['value']})
  if not msgs or msgs[-1]['role']!='assistant':continue
  try:json.loads(msgs[-1]['content'])
  except (ValueError,TypeError):continue
  if sum(len(m['content']) for m in msgs)>2800:continue
  examples.append({'id':'hermes_'+str(row.get('id',len(examples))),'source':'NousResearch/hermes-function-calling-v1/json-mode-singleturn','messages':msgs})
  if len(examples)>=64:break
 return examples

def main():
 d=OUT/'models/configuration/datasets/initial';d.mkdir(parents=True,exist_ok=True)
 splits={'train':[make(i,'train') for i in range(800)],'validation':[make(10000+i,'validation') for i in range(64)],'test':[make(20000+i,'test') for i in range(60)]}
 external=external_examples();splits['train']+=external
 for split,rows in splits.items():
  with (d/(split+'.jsonl')).open('w',encoding='utf-8') as f:
   for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')
 report={'counts':{k:len(v) for k,v in splits.items()},'synthetic_domain':800,'external_json_auxiliary':len(external),'split_policy':'Different inventory families and asset IDs across all splits; test additionally uses held-out paraphrase and asset-name lists. Domain samples are synthetic oracle labels, not human UE expert annotations. External samples only in training.','sources':['../sources.json','../external/hermes/provenance.json']}
 (d/'manifest.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
