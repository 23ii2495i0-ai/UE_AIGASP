"""Balanced initial roles and mixed short IDs for an independent 4B adapter.

Earlier observed suites are development regressions. New test requests use
separate ID pools and wording; no test targets enter training.
"""
import copy,hashlib,json,random,re
from build_behavior_requirements_v3 import example,ROOT
from build_behavior_requirements_v2 import staged,original_development
from behavior_requirements import anchor_topology,prompt_fingerprint

OUT=ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v4'


def mixed(index,test=False):
    rng=random.Random(index+993);base=example(index,test=test,style=index%9)
    targets={r['stage']:copy.deepcopy(r['target']) for r in base};request=base[0]['request']
    names={n for g in targets['topology']['groups'] for n in [g['id']]+g['children']}
    for kind,keys in [('jump',['counter']),('combo',['hit','buffer'])]:
        if targets[kind]['policy']:
            names.update(targets[kind]['policy'][k] for k in keys)
    if targets['combo']['policy']:names.update(targets['combo']['policy']['attacks'])
    names.update(v['id'] for v in targets['dependencies']['external_variables'])
    # Distinct ID pools; role and initial choice are independent of all spellings.
    pool=[c+str(n) for c in ('xyzuvw' if test else 'abcdefghijklmnop') for n in range(10)]
    chosen=rng.sample(pool,len(names));mapping=dict(zip(sorted(names),chosen))
    def rename(v):
        if isinstance(v,str):return re.sub(r'\b[A-Za-z_][A-Za-z0-9_]*\b',lambda m:mapping.get(m[0],m[0]),v)
        if isinstance(v,list):return [rename(x) for x in v]
        if isinstance(v,dict):return {k:rename(x) for k,x in v.items()}
        return v
    targets=rename(targets);lines=rename(request).splitlines()
    for g in targets['topology']['groups']:
        g['initial']=rng.choice(g['children']);children=list(g['children']);rng.shuffle(children)
        if test:line=f"父层 {g['id']} 下的直接成员为 {' / '.join(children)}；该层的初始子节点指定为 {g['initial']}。"
        elif index%2:line=f"{g['id']} 为父状态，包含 {'、'.join(children)}；初始子状态是 {g['initial']}。"
        else:line=f"Parent {g['id']} has direct children {', '.join(children)}; its initial child is {g['initial']}."
        if g['id']==targets['topology']['entry']:line+=' Entry '+g['id']+'.'
        lines[g['source_lines'][0]]=line
    loc=targets['locomotion']['policy'];pairs=[(loc['idle'],'待机'),(loc['walk'],'走路'),(loc['run'],'跑步')];rng.shuffle(pairs)
    for i,line in enumerate(lines):
        if '使用 Motion Matching：' in line and all(loc[k] in line for k in ('idle','walk','run')):
            verb='用作' if test else '表示' if index%2 else '对应'
            lines[i]='Motion Matching：'+'，'.join(f'{n} {verb}{role}' for n,role in pairs)+'；根据移动输入和步态选择，停止输入返回 '+loc['idle']+'。'
    request='\n'.join(lines);targets['topology']=anchor_topology(targets['topology'],request)
    return staged(request,targets,index)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    manifest=dict(protocol='requirement_ir_v1',prompt_sha256=prompt_fingerprint(),original_request_in_training=True,original_development_replays=4,prior_observed_suites='development regressions',test_ids_and_wording_disjoint=True,initial_roles='uniform random among all direct children; not inferred from idle or list order',note='Bounded synthetic supported policies; no universal NL or combat-playback claim',splits={})
    for split,count,start in [('train',256,90000),('validation',8,100000),('test',16,110000)]:
        data=[r for i in range(count) for r in mixed(start+i,test=split=='test')]
        if split=='train':
            for replay in range(4):
                for row in original_development():row['id']+=f'_replay{replay}';data.append(row)
        path=OUT/(split+'.jsonl');path.write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in data)+'\n',encoding='utf-8')
        manifest['splits'][split]=dict(requests=count+(4 if split=='train' else 0),rows=len(data),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest))


if __name__=='__main__':main()
