"""Synthetic supported-policy extraction data, split by wording template and IDs.

Not arbitrary-language ground truth or animation-content supervision.
"""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import sys,json,random,copy,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from behavior_requirements import extraction_messages,prompt_fingerprint

ROOT=_gasp_workspace
OUT=ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v1'


def example(index,style):
    rng=random.Random(1009+index)
    suffix=str(index)
    ground='Ground_'+suffix;air='Air_'+suffix
    idle='Idle_'+suffix;walk='Walk_'+suffix;run='Run_'+suffix
    rise='Rise_'+suffix;fall='Fall_'+suffix
    counter='Jumps_'+suffix;buffer='Queue_'+suffix
    attacks=['Strike'+str(i)+'_'+suffix for i in range(rng.choice([1,2,3]))];hit='Hurt_'+suffix
    limit=rng.choice([1,2,3,4]);jump_on=index%5!=0;combo_on=index%4!=0
    ground_phrases=[f'{ground} 为父状态，包含 {idle}、{walk}、{run}。默认子状态 {idle}，入口为 {ground}。',f'父组 {ground} 的直接子节点为 {idle}, {walk}, {run}；初始节点 {idle}，总入口 {ground}。',f'Parent group {ground}: children {idle}, {walk}, {run}; initial child {idle}; entry {ground}.',f'Build group {ground} containing {idle}, {walk}, {run}. Start in {ground} via {idle}.',f'进入 {ground} 时先进入 {idle}；{idle}/{walk}/{run} 都直接属于父状态 {ground}，它是整个流程入口。',f'The initial state is {ground}. Nest {idle}, {walk}, {run} immediately under {ground}, with {idle} as its default child.',f'顶层入口用 {ground}。请把 {walk}、{run} 和 {idle} 放在 {ground} 下面，默认先选 {idle}。']
    lines=[ground_phrases[style],f'Use Motion Matching: {idle} is idle, {walk} is walk, {run} is run; select by movement input and gait, stop to idle.']
    groups=[dict(id=ground,children=[idle,walk,run],initial=idle,source_lines=[0])]
    jump=None;combo=None
    if jump_on:
        group_line=len(lines)
        variants=[f'{air} 为父状态，包含 {rise}、{fall}。初始为 {rise}。',f'父组 {air} 包含直接子状态 {rise} 和 {fall}，初始 {rise}。',f'Parent group {air}: children {rise}, {fall}; initial {rise}.',f'Nest {rise} and {fall} in group {air}, default {rise}.',f'{rise} 与 {fall} 均直接属于 {air} 父状态，先进入 {rise}。',f'Use {air} as the parent of {rise} and {fall}; its default child is {rise}.',f'空中层叫 {air}，下面只有 {fall} 和 {rise} 两个子节点，默认进 {rise}。']
        lines.extend([variants[style],f'Jump counter {counter} starts at 0. Only allow {counter} < {limit}; launch and add 1 on successful jumps. Landed resets {counter}. Up/down follows vertical speed.'])
        groups.append(dict(id=air,children=[rise,fall],initial=rise,source_lines=[group_line]))
        jump=dict(group=air,rise=rise,fall=fall,counter=counter,max_jumps=limit)
    if combo_on:
        lines.extend([f'Attack combo order: '+ ' -> '.join(attacks)+f'. Hit state: {hit}. Internal input buffer {buffer}=false.',f'Only queue one Attack inside the combo window. Consume buffer for next attack, otherwise return to {ground}. Clear {buffer} on entry/exit and Hit interrupt. {hit} ends by testing ground/air, never resume an attack.'])
        combo=dict(attacks=attacks,hit=hit,buffer=buffer)
    ext=[];unsupported=[]
    if index%7==0:
        name='CanUse_'+suffix;lines.append(f'External variable {name}=false; source Blueprint.SetBoolVariable. It is not connected yet.')
        ext=[dict(id=name,initial=False,source='Blueprint.SetBoolVariable')]
    if index%11==0:
        lines.append('Also generate a wall-running gameplay system; report it as unsupported.')
        unsupported=['wall-running gameplay system']
    setting_keys=['move_blend','attack_blend','hit_blend','window_start','window_end','jump_velocity']
    settings={k:None for k in setting_keys}
    if index%3:
        settings.update(move_blend=.2,attack_blend=.1,hit_blend=.05)
        lines.append('Blends in seconds: ground 0.2, attacks 0.1, hit 0.05.')
    if index%6==0:
        settings.update(window_start=.3,window_end=.7,jump_velocity=600)
        lines.append('Normalized combo window: 0.3 to 0.7. Jump launch velocity: 600.')
    request='\n'.join(lines)
    raw_topology=dict(entry=ground,groups=groups)
    reviewed=dict(version=1);rows=[]
    targets=dict(topology=raw_topology,locomotion=dict(policy=dict(group=ground,idle=idle,walk=walk,run=run)),jump=dict(policy=jump),combo=dict(policy=combo),dependencies=dict(external_variables=ext,unsupported=unsupported),settings=settings)
    for stage in ('topology','locomotion','jump','combo','dependencies','settings'):
        schema,messages=extraction_messages(stage,request,copy.deepcopy(reviewed))
        target=targets[stage]
        rows.append(dict(id=f'{index}_{stage}',stage=stage,request=request,reviewed=copy.deepcopy(reviewed),schema=schema,target=copy.deepcopy(target),messages=messages+[dict(role='assistant',content=json.dumps(target,ensure_ascii=False,separators=(',',':')))]))
        if stage=='topology':reviewed['topology']=dict(copy.deepcopy(target),standalone=[])
        elif stage in ('locomotion','jump','combo'):
            reviewed[stage]=copy.deepcopy(target['policy'])
            if stage=='combo' and combo:reviewed['topology']['standalone']=sorted(attacks+[hit])
        elif stage=='dependencies':reviewed.update(copy.deepcopy(target))
    return rows


def main():
    OUT.mkdir(parents=True,exist_ok=True);manifest=dict(protocol='requirement_ir_v1',prompt_sha256=prompt_fingerprint(),note='Synthetic supported policies; disjoint wording templates and IDs across splits. Does not prove arbitrary NL understanding or real combat content.',splits={})
    for split,count,start,styles in [('train',144,100,[0,1,2,3]),('validation',8,10000,[4]),('test',16,20000,[5,6])]:
        rows=[r for i in range(count) for r in example(start+i,styles[i%len(styles)])]
        path=OUT/(split+'.jsonl');path.write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows)+'\n',encoding='utf-8')
        manifest['splits'][split]=dict(requests=count,rows=len(rows),templates=styles,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest,ensure_ascii=False))

if __name__=='__main__':main()
