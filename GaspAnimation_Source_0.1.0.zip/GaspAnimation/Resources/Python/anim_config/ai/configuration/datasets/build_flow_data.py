"""Synthetic MM-flow oracle data + deduplicated public JSON auxiliary, split by family."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,random,hashlib
from pathlib import Path
from flow_protocol import messages,validate_ir,ROLES
ROOT=_LAYOUT_REPO;ART=ROOT/'artifacts/anim_config';OUT=ART/'models/configuration/datasets/flow_v2/data'
TRAIN={'idle':['待机','保持站立','idle'],'walk':['行走','缓步前进','walk'],'run':['跑步','小跑赶路','run'],'sprint':['冲刺','全速奔跑','sprint'],'crouch':['蹲伏移动','压低身体走','crouch']}
HELD={'idle':['静止时放松站好','stand at ease'],'walk':['以散步的步幅向前挪动','move at a walking pace'],'run':['让人物用正常跑速前进','maintain a jogging gait'],'sprint':['爆发速度快速赶路','dash at maximum speed'],'crouch':['弯膝低姿态向前活动','move with knees bent']}
def make(seed,split):
 rng=random.Random(seed);rig=f'/Game/{split}_{seed}/Skeleton.Skeleton';assets=[{'id':f'/Game/{split}_{seed}/Mesh.Mesh','kind':'mesh','name':'Character','skeleton':rig,'bones':['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03']}]
 chosen=rng.sample(ROLES,rng.randint(1,3));roles=[r for r in ROLES if r in chosen]
 filters={};variant=rng.choice(['plain','rifle','injured','aim'])
 if variant=='rifle':filters={'weapon':'rifle'}
 elif variant!='plain':filters={variant:True}
 acts={};policy={};parts=[]
 if rng.random()<.6:
  acts['hit']=None
  if rng.random()<.7:policy['hit_interrupts']='all';parts.append('受击打断所有当前动作' if split!='test' else '一旦被打中就中断正在做的动作')
  else:parts.append('添加受击动作' if split!='test' else '受到伤害时播放反应动画')
  policy['after_hit']=rng.choice(['previous','locomotion'])
  parts.append(('受击结束恢复上一个动作' if policy['after_hit']=='previous' else '受击结束恢复移动选库') if split!='test' else ('伤害反应播完回到被打断前的行为' if policy['after_hit']=='previous' else '伤害反应结束后重新交给运动匹配'))
 if rng.random()<.55:
  acts['attack']=None
  if rng.random()<.7:policy['attack_exit']='finished';parts.append('攻击必须播完才能退出' if split!='test' else '进攻片段结束之前不允许离开攻击')
  else:parts.append('添加攻击动作' if split!='test' else '需要播放进攻动画')
 if rng.random()<.5:policy['sprint_aim']='block';parts.append('冲刺时禁止瞄准' if split!='test' else '全速跑期间不能进入瞄准')
 if rng.random()<.3:variant='plain';filters={};acts={};policy={};parts=[]
 bindings={}
 for role in roles:
  for v in dict.fromkeys([variant,rng.choice([x for x in ['plain','rifle','injured','aim'] if x!=variant])]):
   a={'id':f'/Game/{split}_{seed}/{role}_{v}.{role}_{v}','name':f'{v}_{role}_Loop_{rng.randrange(99999)}','kind':'sequence','skeleton':rig,'loop':True,'tags':[role,v]}
   assets.append(a)
   if v==variant:bindings[role]=a['id']
 for act in acts:
  a={'id':f'/Game/{split}_{seed}/{act}.{act}','kind':'sequence','name':f'{act}_Reaction' if act=='hit' else 'attack_Strike','skeleton':rig,'loop':False,'tags':[act]};assets.append(a);acts[act]=a['id']
 if rng.random()<.5:
  a=dict(assets[-1]);a['id']+='_Foreign';a['skeleton']='/Game/Foreign.Foreign';assets.append(a)
 mode=rng.choices(['ok','missing','ambiguous','mesh','unsupported'],[76,9,7,3,5])[0];reject=None
 bad=roles[0]
 if mode=='missing':assets=[a for a in assets if a['id']!=bindings[bad]];bindings[bad]=None;reject='missing'
 if mode=='ambiguous':a=dict(next(a for a in assets if a['id']==bindings[bad]));a['id']+='_Duplicate';assets.append(a);bindings[bad]=None;reject='ambiguous'
 if mode=='mesh':assets=[a for a in assets if a['kind']!='mesh'];bindings={r:None for r in roles};acts={k:None for k in acts};reject='mesh'
 phrase=HELD if split=='test' else TRAIN
 request='配置'+('、'.join(rng.choice(phrase[r]) for r in roles))
 if variant=='rifle':request+='，移动只用持步枪的动画' if split!='test' else '，这些移动都采用步枪姿态'
 if variant=='injured':request+='，移动只用受伤版本' if split!='test' else '，这些运动采用带伤步态'
 if variant=='aim':request+='，移动只用瞄准版本' if split!='test' else '，这些移动保持瞄准姿态'
 if parts:request+='；'+'；'.join(parts)
 blend=rng.choice([.2,.2,.15,.25,.3,.4]);request+=f'；混合时间{blend}秒'
 if mode=='unsupported':request+='；并自动实现联机预测与技能冷却' if split!='test' else '；还要生成联网补偿和招式冷却逻辑';reject='unsupported'
 rng.shuffle(assets);catalog={'version':1,'assets':assets};msg,ids=messages(catalog,request);rev={v:k for k,v in ids.items()}
 target={'roles':roles,'bindings':{k:rev.get(v) for k,v in bindings.items()},'blend_seconds':blend,'filters':filters,'actions':{k:rev.get(v) for k,v in acts.items()},'policy':policy,'reject':reject}
 validate_ir(catalog,target)
 msg.append({'role':'assistant','content':json.dumps(target,ensure_ascii=False,separators=(',',':'))})
 return {'id':f'{split}_{seed}','source':'synthetic_mm_flow_oracle_v2','messages':msg,'catalog':catalog,'request':request,'target':target}
def external():
 seen=set();rows=[];audit={'raw_rows':0,'json_eligible':0,'duplicate_conversations':0,'invalid_or_nonjson':0,'files':{}}
 for path in sorted((ART/'models/configuration/sources/bulk').glob('*.json')):
  if path.name=='sources.json':continue
  data=json.loads(path.read_text(encoding='utf-8'));audit['files'][path.name]=len(data)
  for row in data:
   audit['raw_rows']+=1;conv=row.get('conversations',[]);msgs=[]
   for t in conv:
    role={'system':'system','human':'user','gpt':'assistant'}.get(t.get('from'))
    if role:msgs.append({'role':role,'content':t.get('value','')})
   if not msgs or msgs[-1]['role']!='assistant':continue
   content=msgs[-1]['content'].strip()
   if content.startswith('```'):content=content.split('\n',1)[-1].rsplit('```',1)[0].strip()
   try:json.loads(content)
   except (ValueError,TypeError):audit['invalid_or_nonjson']+=1;continue
   if sum(len(m['content']) for m in msgs)>2600:continue
   msgs[-1]['content']=content;digest=hashlib.sha256(json.dumps(msgs,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
   if digest in seen:audit['duplicate_conversations']+=1;continue
   seen.add(digest);audit['json_eligible']+=1;rows.append({'id':'public_'+digest[:16],'source':path.name,'messages':msgs})
 random.Random(77).shuffle(rows);return rows,audit
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 # Different families/IDs and test phrasing; templates still synthetic, not expert labels.
 domain=[make(i,'train') for i in range(8192)]
 aux,audit=external();selected=aux[:512]
 splits={'train':domain[:3584]+selected,'validation':[make(100000+i,'validation') for i in range(64)],'test':[make(200000+i,'test') for i in range(120)]}
 for key,rows in {**splits,'domain_pool':domain,'public_clean_pool':aux}.items():
  (OUT/(key+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
 manifest={'counts':{k:len(v) for k,v in splits.items()},'available_domain_synthetic':len(domain),'public_audit':audit,'public_used':len(selected),'synthetic_used':3584,'split_policy':'Separate family/ID ranges; test uses held-out Chinese paraphrases. Synthetic templates are shared; not a human expert benchmark. Public auxiliary only in training.','sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.jsonl')}}
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print(json.dumps(manifest),flush=True)
if __name__=='__main__':main()
