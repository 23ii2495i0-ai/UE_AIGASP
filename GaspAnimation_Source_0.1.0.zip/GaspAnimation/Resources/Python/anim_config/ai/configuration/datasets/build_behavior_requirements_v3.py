"""Opaque-ID and numeric-copy curriculum. v1/v2 observed tests are development.

State names carry no locomotion role; declaration order and initial child vary.
New word pools, wording templates and per-field numbers form the test split.
"""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import sys,json,copy,re,random,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from behavior_requirements import anchor_topology,prompt_fingerprint
from build_behavior_requirements_v2 import long_example,staged,original_development

ROOT=_gasp_workspace
OUT=ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v3'
TRAIN_WORDS='Maple Quartz Cedar Orion Vale Atlas Iris Coral Mica Pine Jade Rook Dune Pearl Flint Echo Lyra Tide Beryl Aster Aspen Sable Raven Lumen'.split()
TEST_WORDS='Willow Nadir Kite Lagoon Fable Grotto Juniper Kestrel Opal Thistle Meadow Wren Grove Lotus Finch Prism Summit Terra Violet Zephyr Hazel Fern Moss Dawn'.split()


def example(index,test=False,style=0):
    rng=random.Random(index+731)
    base=long_example(index,style%9)
    targets={row['stage']:copy.deepcopy(row['target']) for row in base};request=base[0]['request']
    names={name for g in targets['topology']['groups'] for name in [g['id']]+g['children']}
    jump=targets['jump']['policy'];combo=targets['combo']['policy']
    if jump:names.add(jump['counter'])
    if combo:names.update(combo['attacks']+[combo['hit'],combo['buffer']])
    names.update(v['id'] for v in targets['dependencies']['external_variables'])
    words=rng.sample(TEST_WORDS if test else TRAIN_WORDS,len(names))
    mapping={name:word+''.join(rng.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(2)) for name,word in zip(sorted(names),words)}
    def rename(value):
        if isinstance(value,str):
            for old,new in mapping.items():value=re.sub(r'\b'+re.escape(old)+r'\b',new,value)
            return value
        if isinstance(value,list):return [rename(v) for v in value]
        if isinstance(value,dict):return {k:rename(v) for k,v in value.items()}
        return value
    targets=rename(targets);request=rename(request)
    loc=targets['locomotion']['policy'];jump=targets['jump']['policy'];combo=targets['combo']['policy']
    if index%9==1:targets['topology']['groups'][0]['initial']=loc['walk']
    if jump and index%7==0:next(g for g in targets['topology']['groups'] if g['id']==jump['group'])['initial']=jump['fall']
    lines=request.splitlines()
    # Group declarations preserve independent initial choice, not a role prefix
    # or the first child in the textual list.
    for group in targets['topology']['groups']:
        children=list(group['children']);rng.shuffle(children)
        source=group['source_lines'][0]
        if test and style%2==0:line=f"{group['id']} 作为父组，{'、'.join(children)} 是其直接子状态；激活该组时先进入 {group['initial']}。"
        elif test:line=f"Under parent {group['id']} place child nodes {', '.join(children)}. Its initial child is {group['initial']}."
        elif style%3==0:line=f"{group['id']} 为父状态，包含 {'、'.join(children)}。初始子状态 {group['initial']}。"
        elif style%3==1:line=f"Parent {group['id']} contains {', '.join(children)} as direct children; initial child {group['initial']}."
        else:line=f"在父组 {group['id']} 下放入子节点 {'、'.join(children)}，进入组先选择 {group['initial']}。"
        if group['id']==loc['group']:line+=f" 整体入口 {loc['group']}。"
        lines[source]=line
    # Role evidence is explicit and independently permuted.
    role_pairs=[(loc['idle'],'待机'),(loc['walk'],'走路'),(loc['run'],'跑步')];rng.shuffle(role_pairs)
    for i,line in enumerate(lines):
        if all(loc[k] in line for k in ('idle','walk','run')) and '是待机' in line:
            lines[i]='使用 Motion Matching：'+'；'.join(f'{name} 是 {role}' for name,role in role_pairs)+'；按移动输入与步态切换，停止时回到待机。'
    if jump:
        lines.append(f"上升使用 {jump['rise']}，下降使用 {jump['fall']}，由垂直速度的正负选择。")
    # Vary only explicit facts. Null stays null; no training default is silently
    # turned into an extracted fact.
    settings=targets['settings']
    pools=dict(move_blend=[.13,.19,.27,.33,.41] if test else [.11,.16,.23,.29,.36,.42],attack_blend=[.09,.15,.21] if test else [.06,.12,.18,.24],hit_blend=[.03,.05,.08] if test else [.02,.04,.07,.1],window_start=[.12,.22,.32] if test else [.1,.25,.35],window_end=[.62,.72,.82] if test else [.6,.75,.9],jump_velocity=[450,570,690,810] if test else [400,520,640,880])
    for key in settings:
        if settings[key] is not None:settings[key]=rng.choice(pools[key])
    lines=[line for line in lines if not line.startswith(('普通移动切换混合','Normalized combo window:','Blends in seconds:'))]
    if settings['move_blend'] is not None:lines.append(f"Blends in seconds: ground {settings['move_blend']}, attacks {settings['attack_blend']}, hit {settings['hit_blend']}.")
    if settings['window_start'] is not None:lines.append(f"Normalized combo window: {settings['window_start']} to {settings['window_end']}. Jump launch velocity: {settings['jump_velocity']}.")
    request='\n'.join(lines)
    targets['topology']=anchor_topology(targets['topology'],request)
    return staged(request,targets,index)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    manifest=dict(protocol='requirement_ir_v1',prompt_sha256=prompt_fingerprint(),original_request_in_training=True,original_development_replays=4,observed_v1_v2_tests='development only',test_is_role_agnostic=True,test_numeric_pools_disjoint_by_field=True,test_word_pool_disjoint=True,note='Still bounded synthetic policies, not arbitrary NL or animation-content proof',splits={})
    for split,count,start in [('train',256,60000),('validation',8,70000),('test',16,80000)]:
        data=[row for i in range(count) for row in example(start+i,test=split=='test',style=i%9)]
        if split=='train':
            for replay in range(4):
                for row in original_development():row['id']+=f'_replay{replay}';data.append(row)
        path=OUT/(split+'.jsonl');path.write_text('\n'.join(json.dumps(row,ensure_ascii=False) for row in data)+'\n',encoding='utf-8')
        manifest['splits'][split]=dict(synthetic_requests=count,rows=len(data),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest,ensure_ascii=False))

if __name__=='__main__':main()
