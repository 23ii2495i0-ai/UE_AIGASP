"""Complete locomotion-shape coverage; no special handling for the user's Move ID."""
import copy,hashlib,json,random
from build_behavior_requirements_v4 import mixed,ROOT
from build_behavior_requirements_v2 import staged,original_development
from behavior_requirements import anchor_topology,prompt_fingerprint

OUT=ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v5'


def small(index,mode,test=False):
    rng=random.Random(index+45);prefix='z' if test else 'b'
    group,idle,walk,run=rng.sample([prefix+str(n) for n in range(100)],4)
    child=[idle]+([walk] if mode==2 else [run] if mode==3 else [])
    initial=rng.choice(child);declared=list(child);rng.shuffle(declared)
    if mode==0:
        line=f'这张图没有复合节点，唯一叶节点为 {idle}，从 {idle} 开始；不要创建父子关系。' if test else f'仅建立一个状态 {idle}，入口 {idle}，不设父组。'
        topology=dict(entry=idle,groups=[]);loc=dict(group=idle,idle=idle,walk=None,run=None)
    else:
        line=f'请让 {group} 管理这一层，其直属节点只有 {" / ".join(declared)}；激活本层先选 {initial}，整张图入口用 {group}。' if test else f'{group} 为父状态，包含 {"、".join(declared)}；初始子状态 {initial}，入口 {group}。'
        topology=dict(entry=group,groups=[dict(id=group,children=child,initial=initial,source_lines=[0])]);loc=dict(group=group,idle=idle,walk=walk if mode==2 else None,run=run if mode==3 else None)
    roles=[(idle,'待机')]+([(walk,'走路')] if mode==2 else [(run,'跑步')] if mode==3 else []);rng.shuffle(roles)
    lines=[line,'Motion Matching：'+'；'.join(name+(' 负责' if test else ' 表示')+role for name,role in roles)+'。只使用上述移动状态，停止输入回到 '+idle+'。','没有列出的移动状态不要补；不配置空中组、多段跳、攻击、连招或受击。']
    settings=dict(move_blend=None,attack_blend=None,hit_blend=None,window_start=None,window_end=None,jump_velocity=None)
    if index%2:
        settings.update(move_blend=rng.choice([.17,.28,.39] if test else [.12,.24,.36]),attack_blend=.13 if test else .12,hit_blend=.03 if test else .04)
        lines.append(f"Blends in seconds: ground {settings['move_blend']}, attacks {settings['attack_blend']}, hit {settings['hit_blend']}.")
    request='\n'.join(lines);topology=anchor_topology(topology,request)
    targets=dict(topology=topology,locomotion=dict(policy=loc),jump=dict(policy=None),combo=dict(policy=None),dependencies=dict(external_variables=[],unsupported=[]),settings=settings)
    return staged(request,targets,index)


def full(index,test=False):
    rows=mixed(index,test=test)
    if test:
        t={r['stage']:copy.deepcopy(r['target']) for r in rows};lines=rows[0]['request'].splitlines()
        for g in t['topology']['groups']:
            lines[g['source_lines'][0]]=f"以 {g['id']} 组织这一层：直接成员为 {'、'.join(reversed(g['children']))}，激活本层的首节点为 {g['initial']}。"+(' 总入口 '+g['id']+'。' if g['id']==t['topology']['entry'] else '')
        request='\n'.join(lines);t['topology']=anchor_topology(t['topology'],request);rows=staged(request,t,index)
    return rows


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    manifest=dict(protocol='requirement_ir_v1',prompt_sha256=prompt_fingerprint(),observed_v1_v4_suites='development regressions',original_request_in_training=True,original_development_replays=4,supported_shapes=['full ground/air/combo policies','ungrouped idle MM','grouped idle MM','idle+walk without run','idle+run without walk'],test_full_requests=8,test_small_requests=8,note='New names/wording and shape coverage. Original Move probe is not a special runtime fallback.',splits={})
    for split,full_n,small_n,start in [('train',128,128,130000),('validation',4,4,140000),('test',8,8,150000)]:
        data=[r for i in range(full_n) for r in full(start+i,test=split=='test')]
        data += [r for i in range(small_n) for r in small(start+1000+i,i%4,test=split=='test')]
        if split=='train':
            for replay in range(4):
                for row in original_development():row['id']+=f'_replay{replay}';data.append(row)
        path=OUT/(split+'.jsonl');path.write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in data)+'\n',encoding='utf-8')
        manifest['splits'][split]=dict(requests=full_n+small_n+(4 if split=='train' else 0),full=full_n,small=small_n,rows=len(data),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest))


if __name__=='__main__':main()
