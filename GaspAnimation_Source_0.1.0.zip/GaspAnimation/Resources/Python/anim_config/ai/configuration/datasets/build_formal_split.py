"""Build versioned task-isolated synthetic corpora with reserved phrase families."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,random
from pathlib import Path
from build_flow_data import make
from build_split_data import convert
from split_protocol import generator_messages,selector_messages

PHRASES={
 'train':{'idle':['待机','静止站立','不移动时站好','idle'], 'walk':['行走','慢走前进','散步移动','walk'], 'run':['跑步','小跑前进','正常跑速移动','run'], 'sprint':['冲刺','全速奔跑','高速冲刺','sprint'], 'crouch':['蹲伏移动','蹲着走','低姿态移动','crouch'],
 'hit':['添加受击动作','需要受击反应','配置被击中反应'], 'attack':['添加攻击动作','配置攻击片段','需要进攻动作'],
 'all':['受击打断所有当前动作','被击中立即中断任何动作','受伤反应优先打断其他行为'], 'finished':['攻击必须播完才能退出','进攻动作结束后才允许切换','攻击期间锁定直到播放结束'], 'previous':['受击结束恢复上一个动作','受击反应后回到被打断的动作','受击播完接着先前行为'], 'locomotion':['受击结束恢复移动选库','受击播完返回运动匹配','受击反应结束回到基础移动'], 'block':['冲刺时禁止瞄准','全速跑时不允许瞄准','进入冲刺时关闭瞄准']},
 'validation':{'idle':['原地待命'], 'walk':['以步行速度前移'], 'run':['用跑的方式赶路'], 'sprint':['用最高速度冲出去'], 'crouch':['弯膝保持低位行进'], 'hit':['加入挨打反馈'], 'attack':['加入挥击行为'], 'all':['挨打时马上终止一切正在播放的行为'], 'finished':['挥击的片段完整结束才可以离开'], 'previous':['挨打反馈结束继续之前被打断的行为'], 'locomotion':['挨打反馈完毕交回基础运动匹配'], 'block':['最快奔跑时不进入瞄准']},
 'test':{'idle':['停止输入后维持站姿'], 'walk':['用普通步幅缓慢赶路'], 'run':['维持常规奔跑节奏'], 'sprint':['爆发最大速度疾驰'], 'crouch':['压低身形曲膝前行'], 'hit':['安排伤害反应片段'], 'attack':['安排一次进攻播放'], 'all':['伤害到来时无论在做什么都立即让位给伤害反应'], 'finished':['一次进攻启动以后应完整播放后再放行切换'], 'previous':['伤害反应收尾后续播受伤之前正在做的事'], 'locomotion':['伤害反应收尾后重新回到常规运动匹配选库'], 'block':['疾驰期间拒绝进入瞄准姿态']}}

def example(seed,split):
    row=make(seed,'train');p=row['target'];rng=random.Random(seed+917);phr=PHRASES[split]
    # Match the editor's real catalogs: both databases/sequences, usually WITHOUT tags.
    # Separate RNG preserves text/generator labels exactly across this catalog augmentation.
    crng=random.Random(seed+271828)
    kinds={}
    names={}
    for asset in row['catalog']['assets']:
        if asset['kind']=='mesh':continue
        role=next((r for r in ('idle','walk','run','sprint','crouch','hit','attack') if r in asset.get('tags',[])),None)
        if role in ('idle','walk','run','sprint','crouch'):
            key=(role,tuple(asset.get('tags',[])))
            kind=kinds.setdefault(key,crng.choice(['sequence','sequence','database']))
            if key not in names:
                variant=asset['tags'][1]
                label=crng.choice([role,role.title(),{'idle':'Idles','walk':'Walk','run':'Run','sprint':'Sprint','crouch':'Crouch'}[role]])
                prefix=crng.choice(['plain','Neutral','Stand']) if variant=='plain' else variant
                names[key]=f'{prefix}_{label}_Loops_{seed}' if crng.random()<.7 else (f'A_FastRun_{seed}' if role=='run' and variant=='plain' else f'A_{prefix}{label}_{seed}')
            asset['name']=names[key]
            asset['kind']=kind
            if kind=='database':asset.pop('loop',None);asset['name']='PSD_Dense_'+asset['name']
        if crng.random()<.7:asset.pop('tags',None)
    clauses=[rng.choice(phr[r]) for r in p['roles']]
    clauses += [rng.choice(phr[r]) for r in p['actions']]
    for key,value in p['policy'].items():clauses.append(rng.choice(phr[value]))
    if p['filters'].get('weapon'):clauses.append(rng.choice(['移动只用持步枪版本','移动动画采用步枪姿态']))
    if p['filters'].get('injured'):clauses.append(rng.choice(['移动采用受伤版本','所有移动使用带伤步态']))
    if p['filters'].get('aim'):clauses.append(rng.choice(['移动保持瞄准版本','移动动画选用瞄准姿态']))
    clauses.append(f"混合时间{p['blend_seconds']}秒")
    if p['reject']=='unsupported':clauses.append('还需要自动实现联机预测与技能冷却')
    rng.shuffle(clauses);row['request']=rng.choice(['请配置：','动作要求：','为角色设置：'])+'；'.join(clauses)
    row['id']=f'formal_{split}_{seed}'
    g,s=convert(row)
    g['messages']=generator_messages(row['request'])+[g['messages'][-1]]
    s['messages']=selector_messages(row['catalog'],row['request'],s['configuration'])+[s['messages'][-1]]
    return g,s

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--train',type=int,default=12000);a=p.parse_args()
    seen={t:set() for t in ('generator','selector')};counts={}
    for split,n,offset in [('train',a.train,300000),('validation',192,600000),('test',192,900000)]:
        outputs={t:[] for t in seen};i=0
        while any(len(v)<n for v in outputs.values()):
            for task,row in zip(outputs,example(offset+i,split)):
                digest=hashlib.sha256(json.dumps(row['messages'][:-1],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
                if digest not in seen[task] and len(outputs[task])<n:outputs[task].append(row);seen[task].add(digest)
            i+=1
        for task,rows in outputs.items():
            out=a.output/task;out.mkdir(parents=True,exist_ok=True)
            (out/(split+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8');counts[task+'/'+split]=len(rows)
    manifest={'counts':counts,'provenance':'Local synthetic MM oracle, dedicated disjoint lexical families. Not human annotated and not downloaded motion data. No generic public JSON mixed into task supervision.','sha256':{str(p.relative_to(a.output)):hashlib.sha256(p.read_bytes()).hexdigest() for p in a.output.rglob('*.jsonl')}}
    (a.output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest))
if __name__=='__main__':main()
