"""Expanded synonym/contrast supervision; V1 validation became development data.
Fresh IDs and reserved wording are used for the next evaluation; no V1 test predictions used.
"""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,hashlib,json,random
from pathlib import Path
from build_formal_split import example as oracle
from split_protocol import generator_messages,selector_messages

def phrases(s):return s.split('|')
TRAIN={
'idle':phrases('待机|站立待命|保持静止|原地站好|不动时放松站立|停止输入后站着|静止站姿|原地等候|停止移动进入待机|站着休息|空闲站立|停下来站稳|原地待命|静止不走动|standing idle|stand still|standing at rest|stationary idle|remain standing without movement'),
'walk':phrases('行走|步行|缓步前进|慢走|普通步幅走路|以步行速度前移|用走的方式移动|低速步行|正常步行|散步前进|慢慢走过去|步行赶路|步行速度移动|walking|walk at normal walking speed|move slowly on foot|a relaxed walking gait'),
'run':phrases('跑步|小跑|常规奔跑|正常跑速前进|以正常速度跑动|用跑的方式赶路|正常慢跑|一般跑步速度|稳定的小跑|跑动前进|普通奔跑|保持慢跑节奏|以跑步速度移动|慢跑赶路|run|jogging|regular running pace|a steady jog|ordinary running gait'),
'sprint':phrases('冲刺|疾跑|全速奔跑|最高速度奔跑|以最高速冲出去|用最大速度跑动|爆发速度冲刺|极速奔跑|全力疾驰|快跑冲刺|高速飞奔|全速赶路|开足速度奔跑|尽最快速度冲向前方|最大跑速|全力冲刺|sprint|dash at top speed|maximum speed running|a full speed burst|run as fast as possible'),
'crouch':phrases('蹲伏移动|蹲着走|低姿态前进|压低身体移动|曲膝低位行进|弯膝保持低位行进|蹲姿行走|保持蹲伏|低位蹲行|下蹲移动|降低身形前移|蹲下来走动|蹲走|crouch walking|move in a crouched stance|knees bent low movement|crouched locomotion'),
'hit':phrases('添加受击反应|被打中时反应|挨打时播放反馈|受到伤害时有反应|角色受创反应|遭受攻击后的反应|被击中的疼痛反馈|承受打击的反应|挨揍后的反应|需要受击片段|taking damage reaction|passive hit reaction|react to being struck'),
'attack':phrases('添加攻击动作|主动进攻|挥击对手|出招攻击|需要攻击片段|加入挥击行为|打击敌人|角色主动出拳|发起一次进攻|执行攻击|主动挥打|攻击对方|需要进攻动画|attack|strike the enemy|perform an attack|offensive strike|throw a punch at an opponent'),
'all':phrases('受击打断所有当前动作|被打中立即中断任何行为|挨打时马上终止一切正在播放的行为|伤害反应抢占全部动作|无论当前做什么受击都先打断|受创时优先取代当前行为|遭受伤害就无条件打断其他动作|受击可以抢占任何动作|受到打击必须立即停止正在做的事|伤害反应最高优先级|正在播放任何行为时受伤都立即打断|受击优先于所有其他动作|hit reactions interrupt everything|damage interrupts any current action|being hit overrides all ongoing actions|hit reaction has highest priority'),
'finished':phrases('攻击必须播完才能退出|进攻动作结束才能切换|出招后完整播放再离开|挥击的片段完整结束才可以离开|攻击动画没完不能切换|进攻片段结束前锁定攻击|一次攻击要完整播放|招式结束以后才允许退出|攻击不可在结束前切走|播放完整攻击后再放行|攻击期间不能主动切换直到播完|攻击锁定到片段结束|attack must finish before exit|lock attack until its clip completes|do not leave attack until playback finishes|an offensive strike must play to completion'),
'previous':phrases('受击结束恢复上一个动作|受击播完继续先前动作|受创反应结束后恢复被打断行为|挨打反馈结束继续之前被打断的行为|受到伤害后反应播完接着刚才的动作|受击后从原位置续播先前行为|伤害反应后继续原动作|受击结束后恢复中断前的行为|受击收尾后接着之前的动作|受击反应完毕恢复之前正在做的事|resume interrupted action after hit|after damage reaction resume previous behavior|continue the prior action after hit finishes'),
'locomotion':phrases('受击结束恢复移动选库|受击播完返回运动匹配|伤害反应结束回到基础移动|挨打反馈完毕交回基础运动匹配|受击结束后重新进行MM选库|受创反应后返回常规移动|受击播放完交回运动匹配系统|受击结束回归移动动画选择|伤害反应结束返回MM|受击反应后恢复基础行走系统|return to locomotion after hit|after hit hand control back to motion matching|resume base movement after damage reaction'),
'block':phrases('冲刺时禁止瞄准|全速跑期间不许瞄准|疾跑时关闭瞄准|最快奔跑时不进入瞄准|冲刺和瞄准互斥|高速冲刺期间不能瞄准|全力奔跑时拒绝瞄准|冲刺模式不允许进入瞄准|跑得最快时不能举枪瞄准|冲刺优先于瞄准|疾驰中不能开启瞄准|block aiming during sprint|sprint and aiming are mutually exclusive|no aiming while sprinting|disable aim in sprint')}
VALID={k:phrases(v) for k,v in {
'idle':'人物没有位移时站着待命|不移动时采用闲置站姿', 'walk':'按正常走路节奏前进|以悠闲步速行进', 'run':'用常规慢跑速度前行|使用普通奔跑步态', 'sprint':'让速度达到最大值疾跑|以极限速度向前冲', 'crouch':'以屈膝蹲姿行进|身体保持低矮姿态走动',
'hit':'呈现被敌人击伤后的反应|人物遭到打击时作出反馈', 'attack':'角色主动打向目标|安排一次向敌人的挥打',
'all':'受伤发生时立即抢占目前的一切行为|被攻击打中时立刻让正在做的事停止', 'finished':'一次攻击播放彻底结束才放开离开权限|发起进攻以后等整段动画结束再切换', 'previous':'伤害反馈播完从断点接回先前行为|挨打表现结束之后接着之前的动作播放', 'locomotion':'伤害反馈完成后交还给运动匹配选动画|被打反应结束交还基础运动系统', 'block':'全力疾跑阶段屏蔽瞄准输入|处于极限跑速模式时不准进入瞄准'}.items()}
TEST={k:phrases(v) for k,v in {
'idle':'留在原处采用休息站姿|停步之后保持站姿等候', 'walk':'用日常走路的速度赶往前方|按日常行走步幅缓慢前移', 'run':'以平常跑步的节奏往前跑|用普通慢跑步态赶往目标', 'sprint':'拿出全部速度飞奔向前|用身体能达到的最快跑速前进', 'crouch':'维持下蹲的姿态往前挪动|把身子压低并弯膝走向目标',
'hit':'添加角色承受敌方伤害后的反馈|角色被击伤时有一个受创表现', 'attack':'让角色向对手主动出招|让人物主动发起打击目标的行为',
'all':'遭到击伤时无条件覆盖任何仍在进行的行为|只要被敌人打中便优先顶替当前正在播放的动作', 'finished':'进攻一旦开始就等完整片段播放结束才允许离开|发起攻击后在动画抵达末尾之前保持锁定', 'previous':'受创表现结束后沿着被打断时的进度接着原动作|被敌人打伤的反馈播放结束再续上先前中断的行为', 'locomotion':'受创表现收尾以后重新交给基础运动匹配来选动作|挨打的反馈片段播放完回到日常移动动画匹配', 'block':'用尽全速跑动的阶段不让瞄准生效|进入最大跑速后屏蔽举枪瞄准'}.items()}

def example(seed,split):
    g,s=oracle(seed,'train');target=g['target'];rng=random.Random(seed+41);pool={'train':TRAIN,'validation':VALID,'test':TEST}[split]
    parts=[rng.choice(pool[r]) for r in target['roles']]
    if 'idle' not in target['roles'] and rng.random()<.25:
        parts.append(rng.choice(['停止移动时使用参考姿势','静止时回到骨架参考姿态','停下来使用绑定姿势'] if split=='train' else ['停止运动后显示网格的参考姿态','没有移动输入时采用绑定参考姿势']))
    policy=target['policy']
    for r in ('hit','attack'):
        implied=(r=='hit' and any(k in policy for k in ('after_hit','hit_interrupts'))) or (r=='attack' and 'attack_exit' in policy)
        if r in target['slots'] and (not implied or rng.random()<.5):parts.append(rng.choice(pool[r]))
    for value in policy.values():parts.append(rng.choice(pool[value]))
    filters=target['filters']
    if filters.get('weapon'):parts.append('所有移动动画使用步枪版本')
    if filters.get('injured'):parts.append('移动片段使用受伤变体')
    if filters.get('aim'):parts.append('移动动画使用瞄准姿态版本')
    if target['reject']:parts.append('额外自动生成联机预测及技能冷却系统')
    parts.append(f"混合时长设为{target['blend_seconds']}秒")
    rng.shuffle(parts);request=rng.choice(['配置需求：','希望角色这样工作：','请安排以下动画配置：'])+'；'.join(parts)
    for row in (g,s):row['request']=request;row['id']=f'semantic_{split}_{seed}';row['source']='semantic_contrast_synthetic_v2'
    g['prompt_version']=2;g['messages']=generator_messages(request,2)+[g['messages'][-1]]
    s['messages']=selector_messages(s['catalog'],request,target)+[s['messages'][-1]]
    return g,s

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();seen={k:set() for k in ('generator','selector')};counts={}
    for split,n,offset in [('train',12000,1200000),('validation',192,1500000),('test',192,1800000)]:
        output={k:[] for k in seen};i=0
        while any(len(v)<n for v in output.values()):
            for task,row in zip(output,example(offset+i,split)):
                digest=hashlib.sha256(json.dumps(row['messages'][:-1],sort_keys=True,ensure_ascii=False).encode()).hexdigest()
                if digest not in seen[task] and len(output[task])<n:seen[task].add(digest);output[task].append(row)
            i+=1
        for task,rows in output.items():
            dest=a.output/task;dest.mkdir(parents=True,exist_ok=True);(dest/(split+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8');counts[task+'/'+split]=len(rows)
    (a.output/'manifest.json').write_text(json.dumps({'counts':counts,'source':'Local synthetic synonyms/contrasts. V1 validation inspected for diagnosis. Fresh phrase families and IDs for V2 validation/test; not human annotated.','sha256':{str(p.relative_to(a.output)):hashlib.sha256(p.read_bytes()).hexdigest() for p in a.output.rglob('*.jsonl')}},ensure_ascii=False,indent=2),encoding='utf-8');print(counts)
if __name__=='__main__':main()
