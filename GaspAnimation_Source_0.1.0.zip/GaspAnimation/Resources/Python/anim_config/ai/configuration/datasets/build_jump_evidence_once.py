"""Single-candidate supervised data. Never reads sealed independent requests."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import sys,json,random,copy,hashlib,re
ROOT=_gasp_workspace
sys.path.insert(0,str(ROOT/'tools/anim_config'))
from jump_evidence_protocol import evidence_messages,compile_evidence,protocol_fingerprint,PROTOCOL
from behavior_requirements import anchor_topology,extraction_messages
OUT=ROOT/'artifacts/anim_config/models/configuration/datasets/jump_evidence_once_v1'

def make_case(index,kind,limit=2,split='train'):
 rng=random.Random(index+817);prefix='j' if split=='train' else 't'
 pool=[c+str(n) for c in ('abcdefghijklmnop' if split=='train' else 'uvwxyz') for n in range(10)]
 ids=rng.sample(pool,9);ground,idle,walk,run,air,rise,fall,counter,unused=ids
 # A few lexical traps; role assignment still comes from explicit prose.
 if index%12==0:ground='AirDeck'+str(index);idle='RisePose'+str(index)
 children=[idle,walk,run];initial=rng.choice(children);ainitial=rng.choice([rise,fall]);order=list(children);rng.shuffle(order)
 records=[]
 def add(key,text):records.append((key,text))
 add('ground',f'{ground} 为父状态，包含 {"、".join(order)}；初始子状态 {initial}，入口 {ground}。')
 pairs=[(idle,'待机'),(walk,'走路'),(run,'跑步')];rng.shuffle(pairs)
 add('locomotion','Motion Matching：'+'，'.join(n+' 表示'+role for n,role in pairs)+'；根据移动输入和步态切换。')
 positive=kind not in ('absent','forbidden')
 if positive:
  achild=[rise,fall];rng.shuffle(achild)
  add('air',f'{air} 为父状态，包含 {"、".join(achild)}；初始子状态 {ainitial}。')
  add('roles',f'{rise} 负责上升，{fall} 负责下降，用实际垂直速度切换。')
  add('counter',rng.choice([f'内部跳跃计数 {counter} 初始0。',f'把内部整数 {counter} 的初始值设为0。']))
  add('trigger',rng.choice(['跳跃输入到来时请求起跳。','玩家按下跳跃按键时处理跳跃请求。','收到 Jump 输入事件时检查是否允许起跳。']))
  add('limit',f'只有 {counter} < {limit} 才允许实际起跳，一个落地周期最多成功{limit}次。')
  add('launch',rng.choice(['通过次数条件后执行真正起跳。','仅在允许跳跃时执行实际起跳动作。']))
  delta=2 if kind=='unsupported_count' else 1
  add('count',f'只有成功起跳才将计数加{delta}，拒绝的按键不计数。')
  if kind!='missing_reset':add('reset',f'真正落地时把 {counter} 清零为0，并返回 {ground}。')
  if kind=='conflict':add('conflict',f'同一计数 {counter} 的唯一上限又必须为{limit+1}，只能按 {counter} < {limit+1} 执行；它与上面的唯一上限都不可覆盖，且没有优先规则。')
  if index%3==0 or kind=='limited_extra':add('negative',f'允许的{limit}次成功起跳用完以后，禁止额外跳跃；不要取消这{limit}次允许的起跳。')
 elif kind=='forbidden':add('negative',rng.choice(['完全不允许跳跃，禁止所有起跳，不配置空中组或跳跃计数。','所有跳跃都禁止：跳跃按键不得触发起跳，不创建跳跃流程。','本次只要地面移动，明确禁止任何实际跳跃。']))
 else:add('negative',rng.choice(['没有跳跃需求，不配置空中组、跳跃计数或起跳动作。','本次没有请求跳跃，只保留上述地面状态。','不需要跳跃，也没有攻击、连招或受击。']))
 add('no_combat','不配置攻击、连招或受击。')
 # Shuffle macro sections, not just child identifiers.
 rng.shuffle(records);lines=[text for key,text in records];positions={key:i for i,(key,text) in enumerate(records)}
 request='\n'.join(lines)
 groups=[dict(id=ground,children=children,initial=initial,source_lines=[positions['ground']])]
 if positive:groups.append(dict(id=air,children=[rise,fall],initial=ainitial,source_lines=[positions['air']]))
 reviewed=dict(version=1,topology=dict(entry=ground,groups=groups,standalone=[]),locomotion=dict(group=ground,idle=idle,walk=walk,run=run))
 def fact(key,**extra):return dict(line=positions[key],quote=lines[positions[key]],**extra)
 ev=dict(status='required' if positive else kind,trigger=None,launch=None,successful_count=None,landing_reset=None,limit=None,counter=None,states=[],negative_constraints=[])
 if positive:
  ev.update(trigger=fact('trigger',event='Jump'),launch=fact('launch',kind='jump'),successful_count=fact('count',value=delta,timing='successful_launch_only'),landing_reset=None if kind=='missing_reset' else fact('reset',value=0,event='landed'),limit=None if kind=='conflict' else fact('limit',value=limit),counter=fact('counter',id=counter,initial=0),states=[fact('air',id=air,role='air_group'),fact('roles',id=rise,role='rising'),fact('roles',id=fall,role='falling')])
  if kind=='conflict':ev['status']='unclear'
 if 'negative' in positions:ev['negative_constraints']=[fact('negative',scope='beyond_limit' if positive else 'all_jumps' if kind=='forbidden' else 'other')]
 should_reject=kind in ('missing_reset','conflict','unsupported_count')
 try:policy=compile_evidence(ev,request,reviewed)
 except ValueError:
  if not should_reject:raise
  policy=None
 else:
  if should_reject:raise AssertionError('Bad gold evidence accepted')
 schema,messages=evidence_messages(request,reviewed)
 target=ev
 return dict(id=f'{split}_{index}_jump_evidence',stage='jump_evidence',request=request,reviewed=reviewed,schema=schema,target=target,messages=messages+[dict(role='assistant',content=json.dumps(target,ensure_ascii=False,separators=(',',':')))],stratum=kind+(('_'+str(limit)) if positive else ''),expected_policy=policy,expected_reject=should_reject)

def legacy_evidence(chunk):
 row=next(r for r in chunk if r['stage']=='jump');request=row['request'];reviewed=copy.deepcopy(row['reviewed']);jump=row['target']['policy'];lines=request.splitlines()
 def locate(pattern,**extra):
  for i,line in enumerate(lines):
   match=re.search(pattern,line)
   if match:return dict(line=i,quote=match.group(0),**extra)
  raise ValueError('No source evidence: '+pattern)
 ev=dict(status='required' if jump else 'absent',trigger=None,launch=None,successful_count=None,landing_reset=None,limit=None,counter=None,states=[],negative_constraints=[])
 if jump:
  counter=re.escape(jump['counter'])
  ev.update(trigger=locate(r'响应跳跃',event='Jump'),launch=locate(r'执行实际起跳',kind='jump'),successful_count=locate(r'允许时同时执行实际起跳和计数加1',value=1,timing='successful_launch_only'),landing_reset=locate(r'落地必须清零',value=0,event='landed'),limit=locate(counter+r'\s*<\s*'+str(jump['max_jumps']),value=jump['max_jumps']),counter=locate(r'内部变量\s+'+counter+r'\s+初始为0',id=jump['counter'],initial=0))
  g=next(g for g in reviewed['topology']['groups'] if g['id']==jump['group']);line=g['source_lines'][0]
  ev['states']=[dict(line=line,quote=lines[line],id=jump['group'],role='air_group'),locate(r'上升使用\s+'+re.escape(jump['rise']),id=jump['rise'],role='rising'),locate(r'下降使用\s+'+re.escape(jump['fall']),id=jump['fall'],role='falling')]
 else:
  negative=next((dict(line=i,quote=line,scope='other') for i,line in enumerate(lines) if '不需要空中' in line or '不配置空中' in line),None)
  if negative:ev['negative_constraints']=[negative]
 policy=compile_evidence(ev,request,reviewed)
 if policy!=jump:raise AssertionError('Legacy evidence does not preserve its label')
 schema,messages=evidence_messages(request,reviewed)
 return dict(id='evidence_'+row['id'],stage='jump_evidence',request=request,reviewed=reviewed,schema=schema,target=ev,messages=messages+[dict(role='assistant',content=json.dumps(ev,ensure_ascii=False,separators=(',',':')))],stratum='legacy_evidence_positive' if jump else 'legacy_evidence_absent',expected_policy=policy,expected_reject=False)


def main():
 OUT.mkdir(parents=True,exist_ok=True)
 data=[];index=0
 for limit in (1,2,3,4):
  for n in range(48):data.append(make_case(index,'limited_extra' if n%2 else 'required',limit));index+=1
 for kind,count in [('absent',48),('forbidden',48),('missing_reset',16),('conflict',16),('unsupported_count',8)]:
  for n in range(count):data.append(make_case(index,kind,(n%4)+1));index+=1
 # Original six tasks are replayed from training data only, with all shapes.
 legacy_path=ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v5/train.jsonl'
 legacy=[json.loads(line) for line in legacy_path.read_text(encoding='utf-8').splitlines() if line.strip()]
 full=[legacy[i:i+6] for i in range(0,128*6,6)];small=[legacy[i:i+6] for i in range(128*6,(128+128)*6,6)]
 selected=[full[i*4+1] for i in range(32)]+[small[i] for i in range(32)]
 for chunk in selected:
  data.append(legacy_evidence(chunk))
  for row in chunk:
   row=copy.deepcopy(row);row['id']='legacy_'+row['id'];row['stratum']='legacy_'+row['stage']
   row['schema'],fresh_messages=extraction_messages(row['stage'],row['request'],row['reviewed'])
   row['messages']=fresh_messages+[dict(role='assistant',content=json.dumps(row['target'],ensure_ascii=False,separators=(',',':')))]
   data.append(row)
 path=OUT/'train.jsonl';path.write_text('\n'.join(json.dumps(row,ensure_ascii=False) for row in data)+'\n',encoding='utf-8')
 # Representative labels for individual source/semantic review, no sealed data.
 representative=[]
 for limit in (1,2,3,4):
  representative.append(next(r for r in data if r['stratum']=='required_'+str(limit)))
 for kind in ['limited_extra','absent','forbidden','missing_reset','conflict','unsupported_count','legacy_evidence_positive','legacy_evidence_absent']:
  representative.append(next(r for r in data if r['stratum']==kind or r['stratum'].startswith(kind+'_')))
 (OUT/'representative_review.json').write_text(json.dumps(representative,ensure_ascii=False,indent=2),encoding='utf-8')
 manifest=dict(protocol=PROTOCOL,protocol_sha256=protocol_fingerprint(),train_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),evidence_rows=sum(r['stage']=='jump_evidence' for r in data),legacy_rows=sum(r['stage']!='jump_evidence' for r in data),total_rows=len(data),epochs=2,accum=2,planned_presentations=len(data)*2,planned_steps=len(data),seed=417,sealed_cases_read=False,base_unchanged=True)
 (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 print(json.dumps(manifest))
if __name__=='__main__':main()
