"""Long Chinese/English extraction coverage; v1 test is now regression only.

The user's original request is explicitly a development training sample. Fresh
test templates 7/8 and fresh state IDs are never added to training.
"""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import sys,json,copy,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from behavior_requirements import extraction_messages,prompt_fingerprint,anchor_topology
from build_behavior_requirements_data import example

ROOT=_gasp_workspace
OUT=ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v2_clean'


def staged(request,targets,case_id):
    reviewed=dict(version=1);result=[]
    for stage in ('topology','locomotion','jump','combo','dependencies','settings'):
        schema,messages=extraction_messages(stage,request,copy.deepcopy(reviewed));target=targets[stage]
        result.append(dict(id=f'{case_id}_{stage}',stage=stage,request=request,reviewed=copy.deepcopy(reviewed),schema=schema,target=copy.deepcopy(target),messages=messages+[dict(role='assistant',content=json.dumps(target,ensure_ascii=False,separators=(',',':')))]))
        if stage=='topology':
            declared={n for g in target['groups'] for n in [g['id']]+g['children']}
            reviewed['topology']=dict(copy.deepcopy(target),standalone=[] if target['entry'] in declared else [target['entry']])
        elif stage in ('locomotion','jump','combo'):
            reviewed[stage]=copy.deepcopy(target['policy'])
            if stage=='combo' and target['policy']:reviewed['topology']['standalone']=sorted(set(reviewed['topology']['standalone'])|set(target['policy']['attacks']+[target['policy']['hit']]))
        elif stage=='dependencies':reviewed.update(copy.deepcopy(target))
    return result


def long_example(index,style):
    base=example(index,style if style<7 else 0 if style==7 else 2)
    targets={row['stage']:copy.deepcopy(row['target']) for row in base};lines=base[0]['request'].splitlines()
    loc=targets['locomotion']['policy'];jump=targets['jump']['policy'];combo=targets['combo']['policy']
    text=[]
    for line in lines:
        if line.startswith('Use Motion Matching:'):line=f"{loc['idle']} 是待机，{loc['walk']} 是走路，{loc['run']} 是跑步，内部均使用MM；按移动输入和步态选择，停止时返回待机。"
        if line.startswith('Jump counter '):line=f"最多允许{jump['max_jumps']}次起跳，内部变量 {jump['counter']} 初始为0。只有 {jump['counter']} < {jump['max_jumps']} 才响应跳跃；允许时同时执行实际起跳和计数加1，落地必须清零。依据垂直速度选择上升或下降状态。"
        if line.startswith('Attack combo order:'):line=f"连招依次经过 {' → '.join(combo['attacks'])}；受击使用 {combo['hit']}。内部缓存 {combo['buffer']} 初始false。"
        if line.startswith('Only queue one Attack'):
            if len(combo['attacks'])==1:line=f"这是单段攻击，完整播放后返回 {loc['group']}，不缓存后续攻击输入。进入、退出或受击时清空 {combo['buffer']}。受击结束按真实地面/空中状态恢复，不续接攻击。"
            else:line=f"每个非末段仅在连招窗口内缓存一次攻击输入；重复按键不能反复缓存。完成时有缓存才进入下一段，否则返回 {loc['group']}。进入下一段、退出攻击或受击打断均清空 {combo['buffer']}。受击结束按真实地面/空中状态恢复，不续接攻击。"
        if line.startswith('Blends in seconds:'):line='普通移动切换混合0.2秒；进入攻击0.1秒；进入受击0.05秒。'
        if style in (7,8):
            for group in targets['topology']['groups']:
                if group['id'] in line and all(child in line for child in group['children']) and not line.startswith('Use '):
                    if style==7:line=f"请建立 {group['id']} 这个父节点，{'、'.join(reversed(group['children']))} 是它的直接子状态；启动该组时进入 {group['initial']}。"
                    else:line=f"{group['id']} owns {', '.join(group['children'])} as immediate children, starting at {group['initial']}."
                    if group['id']==loc['group']:line+=f" 整体入口为 {loc['group']}。"
                    break
        text.append(line)
    prefix=['请根据本次选中的同骨架资源生成可编辑状态机。','先审阅动作流程，不要因缺素材而漏掉要求的状态。','外部数据若已有原生接口应读取真实接口，否则声明变量、初始值和待接入来源。']
    prefix+=['配置需求如下：']*(index%4)
    if not jump:text.append('不需要空中分组或多段跳，不要添加未请求的空中状态。')
    if not combo:text.append('本次不配置攻击、连招或受击，但仍须保留已请求的地面和跳跃流程。')
    suffix=['缺少动画或接口时明确报告，不得把初始值当作已绑定。','不要用无条件赋值或自跳转冒充窗口内输入缓存。','没有确认战斗素材时阻断应用；素材缺口不表示不需要动作流程。','输出前检查状态是否完整、引用是否存在、计数及缓存是否正确清零。']
    request='\n'.join(prefix+text+suffix)
    targets['topology']=anchor_topology(targets['topology'],request)
    return staged(request,targets,index)


def original_development():
    request=(ROOT/'artifacts/anim_config/verification/behavior_repair/request.txt').read_text(encoding='utf-8-sig')
    topology=anchor_topology(dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run'],initial='Idle',source_lines=[]),dict(id='Air',children=['Rise','Fall'],initial='Rise',source_lines=[])]),request)
    targets=dict(topology=topology,locomotion=dict(policy=dict(group='Ground',idle='Idle',walk='Walk',run='Run')),jump=dict(policy=dict(group='Air',rise='Rise',fall='Fall',counter='JumpCount',max_jumps=2)),combo=dict(policy=dict(attacks=['Attack1','Attack2'],hit='Hit',buffer='Queued')),dependencies=dict(external_variables=[],unsupported=[]),settings=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=None,window_end=None,jump_velocity=None))
    return staged(request,targets,'original_development')


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    manifest=dict(protocol='requirement_ir_v1',prompt_sha256=prompt_fingerprint(),original_request_in_training=True,v1_test_status='development_regression_after_observation',fresh_test_templates=[7,8],validation_status='development wording overlaps training; IDs disjoint',single_attack_semantics='no successor, no queued input',note='Bounded synthetic policies, not arbitrary-language or animation-content proof',splits={})
    for split,count,start,styles in [('train',196,30000,list(range(7))),('validation',8,40000,[4]),('test',16,50000,[7,8])]:
        data=[row for i in range(count) for row in long_example(start+i,styles[i%len(styles)])]
        if split=='train':data+=original_development()
        path=OUT/(split+'.jsonl');path.write_text('\n'.join(json.dumps(row,ensure_ascii=False) for row in data)+'\n',encoding='utf-8')
        manifest['splits'][split]=dict(requests=count+(split=='train'),rows=len(data),templates=styles,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest,ensure_ascii=False))

if __name__=='__main__':main()
