"""Independent structural/resource and split-integrity audit, no model inference."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import json,hashlib
from pathlib import Path
from flow_protocol import validate_ir,compile_flow
import config_tool
ROOT=_LAYOUT_REPO;DATA=ROOT/'artifacts/anim_config/models/configuration/datasets/flow_v2/data'
def main():
 split_rows={s:[json.loads(x) for x in (DATA/(s+'.jsonl')).read_text(encoding='utf-8').splitlines()] for s in ('train','validation','test')}
 prompts={};audit={};previous=set()
 for split,rows in split_rows.items():
  ids=set();digests=set();domain=blocked=basic=0
  for row in rows:
   if row['id'] in ids:raise RuntimeError('Duplicate ID '+row['id'])
   ids.add(row['id']);prompt=json.dumps(row['messages'][:-1],sort_keys=True,ensure_ascii=False);digests.add(hashlib.sha256(prompt.encode()).hexdigest())
   if row.get('source')!='synthetic_mm_flow_oracle_v2':continue
   domain+=1;p=row['target'];validate_ir(row['catalog'],p)
   plan=compile_flow(row['catalog'],row['request'],'/Game/Audit',p,{})
   errors=config_tool.validate(plan,row['catalog'])
   complex_flow=bool(p['filters'] or p['actions'] or p['policy'])
   if complex_flow:
    if not any(i.get('code')=='flow_runtime_unavailable' for i in plan['issues']):raise RuntimeError('Complex plan escaped capability gate')
    blocked+=1
   elif p['reject'] is None:
    if errors:raise RuntimeError('Basic oracle plan failed validation: '+str(errors))
    basic+=1
  overlap=digests & previous
  if overlap:raise RuntimeError('Train/validation/test prompt overlap')
  previous|=digests;prompts[split]=digests;audit[split]={'rows':len(rows),'domain':domain,'complex_gated':blocked,'basic_applicable':basic,'exact_prompt_overlap':0}
 (DATA/'audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8');print(json.dumps(audit),flush=True)
if __name__=='__main__':main()
