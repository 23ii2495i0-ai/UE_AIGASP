"""Edit SETTINGS or pass --config / --task, then run with the training Python."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import argparse
import hashlib
import json
import os
import random
import sys
import time
from pathlib import Path

ROOT=_gasp_workspace

from split_protocol import score, validate_generator, merge

# Relative paths resolve against THIS file, not the current terminal directory.
SETTINGS={
    'task':'both',  # generator / selector / both
    'base_model':'artifacts/anim_config/models/configuration/base_model',
    'output_dir':'artifacts/anim_config/models/configuration/runs/custom_split_v1',
    'tasks':{
        'generator':{'train':'artifacts/anim_config/models/configuration/datasets/formal_split_v1/data/generator/train.jsonl',
                     'validation':'artifacts/anim_config/models/configuration/datasets/formal_split_v1/data/generator/validation.jsonl',
                     'test':'artifacts/anim_config/models/configuration/datasets/formal_split_v1/data/generator/test.jsonl'},
        'selector':{'train':'artifacts/anim_config/models/configuration/datasets/formal_split_v1/data/selector/train.jsonl',
                    'validation':'artifacts/anim_config/models/configuration/datasets/formal_split_v1/data/selector/validation.jsonl',
                    'test':'artifacts/anim_config/models/configuration/datasets/formal_split_v1/data/selector/test.jsonl'}},
    'steps':2000, 'learning_rate':0.0002, 'batch_size':2,
    'gradient_accumulation':4, 'max_length':1536, 'seed':42,
    'lora_rank':16, 'lora_alpha':32, 'lora_dropout':0.05,
    'target_modules':['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj'],
    'save_steps':60, 'eval_steps':60, 'keep_checkpoints':3,
    'warmup_ratio':0.05, 'weight_decay':0.01,
    'max_new_tokens':512, 'evaluation_limit':0, 'evaluation_batch_size':4, # limit 0 = all examples
    'resume':False, # True = latest FULL Trainer checkpoint per task
}

def path(value):
    p=Path(value);return p if p.is_absolute() else ROOT/p

def rows(filename,task):
    result=[]
    for n,line in enumerate(path(filename).read_text(encoding='utf-8-sig').splitlines(),1):
        if not line.strip():continue
        r=json.loads(line)
        if r.get('task')!=task or not r.get('messages') or r['messages'][-1]['role']!='assistant':
            raise ValueError(f'{filename}:{n}: task/messages mismatch')
        if json.loads(r['messages'][-1]['content'])!=r['target']:raise ValueError('Assistant and target disagree')
        if task=='generator':validate_generator(r['target'])
        else:merge(r['catalog'],r['configuration'],r['target'])
        expected = __import__('split_protocol').generator_messages(r['request'],r.get('prompt_version',1)) if task=='generator' else __import__('split_protocol').selector_messages(r['catalog'],r['request'],r['configuration'])
        if r['messages'][:-1]!=expected:raise ValueError(f'{filename}:{n}: input violates isolated task contract')
        result.append(r)
    if not result:raise ValueError(f'Empty data: {filename}')
    return result

def prepare(c,task):
    if task not in ('generator','selector'):raise ValueError('Unknown task')
    datasets={k:rows(v,task) for k,v in c['tasks'][task].items() if k in ('train','validation','test') and v}
    if not {'train','validation'}<=datasets.keys():raise ValueError('Train and validation required')
    if len({r.get('prompt_version',1) for items in datasets.values() for r in items})!=1:raise ValueError('Each task must use one consistent prompt version')
    seen=set()
    for split,data in datasets.items():
        current={json.dumps(r['messages'][:-1],sort_keys=True,ensure_ascii=False) for r in data}
        if seen&current:raise ValueError(f'{task}: overlapping prompts at {split}')
        seen|=current
    return datasets

def run(c,task,data):
    started=time.monotonic()
    os.environ.setdefault('PYTORCH_CUDA_ALLOC_CONF',c.get('cuda_allocator_config','garbage_collection_threshold:0.75,max_split_size_mb:128'))
    import torch
    from transformers import AutoTokenizer,AutoModelForCausalLM,Trainer,TrainingArguments
    from transformers.trainer_utils import get_last_checkpoint
    from peft import LoraConfig,get_peft_model,PeftModel
    out=path(c['output_dir']) if c.get('output_is_task_directory') else path(c['output_dir'])/task
    checkpoint=get_last_checkpoint(str(out)) if out.exists() else None
    completed_step=json.loads((Path(checkpoint)/'trainer_state.json').read_text(encoding='utf-8'))['global_step'] if checkpoint else 0
    if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required; use .anim_model_env/Scripts/python.exe')
    random.seed(c['seed']);torch.manual_seed(c['seed'])
    tokenizer=AutoTokenizer.from_pretrained(path(c['base_model']),local_files_only=True,trust_remote_code=False)
    tokenizer.pad_token=tokenizer.eos_token
    encoded={}
    for split,items in data.items():
        encoded[split]=[]
        for r in items:
            prefix=tokenizer.apply_chat_template(r['messages'][:-1],tokenize=True,add_generation_prompt=True)
            full=tokenizer.apply_chat_template(r['messages'],tokenize=True)
            if len(full)>c['max_length'] or full[:len(prefix)]!=prefix or len(full)<=len(prefix):
                raise ValueError(f"{task}/{split}/{r['id']}: sequence too long or incompatible chat template; increase max_length")
            encoded[split].append({'input_ids':full,'attention_mask':[1]*len(full),'labels':[-100]*len(prefix)+full[len(prefix):]})
    dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    model=AutoModelForCausalLM.from_pretrained(path(c['base_model']),local_files_only=True,trust_remote_code=False,torch_dtype=dtype,attn_implementation='sdpa')
    initial=c.get('initial_adapters',{}).get(task)
    if initial:
        inherited=json.loads((path(initial)/'adapter_config.json').read_text(encoding='utf-8'))
        if any(inherited[k]!=c[key] for k,key in [('r','lora_rank'),('lora_alpha','lora_alpha'),('lora_dropout','lora_dropout')]) or set(inherited['target_modules'])!=set(c['target_modules']):
            raise ValueError('Initial adapter LoRA rank/alpha/dropout/modules must match settings')
    if initial:model=PeftModel.from_pretrained(model,path(initial),is_trainable=True) # Full resume subsequently restores its newer checkpoint.
    else:model=get_peft_model(model,LoraConfig(r=c['lora_rank'],lora_alpha=c['lora_alpha'],lora_dropout=c['lora_dropout'],target_modules=c['target_modules'],task_type='CAUSAL_LM',bias='none'))
    model.config.use_cache=False;model.enable_input_require_grads()
    if c['resume'] and checkpoint is None:raise ValueError(f'No full checkpoint to resume: {out}')
    manifest={'task':task,'protocol':'generator_selector_v1','settings':c,'files':{k:{'path':str(path(v)),'sha256':hashlib.sha256(path(v).read_bytes()).hexdigest()} for k,v in c['tasks'][task].items() if v},'counts':{k:len(v) for k,v in data.items()}}
    if initial:manifest['initial_adapter_sha256']=hashlib.sha256((path(initial)/'adapter_model.safetensors').read_bytes()).hexdigest()
    manifest_path=out/'run_manifest.json'
    if manifest_path.exists():
        previous=json.loads(manifest_path.read_text(encoding='utf-8'))
        comparable=lambda m:{k:v for k,v in m['settings'].items() if k not in ('resume','task','evaluation_limit','evaluation_batch_size','max_new_tokens')}
        if not c['resume']:raise ValueError(f'Existing run; choose a new output_dir or resume: {out}')
        if previous['files']!=manifest['files'] or comparable(previous)!=comparable(manifest):raise ValueError('Resume data/settings changed; use a new output directory')
        if previous.get('initial_adapter_sha256')!=manifest.get('initial_adapter_sha256'):raise ValueError('Initial adapter provenance changed')
    out.mkdir(parents=True,exist_ok=True);manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    def collate(batch):
        length=max(len(r['input_ids']) for r in batch)
        multiple=c.get('pad_to_multiple_of',64)
        length=((length+multiple-1)//multiple)*multiple
        return {key:torch.tensor([r[key]+[(-100 if key=='labels' else tokenizer.pad_token_id if key=='input_ids' else 0)]*(length-len(r[key])) for r in batch]) for key in ('input_ids','attention_mask','labels')}
    args=TrainingArguments(output_dir=str(out),max_steps=c['steps'],learning_rate=c['learning_rate'],per_device_train_batch_size=c['batch_size'],per_device_eval_batch_size=1,gradient_accumulation_steps=c['gradient_accumulation'],warmup_ratio=c['warmup_ratio'],weight_decay=c['weight_decay'],lr_scheduler_type='cosine',save_steps=c['save_steps'],eval_strategy='steps',eval_steps=c['eval_steps'],save_total_limit=c['keep_checkpoints'],logging_steps=10,report_to=[],bf16=dtype==torch.bfloat16,fp16=dtype==torch.float16,gradient_checkpointing=True,gradient_checkpointing_kwargs={'use_reentrant':False},seed=c['seed'],data_seed=c['seed'],dataloader_num_workers=0,save_safetensors=True,torch_empty_cache_steps=c.get('empty_cache_steps',10))
    from assistant_loss import assistant_inputs
    class AssistantTrainer(Trainer):
        def compute_loss(self,model,inputs,return_outputs=False,num_items_in_batch=None):
            if c.get('assistant_only_logits',True) and model.config.model_type=='qwen2':inputs=assistant_inputs(inputs)
            return super().compute_loss(model,inputs,return_outputs=return_outputs,num_items_in_batch=num_items_in_batch)
    trainer=AssistantTrainer(model=model,args=args,train_dataset=encoded['train'],eval_dataset=encoded['validation'],data_collator=collate)
    if c['resume'] and completed_step>=c['steps']:
        # Restore weights for interrupted post-training evaluation without taking another optimizer step.
        from peft import load_peft_weights,set_peft_model_state_dict
        set_peft_model_state_dict(model,load_peft_weights(checkpoint))
        print('TRAINING_ALREADY_COMPLETE: evaluating saved checkpoint',task,completed_step,flush=True)
    else:trainer.train(resume_from_checkpoint=checkpoint if c['resume'] else None)
    trainer.save_model(str(out/'adapter'));tokenizer.save_pretrained(out/'adapter')
    versions={r.get('prompt_version',1) for split in data.values() for r in split}
    if len(versions)!=1:raise ValueError('Mixed prompt versions in a task')
    (out/'adapter/prompt_config.json').write_text(json.dumps({'task':task,'prompt_version':versions.pop(),'system_prompt_sha256':hashlib.sha256(data['train'][0]['messages'][0]['content'].encode()).hexdigest()}),encoding='utf-8')
    training_report={'task':task,'optimizer_steps':max(completed_step,trainer.state.global_step),'start_step':completed_step if c['resume'] else 0,'full_checkpoint_resume':bool(c['resume'] and completed_step<c['steps']),'training_examples':len(data['train']),'effective_batch':c['batch_size']*c['gradient_accumulation'],'session_seconds_before_generation_eval':time.monotonic()-started,'peak_allocated_gpu_mb':torch.cuda.max_memory_allocated()/2**20,'cuda_allocator_config':os.environ.get('PYTORCH_CUDA_ALLOC_CONF'),'empty_cache_steps':c.get('empty_cache_steps',10),'pad_to_multiple_of':c.get('pad_to_multiple_of',64),'adapter_sha256':hashlib.sha256((out/'adapter/adapter_model.safetensors').read_bytes()).hexdigest()}
    (out/'training_report.json').write_text(json.dumps(training_report,indent=2),encoding='utf-8')
    model.eval();model.gradient_checkpointing_disable();model.config.use_cache=True
    for split in ('validation','test'):
        if split not in data:continue
        items=data[split][:c['evaluation_limit']] if c['evaluation_limit'] else data[split]
        results=[]
        batch_size=c.get('evaluation_batch_size',4)
        for start in range(0,len(items),batch_size):
            batch=items[start:start+batch_size]
            prompts=[tokenizer.apply_chat_template(row['messages'][:-1],add_generation_prompt=True,tokenize=True) for row in batch]
            width=max(map(len,prompts))
            inp=torch.tensor([[tokenizer.eos_token_id]*(width-len(p))+p for p in prompts],device=model.device)
            mask=torch.tensor([[0]*(width-len(p))+[1]*len(p) for p in prompts],device=model.device)
            with torch.inference_mode():tokens=model.generate(inp,attention_mask=mask,max_new_tokens=c['max_new_tokens'],do_sample=False,pad_token_id=tokenizer.eos_token_id)
            for row,token in zip(batch,tokens):
                raw=tokenizer.decode(token[width:],skip_special_tokens=True)
                try:metrics=score(task,row,json.loads(raw));metrics['json_valid']=True
                except (ValueError,TypeError,KeyError):metrics={'json_valid':False,'protocol_valid':False,'exact':False}
                results.append({'id':row['id'],'raw':raw,**metrics})
            print('GENERATIVE_EVAL',task,split,len(results),'/',len(items),flush=True)
        keys=set().union(*(r.keys() for r in results))-{'id','raw'}
        report={'task':task,'n':len(results),'batch_size':batch_size,'adapter_sha256':training_report['adapter_sha256'],'metrics':{k:sum(bool(r.get(k)) for r in results)/len(results) for k in keys},'cases':results}
        (out/(split+'_metrics.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(task,split,report['metrics'],flush=True)
    del trainer,model
    import gc
    gc.collect();torch.cuda.empty_cache()

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',help='Complete JSON settings, same structure as SETTINGS');p.add_argument('--task',choices=['generator','selector','both']);p.add_argument('--check',action='store_true',help='Validate datasets without loading GPU/model');p.add_argument('--write-config',help='Export editable default settings JSON');a=p.parse_args()
    if a.write_config:path(a.write_config).write_text(json.dumps(SETTINGS,ensure_ascii=False,indent=2),encoding='utf-8');return
    # Double-click/system Python launches the project's prepared training environment.
    training_python=ROOT/'.anim_model_env/Scripts/python.exe'
    if not a.check and os.environ.get('GASP_AI_USE_CURRENT_PYTHON')!='1' and training_python.exists() and Path(sys.executable).resolve()!=training_python.resolve():
        import subprocess
        raise SystemExit(subprocess.call([str(training_python),str(Path(__file__).resolve()),*sys.argv[1:]]))
    c=json.loads(path(a.config).read_text(encoding='utf-8-sig')) if a.config else SETTINGS.copy()
    if a.task:c['task']=a.task
    if c['task'] not in ('generator','selector','both'):raise ValueError('Invalid task')
    for key in ('steps','batch_size','gradient_accumulation','max_length','save_steps','eval_steps','keep_checkpoints','max_new_tokens','lora_rank','lora_alpha'):
        if type(c[key]) is not int or c[key]<=0:raise ValueError(f'{key} must be a positive integer')
    if c['learning_rate']<=0 or not 0<=c['lora_dropout']<1 or not 0<=c['warmup_ratio']<=1 or c['evaluation_limit']<0 or type(c.get('evaluation_batch_size',4)) is not int or c.get('evaluation_batch_size',4)<1:raise ValueError('Invalid training parameters')
    if type(c.get('pad_to_multiple_of',64)) is not int or c.get('pad_to_multiple_of',64)<1 or c['max_length']%c.get('pad_to_multiple_of',64):raise ValueError('max_length must be divisible by positive pad_to_multiple_of')
    os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
    tasks=('generator','selector') if c['task']=='both' else (c['task'],)
    prepared={t:prepare(c,t) for t in tasks}
    for task,data in prepared.items():
        print(task,{k:len(v) for k,v in data.items()},flush=True)
        if not a.check:run(c,task,data)
if __name__=='__main__':main()
