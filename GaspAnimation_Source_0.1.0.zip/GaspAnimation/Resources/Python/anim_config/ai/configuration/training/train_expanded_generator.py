"""Train an isolated expanded-slot adapter with replay; no automatic promotion."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from project_paths import REPO,configure_imports
configure_imports()
import argparse,hashlib,json,random,time
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
from peft import PeftModel
from split_protocol import generator_messages,selector_messages,validate_generator,score
from assistant_loss import assistant_inputs

ROOT=REPO/'artifacts/anim_config/models/configuration'
ROLES=['idle','walk','run','sprint','crouch']
ACTIONS=['hit','attack','jump','dodge']
PHRASES={
 'train':[['待机','idle','idle pose','静止站立'],['走路','walk'],['跑步','run'],['冲刺','sprint'],['蹲伏','crouch'],['受击','hit','damage response','hit reaction'],['攻击','attack'],['跳跃','jump'],['闪避翻滚','dodge','roll','evade']],
 'test':[['原地待命','idle animation'],['步行','walking'],['小跑','running'],['全速疾跑','sprinting'],['蹲着走','crouching'],['被击中反应','damage reaction'],['挥击动作','attacking'],['起跳','jumping'],['躲闪','evasive roll']],
}

def examples(split,n):
    rng=random.Random(1021 if split=='train' else 2021);rows=[]
    for i in range(n):
        selected=[r for r in ROLES+ACTIONS if rng.random()<.65]
        if not set(selected)&set(ROLES):selected.insert(0,'run')
        target=dict(roles=[r for r in ROLES if r in selected],slots={r:'locomotion' if r in ROLES else 'action' for r in ROLES+ACTIONS if r in selected},blend_seconds=.2,filters={},policy={},reject=None)
        clauses=[rng.choice(PHRASES[split][(ROLES+ACTIONS).index(r)]) for r in selected]
        if 'hit' in selected and rng.random()<.4:
            clauses.append('受击打断所有动作，受击结束返回移动')
            target['policy']={'hit_interrupts':'all','after_hit':'locomotion'}
        rng.shuffle(clauses)
        request=('配置：' if i%2 else '角色需要：')+'、'.join(clauses)
        rows.append(dict(id=f'expanded_{split}_{i}',request=request,target=target))
    return rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--steps',type=int,default=160);p.add_argument('--task',choices=['generator','selector'],default='generator');p.add_argument('--evaluate-only',action='store_true');a=p.parse_args()
    torch.set_num_threads(4);torch.manual_seed(42);rng=random.Random(42)
    run=ROOT/'runs/expanded_slots_v3';out=run/a.task;out.mkdir(parents=True,exist_ok=True)
    train=examples('train',600);test=examples('test',100)
    if a.task=='selector':
        for row in train+test:
            configuration=row['target']
            assets=[dict(id='/Game/Mesh',name='Mesh',kind='mesh',skeleton='Rig')]
            for role in ROLES+ACTIONS:
                assets.append(dict(id='/Game/'+role,name=role+'_Animation',kind='sequence',skeleton='Rig',loop=role in ROLES))
            rng.shuffle(assets)
            row['catalog']=dict(version=1,assets=assets);row['configuration']=configuration
            bindings={r:'a'+str(next(i for i,v in enumerate(assets) if v['id']=='/Game/'+r)) for r in configuration['slots']}
            row['target']=dict(bindings=bindings,issues={})
    # Replay established filters/policies, keeping resource availability independent.
    replay=ROOT/('datasets/semantic_split_v2/data/'+a.task)
    for split,rows,n in [('train',train,300),('test',test,40)]:
        old=[json.loads(x) for x in (replay/(split+'.jsonl')).read_text(encoding='utf-8').splitlines() if x.strip()]
        rows.extend(rng.sample(old,min(n,len(old))))
        (out/(split+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
    tokenizer=AutoTokenizer.from_pretrained(ROOT/'base_model',local_files_only=True)
    base=AutoModelForCausalLM.from_pretrained(ROOT/'base_model',local_files_only=True,dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda')
    initial=out/'adapter' if a.evaluate_only else ROOT/('runs/formal_split_release_v1/'+a.task+'/adapter')
    model=PeftModel.from_pretrained(base,initial,is_trainable=not a.evaluate_only)
    if not a.evaluate_only:
        model.config.use_cache=False;model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.enable_input_require_grads();model.train()
        optimizer=torch.optim.AdamW([v for v in model.parameters() if v.requires_grad],lr=8e-5)
        samples=[]
        for row in train:
            messages=generator_messages(row['request'],3) if a.task=='generator' else selector_messages(row['catalog'],row['request'],row['configuration'])
            prefix=tokenizer.apply_chat_template(messages,add_generation_prompt=True,tokenize=True)
            full=tokenizer.apply_chat_template(messages+[{'role':'assistant','content':json.dumps(row['target'],ensure_ascii=False,separators=(',',':'))}],tokenize=True)
            assert full[:len(prefix)]==prefix
            samples.append((full,[-100]*len(prefix)+full[len(prefix):]))
        start=time.time()
        for step in range(a.steps):
            optimizer.zero_grad(set_to_none=True);loss_sum=0
            for _ in range(2):
                ids,labels=rng.choice(samples)
                inputs=dict(input_ids=torch.tensor([ids],device='cuda'),labels=torch.tensor([labels],device='cuda'))
                loss=model(**assistant_inputs(inputs)).loss
                if not torch.isfinite(loss):raise ValueError('Nonfinite loss')
                (loss/2).backward();loss_sum+=loss.item()/2
            torch.nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step()
            if step%10==0:print('TRAIN',step+1,loss_sum,round(time.time()-start),flush=True)
        model.save_pretrained(out/'adapter');tokenizer.save_pretrained(out/'adapter')
        if a.task=='generator':(out/'adapter/prompt_config.json').write_text(json.dumps(dict(task='generator',prompt_version=3,system_prompt_sha256=hashlib.sha256(generator_messages('',3)[0]['content'].encode()).hexdigest(),prompt_messages_sha256=hashlib.sha256(json.dumps(generator_messages('',3),ensure_ascii=False,sort_keys=True).encode()).hexdigest())),encoding='utf-8')
    model.eval();model.gradient_checkpointing_disable();model.config.use_cache=True
    results=[]
    with torch.inference_mode():
        for start in range(0,len(test),4):
            batch=test[start:start+4];encoded=[]
            for row in batch:
                messages=generator_messages(row['request'],3) if a.task=='generator' else selector_messages(row['catalog'],row['request'],row['configuration'])
                encoded.append(tokenizer.apply_chat_template(messages,add_generation_prompt=True,tokenize=True))
            width=max(map(len,encoded));pad=tokenizer.eos_token_id
            ids=torch.tensor([[pad]*(width-len(x))+x for x in encoded],device='cuda')
            mask=torch.tensor([[0]*(width-len(x))+[1]*len(x) for x in encoded],device='cuda')
            output=model.generate(ids,attention_mask=mask,max_new_tokens=512,do_sample=False,pad_token_id=pad)
            for row,tokens in zip(batch,output):
                raw=tokenizer.decode(tokens[width:],skip_special_tokens=True)
                try:prediction=json.loads(raw);metrics=score(a.task,row,prediction)
                except (ValueError,TypeError,KeyError):prediction=raw;metrics=dict(json_valid=False,protocol_valid=False,exact=False)
                metrics.setdefault('json_valid',True)
                results.append(dict(id=row['id'],request=row['request'],target=row['target'],prediction=prediction,**metrics))
            print('EVAL',len(results),flush=True)
    report=dict(task=a.task,n=len(results),metrics={k:sum(r[k] for r in results)/len(results) for k in ('json_valid','protocol_valid','exact')},cases=results,warning='Synthetic development evaluation, not UE recognition accuracy; no deployment promotion.')
    (out/'test_metrics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(report['metrics'],flush=True)

if __name__=='__main__':main()
