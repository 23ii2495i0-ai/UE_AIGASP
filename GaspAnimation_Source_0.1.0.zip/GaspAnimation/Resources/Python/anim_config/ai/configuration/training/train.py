"""LoRA SFT with assistant-only loss, deterministic splits, real baseline/evaluation metrics."""

from pathlib import Path as _LayoutPath
import sys as _layout_sys
_layout_sys.path.insert(0,str(next(p for p in _LayoutPath(__file__).resolve().parents if (p/"project_paths.py").is_file())))
from project_paths import REPO as _LAYOUT_REPO, configure_imports as _configure_layout_imports
_configure_layout_imports()
import argparse,json,time,random,math,os
from pathlib import Path
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer
from peft import LoraConfig,get_peft_model,PeftModel
ROOT=_LAYOUT_REPO;ART=ROOT/'artifacts/anim_config'
def load_rows(path):return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
def parse_json(text):
 text=text.strip()
 if text.startswith('```'):text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
 return json.loads(text)
@torch.inference_mode()
def evaluate(model,tokenizer,rows,path):
 model.eval();model.config.use_cache=True
 if hasattr(model,'gradient_checkpointing_disable'):model.gradient_checkpointing_disable()
 results=[]
 for i,row in enumerate(rows):
  start=time.time();prompt=row['messages'][:-1]
  inp=tokenizer.apply_chat_template(prompt,add_generation_prompt=True,return_tensors='pt').to(model.device)
  flow='filters' in row.get('target',{})
  out=model.generate(inp,attention_mask=torch.ones_like(inp),max_new_tokens=384 if flow else 192,do_sample=False,pad_token_id=tokenizer.eos_token_id)
  text=tokenizer.decode(out[0,inp.shape[-1]:],skip_special_tokens=True);item={'id':row['id'],'seconds':round(time.time()-start,3),'raw':text}
  try:
   pred=parse_json(text);target=row['target'];item.update(json_valid=True,roles=pred.get('roles')==target['roles'],bindings=pred.get('bindings')==target['bindings'],reject=pred.get('reject')==target['reject'],blend=pred.get('blend_seconds')==target['blend_seconds'])
   if flow:
    from flow_protocol import validate_ir
    for k in ('filters','actions','policy'):item[k]=pred.get(k)==target[k]
    try:validate_ir(row['catalog'],pred);item['ir_valid']=True
    except (ValueError,TypeError,KeyError):item['ir_valid']=False
   item['exact']=all(item[k] for k in (('roles','bindings','reject','blend','filters','actions','policy','ir_valid') if flow else ('roles','bindings','reject','blend')))
  except Exception as e:
   item.update(json_valid=False,roles=False,bindings=False,reject=False,blend=False,exact=False,error=str(e))
   if flow:item.update(filters=False,actions=False,policy=False,ir_valid=False)
  results.append(item)
  if (i+1)%10==0:print('EVAL',i+1,'/',len(rows),flush=True)
 keys=('json_valid','roles','bindings','reject','blend','exact')+(('filters','actions','policy','ir_valid') if 'filters' in rows[0].get('target',{}) else ())
 metrics={k:sum(bool(r[k]) for r in results)/len(results) for k in keys};metrics['n']=len(results)
 report={'metrics':metrics,'cases':results};path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('METRICS',path.name,metrics,flush=True);return metrics

def main():
 p=argparse.ArgumentParser();p.add_argument('--steps',type=int,default=180);p.add_argument('--accum',type=int,default=4);p.add_argument('--max-length',type=int,default=1024);p.add_argument('--output',default=str(ART/'models/configuration/runs/initial_lora'));p.add_argument('--resume');p.add_argument('--eval-only',action='store_true');p.add_argument('--skip-baseline',action='store_true');p.add_argument('--data-dir',default=str(ART/'models/configuration/datasets/initial'));p.add_argument('--validation-limit',type=int,default=16);p.add_argument('--start-step',type=int,default=0);p.add_argument('--history');a=p.parse_args()
 if not 0<=a.start_step<a.steps or a.start_step and (not a.resume or not a.history):raise ValueError('Recovery requires adapter, matching history and a valid start step')
 data=Path(a.data_dir)
 random.seed(42);torch.manual_seed(42)
 if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required for this training run')
 torch.backends.cuda.matmul.allow_tf32=True
 base=ART/'models/configuration/base_model';out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 tokenizer=AutoTokenizer.from_pretrained(base,local_files_only=True,trust_remote_code=False);tokenizer.pad_token=tokenizer.eos_token
 print('LOAD_MODEL',torch.cuda.get_device_name(),flush=True)
 model=AutoModelForCausalLM.from_pretrained(base,local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa').to('cuda')
 if a.eval_only:
  if a.resume:model=PeftModel.from_pretrained(model,a.resume)
  evaluate(model,tokenizer,load_rows(data/'test.jsonl'),out/'test_metrics.json');return
 val=load_rows(data/'validation.jsonl')[:a.validation_limit]
 if not a.skip_baseline:evaluate(model,tokenizer,val,out/'baseline_validation.json')
 if a.resume:model=PeftModel.from_pretrained(model,a.resume,is_trainable=True)
 else:model=get_peft_model(model,LoraConfig(r=16,lora_alpha=32,lora_dropout=.05,target_modules=['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj'],task_type='CAUSAL_LM',bias='none'))
 model.print_trainable_parameters();model.config.use_cache=False;model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.enable_input_require_grads();model.train()
 rows=load_rows(data/'train.jsonl');tokens=[];skipped=[]
 for row in rows:
  prefix=tokenizer.apply_chat_template(row['messages'][:-1],tokenize=True,add_generation_prompt=True)
  full=tokenizer.apply_chat_template(row['messages'],tokenize=True)
  if len(full)>a.max_length or full[:len(prefix)]!=prefix:skipped.append(row['id']);continue
  labels=[-100]*len(prefix)+full[len(prefix):];tokens.append((full,labels))
 if not tokens:raise RuntimeError('No complete samples fit the sequence limit')
 params=[x for x in model.parameters() if x.requires_grad];optimizer=torch.optim.AdamW(params,lr=2e-4,weight_decay=.01,fused=True)
 records=json.loads(Path(a.history).read_text(encoding='utf-8')) if a.history else []
 if a.start_step and (not records or records[-1]['step']!=a.start_step):raise ValueError('History does not match adapter checkpoint step')
 elapsed_prefix=records[-1]['elapsed_seconds'] if records else 0
 started=time.time();order=list(range(len(tokens)));random.shuffle(order);cursor=0
 for _ in range(a.start_step*a.accum):
  if cursor>=len(order):random.shuffle(order);cursor=0
  cursor+=1
 if a.start_step:
  lr=2e-4*min(a.start_step/10,1)*(.1+.9*.5*(1+math.cos(math.pi*a.start_step/a.steps)))
  for group in optimizer.param_groups:group['lr']=lr
  print('RECOVERY',json.dumps({'start_step':a.start_step,'cursor':cursor,'optimizer_restarted':True}),flush=True)
 optimizer.zero_grad(set_to_none=True)
 for step in range(a.start_step+1,a.steps+1):
  losses=[]
  for _ in range(a.accum):
   if cursor>=len(order):random.shuffle(order);cursor=0
   ids,labels=tokens[order[cursor]];cursor+=1
   ids=torch.tensor([ids],device='cuda');labels=torch.tensor([labels],device='cuda')
   result=model(input_ids=ids,attention_mask=torch.ones_like(ids),labels=labels)
   loss=result.loss
   if not torch.isfinite(loss):raise RuntimeError('Non-finite training loss')
   losses.append(loss.item());(loss/a.accum).backward()
  torch.nn.utils.clip_grad_norm_(params,1.0);optimizer.step();optimizer.zero_grad(set_to_none=True)
  lr=2e-4*min(step/10,1)*(.1+.9*.5*(1+math.cos(math.pi*step/a.steps)))
  for group in optimizer.param_groups:group['lr']=lr
  row={'step':step,'loss':sum(losses)/len(losses),'elapsed_seconds':round(elapsed_prefix+time.time()-started,2),'peak_gpu_mb':round(torch.cuda.max_memory_allocated()/2**20,1)};records.append(row)
  if step==1 or step%10==0:print(json.dumps(row),flush=True)
  if step%60==0:
   model.save_pretrained(out/'adapter');tokenizer.save_pretrained(out/'adapter');(out/'training_progress.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
 model.save_pretrained(out/'adapter');tokenizer.save_pretrained(out/'adapter')
 summary={'base_model':'Qwen/Qwen2.5-1.5B-Instruct','method':'BF16 LoRA rank16 alpha32','steps':a.steps,'gradient_accumulation':a.accum,'training_samples':len(tokens),'skipped_too_long':skipped,'seconds':elapsed_prefix+time.time()-started,'peak_gpu_mb':torch.cuda.max_memory_allocated()/2**20,'history':records,'data_manifest':json.loads((data/'manifest.json').read_text()),'resumed_from':a.resume,'data_dir':str(data),'max_length':a.max_length,'validation_limit':a.validation_limit,'recovery':{'start_step':a.start_step,'optimizer_restarted':bool(a.start_step),'history':a.history,'steps_this_session':a.steps-a.start_step}}
 (out/'training_report.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 evaluate(model,tokenizer,val,out/'adapted_validation.json')
 evaluate(model,tokenizer,load_rows(data/'test.jsonl'),out/'test_metrics.json')
 print('TRAINING_COMPLETE',out,flush=True)
if __name__=='__main__':main()
