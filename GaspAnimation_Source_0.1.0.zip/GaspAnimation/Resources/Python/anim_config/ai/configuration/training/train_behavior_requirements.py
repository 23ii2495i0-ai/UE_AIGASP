"""Isolated assistant-only LoRA experiment. Never promotes a deployment."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import sys,os,json,random,time,argparse,math,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
from behavior_requirements import prompt_fingerprint,validate_topology,extraction_messages
from assistant_loss import assistant_loss

ROOT=_gasp_workspace


def rows(path):return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def canonical(value,stage,request):
    if stage=='topology':
        validate_topology(dict(value,standalone=[]),request)
        return dict(entry=value['entry'],groups=sorted([dict(id=g['id'],children=sorted(g['children']),initial=g['initial']) for g in value['groups']],key=lambda g:g['id']))
    return value


def evaluate(model,tokenizer,data,path,limit):
    import torch
    from transformers import StoppingCriteria,StoppingCriteriaList
    from lmformatenforcer import JsonSchemaParser
    from lmformatenforcer.integrations.transformers import build_transformers_prefix_allowed_tokens_fn
    model.eval();model.config.use_cache=True;model.gradient_checkpointing_disable()
    results=[]
    for row in data[:limit]:
        encoded=tokenizer.apply_chat_template(row['messages'][:-1],add_generation_prompt=True,return_tensors='pt').to('cuda');width=encoded.shape[-1];start=time.monotonic()
        class Complete(StoppingCriteria):
            def __call__(self,ids,scores,**kwargs):
                try:done=isinstance(json.loads(tokenizer.decode(ids[0,width:],skip_special_tokens=True)),dict)
                except ValueError:done=False
                return done or time.monotonic()-start>60
        with torch.inference_mode():
            current_schema,_=extraction_messages(row['stage'],row['request'],row['reviewed'])
            output=model.generate(encoded,attention_mask=torch.ones_like(encoded),max_new_tokens=768,do_sample=False,pad_token_id=tokenizer.eos_token_id,stopping_criteria=StoppingCriteriaList([Complete()]),prefix_allowed_tokens_fn=build_transformers_prefix_allowed_tokens_fn(tokenizer,JsonSchemaParser(current_schema)))
        raw=tokenizer.decode(output[0,width:],skip_special_tokens=True)
        result=dict(id=row['id'],stage=row['stage'],raw=raw,seconds=round(time.monotonic()-start,2),exact=False)
        try:
            prediction=json.loads(raw);result.update(prediction=prediction,exact=canonical(prediction,row['stage'],row['request'])==canonical(row['target'],row['stage'],row['request']))
        except (ValueError,KeyError,TypeError) as error:result['error']=str(error)
        results.append(result);print('BEHAVIOR_EVAL',len(results),'/',min(limit,len(data)),row['stage'],result['exact'],flush=True)
        path.write_text(json.dumps(dict(kind='teacher_forced_extraction_stages_not_end_to_end',cases=results),ensure_ascii=False,indent=2),encoding='utf-8')
    metrics={stage:dict(n=sum(r['stage']==stage for r in results),exact=sum(r['exact'] and r['stage']==stage for r in results)) for stage in sorted({r['stage'] for r in results})}
    report=dict(kind='teacher_forced_extraction_stages_not_end_to_end',schema_source='current_runtime_extraction_messages',runtime_schema_source_sha256=hashlib.sha256(Path(extraction_messages.__code__.co_filename).read_bytes()).hexdigest(),metrics=metrics,exact=sum(r['exact'] for r in results),n=len(results),cases=results)
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print('BEHAVIOR_METRICS',json.dumps(metrics),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--steps',type=int,default=240);parser.add_argument('--accum',type=int,default=2);parser.add_argument('--test-limit',type=int,default=48);parser.add_argument('--test-offset',type=int,default=0);parser.add_argument('--eval-split',choices=['validation','test'],default='test');parser.add_argument('--resume',type=Path);parser.add_argument('--data-dir',type=Path);parser.add_argument('--base',type=Path);parser.add_argument('--load-in-4bit',action='store_true');parser.add_argument('--max-length',type=int,default=3072);parser.add_argument('--eval-only',action='store_true');parser.add_argument('--skip-eval',action='store_true');args=parser.parse_args()
    import torch
    from transformers import AutoModelForCausalLM,AutoTokenizer,BitsAndBytesConfig
    from peft import LoraConfig,get_peft_model,PeftModel,prepare_model_for_kbit_training
    random.seed(31);torch.manual_seed(31);torch.backends.cuda.matmul.allow_tf32=True
    data=args.data_dir or ROOT/'artifacts/anim_config/models/configuration/datasets/behavior_requirements_v1';base=args.base or ROOT/'artifacts/anim_config/models/configuration/base_model'
    args.output.mkdir(parents=True,exist_ok=True)
    manifest=json.loads((data/'manifest.json').read_text(encoding='utf-8'))
    if manifest['prompt_sha256']!=prompt_fingerprint():raise ValueError('Data prompt differs from runtime')
    tokenizer=AutoTokenizer.from_pretrained(base,local_files_only=True,trust_remote_code=False);tokenizer.pad_token=tokenizer.eos_token
    quantization='nf4_double_bfloat16' if args.load_in_4bit else None
    if args.resume:
        metadata=json.loads((args.resume/'behavior_prompt_config.json').read_text(encoding='utf-8'))
        if metadata.get('protocol')!='requirement_ir_v1' or metadata.get('prompt_sha256')!=prompt_fingerprint() or metadata.get('base_quantization')!=quantization:raise ValueError('Resume adapter prompt/protocol/quantization mismatch')
        expected_base=metadata.get('base_config_sha256')
        if expected_base and expected_base!=hashlib.sha256((base/'config.json').read_bytes()).hexdigest():raise ValueError('Resume adapter base mismatch')
    load=dict(local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa')
    if args.load_in_4bit:load.update(quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.bfloat16),device_map={'':'cuda'})
    model=AutoModelForCausalLM.from_pretrained(base,**load)
    if not args.load_in_4bit:model.to('cuda')
    elif not args.eval_only:model=prepare_model_for_kbit_training(model,use_gradient_checkpointing=True,gradient_checkpointing_kwargs={'use_reentrant':False})
    if args.eval_only:
        if args.resume:model=PeftModel.from_pretrained(model,args.resume)
        target=args.output/(args.eval_split+'_stages_from'+str(args.test_offset)+'.json' if args.test_offset else args.eval_split+'_stages.json')
        evaluate(model,tokenizer,rows(data/(args.eval_split+'.jsonl'))[args.test_offset:],target,args.test_limit);return
    model=PeftModel.from_pretrained(model,args.resume,is_trainable=True) if args.resume else get_peft_model(model,LoraConfig(r=16,lora_alpha=32,lora_dropout=.05,target_modules=['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj'],task_type='CAUSAL_LM',bias='none'))
    model.config.use_cache=False;model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.enable_input_require_grads();model.train()
    samples=[];lengths=[]
    for row in rows(data/'train.jsonl'):
        prefix=tokenizer.apply_chat_template(row['messages'][:-1],add_generation_prompt=True,tokenize=True)
        full=tokenizer.apply_chat_template(row['messages'],tokenize=True)
        if full[:len(prefix)]!=prefix or len(full)>args.max_length:raise ValueError('Invalid/truncated training example: '+row['id'])
        samples.append((full,[-100]*len(prefix)+full[len(prefix):]));lengths.append(len(full))
    print('BEHAVIOR_TRAIN_READY',len(samples),'max_tokens',max(lengths),flush=True)
    params=[p for p in model.parameters() if p.requires_grad];optimizer=torch.optim.AdamW(params,lr=2e-4,weight_decay=.01,fused=True)
    order=list(range(len(samples)));random.shuffle(order);cursor=0;history=[];start=time.monotonic();optimizer.zero_grad(set_to_none=True)
    def save(step):
        adapter=args.output/'adapter';model.save_pretrained(adapter);tokenizer.save_pretrained(adapter)
        (adapter/'behavior_prompt_config.json').write_text(json.dumps(dict(protocol='requirement_ir_v1',prompt_sha256=prompt_fingerprint(),steps=step,base=str(base.resolve()),base_config_sha256=hashlib.sha256((base/'config.json').read_bytes()).hexdigest(),base_quantization=quantization,unvalidated=True)),encoding='utf-8')
        (args.output/'progress.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
    for step in range(1,args.steps+1):
        losses=[]
        for _ in range(args.accum):
            if cursor==len(order):cursor=0;random.shuffle(order)
            ids,labels=samples[order[cursor]];cursor+=1
            ids=torch.tensor([ids],device='cuda');labels=torch.tensor([labels],device='cuda')
            loss=assistant_loss(model,ids,labels)
            if not torch.isfinite(loss):raise RuntimeError('Non-finite extraction loss')
            losses.append(loss.item());(loss/args.accum).backward()
        torch.nn.utils.clip_grad_norm_(params,1.0);optimizer.step();optimizer.zero_grad(set_to_none=True)
        for group in optimizer.param_groups:group['lr']=2e-4*min(step/10,1)*(.1+.9*.5*(1+math.cos(math.pi*step/args.steps)))
        history.append(dict(step=step,loss=sum(losses)/len(losses),seconds=round(time.monotonic()-start,2),peak_gpu_mb=round(torch.cuda.max_memory_allocated()/2**20,1)))
        if step==1 or step%10==0:print('BEHAVIOR_TRAIN',json.dumps(history[-1]),flush=True)
        if step%60==0:save(step)
    save(args.steps)
    (args.output/'training_report.json').write_text(json.dumps(dict(manifest=manifest,base=str(base.resolve()),base_quantization=quantization,loss='assistant_suffix_equivalent_to_masked_causal_loss',steps=args.steps,accum=args.accum,samples=len(samples),history=history,resumed_from=str(args.resume) if args.resume else None,optimizer_restarted=bool(args.resume),active_deployment_modified=False),ensure_ascii=False,indent=2),encoding='utf-8')
    del optimizer;torch.cuda.empty_cache()
    if not args.skip_eval:evaluate(model,tokenizer,rows(data/'test.jsonl'),args.output/'test_stages.json',args.test_limit)

if __name__=='__main__':main()
