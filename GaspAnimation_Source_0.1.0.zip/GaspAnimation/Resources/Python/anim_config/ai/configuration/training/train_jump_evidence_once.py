"""One authorized run, two complete epochs, exact exposure log, no model selection."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import sys,json,random,time,math,hashlib,threading,os
ROOT=_gasp_workspace
sys.path.insert(0,str(ROOT/'tools/anim_config'))
sys.path.insert(0,str(Path(__file__).parent))
from jump_evidence_protocol import protocol_fingerprint,PROTOCOL
from chunked_assistant_loss import chunked_assistant_loss
FOLDER=ROOT/'artifacts/anim_config/verification/jump_training_once'
DATA=ROOT/'artifacts/anim_config/models/configuration/datasets/jump_evidence_once_v1'
OUT=ROOT/'artifacts/anim_config/models/configuration/runs/behavior_jump_evidence_once_20261023'
BASE=ROOT/'artifacts/anim_config/models/configuration/behavior_bases/Qwen3-4B-Instruct-2507'
RESUME=ROOT/'artifacts/anim_config/models/configuration/runs/behavior_requirements_qwen3_v5_nf4_trial_20261022/adapter'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
budget=json.loads((FOLDER/'budget.json').read_text(encoding='utf-8'))
deadline=datetime.strptime(budget['deadline_utc'],'%Y-%m-%d %H:%M:%S UTC').replace(tzinfo=timezone.utc).timestamp()
def check_deadline():
 if time.time()>=deadline:raise TimeoutError('Four-hour total experiment deadline reached')
def hard_stop():
 (FOLDER/'deadline_stop.json').write_text(json.dumps(dict(stopped=True,phase='training',utc=datetime.now(timezone.utc).isoformat())),encoding='utf-8');os._exit(124)
check_deadline();timer=threading.Timer(deadline-time.time(),hard_stop);timer.daemon=True;timer.start()
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer,BitsAndBytesConfig
from peft import PeftModel,prepare_model_for_kbit_training
manifest=json.loads((DATA/'manifest.json').read_text(encoding='utf-8'))
assert manifest['protocol_sha256']==protocol_fingerprint() and manifest['train_sha256']==sha(DATA/'train.jsonl')
review=json.loads((FOLDER/'label_review.json').read_text(encoding='utf-8'));assert review['dataset_sha256']==manifest['train_sha256'] and review['count']==12
rows=[json.loads(line) for line in (DATA/'train.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
tokenizer=AutoTokenizer.from_pretrained(BASE,local_files_only=True,trust_remote_code=False);tokenizer.pad_token=tokenizer.eos_token
samples=[];lengths=[];answers=[]
for row in rows:
 prefix=tokenizer.apply_chat_template(row['messages'][:-1],add_generation_prompt=True,tokenize=True)
 full=tokenizer.apply_chat_template(row['messages'],tokenize=True)
 if full[:len(prefix)]!=prefix or len(full)>4096:raise ValueError('Invalid or overbudget example; no truncation allowed: '+row['id'])
 samples.append((full,[-100]*len(prefix)+full[len(prefix):]));lengths.append(len(full));answers.append(len(full)-len(prefix))
(FOLDER/'tokenization_preflight.json').write_text(json.dumps(dict(max_input_plus_answer=max(lengths),max_answer=max(answers),rows=len(rows),truncated=0,tokenizer_base=str(BASE)),indent=2),encoding='utf-8')
OUT.mkdir(parents=True,exist_ok=True)
with (FOLDER/'training_started.json').open('x',encoding='utf-8') as file:json.dump(dict(utc=datetime.now(timezone.utc).isoformat(),candidate=str(OUT),single_run=True),file)
seed=manifest['seed'];torch.manual_seed(seed);torch.backends.cuda.matmul.allow_tf32=True
model=AutoModelForCausalLM.from_pretrained(BASE,local_files_only=True,trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa',quantization_config=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',bnb_4bit_use_double_quant=True,bnb_4bit_compute_dtype=torch.bfloat16),device_map={'':'cuda'})
model=prepare_model_for_kbit_training(model,use_gradient_checkpointing=True,gradient_checkpointing_kwargs={'use_reentrant':False})
model=PeftModel.from_pretrained(model,RESUME,is_trainable=True)
model.config.use_cache=False;model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.enable_input_require_grads();model.train()
params=[p for p in model.parameters() if p.requires_grad];optimizer=torch.optim.AdamW(params,lr=1e-4/20,weight_decay=.01,fused=True)
optimizer.zero_grad(set_to_none=True)
counts=Counter();attempts=Counter();by_stage=Counter();by_stratum=Counter();history=[];steps=0;applied_presentations=0;pending=[];started=time.monotonic()
source_names=['tools/anim_config/jump_evidence_protocol.py','tools/anim_config/jump_extraction_trial.py','tools/anim_config/behavior_requirements.py','tools/anim_config/ai/configuration/runtime/split_runtime.py','tools/anim_config/ai/configuration/training/chunked_assistant_loss.py','tools/anim_config/ai/configuration/training/train_jump_evidence_once.py']
source_hashes={name:sha(ROOT/name) for name in source_names}
def save_exposure(completed=False,error=None):
 report=dict(completed=completed,error=error,prepared_rows=len(rows),planned_epochs=2,actual_forward_attempts=sum(attempts.values()),backward_completed_presentations=sum(counts.values()),optimizer_applied_presentations=applied_presentations,unique_rows_with_backward=len(counts),coverage=len(counts)/len(rows),per_row_presentations=dict(counts),per_row_forward_attempts=dict(attempts),by_stage=dict(by_stage),by_stratum=dict(by_stratum),optimizer_steps=steps,history=history,source_hashes=source_hashes,base_config_sha256=sha(BASE/'config.json'),resumed_adapter_sha256=sha(RESUME/'adapter_model.safetensors'),dataset_sha256=manifest['train_sha256'])
 (OUT/'training_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 return report
log=(OUT/'sample_exposure.jsonl').open('a',encoding='utf-8',buffering=1)
print('TRAIN_READY',len(rows),'max_tokens',max(lengths),'max_answer',max(answers),'steps',manifest['planned_steps'],flush=True)
try:
 for epoch in range(2):
  order=list(range(len(rows)));random.Random(seed+epoch).shuffle(order)
  for offset,index in enumerate(order):
   check_deadline();row=rows[index];ids,labels=samples[index];attempts[row['id']]+=1
   event=dict(epoch=epoch+1,optimizer_step=steps+1,microbatch=offset%2,id=row['id'],stage=row['stage'],stratum=row['stratum'],input_tokens=lengths[index],row_sha256=hashlib.sha256(json.dumps(row,sort_keys=True,ensure_ascii=False).encode()).hexdigest())
   log.write(json.dumps(dict(event,event='forward_attempt'))+'\n')
   ids=torch.tensor([ids],device='cuda');labels=torch.tensor([labels],device='cuda')
   loss=chunked_assistant_loss(model,ids,labels,chunk_size=128)
   if not torch.isfinite(loss):raise RuntimeError('Non-finite training loss')
   (loss/2).backward()
   counts[row['id']]+=1;by_stage[row['stage']]+=1;by_stratum[row['stratum']]+=1;pending.append(loss.item())
   log.write(json.dumps(dict(event,event='backward_completed',loss=loss.item()))+'\n')
   if len(pending)==2:
    torch.nn.utils.clip_grad_norm_(params,1.0);optimizer.step();optimizer.zero_grad(set_to_none=True);steps+=1;applied_presentations+=2
    for group in optimizer.param_groups:group['lr']=1e-4*min((steps+1)/20,1)*(.1+.9*.5*(1+math.cos(math.pi*(steps+1)/manifest['planned_steps'])))
    history.append(dict(step=steps,epoch=epoch+1,loss=sum(pending)/2,seconds=round(time.monotonic()-started,2),peak_gpu_mb=round(torch.cuda.max_memory_allocated()/2**20,1)));pending=[]
    if steps==1 or steps%10==0:print('TRAIN_PROGRESS',json.dumps(history[-1]),flush=True)
    if steps%20==0:save_exposure()
 assert steps==manifest['planned_steps'] and len(counts)==len(rows) and set(counts.values())=={2}
 check_deadline();adapter=OUT/'adapter';model.save_pretrained(adapter);tokenizer.save_pretrained(adapter)
 config=dict(training_parameters=dict(epochs=2,accum=2,max_lr=1e-4,warmup_steps=20,seed=seed,loss_chunk_size=128,max_tokens=4096),protocol=PROTOCOL,protocol_sha256=protocol_fingerprint(),base=str(BASE),base_config_sha256=sha(BASE/'config.json'),base_quantization='nf4_double_bfloat16',resumed_from=str(RESUME),resumed_adapter_sha256=sha(RESUME/'adapter_model.safetensors'),source_hashes=source_hashes,data_manifest=manifest,training_steps=steps,actual_presentations=sum(counts.values()),unique_rows_seen=len(counts),old_requirement_prompt_sha256=json.loads((RESUME/'behavior_prompt_config.json').read_text())['prompt_sha256'],policy_source='deterministic_from_model_evidence',unvalidated=True)
 (adapter/'jump_evidence_config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
 save_exposure(completed=True)
 frozen=dict(utc=datetime.now(timezone.utc).isoformat(),adapter=str(adapter),adapter_sha256=sha(adapter/'adapter_model.safetensors'),adapter_config_sha256=sha(adapter/'adapter_config.json'),protocol_config_sha256=sha(adapter/'jump_evidence_config.json'),source_hashes=source_hashes,data_manifest_sha256=sha(DATA/'manifest.json'),sealed_sha256=(FOLDER/'sealed_before.sha256').read_text(),candidate_selection='only final weights; no test-based checkpoint selection')
 (FOLDER/'candidate_frozen.json').write_text(json.dumps(frozen,indent=2),encoding='utf-8')
 print('TRAIN_COMPLETE',steps,sum(counts.values()),len(counts),flush=True)
except BaseException as error:
 save_exposure(error=type(error).__name__+': '+str(error));raise
finally:log.close();timer.cancel()
