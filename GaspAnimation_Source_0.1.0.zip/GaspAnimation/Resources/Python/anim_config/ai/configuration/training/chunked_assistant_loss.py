"""Exact suffix loss with checkpointed vocabulary chunks, for this Qwen trial."""
def chunked_assistant_loss(model, input_ids, labels, chunk_size=128):
    import torch
    from torch.utils.checkpoint import checkpoint
    if labels.shape!=input_ids.shape or labels.shape[0]!=1:raise ValueError('Expected one unpadded example')
    valid=labels[0].ne(-100);count=int(valid.sum());start=labels.shape[1]-count
    if not count or start<1 or bool(valid[:start].any()) or not bool(valid[start:].all()):raise ValueError('Expected contiguous assistant suffix')
    base=model.get_base_model() if hasattr(model,'get_base_model') else model
    hidden=base.model(input_ids=input_ids,attention_mask=torch.ones_like(input_ids),use_cache=False).last_hidden_state[:,start-1:-1,:]
    targets=labels[:,start:]
    def summed_loss(part,gold):
        logits=base.get_output_embeddings()(part)
        return torch.nn.functional.cross_entropy(logits.float().reshape(-1,logits.shape[-1]),gold.reshape(-1),reduction='sum')
    terms=[checkpoint(summed_loss,hidden[:,offset:offset+chunk_size,:],targets[:,offset:offset+chunk_size],use_reentrant=False) for offset in range(0,count,chunk_size)]
    return torch.stack(terms).sum()/count
