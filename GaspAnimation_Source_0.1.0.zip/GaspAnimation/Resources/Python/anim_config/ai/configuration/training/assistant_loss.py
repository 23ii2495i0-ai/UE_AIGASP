"""Exact assistant-only causal loss without projecting ignored prompt tokens."""
def assistant_loss(model,input_ids,labels):
    import torch
    if labels.shape!=input_ids.shape or labels.shape[0]!=1:raise ValueError('Expected one unpadded training example')
    valid=labels[0].ne(-100);count=int(valid.sum().item());start=labels.shape[1]-count
    if not count or start<1 or bool(valid[:start].any()) or not bool(valid[start:].all()):raise ValueError('Assistant labels must be one contiguous suffix after a prompt')
    # The logit immediately before the first answer token predicts that token.
    # Keep that position through the final position, then omit the unused last
    # prediction. All prompt tokens still participate in causal attention.
    logits=model(input_ids=input_ids,attention_mask=torch.ones_like(input_ids),logits_to_keep=count+1).logits[:,:-1,:]
    return torch.nn.functional.cross_entropy(logits.float().reshape(-1,logits.shape[-1]),labels[:,start:].reshape(-1))
