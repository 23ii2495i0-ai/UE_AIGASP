"""Staged model extraction for the uniform IR; no fixed action taxonomy."""
import copy
import json
import re
from datetime import datetime
from pathlib import Path
import jsonschema
from behavior_graph import generation_schema,BUILTINS_V3,_id
from unified_behavior import PROTOCOL,compile_unified

SYSTEM='''Generate DATA ONLY for a uniform Unreal state machine. No code or scripts. State structure does NOT depend on action categories or trained labels. Preserve the user's state labels verbatim; use explicit ASCII IDs or State1, State2 etc for Chinese labels. Copy source_quote verbatim. Only create requested states and transitions. A condition belongs to an edge; animation content belongs to a state. Never invent resource paths. Custom/untrained action names are allowed. Use free English name-token queries for content, or exact selected paths only when explicitly supplied. Missing assets will remain unresolved; never substitute attack/hit or a familiar trained class. Supported execution primitives: nested groups, mm/sequence/montage/native locomotion players, numeric/bool internal/external variables, condition all/any/not with eq/ne/lt/le/gt/ge, set/add/jump actions, entry/exit/completion actions, conditional internal event handlers. MM has no finite completion event: use explicit time/conditions or report an unresolved requirement. Unknown external conditions can use an external bool initially false, with its required gameplay source described. Builtin values are read-only; do not redeclare them. Do not invent transitions merely to pass reachability. Report unsupported capabilities or unspecified essential conditions in unresolved.'''

def obj(p):return dict(type='object',properties=p,required=list(p),additionalProperties=False)
def arr(p,n=32):return dict(type='array',items=p,maxItems=n)
def enum(v):return dict(type='string',enum=list(v))
def opt(p):return dict(anyOf=[p,dict(type='null')])
ID=dict(type='string',pattern='^[A-Za-z_][A-Za-z0-9_]{0,63}$')
STR=dict(type='string')
BOOL=dict(type='boolean')
SCALAR=dict(anyOf=[dict(type='number'),BOOL])
RUNTIME_CONTRACT=dict(values=dict(falling='boolean: CharacterMovement.IsFalling; true=airborne, false=grounded; vertical_speed==0 alone is NOT landing',crouched='boolean: actual Character.bIsCrouched',move_input='number 0..1: combined movement input length',gait='number: 0=walk, 1=run, 2=sprint',vertical_speed='number: actual world vertical velocity; >0 rising, <0 falling',state_time='number: seconds in active state'),events=dict(Jumped='native successful jump callback',Landed='actual Character.Landed callback',Attack='existing attack input',Hit='existing hit/damage input',Dodge='existing dodge input'),keys=dict(SpaceBar='Space key; graph binding consumes the existing default Jump input'),jump_action='jump launches actual vertical movement via LaunchCharacter; it does not emit native Jumped. For an explicit custom jump handler, launch and add counter once in the same pressed-event action list; never reset counter on unrelated state changes.')

def actions(names):
    variants=[obj(dict(op=enum(['jump']),velocity=dict(type='number',minimum=1,maximum=2000)))]
    if names:variants.insert(0,obj(dict(op=enum(['set','add']),var=enum(names),value=SCALAR)))
    return arr(dict(anyOf=variants))

def forbidden_list(request,terms):
    """Only explicit negative lists, never infer a missing user requirement."""
    for clause in re.split(r'[。；;\n]|(?:，|,)但',request):
        match=re.search(r'(?:没有|不声明|不创建|不添加|不需要|不要)(?!从|根据|基于)([^：:]+)$',clause)
        if match:
            items=[x.strip() for x in re.split(r'、|，|,|或|和|及|与',match[1])]
            if any(item in terms for item in items):return clause.strip()
    return None

def resource_mentions(request,catalog):
    names={a['name'] for a in catalog['assets'] if a.get('kind') in ('sequence','montage','database') and a.get('name') and re.search(r'(?<![A-Za-z0-9_])'+re.escape(a['name'])+r'(?![A-Za-z0-9_])',request)}
    # Preserve explicitly requested names even when they are not in the palette;
    # otherwise the model might substitute a familiar, available animation.
    names.update(re.findall(r'(?:素材|资源|动画)(?:名称|名)\s*(?:为|是|[:：])?\s*([A-Za-z_][A-Za-z0-9_]*)',request))
    return sorted(names)

def node_resource_mentions(request,node,catalog):
    lines=[line for line in request.splitlines() if re.search(r'(?<![A-Za-z0-9_])'+re.escape(node['id'])+r'(?![A-Za-z0-9_])',line)]
    local=resource_mentions('\n'.join(lines),catalog)
    return local or resource_mentions(request,catalog),lines

def declared_node_palette(request):
    """Ground explicitly closed ASCII declarations, not action categories.

    Return None for open/mixed naming; never treat animation identifiers or
    transition endpoints as declarations by themselves.
    """
    declared={}
    # Parenthetical explanations such as ``Idle（站立待机）`` are annotations,
    # not part of the comma-separated identifier list.
    declaration_text=re.sub(r'（[^）]*）|\([^)]*\)','',request)
    names=r'([A-Za-z_][A-Za-z0-9_]*(?:\s*[、,，]\s*[A-Za-z_][A-Za-z0-9_]*)*)'
    patterns=((r'父组\s+'+names,'group'),
              (r'(?:直接)?叶子状态\s*[:：]?\s*'+names,'leaf'),
              (r'直接子状态\s*[:：]?\s*'+names,'leaf'),
              (r'子状态\s*[:：]?\s*'+names,'leaf'))
    for pattern,kind in patterns:
        for match in re.finditer(pattern,declaration_text):
            for name in re.split(r'\s*[、,，]\s*',match[1]):
                if name in declared and declared[name]!=kind:return None
                declared[name]=kind
    if not declared:return None
    count_words={'单个':1,'一个':1,'两个':2,'三个':3,'四个':4,'五个':5,'六个':6,'七个':7,'八个':8,'九个':9,'十个':10}
    counts=[]
    for word,count in count_words.items():
        if re.search(r'(?:只有|仅有|创建)(?:这)?'+word+r'(?:顶层)?叶子状态',request) or re.search(r'只创建这'+word+r'节点',request):counts.append(count)
    # Explicit per-kind counts plus a closed-world statement make a complete
    # palette even when the user writes the names after a colon (common in
    # generated prompts) instead of using the older whitespace-only syntax.
    kind_counts={}
    for kind_word,kind in (('父组','group'),('叶子状态','leaf')):
        for word,count in count_words.items():
            if re.search(word+r'\s*(?:直接)?'+kind_word,request):
                kind_counts[kind]=count
    closed=bool(re.search(r'(?:除以上|除上述|除此之外).{0,40}(?:不创建|不得创建|不要创建).{0,12}(?:其他|额外)',declaration_text))
    counts_match=bool(counts and all(count==len(declared) for count in counts))
    per_kind_match=bool(kind_counts and all(sum(1 for value in declared.values() if value==kind)==count for kind,count in kind_counts.items()))
    return declared if counts_match or (closed and per_kind_match and len(kind_counts)>=2) else None

def state_spec_schema(names,group,content):
    variants=[]
    for player in (['group'] if group else ['mm','sequence','montage']):
        finite=player in ('sequence','montage')
        variants.append(obj(dict(player=enum([player]),loop=dict(type='boolean',enum=[False]) if group else BOOL,
            allow_movement=BOOL,lock_until_finished=BOOL if finite else dict(type='boolean',enum=[False]),
            min_duration=dict(type='number',minimum=0,maximum=60),blend_seconds=dict(type='number',minimum=0,maximum=2),
            on_entry=actions(names),on_exit=actions(names),on_complete=actions(names) if finite else dict(type='array',items=STR,maxItems=0),
            content=dict(type='null') if group else content)))
    return variants[0] if group else dict(anyOf=variants)

def transition_tasks(request,state_ids):
    """Anchor each explicit arrow separately; keep all other prose for review.

    This only identifies syntax and source spans, never invents conditions.
    """
    explicit=[];remaining=[]
    for index,line in enumerate(request.splitlines()):
        if not line.strip():continue
        match=re.match(r'^\s*(?:[-*]\s*)?([A-Za-z_][A-Za-z0-9_]*)\s*(?:→|->|到)\s*([A-Za-z_][A-Za-z0-9_]*)\s*[:：]\s*(.+)',line)
        if match and match[1] in state_ids and match[2] in state_ids:
            explicit.append(dict(source=match[1],target=match[2],lines=[dict(index=index,text=line)],expression=match[3].rstrip('。')))
        else:remaining.append(dict(index=index,text=line))
    if not explicit:return [dict(source=s,target=None,lines=[dict(index=i,text=l) for i,l in enumerate(request.splitlines()) if l.strip()]) for s in state_ids+['*']]
    # Residual extraction remains necessary: non-arrow prose may contain crouch
    # transitions, input handlers or other requirements. Do not drop it merely
    # because a request also contains easy arithmetic arrows.
    return explicit+[dict(source=s,target=None,lines=remaining) for s in state_ids+['*']]

def builtin_prose_condition(text):
    """Small, auditable runtime-predicate vocabulary, independent of state IDs.

    This is deterministic language compilation, not evidence of model skill.
    Return None for unfamiliar wording; never infer from an animation label.
    """
    if re.search(r'垂直速度(?:转为|重新)?(?:向上|上升)',text):
        return dict(var='vertical_speed',op='gt',value=0)
    if re.search(r'垂直速度(?:转为)?下降',text):
        return dict(var='vertical_speed',op='lt',value=0)
    if re.search(r'角色真实落地后',text):
        return dict(var='falling',op='eq',value=False)
    if re.search(r'真实起跳或角色处于真实下落状态',text):
        return dict(var='falling',op='eq',value=True)
    return None

def node_callback_requested(request,node,field):
    token=r'(?<![A-Za-z0-9_])'+re.escape(node)+r'(?![A-Za-z0-9_])'
    verbs={'on_entry':'进入','on_exit':'退出|离开','on_complete':'播放完成|播完|完成时'}
    for clause in re.split(r'[。；\n]',request):
        if not re.search(token,clause):continue
        if field in clause:return True
        if field=='on_complete' and re.search(verbs[field],clause):return True
        if field!='on_complete' and re.search(r'(?:'+verbs[field]+r')\s*(?:状态\s*)?'+token+r'\s*(?:时|后|[，,:：])',clause):return True
    return False

def declared_group_relations(request,groups,ids):
    """Read explicit direct-child lists; never infer hierarchy from transitions."""
    text=re.sub(r'（[^）]*）|\([^)]*\)','',request)
    result={}
    for group in groups:
        token=r'(?<![A-Za-z0-9_])'+re.escape(group)+r'(?![A-Za-z0-9_])'
        lists=[]
        for match in re.finditer(token+r'\s*下(?:有|包含)[^\n。:：]*[:：]([^\n。]+)',text):
            children=re.findall(r'[A-Za-z_][A-Za-z0-9_]*',match[1])
            if children and all(c in ids and c!=group for c in children) and len(children)==len(set(children)):
                lists.append(children)
        initials=re.findall(token+r'[^\n。]*?初始子状态(?:为|是|[:：])\s*([A-Za-z_][A-Za-z0-9_]*)',text)
        if lists and all(set(x)==set(lists[0]) for x in lists):
            result[group]={'children':lists[0]}
        if initials and len(set(initials))==1 and initials[0] in ids:
            result.setdefault(group,{})['initial_child']=initials[0]
    return result

def generate(runtime,catalog,request,destination,info,repo):
    folder=Path(repo)/'artifacts/anim_config/models/configuration/logs';folder.mkdir(parents=True,exist_ok=True)
    log=folder/('unified_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
    trace=[];ir=dict(protocol=PROTOCOL)
    prohibited={key:forbidden_list(request,terms) for key,terms in dict(variables={'变量','计数变量'},inputs={'输入','按键','按键输入'},transitions={'转换','状态转换'},handlers={'内部事件','事件处理'}).items()}
    selected_paths=[a['id'] for a in catalog['assets'] if a['id'] in request]
    def save(error=None):
        log.write_text(json.dumps(dict(request=request,ir=ir,stages=trace,error=error),ensure_ascii=False,indent=2),encoding='utf-8')
    def stage(name,schema,payload,check=lambda x:None):
        runtime.behavior_schema=schema;runtime.behavior_max_tokens=4096
        focus=payload.pop('_focus_request',request)
        payload['runtime_contract']=RUNTIME_CONTRACT
        messages=[dict(role='system',content=SYSTEM if name!='layout' else '你只负责提取用户要求的状态布局，输出output_schema规定的JSON。id是技术标识符，action_name是原文中的动作显示名称，两者可以不同。原文指定了自定义动作名时照抄动作名。父组不播放动作；叶子没有初始子状态。不要生成资源、变量或连接，不要引用示例。'),dict(role='user',content=json.dumps(dict(stage=name,request=focus,original_request=request,output_schema=schema,builtin_values=sorted(BUILTINS_V3),explicit_prohibitions=prohibited,**payload),ensure_ascii=False))]
        for attempt in range(3):
            getattr(runtime,'progress',{}).update(stage=name,attempt=attempt+1,phase='prepare',tokens=0)
            output=None
            try:
                output=runtime.predict('behavior',messages)
                trace.append(dict(stage=name,attempt=attempt+1,output=copy.deepcopy(output),raw=copy.deepcopy(runtime.last_prediction_raw),messages=copy.deepcopy(messages),schema=copy.deepcopy(schema)))
                jsonschema.validate(output,schema);check(output);save();return output
            except (ValueError,TypeError,KeyError,RuntimeError,jsonschema.ValidationError) as error:
                trace.append(dict(stage=name+'_validation',attempt=attempt+1,error=str(error)));save(str(error))
                if attempt==2 or getattr(runtime,'last_decode_timeout',None) or '显存余量不足' in str(error):raise ValueError('统一状态机阶段失败 ['+name+']：'+str(error)+'；日志：'+str(log)) from error
                messages.extend([dict(role='assistant',content=json.dumps(output,ensure_ascii=False)),dict(role='user',content='本阶段不符合协议/用户需求：'+str(error)+'。只修复本阶段；不得改状态名称、补虚构动画或无条件连接。')])
    try:
        layout_schema=obj(dict(entry=ID,states=arr(obj(dict(id=ID,action_name=dict(type='string',description='原文指定的动作名称；不是节点技术ID。没有另指定动作名时使用原文状态名。'),node_type=enum(['leaf','group']))))))
        palette=declared_node_palette(request)
        if palette:
            layout_schema['properties']['entry']=enum(palette)
            variants=[]
            for name,kind in palette.items():
                scope='\n'.join(line for line in request.splitlines() if re.search(r'(?<![A-Za-z0-9_])'+re.escape(name)+r'(?![A-Za-z0-9_])',line))
                labels=re.findall(r'动作(?:名称|名)(?:为|是|[:：])\s*([^，,。；;\n]+)',scope)
                # With an explicit closed declaration, an unspecified display
                # action defaults to the declared state name. Do not ask the
                # model to invent a second free-text copy (including empty).
                label_schema=enum(sorted(set(labels))) if kind=='leaf' and labels else enum([name])
                variants.append(obj(dict(id=enum([name]),action_name=label_schema,node_type=enum([kind]))))
            layout_schema['properties']['states']=dict(type='array',items=dict(anyOf=variants),minItems=len(palette),maxItems=len(palette))
        def check_layout(v):
            nodes=v['states'];ids={n['id'] for n in nodes}
            if not nodes or len(ids)!=len(nodes) or v['entry'] not in ids:raise ValueError('节点/入口缺失或重复')
            if palette and ids!=set(palette):raise ValueError('节点必须对应原文明示的封闭声明：'+', '.join(palette))
            for n in nodes:
                if n['node_type']=='group' and n['id'] in request:
                    # Groups are structural containers and have no animation
                    # action. Keep their display name anchored to their ID.
                    n['action_name']=n['id']
                elif n['node_type']=='leaf' and n['id'] in request and n['action_name'].casefold()==n['id'].casefold():
                    # Accept casing drift from constrained model decoding while
                    # preserving the exact user-declared state label.
                    n['action_name']=n['id']
                if not n['action_name'] or n['action_name'] not in request:raise ValueError('节点动作名必须来自原文：'+n['id'])
        extracted=stage('layout',layout_schema,dict(instruction='只提取所有节点及入口。id使用原文指定的技术ID；action_name使用原文指定的动作名。node_type：有子状态的父组为group，播放动作的叶子为leaf。状态转换关系不是父子关系。不要把入口状态当作其他状态的父组。'),check_layout)
        groups=[n['id'] for n in extracted['states'] if n['node_type']=='group']
        relations={n['id']:dict(parent=None,initial_child=None) for n in extracted['states']}
        if groups:
            ids=[n['id'] for n in extracted['states']]
            relation_fields={g:obj(dict(children=dict(type='array',items=enum([i for i in ids if i!=g]),minItems=1,maxItems=len(ids)-1),initial_child=enum([i for i in ids if i!=g]))) for g in groups}
            explicit_relations=declared_group_relations(request,groups,ids)
            for g,field in relation_fields.items():
                children=field['properties']['children'];children['uniqueItems']=True
                explicit=explicit_relations.get(g,{})
                if 'children' in explicit:
                    allowed=explicit['children']
                    children.update(items=enum(allowed),minItems=len(allowed),maxItems=len(allowed))
                    field['properties']['initial_child']=enum(allowed)
                if 'initial_child' in explicit:
                    field['properties']['initial_child']=enum([explicit['initial_child']])
            def check_relations(value):
                parents={}
                for group,value in value['groups'].items():
                    if value['initial_child'] not in value['children']:raise ValueError('初始子状态必须在本组children中：'+group)
                    for child in value['children']:
                        if child in parents:raise ValueError('子状态重复声明或有多个父组：'+child)
                        parents[child]=group
                for child in parents:
                    seen=set();current=child
                    while current in parents:
                        if current in seen:raise ValueError('父子关系形成循环：'+child)
                        seen.add(current);current=parents[current]
            hierarchy=stage('hierarchy',obj(dict(groups=obj(relation_fields))),dict(nodes=extracted['states'],instruction='每个父组只填写一次：children为它的全部直接子节点ID，initial_child为其中一个。不要填写叶子的parent；程序会从children唯一推导，避免双向字段矛盾。状态转换不是父子关系。'),check_relations)
            for group,value in hierarchy['groups'].items():
                relations[group]['initial_child']=value['initial_child']
                for child in value['children']:relations[child]['parent']=group
        # A verbatim name is already a source span; do not ask the model to
        # repeat it in a second evidence field and risk contradictory values.
        layout=dict(entry=extracted['entry'],states=[dict(id=n['id'],label=n['action_name'],source_quote=n['action_name'],parent=relations[n['id']]['parent'],initial=relations[n['id']]['initial_child']) for n in extracted['states']])
        ir['entry']=layout['entry'];ir['states']=[]
        declaration=obj(dict(variables=arr(obj(dict(id=ID,initial=SCALAR,scope=enum(['internal','external']),source=STR)),64),
            inputs=arr(obj(dict(key=ID,phase=enum(['pressed','released']),event=ID,set=dict(type='object',additionalProperties=SCALAR))),64),unresolved=arr(STR)))
        for field in ('variables','inputs'):
            if prohibited[field]:declaration['properties'][field]['maxItems']=0
        declared_variables=sorted(set(re.findall(r'(?:整数(?:变量)?|布尔(?:变量)?|变量)\s+([A-Za-z_][A-Za-z0-9_]*)',request)))
        variable_schema=declaration['properties']['variables']['items']['properties']
        variable_schema['source']=dict(type='string',minLength=1)
        if declared_variables:
            variable_schema['id']=enum(declared_variables)
            variable_variants=[]
            for variable in declared_variables:
                fields=copy.deepcopy(variable_schema);fields['id']=enum([variable])
                for scope,word in (('internal','内部'),('external','外部')):
                    if re.search(word+r'[^。；\n]{0,20}(?<![A-Za-z0-9_])'+re.escape(variable)+r'(?![A-Za-z0-9_])',request):fields['scope']=enum([scope])
                variable_variants.append(obj(fields))
            declaration['properties']['variables']['items']=dict(anyOf=variable_variants)
            declaration['properties']['variables'].update(minItems=len(declared_variables),maxItems=len(declared_variables),uniqueItems=True)
        def check_vars(v):
            ids=[x['id'] for x in v['variables']]
            if len(ids)!=len(set(ids)) or any(x.lower() in BUILTINS_V3 for x in ids):raise ValueError('变量重复或重声明了只读内置量')
            if declared_variables and set(ids)!=set(declared_variables):raise ValueError('变量必须保留原文明示的名称：'+', '.join(declared_variables))
            for item in v['variables']:
                if not item['source'].strip():raise ValueError('变量缺少内部用途或外部接入来源：'+item['id'])
                if re.search(r'内部[^。；\n]{0,20}(?<![A-Za-z0-9_])'+re.escape(item['id'])+r'(?![A-Za-z0-9_])',request) and item['scope']!='internal':raise ValueError('原文明示内部变量不能声明为external：'+item['id'])
        shared=stage('declarations',declaration,dict(layout=layout,instruction='仅提取原文明确要求声明的可写变量和按键事件。状态名称、动作名、素材名不是变量；使用MM不需要自动建立速度变量或蹲姿变量。内置数据直接读取，不重复声明。原文没有要求变量或按键事件时对应数组为空。External variables need initial values and intended setter source. Do not invent gameplay logic.'),check_vars)
        ir.update(shared);names=[v['id'] for v in ir['variables']]
        content_constraint_trace={}
        for node in layout['states']:
            group=node['initial'] is not None
            from unified_content_rules import content_constraints
            authored_content=content_constraints(request,node['id'])
            content_constraint_trace[node['id']]=copy.deepcopy(authored_content)
            named_resources,evidence=node_resource_mentions(request,node,catalog)
            content=opt(obj(dict(action_name=STR,queries=arr(STR,16),resources=arr(STR,32),max_candidates=dict(type='integer',minimum=1,maximum=32))))
            binding=content['anyOf'][0]['properties']
            binding['action_name']=enum([node['label']])
            if named_resources:
                binding['queries']['items']=enum(named_resources)
                binding['queries']['maxItems']=min(16,len(named_resources))
            elif authored_content['queries']:
                from unified_behavior import resolve_content
                mesh_id=next(a['id'] for a in catalog['assets'] if a['kind']=='mesh')
                available_queries=[query for query in authored_content['queries'] if resolve_content(dict(queries=[query],resources=[],max_candidates=1),catalog,mesh_id,'mm',authored_content['role'])[0]]
                allowed_queries=available_queries or authored_content['queries']
                binding['queries']['items']=enum(allowed_queries)
                binding['queries']['maxItems']=len(allowed_queries)
            if not selected_paths:binding['queries']['minItems']=1
            binding['queries']['items'].setdefault('minLength',1)
            if authored_content['max_candidates'] is not None:
                binding['max_candidates']=dict(type='integer',enum=[authored_content['max_candidates']])
            binding['resources']['maxItems']=len(selected_paths)
            if selected_paths:binding['resources']['items']=enum(selected_paths)
            schema=state_spec_schema(names,group,content['anyOf'][0])
            from unified_runtime_rules import authored_node_settings
            node_settings=authored_node_settings(request,node['id'])
            content_constraint_trace[node['id']]['node_settings']=node_settings
            for variant in schema.get('anyOf',[schema]):
                for field,value in node_settings.items():variant['properties'][field]=dict(type='number',enum=[value])
                for field in ('on_entry','on_exit','on_complete'):
                    if not node_callback_requested(request,node['id'],field):variant['properties'][field]['maxItems']=0
            def check_spec(spec):
                if spec['player'] in ('mm','group','locomotion') and (spec['lock_until_finished'] or spec['on_complete']):raise ValueError('MM/group不能锁定到播放完成或使用完成回调')
                if spec['player']=='group' and spec['loop']:raise ValueError('group.loop必须为false')
                if spec['player'] in ('mm','sequence','montage') and spec['content'] is None:raise ValueError('播放状态需要内容绑定声明，自定义动作也使用相同字段')
            spec=stage('state_'+node['id'],schema,dict(node=node,node_content_evidence=evidence,authored_content_constraints=authored_content,layout=layout,declarations=shared,instruction='Fill only this uniform node. action_name is free text, not a trained class. Only bind the animation names requested for THIS node; never copy every other node\'s resource. queries are AND-token name queries, alternatives form OR. Use precise tokens to separate crouch/standing or jump phases. Use no resource path unless the user supplies its exact path.'),check_spec)
            ir['states'].append(dict(node,**spec));save()
        ir['transitions']=[];ir['handlers']=[]
        state_ids=[n['id'] for n in ir['states']]
        from unified_runtime_rules import compile_runtime_rules,control_rule_lines,merge_selection_edges
        runtime_rules=compile_runtime_rules(request,ir['states'],ir['variables'],ir['inputs'])
        ir['inputs']=runtime_rules['inputs']
        ir['handlers']=copy.deepcopy(runtime_rules['handlers'])
        trace.append(dict(stage='runtime_rule_compiler',origin='deterministic_runtime_vocabulary_not_model_extraction',evidence=runtime_rules['evidence'],defaults=runtime_rules['defaults'],handled_lines=sorted(runtime_rules['handled_lines'])));save()
        source_lines=[dict(index=i,text=line) for i,line in enumerate(request.splitlines()) if line.strip()]
        line_ids=[line['index'] for line in source_lines]
        input_events=sorted({item['event'] for item in ir['inputs']})
        declared_events=set(re.findall(r'(?:事件|event)\s+([A-Za-z_][A-Za-z0-9_]*)',request))
        available_events=sorted(set(input_events)|set(RUNTIME_CONTRACT['events'])|declared_events)
        from unified_explicit_edges import compile_edges
        explicit_edges=None
        if not ir['variables'] and not ir['inputs'] and not re.search(r'事件|触发|计数|起跳|进入时|退出时|完成时',request):
            explicit_edges=compile_edges(request,state_ids,BUILTINS_V3)
        if explicit_edges is not None:
            ir['transitions']=explicit_edges
            trace.append(dict(stage='explicit_transition_compiler',origin='deterministic_user_expression_not_model_condition_extraction',output=copy.deepcopy(explicit_edges)));save()
        for task_index,task in enumerate([] if explicit_edges is not None else transition_tasks(request,state_ids)):
            target=task['target']
            source=task['source'];task_lines=task['lines']
            if target is None:task_lines=control_rule_lines(task_lines,runtime_rules['handled_lines'])
            if not task_lines:continue
            task_line_ids=[line['index'] for line in task_lines]
            if target is not None:
                from unified_explicit_edges import condition as compile_condition
                try:tree=compile_condition(task['expression'],set(BUILTINS_V3)|set(names))
                except (ValueError,SyntaxError):tree=None
                origin='deterministic_user_expression_not_model_extraction'
                if tree is None:
                    tree=builtin_prose_condition(task['expression'])
                    origin='deterministic_builtin_prose_predicate_not_model_extraction'
                if tree is not None:
                    parsed=dict({'from':source,'to':target,'event':'','all':[],'condition':tree,'priority':0,'interrupt':False,'actions':[],'source_quote':task_lines[0]['text']})
                    ir['transitions'].append(parsed)
                    trace.append(dict(stage='explicit_edge_'+str(task_index),origin=origin,output=copy.deepcopy(parsed)));save()
                    continue
            schema=generation_schema([],stage='transitions',state_ids=state_ids,variable_names=names,source=source,version=3)
            edge=schema['properties']['transitions']['items']
            edge['properties']['actions']=actions(names)
            edge['properties']['event']=enum(['']+available_events)
            edge['properties']['source_line']=dict(type='integer',enum=task_line_ids);edge['required'].append('source_line')
            if target is not None:
                edge['properties']['to']=enum([target])
                schema['properties']['transitions'].update(minItems=1,maxItems=1)
            condition={'$ref':'#/$defs/condition'}
            handler_actions=actions(names);handler_actions['minItems']=1
            handler=obj({'from':enum([source]),'event':enum(available_events),'condition':condition,'actions':handler_actions,'priority':dict(type='integer',minimum=-1000,maximum=1000),'source_line':dict(type='integer',enum=task_line_ids)})
            schema['properties']['handlers']=arr(handler,128);schema['required'].append('handlers')
            schema['properties']['unresolved']=arr(STR);schema['required'].append('unresolved')
            for field in ('transitions','handlers'):
                if prohibited[field]:schema['properties'][field]['maxItems']=0
            if target is not None:schema['properties']['handlers']['maxItems']=0
            def check_edges(out):
                for edge in out['transitions']+out['handlers']:
                    if edge['from']!=source or edge['source_line'] not in task_line_ids:raise ValueError('连线/事件来源或原文行号无效')
                for edge in out['transitions']:
                    line=request.splitlines()[edge['source_line']]
                    arrow=re.search(r'([A-Za-z_][A-Za-z0-9_]*)\s*(?:→|->|到)\s*([A-Za-z_][A-Za-z0-9_]*)\s*[:：]',line)
                    if arrow and (edge['from'],edge['to'])!=arrow.groups():raise ValueError('转换起终点与所引用原文不符：'+line)
                for handler in out['handlers']:
                    if not handler['event'].strip() or handler['event'].lower() in ('none','noop'):raise ValueError('内部事件需要真实非空触发事件')
                    if not handler['actions']:raise ValueError('内部事件不能没有动作')
                    text=request.splitlines()[handler['source_line']]
                    event_words={'Attack':r'攻击','Hit':r'受击|命中|伤害','Dodge':r'闪避','Landed':r'落地','Jumped':r'起跳|跳跃'}
                    if handler['event'] in event_words and not re.search(event_words[handler['event']],text):raise ValueError('事件触发与原文不符：'+handler['event']+'；'+text)
            instruction=('只处理request_lines中的这一条转换；起点、终点、行号已固定，只抽取本条条件和动作。不得处理其他转换或内部事件。无法实现的子规则写入unresolved。' if target is not None else '只抽取request_lines剩余自然语言中属于本source的出边和内部事件；显式箭头已经另行处理，绝对不要再次生成。没有要求时数组为空。不得凭名称发明动作或事件；无法实现的要求写入unresolved。')
            output=stage('edge_'+str(task_index)+'_'+source+('_'+target if target else '_residual'),schema,dict(source=source,target=target,request_lines=task_lines,layout=layout,declarations=shared,state_specs=ir['states'],instruction=instruction,_focus_request='\n'.join(x['text'] for x in task_lines)),check_edges)
            for item in output['transitions']+output['handlers']:
                item['source_quote']=request.splitlines()[item.pop('source_line')]
            ir['transitions'].extend(output['transitions']);ir['handlers'].extend(output['handlers']);ir['unresolved'].extend(output['unresolved']);save()
        ir['transitions']=merge_selection_edges(ir['transitions'],runtime_rules)
        ir['unresolved'].extend(runtime_rules['unresolved'])
        plan=compile_unified(ir,request,catalog,destination)
        plan['model_info']['model']=copy.deepcopy(info)
        plan['model_info']['behavior_generation'].update(requirements_log=str(log),trained_unified_adapter=False,origin='model_and_deterministic_compilers',content_constraints=content_constraint_trace)
        plan['model_info']['behavior_generation']['condition_generation']='explicit_expression_compiler' if explicit_edges is not None else 'anchored_expression_builtin_predicate_and_model_extraction'
        plan['model_info']['behavior_generation']['runtime_rule_defaults']=runtime_rules['defaults']
        save();return plan,ir,dict(mode='explicit_resource_or_name_query_not_trained_category')
    except Exception as error:
        save(str(error));raise
