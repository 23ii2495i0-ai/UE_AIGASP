import sys
import unittest
import copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from build_flow_data import make
from build_split_data import convert
from split_protocol import merge,validate_generator,score

class SplitProtocolTests(unittest.TestCase):
    def test_missing_requested_jump_is_blocked(self):
        from split_protocol import validate_action_coverage
        row,(g,s)=self.fixture();configuration=g['target']
        with self.assertRaisesRegex(ValueError,'jump'):validate_action_coverage('配置走跑跳蹲',configuration)
        with self.assertRaisesRegex(ValueError,'dodge'):validate_action_coverage('需要闪避翻滚',configuration)
        validate_action_coverage('不要跳跃',configuration)
    def test_jump_requires_action_slot(self):
        p=dict(roles=['idle','walk','run','jump'],slots={'idle':'locomotion','walk':'locomotion','run':'locomotion','jump':'locomotion'},blend_seconds=.2,filters={},policy={},reject=None)
        with self.assertRaisesRegex(ValueError,'jump:action'):validate_generator(p)
        self.assertIn('jump',p['roles']) # Validation never silently removes a requested role.
    def test_expanded_actions_compile_and_validate(self):
        from split_protocol import compile_split, generator_messages
        from protocol import compact_catalog
        import config_tool
        row,(g,s)=self.fixture();catalog=copy.deepcopy(row['catalog'])
        configuration=copy.deepcopy(g['target']);selection=copy.deepcopy(s['target'])
        skeleton=next(a['skeleton'] for a in catalog['assets'] if a['kind']=='mesh')
        for role in ('jump','dodge'):
            catalog['assets'].append(dict(id='/Game/'+role,name=role,kind='sequence',skeleton=skeleton,loop=False))
            configuration['slots'][role]='action'
        _,ids=compact_catalog(catalog)
        for role in ('jump','dodge'):selection['bindings'][role]=next(k for k,v in ids.items() if v=='/Game/'+role)
        plan=compile_split(catalog,'走跑跳蹲攻击受击闪避','/Game/Native/Generated/Expanded',configuration,selection,{})
        self.assertEqual([],config_tool.validate(plan,catalog))
        self.assertEqual(plan['runtime_flow']['actions']['jump'],'/Game/jump')
        self.assertIn('jump/dodge',generator_messages('',3)[0]['content'])
        catalog['assets'][-1]['loop']=True
        with self.assertRaises(ValueError):compile_split(catalog,'test','/Game/Test',configuration,selection,{})
    def test_unknown_action_slot_is_explained(self):
        p=dict(roles=['run'],slots={'run':'locomotion','dance':'action'},blend_seconds=.2,filters={},policy={},reject=None)
        with self.assertRaisesRegex(ValueError,'dance'):validate_generator(p)
    def test_invalid_selector_alias_is_discarded_without_mutation(self):
        from catalog_batches import checked_selection
        row,(g,s)=self.fixture();bad=copy.deepcopy(s['target']);role=next(iter(bad['bindings']));bad['bindings'][role]='a999999'
        checked,error=checked_selection(row['catalog'],g['target'],bad)
        self.assertTrue(error);self.assertTrue(all(v is None for v in checked['bindings'].values()))
        self.assertEqual(bad['bindings'][role],'a999999')
    def fixture(self):
        for i in range(100):
            row=make(i,'train')
            if row['target']['reject'] is None:return row,convert(row)
    def test_oracle_roundtrip(self):
        for i in range(100):
            row=make(i,'train');g,s=convert(row)
            merged=merge(row['catalog'],g['target'],s['target'])
            self.assertEqual(merged,row['target'])
    def test_generator_never_sees_catalog(self):
        row,(g,s)=self.fixture()
        self.assertEqual(g['messages'][1]['content'],row['request'])
        self.assertNotIn('catalog',g)
    def test_selector_cannot_change_policy(self):
        row,(g,s)=self.fixture();bad=copy.deepcopy(s['target']);bad['policy']={}
        with self.assertRaises(ValueError):merge(row['catalog'],g['target'],bad)
    def test_invented_resource_rejected(self):
        row,(g,s)=self.fixture();bad=copy.deepcopy(s['target']);bad['bindings'][g['target']['roles'][0]]='a999'
        with self.assertRaises(ValueError):merge(row['catalog'],g['target'],bad)
    def test_missing_issue_required(self):
        row,(g,s)=self.fixture();bad=copy.deepcopy(s['target']);bad['bindings'][g['target']['roles'][0]]=None
        with self.assertRaises(ValueError):merge(row['catalog'],g['target'],bad)
    def test_generator_cannot_bind(self):
        row,(g,s)=self.fixture();bad=copy.deepcopy(g['target']);bad['bindings']={}
        with self.assertRaises(ValueError):validate_generator(bad)
    def test_separate_evaluation(self):
        row,(g,s)=self.fixture()
        self.assertTrue(score('generator',g,g['target'])['exact'])
        self.assertTrue(score('selector',s,s['target'])['exact'])
if __name__=='__main__':unittest.main()
