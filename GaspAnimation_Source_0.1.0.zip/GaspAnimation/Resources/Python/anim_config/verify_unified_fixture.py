"""Deterministic execution fixture, never a model or user-approved draft."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import json
from pathlib import Path
from unified_behavior import compile_unified,PROTOCOL
from config_tool import validate

ROOT=_gasp_workspace
OUT=ROOT/'artifacts/anim_config/verification/unified_state_v1'
CAT=ROOT/'unreal/Saved/AnimationConfigurator/BDDE9D4545098AC2B70C159188A256C6/catalog.json'
request='待机；跑步；低姿观察；有输入时跑步；无输入时待机；下蹲时观察；解除下蹲后根据输入选择。'
nodes=[]
for id,label,query in [('State1','待机','M_Neutral_Stand_Idle_Loop'),('State2','跑步','M_Neutral_Run_Loop_F'),('State3','低姿观察','M_Neutral_Crouch_Idle_Loop')]:
    nodes.append(dict(id=id,label=label,source_quote=label,parent=None,initial=None,player='mm',loop=True,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2,on_entry=[],on_exit=[],on_complete=[],content=dict(action_name=label,queries=[query],resources=[],max_candidates=1)))
edges=[]
for a in ('State1','State2','State3'):
    for b,condition in [('State1',[dict(var='crouched',op='eq',value=False),dict(var='move_input',op='le',value=.01)]),('State2',[dict(var='crouched',op='eq',value=False),dict(var='move_input',op='gt',value=.01)]),('State3',[dict(var='crouched',op='eq',value=True)])]:
        if a!=b:edges.append(dict({'from':a,'to':b,'event':'','all':condition,'priority':10 if b=='State3' else 0,'interrupt':False,'source_quote':request}))
ir=dict(protocol=PROTOCOL,entry='State1',states=nodes,variables=[],inputs=[],transitions=edges,handlers=[],unresolved=[])
catalog=json.loads(CAT.read_text(encoding='utf-8-sig'))
p=compile_unified(ir,request,catalog,'/Game/Native/Generated/UnifiedExecutionFixture_20261026','rules')
# Separate, explicitly synthetic execution artifact. It does not approve or
# bypass the review of any model/user draft.
p['model_info']=dict(origin='deterministic_execution_fixture_not_model_or_user_approval',unified_fixture_ir=ir)
errors=validate(p,catalog)
if errors:raise RuntimeError(errors)
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'fixture_plan.json').write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8')
print('FIXTURE_VALID')
