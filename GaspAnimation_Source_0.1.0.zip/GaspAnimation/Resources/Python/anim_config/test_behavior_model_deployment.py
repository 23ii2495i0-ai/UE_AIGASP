import copy,unittest
from behavior_model_deployment import check_reports,TARGET_CLASS,REQUIRED_RUNTIME_CHECKS


class ExperimentalAcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.stages=dict(kind='teacher_forced_extraction_stages_not_end_to_end',n=96,exact=96,cases=[dict(id=str(i),stage=('topology','locomotion','jump','combo','dependencies','settings')[i%6],exact=True) for i in range(96)])
        self.pipeline=dict(completed=True,n=21,planned_n=21,cases=[dict(id=name,split='heldout' if i>=5 else 'development',requirements_exact=True,compiled_equivalence=True,manually_edited=False,fixture_bound=False,application_accepted=i in (1,2),model=dict(behavior_adapter_sha256='same')) for i,name in enumerate(['original_user_request','original_movement_jump','minimal_single_mm','counterfactual_numeric','short_ids_fresh_v3']+[str(n) for n in range(16)])])
        self.runtime=dict(animation_set='/Game/Isolated/DA_Config.DA_Config',character_class=TARGET_CLASS,failures=0,checks=[dict(name=name,passed=True) for name in sorted(REQUIRED_RUNTIME_CHECKS)]+[dict(name='extra'+str(i),passed=True) for i in range(4)])
    def check(self):return check_reports(self.stages,self.pipeline,self.runtime,'same','/Game/Isolated/DA_Config.DA_Config')
    def test_bounded_extraction_acceptance_never_approves_combat(self):
        result=self.check();self.assertFalse(result['combat_playback_validated']);self.assertTrue(result['requires_human_review'])
    def test_partial_pipeline_or_teacher_forced_only_cannot_activate(self):
        self.pipeline['completed']=False
        with self.assertRaises(ValueError):self.check()
        self.pipeline['completed']=True;self.stages['cases'][0]['exact']=False
        with self.assertRaises(ValueError):self.check()
    def test_mismatched_weights_manual_repair_and_fixtures_are_rejected(self):
        for change in (dict(model=dict(behavior_adapter_sha256='other')),dict(manually_edited=True),dict(fixture_bound=True),dict(requirements_exact=False)):
            before=copy.deepcopy(self.pipeline['cases'][0]);self.pipeline['cases'][0].update(change)
            with self.assertRaises(ValueError):self.check()
            self.pipeline['cases'][0]=before
    def test_wrong_target_class_config_or_failed_real_playback_is_rejected(self):
        for change in (dict(character_class='Fixture'),dict(animation_set='/Game/Other'),dict(failures=1),dict(checks=[dict(passed=False)]*14)):
            before=copy.deepcopy(self.runtime);self.runtime.update(change)
            with self.assertRaises(ValueError):self.check()
            self.runtime=before
    def test_schema_and_runtime_evidence_cannot_be_reused_after_source_change(self):
        with self.assertRaisesRegex(ValueError,'schema'):check_reports(self.stages,self.pipeline,self.runtime,'same',self.runtime['animation_set'],schema_sha='new-schema')
        with self.assertRaisesRegex(ValueError,'runtime'):check_reports(self.stages,self.pipeline,self.runtime,'same',self.runtime['animation_set'],runtime_sha='new-runtime')
    def test_minimal_ungrouped_probe_and_real_physics_checks_cannot_be_omitted(self):
        original=copy.deepcopy(self.pipeline)
        self.pipeline['cases']=[c for c in self.pipeline['cases'] if c['id']!='minimal_single_mm'];self.pipeline.update(n=20,planned_n=20)
        with self.assertRaisesRegex(ValueError,'required probe'):self.check()
        self.pipeline=original;self.runtime['checks']=[dict(name='unrelated',passed=True)]*14
        with self.assertRaisesRegex(ValueError,'runtime coverage'):self.check()


if __name__=='__main__':unittest.main()
