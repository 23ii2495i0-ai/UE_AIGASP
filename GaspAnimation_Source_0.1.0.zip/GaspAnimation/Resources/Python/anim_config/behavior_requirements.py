"""Reviewed requirement IR and deterministic feature compiler, not an NL parser.

Supported policies are explicit: ground MM, bounded air jumps, buffered combos,
and hit recovery. State IDs/parents come from model extraction and are frozen.
Unsupported prose remains a blocking issue. No sample graph is a fallback.
"""
import copy
import re
from behavior_graph import _id, _scalar, validate_graph, explicit_layout_errors
from landing_policy import STAGE_ROLES,landing_nodes,validate_landing,durations

COMPILER_VERSION=1
GROUND_ROLES=('idle','walk','run','crouch','crouch_idle','crouch_move')
CAPABILITIES={
    'vertical_speed':'Character.GetVelocity().Z',
    'move_input':'Character.RawMoveInput.Size() clamped to 0..1 before movement locking',
    'gait':'Character.Gait (Walk=0, Run=1, Sprint=2)',
    'crouched':'Character.bIsCrouched',
    'character_movement':'Existing native CharacterMovement handles walking, crouched capsule/height and movement. Native Crouch input toggles Character.Crouch/UnCrouch; no new external variable is needed.',
    'crouch_idle':'Supported independent stationary crouched MM database category; actual crouched=true and move_input<=0.01.',
    'crouch_move':'Supported independent moving crouched MM database category; actual crouched=true and move_input>0.01.',
    'jump_landing':'Optional separate recovery group: jump_start/jump_fall/jump_land/jump_land_run MM databases. Actual Landed event selects stationary or running recovery using a takeoff-run latch and current input/gait. Recovery exits by explicit state_time windows, not animation completion. Heavy running-land clips require semantic review for stumble appearance.',
    'animation_phase':'active montage position / length (0..1)',
    'falling':'CharacterMovement.IsFalling()',
    'Hit':'TakeDamage>0 or H input or Blueprint.SendEvent(Hit)',
    'Landed':'Character.Landed sends Landed after CMC landing',
    'jump':'LaunchCharacter; processed on the next CMC tick, Z override',
    'internal_handler':'conditional event actions, no transition/reentry, consumes event once',
}


def obj(properties):return dict(type='object',properties=properties,required=list(properties),additionalProperties=False)
def arr(items,maximum=32,minimum=0):return dict(type='array',items=items,maxItems=maximum,minItems=minimum)
def string():return dict(type='string')
def ident(names=None):return dict(type='string',**(dict(enum=names) if names else dict(pattern='^[A-Za-z_][A-Za-z0-9_]{0,63}$')))
def optional(schema):return dict(anyOf=[schema,dict(type='null')])


def source_identifiers(text):
    # Unicode \b considers adjacent Chinese characters word characters, so it
    # loses Ground in "Ground为父状态". IDs have ASCII boundaries instead.
    return sorted(set(re.findall(r'(?<![A-Za-z0-9_])[A-Za-z_][A-Za-z0-9_]{0,63}(?![A-Za-z0-9_])',text)))


def identifier_in(name,text):
    return re.search(r'(?<![A-Za-z0-9_])'+re.escape(name)+r'(?![A-Za-z0-9_])',text) is not None


def parent_declaration_in(text):
    return bool(re.search(r'父(?:状态|組|组|级)|(?:parent|group).{0,50}(?:contain|child)|(?:contains|has\s+children)',text,re.I))


def non_action_states(ir):
    """A movement leaf, air leaf or group cannot also be an action player."""
    ground=ir.get('locomotion') or {};jump=ir.get('jump') or {}
    return ({g['id'] for g in ir.get('topology',{}).get('groups',[])} |
            {ground[k] for k in ('group',)+GROUND_ROLES if ground.get(k)} |
            {jump[k] for k in ('group','rise','fall') if jump.get(k)} | landing_nodes(jump))


def explicitly_closed_group_states(request):
    return bool(re.search(r'除上述父组和子状态外[，,]?\s*不创建其他(?:行为)?状态',request))


def extraction_schema(stage,names=None,line_count=None,variable_names=None):
    ref=ident(names)
    if stage=='topology':
        return obj(dict(entry=ref,groups=arr(obj(dict(id=ref,children=arr(ref,minimum=1),initial=ref,source_lines=arr(dict(type='integer',minimum=0,maximum=max(0,(line_count or 1)-1)),8,1))))))
    if stage=='locomotion':return obj(dict(policy=optional(obj(dict(group=ref,idle=ref,walk=optional(ref),run=optional(ref),crouch=optional(ref),crouch_idle=optional(ref),crouch_move=optional(ref))))))
    if stage=='jump':return obj(dict(policy=optional(obj(dict(group=ref,rise=ref,fall=ref,counter=ident(variable_names),max_jumps=dict(type='integer',minimum=1,maximum=8),landing=optional(obj(dict(group=ref,land=ref,land_run=optional(ref),land_seconds=optional(dict(type='number',minimum=.05,maximum=5)),run_seconds=optional(dict(type='number',minimum=.05,maximum=5))))))))))
    if stage=='combo':return obj(dict(policy=optional(obj(dict(attacks=arr(ref,8,1),hit=ref,buffer=ident(variable_names))))))
    if stage=='dependencies':
        state_names=set(names or ())|set(variable_names or ())
        blocked={'JumpCount','Queued'}
        external_names=sorted(set(variable_names or ())-set(names or ())-blocked)
        unresolved=string();unresolved['not']={'enum':sorted(state_names|blocked|set(CAPABILITIES))}
        external_items=obj(dict(id=ident(external_names or []),initial=dict(anyOf=[dict(type='number'),dict(type='boolean')]),source=string()))
        return obj(dict(external_variables=arr(external_items,32 if external_names else 0),unsupported=arr(unresolved,32)))
    if stage=='settings':return obj({k:optional(dict(type='number')) for k in ('move_blend','attack_blend','hit_blend','window_start','window_end','jump_velocity')})
    raise ValueError('Unknown extraction stage')


EXTRACTION_SYSTEM='''Extract requirements, do not generate a state graph or code. Return only the JSON for this stage. Copy state identifiers exactly from the user's text. Do not invent extra states, parents, variables, inputs or examples. A group contains named children; it is not a locomotion leaf. Use null policy if the requested feature is absent. User-supplied English state identifiers must be preserved. Only extract the selected stage, not transitions. Defaults for keys/timing are compiler assumptions requiring review, not extracted facts. Builtin data and event bindings are supplied in capabilities; do not declare them as custom external variables. Counters and buffered-input flags are internal, never external. Unsupported requirements must be reported, not silently dropped.'''

STAGE_INSTRUCTIONS={
    'topology':'Extract ONLY explicitly named parent groups and their children, plus the entry. Do not list action states or variables in this stage. No implicit extra group. source_lines contains indices into the original request_lines proving the parent/children declaration. Do not create groups named after sections. Entry must be an existing top-level state. Do not describe players, variables, conditions or transitions.',
    'locomotion':'Extract the ground group and idle/walk/run/crouch child IDs. Use null for unrequested walk/run/crouch. If the request has only one ungrouped locomotion state, group=idle=that state.',
    'jump':'Extract air group, rising/falling children, internal jump counter name and maximum successful jumps. Do not count rejected key presses. Use null if no jump flow requested.',
    'combo':'Extract ordered attack state IDs, hit state ID and one internal boolean input buffer name. Use null if no attack/hit flow requested. Do not add states absent from source text. If no buffer name is supplied use Queued.',
    'dependencies':'List custom external VARIABLES not provided by capabilities and unsupported features. Builtin input/gait/velocity and native Hit/Landed events have actual runtime sources, not custom variables. Jump counter and input buffer are internal. Do not mark missing animation resources here; resource binding is later. If no custom variables or unsupported features, use empty arrays.',
    'settings':'Extract only explicit numeric settings. Missing values must be null. Blends are seconds; window_start/window_end are normalized clip phases and only if explicitly specified as such. Do not invent a jump velocity or timing window.'}


def extraction_messages(stage,request,reviewed):
    import json
    lines=[line.strip() for line in request.splitlines() if line.strip()]
    grounded=source_identifiers(request)
    topology=reviewed.get('topology',{})
    names=sorted({n for g in topology.get('groups',[]) for n in [g['id']]+g['children']}|set(topology.get('standalone',[])))
    variable_names=sorted(set(grounded)|({'JumpCount'} if stage=='jump' else {'Queued'} if stage=='combo' else set()))
    if stage=='dependencies':
        # Capitalized feature terms (for example "Motion" in "Motion Matching")
        # are not declarations. Only expose source identifiers explicitly
        # called variables, plus conventional bFoo external booleans such as bHit.
        declared=set()
        for match in re.finditer(r'(?i)(?:变量|variable)\s*(?:名为|叫做|named|called)?\s*([A-Za-z_][A-Za-z0-9_]*)|([A-Za-z_][A-Za-z0-9_]*)\s*(?:变量|variable)',request):
            declared.update(x for x in match.groups() if x)
        declared.update(n for n in grounded if re.fullmatch(r'b[A-Z][A-Za-z0-9_]*',n))
        variable_names=sorted(declared-set(names)-{'JumpCount','Queued'})
    schema=extraction_schema(stage,grounded if stage in ('topology','combo') else names,len(lines),variable_names)
    if stage=='combo':
        candidates=sorted((set(names) if explicitly_closed_group_states(request) else set(grounded))-non_action_states(reviewed))
        if not candidates:
            schema=obj(dict(policy=dict(type='null')))
        else:
            props=schema['properties']['policy']['anyOf'][0]['properties']
            props['attacks']=arr(ident(candidates),8,1);props['hit']=ident(candidates)
    if stage=='jump':
        recovery_groups=[g for g in topology.get('groups',[]) if re.search(r'land|recover',g['id'],re.I)]
        if recovery_groups:
            p=schema['properties']['policy']['anyOf'][0]['properties']
            landing=p['landing']['anyOf'][0];p['landing']=landing
            landing['properties']['group']=ident([g['id'] for g in recovery_groups])
            children=[n for g in recovery_groups for n in g['children']]
            stands=[n for n in children if re.fullmatch(r'(?:jump_?)?land(?:ing)?',n,re.I)]
            runs=[n for n in children if re.search(r'(?:land.*run|run.*land|stumble)',n,re.I)]
            if stands:landing['properties']['land']=ident(stands)
            if runs:landing['properties']['land_run']=ident(runs)
        air_groups=[]
        for group in topology.get('groups',[]):
            declaration='\n'.join(lines[i] for i in group.get('source_lines',[]) if 0<=i<len(lines)).lower()
            child_names=[n.lower() for n in group['children']]
            if any(word in declaration for word in ('空中','airborne','air group')) or (any(re.search(r'rise|ascend',n) for n in child_names) and any(re.search(r'fall|descend',n) for n in child_names)):
                air_groups.append(group)
        if air_groups:
            policy=schema['properties']['policy']['anyOf'][0]
            props=policy['properties'];props['group']=ident([g['id'] for g in air_groups])
            possible=[n for g in air_groups for n in g['children']]
            rises=[n for n in possible if re.search(r'(?:rise|up|ascend|jumpstart|jump_rise)',n,re.I)]
            falls=[n for n in possible if re.search(r'(?:fall|down|descend|jumpfall|jump_fall)',n,re.I)]
            if rises:props['rise']=ident(rises)
            if falls:props['fall']=ident(falls)
    if stage=='locomotion':
        prompt_roles=' Use crouch_idle for stationary crouching and crouch_move for moving while crouched. When both are requested, crouch must be null; preserve both distinct child IDs.'
        props=schema['properties']['policy']['anyOf'][0]['properties']
        split_idle=[n for n in names if re.fullmatch(r'crouch_?idle',n,re.I)]
        split_move=[n for n in names if re.fullmatch(r'crouch_?(?:move|walk)',n,re.I)]
        if split_idle and split_move:
            props['crouch_idle']=ident(split_idle);props['crouch_move']=ident(split_move)
            props['crouch']=dict(type='null')
    else:prompt_roles=''
    if stage=='jump':prompt_roles=' Optional landing policy names a separate recovery group, Land and optional LandRun MM child. Air still contains ONLY rise/fall. Landed enters recovery, not Air. Missing recovery times are null and become visible defaults; legacy jump without landing has landing=null. Running landing is chosen by takeoff Run gait and continued movement at touchdown.'
    prompt=dict(stage=stage,instruction=STAGE_INSTRUCTIONS[stage]+prompt_roles,request_lines=[dict(index=i,text=line) for i,line in enumerate(lines)],capabilities=CAPABILITIES,reviewed_requirements=reviewed)
    if stage=='locomotion' and not topology.get('groups') and len(names)==1:
        # The model must distinguish an idle-only leaf from the native chooser.
        # Older IR without this field retains its original idle-only meaning.
        policy=schema['properties']['policy']['anyOf'][0]
        policy['properties']['selection']=dict(type='string',enum=['native_ground','idle_only'])
        policy['required'].append('selection')
        prompt['instruction']+=' For a single leaf, selection=native_ground means selecting ground idle/walk/run internally from actual movement input and gait; selection=idle_only means explicitly idle-only. Choose from the user request. Neither creates extra graph states or transitions.'
    return schema,[dict(role='system',content=EXTRACTION_SYSTEM),dict(role='user',content=json.dumps(prompt,ensure_ascii=False))]


def prompt_fingerprint():
    import hashlib,json
    return hashlib.sha256(json.dumps(dict(system=EXTRACTION_SYSTEM,instructions=STAGE_INSTRUCTIONS,capabilities=CAPABILITIES),sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def validate_generated_symbols(ir,request):
    """Reject model-invented variable spellings; never rewrite a user's ID.

    The two conventional unnamed internal variables remain visible assumptions.
    This is a source-integrity guard, not a variable-role language parser.
    Manual IR edits are intentionally checked by the compiler, not this guard.
    """
    names=set(source_identifiers(request));defaults={}
    for policy,key,default in (('jump','counter','JumpCount'),('combo','buffer','Queued')):
        if not ir.get(policy):continue
        name=ir[policy][key]
        if name in names:continue
        if name!=default:raise ValueError('模型变量标识未在原文出现：'+name)
        defaults[policy+'.'+key]=name
    for var in ir.get('external_variables',[]):
        if var['id'] not in names:raise ValueError('模型外部变量标识未在原文出现：'+var['id'])
    return defaults


def validate_extracted_stage(stage,result,ir,request):
    """Cross-check model fields against already reviewed topology and explicit intent."""
    topology=ir.get('topology',{})
    groups={g['id']:g for g in topology.get('groups',[])}
    names={n for g in topology.get('groups',[]) for n in [g['id']]+g['children']}|set(topology.get('standalone',[]))
    if stage=='locomotion':
        policy=result.get('policy')
        if not policy:raise ValueError('需求包含地面移动但模型未给出locomotion策略')
        group=policy['group']
        if group not in groups:
            if not groups and names=={group} and policy['idle']==group and not any(policy.get(k) for k in GROUND_ROLES if k!='idle'):return True
            raise ValueError('locomotion.group必须引用已声明的地面父组')
        children=[policy[k] for k in GROUND_ROLES if policy.get(k)]
        if set(children)!=set(groups[group]['children']) or len(children)!=len(set(children)):
            raise ValueError('locomotion必须为地面父组的每个直接子状态指定恰好一个地面资源类别（含crouch_idle/crouch_move）')
        if policy['idle']!=groups[group]['initial']:
            raise ValueError('locomotion.idle必须与地面父组的initial状态一致')
    elif stage=='jump':
        requested=bool(re.search(r'(?<![A-Za-z0-9_])(?:JumpCount|JumpRise|JumpFall)(?![A-Za-z0-9_])|二段跳|多段跳|连续成功起跳',request))
        policy=result['policy']
        if requested and not policy:raise ValueError('原文明确要求跳跃流程，不能输出null policy')
        if policy:
            group=groups.get(policy['group'])
            if not group or policy['rise']==policy['fall'] or set(group['children'])!={policy['rise'],policy['fall']}:
                raise ValueError('跳跃策略须引用已声明的空中父组和两个不同的上升/下降状态')
            validate_landing(policy,groups,ir['locomotion'])
    elif stage=='dependencies':
        internals=names|set(CAPABILITIES)|({ir['jump']['counter']} if ir.get('jump') else set())|({ir['combo']['buffer']} if ir.get('combo') else set())
        duplicates=sorted({v['id'] for v in result['external_variables']}&internals)
        if duplicates:raise ValueError('以下变量已是状态ID或内部计数/缓冲变量，不能声明为外部变量：'+', '.join(duplicates))
        mislabeled=sorted({identifier for item in result['unsupported'] for identifier in source_identifiers(item)}&internals)
        if mislabeled:raise ValueError('以下已声明状态或受支持的内部变量不能列为unsupported：'+', '.join(mislabeled))
    elif stage=='combo' and result.get('policy'):
        policy=result['policy'];actions=policy['attacks']+[policy['hit']]
        overlaps=sorted(set(actions)&non_action_states(ir))
        if len(actions)!=len(set(actions)) or overlaps:
            raise ValueError('攻击和受击状态必须各不相同，且不能复用地面、蹲姿、空中状态或父组：'+', '.join(overlaps))
        if explicitly_closed_group_states(request) and set(actions)-names:
            raise ValueError('原文禁止在上述父组和子状态之外创建动作状态')
    return True


def anchor_topology(topology,request):
    """Compiler source mapping only: NEVER changes IDs, parents or initials.

    Model-generated line offsets are not semantic facts. Locate exact identifier
    spans in the actual source; ambiguous or absent spans remain hard failures.
    Raw model offsets stay in the extraction trace for audit.
    """
    result=copy.deepcopy(topology)
    lines=[line.strip() for line in request.splitlines() if line.strip()]
    for group in result['groups']:
        if not group['children'] or group['id'] in group['children'] or group['initial'] not in group['children']:
            raise ValueError('无效父组 '+group['id']+'：必须有非自身的子状态，initial 必须引用直接子状态；叶子状态不应放入 groups')
        names=[group['id']]+group['children']
        candidates=[]
        for width in range(1,9):
            for start in range(len(lines)-width+1):
                text='\n'.join(lines[start:start+width])
                if parent_declaration_in(lines[start]) and identifier_in(group['id'],lines[start]) and all(identifier_in(name,text) for name in names):candidates.append(list(range(start,start+width)))
            if candidates:break
        if len(candidates)!=1:raise ValueError('父子声明的原文位置缺失或不唯一：'+group['id'])
        group['source_lines']=candidates[0]
    return result


def validate_topology(topology,request):
    if set(topology)!={'entry','groups','standalone'}:raise ValueError('Invalid topology fields')
    all_names=[];parents={}
    for group in topology['groups']:
        if re.search(r'(?<![A-Za-z0-9_])'+re.escape(group['id'])+r'\s*是叶子状态',request):
            raise ValueError('原文明确声明为叶子状态，不能输出为父组：'+group['id'])
        if set(group)!={'id','children','initial','source_lines'} or not group['children'] or group['initial'] not in group['children']:raise ValueError('Group needs children and direct initial child')
        lines=[line.strip() for line in request.splitlines() if line.strip()]
        if not group['source_lines'] or any(type(i) is not int or not 0<=i<len(lines) for i in group['source_lines']):raise ValueError('Group source lines are invalid')
        evidence='\n'.join(lines[i] for i in group['source_lines'])
        if any(not identifier_in(name,evidence) for name in [group['id']]+group['children']):raise ValueError('Group source lines must name parent and every child')
        all_names.append(group['id'])
        for child in group['children']:
            if child in parents:raise ValueError('Child assigned to multiple groups: '+child)
            parents[child]=group['id']
    all_names+=list(parents)+topology['standalone']
    names=set(all_names)
    groups={g['id']:g for g in topology['groups']}
    # A group may itself be a child. Leaves cannot be separately redeclared.
    if len(topology['standalone'])!=len(set(topology['standalone'])) or set(topology['standalone'])&(set(parents)|set(groups)):raise ValueError('Duplicate standalone state')
    if len(groups)!=len(topology['groups']) or not 1<=len(names)<=32:raise ValueError('Duplicate/excessive group or state IDs')
    for name in names:
        if not _id(name) or not identifier_in(name,request):raise ValueError('State not grounded in request: '+name)
        seen={name};node=name
        while node in parents:
            node=parents[node]
            if node in seen or len(seen)>=8:raise ValueError('Cyclic or excessive hierarchy')
            seen.add(node)
    if topology['entry'] not in names or topology['entry'] in parents:raise ValueError('Entry must be an existing top-level state')
    skeleton={'states':[dict(id=n,player='group' if n in groups else 'locomotion',**({'parent':parents[n]} if n in parents else {})) for n in names]}
    errors=explicit_layout_errors(request,skeleton)
    if errors:raise ValueError('; '.join(errors))
    return sorted(names)


def validate_requirements(ir,request):
    names=validate_topology(ir['topology'],request);name_set=set(names)
    if set(ir)!={'version','topology','locomotion','jump','combo','external_variables','unsupported','settings'} or ir['version']!=1:raise ValueError('Invalid requirement IR')
    groups={g['id']:g for g in ir['topology']['groups']}
    assigned=set(groups)
    def refs(values):
        if any(v not in name_set for v in values):raise ValueError('Policy references an undeclared state')
    ground=ir['locomotion']
    if not ground:raise ValueError('This compiler requires a ground locomotion policy')
    native_ground=ground.get('selection')=='native_ground'
    if not {'group','idle','walk','run'}<=set(ground) or set(ground)-({'group','selection'}|set(GROUND_ROLES)):raise ValueError('Invalid locomotion policy')
    if ground.get('crouch') and (ground.get('crouch_idle') or ground.get('crouch_move')):raise ValueError('不能同时使用合并crouch和分离crouch_idle/crouch_move')
    if bool(ground.get('crouch_idle'))!=bool(ground.get('crouch_move')):raise ValueError('蹲姿分离需要同时声明crouch_idle与crouch_move')
    if 'selection' in ground and ground['selection'] not in ('native_ground','idle_only'):raise ValueError('Unknown locomotion selection')
    if native_ground and (ir['topology']['groups'] or len(names)!=1 or ground['group']!=ground['idle'] or ground['walk'] is not None or ground['run'] is not None or ir['jump'] is not None or ir['combo'] is not None or ir['external_variables'] or ir['unsupported']):
        raise ValueError('Native ground selection requires exactly one ungrouped locomotion leaf without extra logic')
    children=[ground[k] for k in GROUND_ROLES if ground.get(k)]
    refs([ground['group']]+children)
    if ground['group'] not in groups:
        if children!=[ground['group']]:raise ValueError('Ungrouped locomotion supports one leaf only')
    elif set(groups[ground['group']]['children'])!=set(children) or len(children)!=len(set(children)):raise ValueError('Ground policy must cover its declared direct children exactly')
    assigned.update(children)
    jump=ir['jump']
    if jump:
        if not {'group','rise','fall','counter','max_jumps'}<=set(jump) or set(jump)-{'group','rise','fall','counter','max_jumps','landing'} or type(jump['max_jumps']) is not int or not 1<=jump['max_jumps']<=8 or not _id(jump['counter']):raise ValueError('Invalid jump policy')
        refs([jump[k] for k in ('group','rise','fall')])
        if jump['group'] not in groups or set(groups[jump['group']]['children'])!={jump['rise'],jump['fall']} or jump['rise']==jump['fall']:raise ValueError('Air policy must cover Rise/Fall children exactly')
        assigned.update((jump['rise'],jump['fall']))
        assigned.update(validate_landing(jump,groups,ground))
    combo=ir['combo']
    if combo:
        if set(combo)!={'attacks','hit','buffer'} or not 1<=len(combo['attacks'])<=8 or len(combo['attacks'])!=len(set(combo['attacks'])) or not _id(combo['buffer']):raise ValueError('Invalid combo policy')
        overlaps=set(combo['attacks']+[combo['hit']])&non_action_states(ir)
        if overlaps:raise ValueError('攻击/受击状态不能复用地面、蹲姿、空中状态或父组：'+', '.join(sorted(overlaps)))
        refs(combo['attacks']+[combo['hit']]);assigned.update(combo['attacks']+[combo['hit']])
        if combo['hit'] in combo['attacks']:raise ValueError('Hit cannot be an attack state')
    if assigned!=name_set:raise ValueError('Unsupported/unassigned states: '+', '.join(sorted(name_set-assigned)))
    if (jump and combo and jump['counter']==combo['buffer']):raise ValueError('Counter and buffer variables must differ')
    variables=set()
    for var in ir['external_variables']:
        if set(var)!={'id','initial','source'} or not _id(var['id']) or not _scalar(var['initial']) or not var['source'] or var['id'] in variables:raise ValueError('Invalid external variable declaration')
        variables.add(var['id'])
    if variables & ({jump['counter']} if jump else set()) | variables & ({combo['buffer']} if combo else set()):raise ValueError('Internal variable declared external')
    settings=ir['settings']
    if set(settings)!={'move_blend','attack_blend','hit_blend','window_start','window_end','jump_velocity'}:raise ValueError('Unknown settings')
    if any(type(v) not in (int,float) or not _scalar(v) for v in settings.values()):raise ValueError('Settings must be finite numbers, not booleans')
    if not 0<=settings['window_start']<settings['window_end']<=1:raise ValueError('Invalid normalized combo window')
    if not 1<=settings['jump_velocity']<=2000 or any(not 0<=settings[k]<=2 for k in ('move_blend','attack_blend','hit_blend')):raise ValueError('Invalid timing/launch settings')
    declared_vars=([jump['counter']] if jump else [])+(['JumpWasRunning'] if jump and jump.get('landing') else [])+([combo['buffer']] if combo else [])+list(variables)
    from behavior_graph import BUILTINS_V3
    if len({v.lower() for v in declared_vars})!=len(declared_vars) or any(v.lower() in BUILTINS_V3 for v in declared_vars):raise ValueError('Conflicting or reserved variable IDs')
    errors=explicit_fact_errors(ir,request)
    if errors:raise ValueError('; '.join(errors))
    return names


def explicit_fact_errors(ir,request):
    """Narrow literal-integrity guards, NOT a general-language interpreter.

    Reject contradictions to recognizable explicit constraints; never repair
    model facts, add states, or claim unrecognized prose has been understood.
    """
    errors=[];settings=ir['settings'];number=r'([0-9]+(?:\.[0-9]+)?)'
    patterns={
        'move_blend':[r'普通移动[^\n。]{0,12}?混合\s*'+number+r'\s*秒',r'Blends in seconds:\s*ground\s+'+number],
        'attack_blend':[r'攻击[^\n。]{0,8}?混合\s*'+number+r'\s*秒',r'Blends in seconds:[^\n]*?attacks\s+'+number],
        'hit_blend':[r'受击[^\n。]{0,8}?混合\s*'+number+r'\s*秒',r'Blends in seconds:[^\n]*?hit\s+'+number],
        'jump_velocity':[r'Jump launch velocity:\s*'+number,r'起跳速度\s*[:：]?\s*'+number]}
    for key,choices in patterns.items():
        for pattern in choices:
            for value in re.findall(pattern,request,re.I):
                if float(value)!=settings[key]:errors.append(key+'与原文显式数值冲突')
    window=r'Normalized combo window:\s*'+number+r'\s*to\s*'+number
    for start,end in re.findall(window,request,re.I):
        if (float(start),float(end))!=(settings['window_start'],settings['window_end']):errors.append('归一化窗口与原文显式数值冲突')
    if ir['jump']:
        counter=ir['jump']['counter']
        for limit in re.findall(r'(?<![A-Za-z0-9_])'+re.escape(counter)+r'\s*<\s*([0-9]+)',request):
            if int(limit)!=ir['jump']['max_jumps']:errors.append('起跳上限与原文显式条件冲突')
    ident_pattern=r'[A-Za-z_][A-Za-z0-9_]*'
    for line in request.splitlines():
        if '连招' not in line and 'Attack combo order:' not in line:continue
        for chain in re.findall(r'('+ident_pattern+r'(?:\s*(?:→|->)\s*'+ident_pattern+r')+)',line):
            expected=re.findall(ident_pattern,chain)
            if not ir['combo'] or ir['combo']['attacks']!=expected:errors.append('攻击顺序与原文显式连招链冲突')
    return errors


def compile_requirements(ir,request,bindings=None):
    """Translate reviewed feature policies; never infer identifiers from prose."""
    names=validate_requirements(ir,request);bindings=bindings or {}
    topology=ir['topology'];groups={g['id']:g for g in topology['groups']}
    parents={child:g['id'] for g in topology['groups'] for child in g['children']}
    settings=ir['settings'];ground=ir['locomotion'];jump=ir['jump'];combo=ir['combo']
    graph=dict(version=3,entry=topology['entry'],variables={},variable_sources={},inputs=[],states=[],transitions=[],handlers=[])
    def var(name,value,scope='internal',source='graph actions'):
        graph['variables'][name]=value;graph['variable_sources'][name]=dict(scope=scope,source=source)
    def set_(name,value):return dict(op='set',var=name,value=value)
    def pred(name,op,value):return dict(var=name,op=op,value=value)
    def all_(*conditions):return dict(all=list(conditions))
    def edge(source,to,event='',conditions=(),priority=0,interrupt=False,actions=()):
        graph['transitions'].append(dict({'from':source,'to':to,'event':event,'all':list(conditions),'priority':priority,'interrupt':interrupt,'actions':list(actions)}))
    def handler(source,event,condition,actions,priority=0):
        graph['handlers'].append(dict({'from':source,'event':event,'condition':condition,'actions':actions,'priority':priority}))
    def input_(key,event):graph['inputs'].append(dict(key=key,phase='pressed',event=event,set={}))
    roles={ground[k]:k for k in GROUND_ROLES if ground.get(k)}
    if jump:roles.update({jump['rise']:'jump',jump['fall']:'jump'});var(jump['counter'],0)
    landing=jump.get('landing') if jump else None
    if landing:
        var('JumpWasRunning',False)
        roles.update({jump['rise']:'jump_start',jump['fall']:'jump_fall',landing['land']:'jump_land'})
        if landing['land_run']:roles[landing['land_run']]='jump_land_run'
    if combo:var(combo['buffer'],False)
    for value in ir['external_variables']:var(value['id'],value['initial'],'external',value['source'])
    for name in names:
        is_group=name in groups;is_action=combo and name in combo['attacks']+[combo['hit']]
        native_leaf=ground.get('selection')=='native_ground' and name==ground['group']
        node=dict(id=name,player='group' if is_group else 'sequence' if is_action else 'locomotion' if native_leaf else 'mm',resources=list(bindings.get(name,[])) if is_action else [],loop=not(is_group or is_action),allow_movement=not bool(is_action),lock_until_finished=bool(is_action),min_duration=0,blend_seconds=settings['move_blend'])
        if name in parents:node['parent']=parents[name]
        if is_group:node['initial']=groups[name]['initial']
        if name in roles and not native_leaf:node['database_role']=roles[name]
        if is_action:
            node['blend_seconds']=settings['hit_blend'] if name==combo['hit'] else settings['attack_blend']
            node['on_entry']=[set_(combo['buffer'],False)]
            node['on_exit']=[set_(combo['buffer'],False)]
        graph['states'].append(node)
    # Entry to a ground group always resolves to its reviewed initial child;
    # automatic selection runs one edge per tick using actual input/gait data.
    for source in [ground[k] for k in GROUND_ROLES if ground.get(k)]:
        if ground.get('crouch_idle'):
            for role,op in [('crouch_idle','le'),('crouch_move','gt')]:
                if source!=ground[role]:edge(source,ground[role],conditions=[pred('crouched','eq',True),pred('move_input',op,.01)])
        if ground.get('crouch') and source==ground['crouch']:
            edge(source,ground['idle'],conditions=[pred('crouched','eq',False)])
            continue
        if ground.get('crouch'):edge(source,ground['crouch'],conditions=[pred('crouched','eq',True)])
        if source!=ground['idle']:edge(source,ground['idle'],conditions=[pred('move_input','le',.01)]+([pred('crouched','eq',False)] if ground.get('crouch') or ground.get('crouch_idle') else []))
        for gait,role in [(0,'walk'),(1,'run')]:
            target=ground[role] or ground['run'] or ground['walk'] or ground['idle']
            if target!=source:edge(source,target,conditions=[pred('move_input','gt',.01),pred('gait','eq' if gait==0 else 'ge',gait)]+([pred('crouched','eq',False)] if ground.get('crouch') or ground.get('crouch_idle') else []))
    if jump:
        input_('SpaceBar','Jump')
        launch=[dict(op='jump',velocity=settings['jump_velocity']),dict(op='add',var=jump['counter'],value=1)]
        allowed=pred(jump['counter'],'lt',jump['max_jumps'])
        if landing:
            if ground.get('run'):edge(ground['run'],jump['group'],'Jump',conditions=[allowed],priority=10,actions=launch+[set_('JumpWasRunning',True)])
            edge(ground['group'],jump['group'],'Jump',conditions=[allowed],actions=launch+[set_('JumpWasRunning',False)])
        else:edge(ground['group'],jump['group'],'Jump',conditions=[allowed],actions=launch)
        handler(jump['group'],'Jump',allowed,launch,10)
        edge(jump['rise'],jump['fall'],conditions=[pred('vertical_speed','lt',0)])
        edge(jump['fall'],jump['rise'],conditions=[pred('vertical_speed','ge',0)])
        # Landed is an actual Character callback, so no false landing occurs in
        # the tick between LaunchCharacter and CMC processing its pending launch.
        if landing:
            land_time,run_time=durations(landing)
            if landing['land_run']:
                edge(jump['group'],landing['land_run'],'Landed',conditions=[pred('JumpWasRunning','eq',True),pred('move_input','gt',.01),pred('gait','ge',1),pred('crouched','eq',False)],priority=310,interrupt=True,actions=[set_(jump['counter'],0)])
            edge(jump['group'],landing['land'],'Landed',priority=300,interrupt=True,actions=[set_(jump['counter'],0)])
            for state,seconds in [(landing['land'],land_time)]+([(landing['land_run'],run_time)] if landing['land_run'] else []):
                # State time is a reviewed recovery window, not MM clip completion.
                for target,conditions in [(ground['idle'],[pred('move_input','le',.01),pred('crouched','eq',False)]),
                    (ground.get('walk') or ground['idle'],[pred('move_input','gt',.01),pred('gait','eq',0),pred('crouched','eq',False)]),
                    (ground.get('run') or ground.get('walk') or ground['idle'],[pred('move_input','gt',.01),pred('gait','ge',1),pred('crouched','eq',False)])]:
                    edge(state,target,conditions=[pred('state_time','ge',seconds)]+conditions)
                edge(state,ground['group'],conditions=[pred('state_time','ge',seconds),pred('crouched','eq',True)])
            edge(landing['group'],jump['group'],conditions=[pred('falling','eq',True)],priority=50)
            edge(landing['group'],jump['group'],'Jump',conditions=[allowed,pred('move_input','gt',.01),pred('gait','ge',1),pred('crouched','eq',False)],priority=60,actions=launch+[set_('JumpWasRunning',True)])
            edge(landing['group'],jump['group'],'Jump',conditions=[allowed],priority=50,actions=launch+[set_('JumpWasRunning',False)])
        else:edge(jump['group'],ground['group'],'Landed',priority=300,interrupt=True,actions=[set_(jump['counter'],0)])
        handler('*','Landed',pred(jump['counter'],'gt',0),[set_(jump['counter'],0)],290)
        edge(ground['group'],jump['group'],conditions=[pred('falling','eq',True)],priority=20,actions=[set_('JumpWasRunning',False)] if landing else [])
        if landing and ground.get('run'):edge(ground['run'],jump['group'],conditions=[pred('falling','eq',True)],priority=30,actions=[set_('JumpWasRunning',True)])
    if combo:
        input_('LeftMouseButton','Attack');input_('H','Hit')
        edge(ground['group'],combo['attacks'][0],'Attack')
        for i,name in enumerate(combo['attacks']):
            if i+1<len(combo['attacks']):
                handler(name,'Attack',all_(pred('animation_phase','ge',settings['window_start']),pred('animation_phase','le',settings['window_end']),pred(combo['buffer'],'eq',False)),[set_(combo['buffer'],True)],10)
                edge(name,combo['attacks'][i+1],conditions=[pred('finished','eq',True),pred(combo['buffer'],'eq',True)],priority=10)
                edge(name,ground['group'],conditions=[pred('finished','eq',True),pred(combo['buffer'],'eq',False)])
            else:edge(name,ground['group'],conditions=[pred('finished','eq',True)])
        # A source-scoped Hit edge for every requested state avoids a recursive
        # global Hit->Hit restart and preserves the selected interrupted policy.
        for name in names:
            if name!=combo['hit']:edge(name,combo['hit'],'Hit',priority=500,interrupt=True)
        edge(combo['hit'],ground['group'],conditions=[pred('finished','eq',True)]+([pred('falling','eq',False)] if jump else []))
        if jump:edge(combo['hit'],jump['group'],conditions=[pred('finished','eq',True),pred('falling','eq',True)])
    resource_roles={'idle','walk','run'} if ground.get('selection')=='native_ground' else set(roles.values())
    return graph,sorted(resource_roles,key=lambda x:['idle','walk','run','sprint','crouch','crouch_idle','crouch_move','jump',*STAGE_ROLES].index(x))


def semantic_audit(ir,request,graph):
    bindings={s['id']:s.get('resources',[]) for s in graph['states']}
    expected,_=compile_requirements(ir,request,bindings)
    return [] if expected==graph else ['状态图已偏离已审阅需求的编译结果；需要重新审阅需求和语义验收，不能沿用旧验收标记']


def resource_bindings(ir,catalog):
    """Name candidates only. Known playback fixtures never count as content."""
    bindings={};issues=[]
    if not ir['combo']:return bindings,issues
    skeletons={a.get('skeleton') for a in catalog['assets'] if a['kind']=='mesh'}
    for state in ir['combo']['attacks']+[ir['combo']['hit']]:
        role='hit' if state==ir['combo']['hit'] else 'attack'
        words=('hit','hurt','reaction') if role=='hit' else ('attack','strike','melee')
        matches=[a for a in catalog['assets'] if a['kind']=='sequence' and a.get('skeleton') in skeletons and len(skeletons)==1 and not a.get('loop') and not a.get('additive') and any(w in a.get('name','').lower() for w in words) and '/actionflowfixture/' not in a['id'].lower() and 'playbacktest' not in a.get('name','').lower()]
        if len(matches)==1 and (role=='hit' or len(ir['combo']['attacks'])==1):
            bindings[state]=[matches[0]['id']]
            issues.append(dict(severity='warning',code='behavior_content_review',message=state+'仅按名称选择候选，尚须人工确认动作内容：'+matches[0]['id']))
        else:issues.append(dict(severity='error',code='behavior_resource_missing',message=state+' 缺少唯一可审阅的真实 '+role+' 动画；PlaybackTest/ActionFlowFixture不作为战斗素材。'))
    return bindings,issues
