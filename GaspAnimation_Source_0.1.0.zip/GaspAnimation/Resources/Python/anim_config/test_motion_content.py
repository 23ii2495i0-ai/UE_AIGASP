import copy
import unittest
from motion_content import BONES,describe,inspect_asset


class MotionContentTests(unittest.TestCase):
    def asset(self):
        frames=[{'time':i/15,'root_position_cm':[i*10,0,0],
                 'positions_root_cm':{b:[i if b=='hand_l' else 0,0,80] for b in BONES}} for i in range(16)]
        return {'id':'/Game/A','name':'attack','motion_samples':{'status':'sampled','reference_height_cm':160,'frames':frames}}

    def test_names_cannot_create_semantics(self):
        a=self.asset();b=copy.deepcopy(a);b['name']='hit';b['id']='/Game/Renamed'
        ra,rb=inspect_asset(a),inspect_asset(b)
        self.assertEqual(ra['features'],rb['features']);self.assertEqual(ra['semantic_role'],'unknown')
        self.assertFalse(ra['usable_for_auto_binding']);self.assertIsNone(ra['confidence'])

    def test_velocity_and_scale_normalization(self):
        a=self.asset()['motion_samples'];b=copy.deepcopy(a);b['reference_height_cm']*=2
        for f in b['frames']:
            f['root_position_cm']=[2*x for x in f['root_position_cm']]
            f['positions_root_cm']={k:[2*x for x in p] for k,p in f['positions_root_cm'].items()}
        self.assertEqual(describe(a),describe(b));self.assertGreater(describe(a)['hand_l.speed_mean'],0)

    def test_incomplete_and_invalid_pose_unknown(self):
        a=self.asset();a['motion_samples']['frames']=a['motion_samples']['frames'][:2]
        self.assertNotIn('features',inspect_asset(a))
        a=self.asset();a['motion_samples']['frames'][2]['time']=0
        self.assertEqual(inspect_asset(a)['reason'],'invalid_sample_times')

    def test_sampling_failure_preserved(self):
        a=self.asset();a['motion_samples']={'status':'unknown','reason':'sampling_failed'}
        self.assertEqual(inspect_asset(a)['reason'],'sampling_failed')


if __name__=='__main__':unittest.main()
