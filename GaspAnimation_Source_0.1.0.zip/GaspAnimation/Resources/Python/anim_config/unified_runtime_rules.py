"""Compile explicitly supported runtime rule vocabulary into uniform graph data.

No state IDs or counter names are reserved. This is a deterministic compiler,
not a trained extractor, and never fills reachability with unconditional edges.
"""
import copy
import re

def pred(var,op,value):return dict(var=var,op=op,value=value)

def transition(source,target,conditions,quote,priority=20):
    return {'from':source,'to':target,'event':'','all':conditions,'priority':priority,'interrupt':False,'actions':[],'source_quote':quote}

def authored_node_settings(request,node_id):
    """Missing timing is a visible compiler default, never a model invention."""
    token=r'(?<![A-Za-z0-9_])'+re.escape(node_id)+r'(?![A-Za-z0-9_])'
    number=r'(\d+(?:\.\d+)?)'
    blend=[];duration=[]
    for line in request.splitlines():
        if re.search(token,line):
            m=re.search(r'(?:最短停留|至少停留|停留时间)\s*(?:为|[:：=])?\s*'+number+r'\s*秒',line)
            if m:duration.append(float(m[1]))
        m=re.search(r'混合时间\s*(?:先使用|使用|为|[:：=])?\s*'+number+r'\s*秒',line)
        if m:blend.append(float(m[1]))
    if len(set(duration))>1 or len(set(blend))>1:raise ValueError('状态计时或混合时间声明有冲突：'+node_id)
    minimum=duration[0] if duration else 0.
    seconds=blend[0] if blend else .2
    if not 0<=minimum<=60 or not 0<=seconds<=2:raise ValueError('状态计时或混合时间超出运行时范围：'+node_id)
    return dict(min_duration=minimum,blend_seconds=seconds)

def compile_runtime_rules(request,states,variables,inputs):
    lines=request.splitlines();by_id={s['id']:s for s in states}
    result=dict(transitions=[],handlers=[],inputs=copy.deepcopy(inputs),handled_lines=set(),selector_nodes=set(),evidence=[],defaults={},unresolved=[])
    roles={}
    # These phrases describe actual runtime predicates, not animation classes.
    vocabulary={'站立待机':(False,'le',None),'站立行走':(False,'gt',0),'站立跑步':(False,'gt',1),
                '蹲姿待机':(True,'le',None),'蹲姿移动':(True,'gt',None)}
    for i,line in enumerate(lines):
        for match in re.finditer(r'([A-Za-z_][A-Za-z0-9_]*)[（(]([^）)]+)[）)]',line):
            name,description=match.groups()
            if name in by_id and description in vocabulary and by_id[name]['player']!='group':
                roles[name]=(vocabulary[description],i)
    selection=[i for i,l in enumerate(lines) if re.search(r'下蹲状态优先|移动输入.{0,30}步态.{0,30}下蹲状态选择',l)]
    selection.sort(key=lambda i:bool(re.search(r'→|->',lines[i])))
    thresholds={float(v) for v in re.findall(r'move_input\s*(?:>=|<=|>|<)\s*([0-9.]+)',request)}
    if selection and roles:
        parents={by_id[n]['parent'] for n in roles}
        if len(parents)==1 and None not in parents and any(v[0][0] for v in roles.values()) and any(not v[0][0] for v in roles.values()):
            if len(thresholds)>1:
                result['unresolved'].append('地面选择存在多个输入阈值，不能自动合并：'+str(sorted(thresholds)))
            else:
                threshold=next(iter(thresholds),.01)
                result['defaults'].update(move_input_threshold=threshold,selection_priority=20)
                result['selector_nodes']=set(roles)
                for target,((crouched,op,gait),line_index) in roles.items():
                    conditions=[pred('falling','eq',False),pred('crouched','eq',crouched),pred('move_input',op,threshold)]
                    if gait is not None:conditions.append(pred('gait','eq' if gait==0 else 'ge',gait))
                    for source in roles:
                        if source!=target:result['transitions'].append(transition(source,target,copy.deepcopy(conditions),lines[selection[0]]))
                result['evidence'].append(dict(kind='named_runtime_selection',declarations=sorted({i for _,i in roles.values()}),rules=selection,states=sorted(roles)))
                targets='(?:'+'|'.join(re.escape(n) for n in roles)+')'
                standing='(?:行走|跑步|Walk|Run|'+'|'.join(re.escape(n) for n,v in roles.items() if not v[0][0])+')'
                patterns=[r'蹲姿移动停止后\s*进入\s*'+targets,r'蹲姿期间有移动输入\s*进入\s*'+targets,r'下蹲状态优先于站立\s*'+standing+r'(?:\s*(?:或|/|、)\s*'+standing+r')*']
                for i,line in enumerate(lines):
                    clauses=[c.strip().lstrip('-* ').strip() for c in re.split(r'[。；;]',line) if c.strip()]
                    if clauses and all(any(re.fullmatch(p,c) for p in patterns) for c in clauses):result['handled_lines'].add(i)
    # A bounded launch rule requires all evidence, not just a familiar variable
    # name or the word "jump". Unknown/incomplete forms stay on the model path.
    bounds=[(i,int(m[1])) for i,l in enumerate(lines) if (m:=re.search(r'最多(?:允许)?(?:成功)?起跳\s*(\d+)\s*次',l))]
    counters=[]
    for variable in variables:
        name=variable['id']
        increment=[i for i,l in enumerate(lines) if '真实起跳' in l and re.search(r'(?<![A-Za-z0-9_])'+re.escape(name)+r'\s*加\s*1',l)]
        reset=[i for i,l in enumerate(lines) if '真实落地' in l and re.search(re.escape(name)+r'\s*清零',l)]
        if increment and reset:counters.append((variable,increment,reset))
    presses=[i for i,l in enumerate(lines) if re.search(r'按下\s*Space',l)]
    no_repeat=[i for i,l in enumerate(lines) if re.search(r'按住\s*Space.*不得重复计数',l)]
    if len(counters)==1 and bounds and len({n for _,n in bounds})==1 and presses and no_repeat:
        variable,increment,reset=counters[0];limit=bounds[0][1];name=variable['id']
        if variable['scope']!='internal' or type(variable['initial']) is not int or variable['initial']!=0:
            result['unresolved'].append('跳跃计数必须保留原文明示的内部整数初始值0：'+name)
        elif not 1<=limit<=8:
            result['unresolved'].append('当前有界跳跃编译只支持1～8次：'+str(limit))
        elif not all(re.search(re.escape(name)+r'\s*<\s*'+str(limit)+r'(?!\d)',lines[i]) for i in presses):
            result['unresolved'].append('Space起跳条件必须与声明的次数上限一致：'+name)
        elif any(i['key']=='SpaceBar' for i in inputs):
            result['unresolved'].append('SpaceBar已有输入绑定，需明确合并后才能生成有界跳跃')
        else:
            velocity_matches=re.findall(r'起跳速度\s*[:：=]?\s*(\d+(?:\.\d+)?)',request)
            velocity=float(velocity_matches[0]) if len(set(velocity_matches))==1 else 500.
            if not 1<=velocity<=2000:raise ValueError('起跳速度超出运行时允许范围')
            event='UnifiedJumpPressed'
            result['inputs'].append(dict(key='SpaceBar',phase='pressed',event=event,set={}))
            result['handlers'].append({'from':'*','event':event,'condition':pred(name,'lt',limit),'actions':[dict(op='jump',velocity=velocity),dict(op='add',var=name,value=1)],'priority':200,'source_quote':lines[presses[0]]})
            result['handlers'].append({'from':'*','event':'Landed','condition':pred(name,'gt',0),'actions':[dict(op='set',var=name,value=0)],'priority':300,'source_quote':lines[reset[0]]})
            air_nodes={n for n,description in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)[（(]([^）)]+)[）)]',request) if description in ('起跳与上升','空中下降') and n in by_id}
            air_groups={by_id[n]['parent'] for n in air_nodes}
            ground_groups={by_id[n]['parent'] for n in roles}
            if len(air_groups)==1 and None not in air_groups and len(ground_groups)==1 and None not in ground_groups:
                air_group=next(iter(air_groups));ground_group=next(iter(ground_groups))
                if air_group!=ground_group:
                    landed=transition(air_group,ground_group,[],lines[reset[0]],priority=300)
                    landed.update(event='Landed',interrupt=True,actions=[dict(op='set',var=name,value=0)])
                    result['transitions'].append(landed)
            result['defaults'].update(jump_velocity=velocity,jump_velocity_source='explicit request' if velocity_matches else 'GaspNativeCharacter.cpp constructor default; blueprint override not inspected',jump_input_phase='pressed')
            result['evidence'].append(dict(kind='bounded_actual_launch',counter=name,limit=limit,rules=increment+reset+presses+no_repeat+[i for i,_ in bounds],note='increment follows accepted LaunchCharacter action, not a physics success acknowledgement'))
            # Consume the complete bounded-jump paragraph only when all of its
            # control clauses match the supported contract. Preserve other prose.
            counter=re.escape(name);n=str(limit)
            patterns=[r'使用内部整数\s+'+counter+r'\s*[，,]\s*初始值为\s*0',r'只有成功执行真实起跳才将\s*'+counter+r'\s*加\s*1',r'每次真实落地前最多成功起跳\s*'+n+r'\s*次',r'空中再次按下\s*Space\s*且\s*'+counter+r'\s*<\s*'+n+r'\s*时执行第[一二三四五六七八\d]+次真实起跳并加\s*1',r'达到\s*'+n+r'\s*次后拒绝后续起跳',r'按住\s*Space\s*不得重复计数',r'真实落地时将\s*'+counter+r'\s*清零']
            for i,line in enumerate(lines):
                clauses=[c.strip().lstrip('-* ').strip() for c in re.split(r'[。；;]',line) if c.strip()]
                if clauses and all(any(re.fullmatch(p,c) for p in patterns) for c in clauses):result['handled_lines'].add(i)
    return result

def control_rule_lines(lines,handled):
    """Select trigger-bearing prose, excluding headers and tool instructions.

    The full original request remains in context and traces. Unrecognized
    non-control instructions are not treated as permission to create handlers.
    """
    result=[]
    for item in lines:
        if item['index'] in handled:continue
        text=item['text'].strip().lstrip('-* ').strip()
        if re.search(r'创建父组|直接叶子状态|初始子状态|入口为|每个叶子状态使用|分别只匹配|根据素材|不创建其他状态',text):continue
        if re.search(r'每类最多选|优先覆盖|候选数量',text):continue
        if re.match(r'只能使用|不得编造|不要|不添加|如果当前运行时|缺少所需运行时|逐项报告|说明哪些|生成后|只使用',text):continue
        if re.search(r'进入|返回|切换|跳转|按下|按住|起跳|落地|清零|加\s*\d|减\s*\d|执行|计数|优先|on_entry|on_exit|on_complete',text):result.append(item)
    return result

def merge_selection_edges(edges,compiled):
    """Apply global stance/ground predicates to matching arithmetic arrows.

    Never silently overwrite a conflicting explicit extra condition/action.
    """
    generated={(e['from'],e['to']):copy.deepcopy(e) for e in compiled['transitions'] if not e['event']}
    event_edges=[copy.deepcopy(e) for e in compiled['transitions'] if e['event']]
    result=[];nodes=compiled['selector_nodes']
    def terms(tree):
        if 'var' in tree:return [tree]
        if set(tree)=={'all'}:return [p for c in tree['all'] for p in terms(c)]
        raise ValueError('nonconjunctive selection condition')
    for edge in edges:
        key=(edge['from'],edge['to'])
        if key in generated:
            candidate=generated[key]
            try:required=edge.get('all',[])+terms(edge['condition']) if edge.get('condition') else edge.get('all',[])
            except ValueError:required=[{}]
            if edge.get('event') or edge.get('actions') or any(t not in candidate['all'] for t in required):
                compiled['unresolved'].append('显式转换与自动地面选择存在额外条件或动作冲突：'+edge['source_quote'])
                result.append(edge)
            else:candidate['source_quote']=edge['source_quote']
        else:
            # Ground->air should win over child selection when IsFalling turns
            # true. Predicate-bearing selection edges are disabled in the air.
            result.append(edge)
    return result+list(generated.values())+event_edges
