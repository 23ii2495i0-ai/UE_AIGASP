import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from unified_behavior import PROTOCOL,compile_unified,compiled_signature,review_errors
from unified_generation import generate,forbidden_list,actions,node_resource_mentions,resource_mentions,declared_node_palette,declared_group_relations
import jsonschema
from config_tool import validate
from unified_generation import state_spec_schema
from unified_generation import transition_tasks
from unified_generation import builtin_prose_condition,node_callback_requested

REQUEST='待机；自定义礼仪动作；有输入时切换；经过1秒返回。'
def catalog():
    return dict(assets=[dict(id='/Game/M.M',kind='mesh',skeleton='S',bones=['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03']),
        dict(id='/Game/Stand.Stand',name='Stand_Idle_Loop',kind='sequence',skeleton='S',loop=True),
        dict(id='/Game/Salute.Salute',name='Meteor_Salute',kind='sequence',skeleton='S',loop=False)])
def node(id,label,player,queries):
    return dict(id=id,label=label,source_quote=label,parent=None,initial=None,player=player,loop=player=='mm',allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2,on_entry=[],on_exit=[],on_complete=[],
        content=dict(action_name=label,queries=queries,resources=[],max_candidates=4))
def ir():
    return dict(protocol=PROTOCOL,entry='State1',states=[node('State1','待机','mm',['stand idle loop']),node('State2','自定义礼仪动作','sequence',['meteor salute'])],variables=[],inputs=[],handlers=[],unresolved=[],
        transitions=[dict({'from':'State1','to':'State2','event':'','all':[dict(var='move_input',op='gt',value=.01)],'priority':0,'interrupt':False,'source_quote':'有输入时切换'}),
                     dict({'from':'State2','to':'State1','event':'','all':[dict(var='state_time',op='ge',value=1)],'priority':0,'interrupt':False,'source_quote':'经过1秒返回'})])

class UnifiedTests(unittest.TestCase):
    def test_compiled_signature_survives_ue_integral_double_serialization(self):
        plan=compile_unified(ir(),REQUEST,catalog(),'/Game/Test')
        original=compiled_signature(plan)
        def ue_roundtrip(value):
            if isinstance(value,float) and value.is_integer():return int(value)
            if isinstance(value,dict):return {k:ue_roundtrip(v) for k,v in value.items()}
            if isinstance(value,list):return [ue_roundtrip(v) for v in value]
            return value
        saved=ue_roundtrip(plan)
        self.assertEqual(original,compiled_signature(saved))
        saved['parameters']['play_rate']=1.001
        self.assertNotEqual(original,compiled_signature(saved))
        saved=ue_roundtrip(plan);saved['parameters']['reference_idle']=0
        self.assertNotEqual(original,compiled_signature(saved))

    def test_builtin_predicates_and_callback_evidence_do_not_depend_on_state_names(self):
        self.assertEqual(builtin_prose_condition('垂直速度转为下降'),dict(var='vertical_speed',op='lt',value=0))
        self.assertEqual(builtin_prose_condition('垂直速度重新向上'),dict(var='vertical_speed',op='gt',value=0))
        self.assertEqual(builtin_prose_condition('角色真实落地后'),dict(var='falling',op='eq',value=False))
        self.assertIsNone(builtin_prose_condition('播放自定义礼仪动作'))
        self.assertTrue(node_callback_requested('进入 Ritual 时，Rounds 加1。','Ritual','on_entry'))
        self.assertFalse(node_callback_requested('Ritual 使用MM。落地时 Count 清零。','Ritual','on_entry'))

    def test_transition_rules_are_anchored_without_dropping_residual_logic(self):
        request='- Alpha → Beta：speed > 2。\n- Beta -> Gamma：落地后进入。\n按下 Space 时计数加1。'
        tasks=transition_tasks(request,['Alpha','Beta','Gamma'])
        explicit=[t for t in tasks if t['target'] is not None]
        self.assertEqual([(t['source'],t['target'],t['lines'][0]['index']) for t in explicit],[('Alpha','Beta',0),('Beta','Gamma',1)])
        residual=[t for t in tasks if t['target'] is None]
        self.assertEqual(len(residual),4)
        self.assertTrue(all(t['lines']==[dict(index=2,text='按下 Space 时计数加1。')] for t in residual))

    def test_explicit_internal_variable_constrains_name_scope_and_source(self):
        class ProbeComplete(Exception):pass
        class Runtime:
            last_prediction_raw=None
            calls=0
            def predict(self,*args):
                self.calls+=1
                if self.calls==1:return dict(entry='Idle',states=[dict(id='Idle',action_name='Idle',node_type='leaf')])
                valid=dict(variables=[dict(id='JumpCount',initial=0,scope='internal',source='jump counter')],inputs=[],unresolved=[])
                jsonschema.validate(valid,self.behavior_schema)
                for field,value in [('id','ground_state'),('scope','external'),('source','')]:
                    invalid=copy.deepcopy(valid);invalid['variables'][0][field]=value
                    with self_test.assertRaises(jsonschema.ValidationError):jsonschema.validate(invalid,self.behavior_schema)
                raise ProbeComplete()
        self_test=self
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ProbeComplete):generate(Runtime(),catalog(),'创建单个顶层叶子状态 Idle。使用内部整数 JumpCount，初始值为0。','/Game/Test',{},folder)

    def test_player_schema_forbids_nonfinite_completion(self):
        base=dict(player='group',loop=False,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2,on_entry=[],on_exit=[],on_complete=[],content=None)
        schema=state_spec_schema(['Count'],True,dict(type='object'))
        jsonschema.validate(base,schema)
        for field,value in [('loop',True),('lock_until_finished',True),('on_complete',[dict(op='add',var='Count',value=1)])]:
            with self.assertRaises(jsonschema.ValidationError):jsonschema.validate(dict(base,**{field:value}),schema)
        leaf=dict(base,player='mm',content={})
        schema=state_spec_schema(['Count'],False,dict(type='object'))
        jsonschema.validate(leaf,schema)
        with self.assertRaises(jsonschema.ValidationError):jsonschema.validate(dict(leaf,lock_until_finished=True),schema)
        jsonschema.validate(dict(leaf,player='sequence',lock_until_finished=True,on_complete=[dict(op='add',var='Count',value=1)]),schema)

    def test_explicit_hierarchy_is_scoped_to_each_group(self):
        request='创建父组 Floor，初始子状态为 Rest。\nFloor 下有两个直接叶子状态：Rest（待机）、Stride（移动）。\n创建父组 Sky，初始子状态为 Rise。\nSky 下有两个直接叶子状态：Rise（上升）、Fall（下降）。\nRest → Rise：falling。'
        result=declared_group_relations(request,['Floor','Sky'],['Floor','Sky','Rest','Stride','Rise','Fall'])
        self.assertEqual(result,dict(Floor=dict(children=['Rest','Stride'],initial_child='Rest'),Sky=dict(children=['Rise','Fall'],initial_child='Rise')))
        self.assertEqual(declared_group_relations('Rest → Rise：falling。',['Floor'],['Floor','Rest','Rise']),{})

    def test_closed_layout_cannot_emit_empty_or_unrelated_action_name(self):
        class ProbeComplete(Exception):pass
        class Runtime:
            def predict(self,*args):
                schema=self.behavior_schema
                valid=dict(entry='Idle',states=[dict(id='Idle',action_name='Idle',node_type='leaf')])
                jsonschema.validate(valid,schema)
                for label in ('','attack','idle'):
                    invalid=copy.deepcopy(valid);invalid['states'][0]['action_name']=label
                    with self_test.assertRaises(jsonschema.ValidationError):jsonschema.validate(invalid,schema)
                raise ProbeComplete()
        self_test=self
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ProbeComplete):
                generate(Runtime(),catalog(),'创建单个顶层叶子状态 Idle。','/Game/Test',{},folder)

    def test_explicit_negative_lists_do_not_infer_absent_requirements(self):
        self.assertIsNone(forbidden_list('不要从动作名称推断变量、输入、事件或额外状态。',{'输入','按键'}))
        self.assertTrue(forbidden_list('没有其他状态、变量、输入、转换或内部事件。',{'变量'}))
        self.assertTrue(forbidden_list('不声明变量、按键、跳跃或战斗。',{'按键'}))
        self.assertIsNone(forbidden_list('没有攻击，但需要变量。',{'变量'}))
        self.assertIsNone(forbidden_list('创建观察动作。',{'变量'}))

    def test_actions_cannot_assign_undeclared_variables(self):
        with self.assertRaises(jsonschema.ValidationError):
            jsonschema.validate([dict(op='set',var='inferred_flag',value=True)],actions([]))
        jsonschema.validate([dict(op='set',var='Count',value=1)],actions(['Count']))

    def test_resource_queries_are_scoped_to_node_and_preserve_missing_name(self):
        c=catalog();text='State1 动画名称 Stand_Idle_Loop。\nState2 素材名称 Stellar_Ritual_ExactlyMissing。'
        self.assertEqual(node_resource_mentions(text,dict(id='State1'),c)[0],['Stand_Idle_Loop'])
        self.assertEqual(node_resource_mentions(text,dict(id='State2'),c)[0],['Stellar_Ritual_ExactlyMissing'])
        self.assertNotIn('Stand_Idle_Loop',resource_mentions('Stand_Idle_Loop_Extra',c))

    def test_closed_node_declarations_exclude_resource_names(self):
        self.assertEqual(declared_node_palette('创建单个顶层叶子状态 Ritual，素材名称 Stellar_Ritual。'),{'Ritual':'leaf'})
        self.assertEqual(declared_node_palette('只有三个顶层叶子状态 A、B、C。'),{'A':'leaf','B':'leaf','C':'leaf'})
        self.assertEqual(declared_node_palette('创建父组 G，包含直接子状态 L。只创建这两个节点。'),{'G':'group','L':'leaf'})
        self.assertIsNone(declared_node_palette('创建叶子状态 A，还需要其他中文状态。'))

    def test_closed_hierarchical_palette_with_descriptive_labels(self):
        request='''节点定义：
- 创建父组 Ground，初始子状态为 Idle。
- Ground 下有五个直接叶子状态：Idle（站立待机）、Walk（站立行走）、Run（站立跑步）、CrouchIdle（蹲姿待机）、CrouchMove（蹲姿移动）。
- 创建父组 Air，初始子状态为 JumpRise。
- Air 下有两个直接叶子状态：JumpRise（起跳与上升）、JumpFall（空中下降）。
- 除以上七个叶子状态和两个父组外，不创建其他状态。'''
        self.assertEqual(declared_node_palette(request),{
            'Ground':'group','Air':'group','Idle':'leaf','Walk':'leaf','Run':'leaf',
            'CrouchIdle':'leaf','CrouchMove':'leaf','JumpRise':'leaf','JumpFall':'leaf'})

    def test_custom_action_uses_same_graph_without_trained_class(self):
        p=compile_unified(ir(),REQUEST,catalog(),'/Game/Test')
        self.assertEqual(p['behavior_graph']['states'][1]['resources'],['/Game/Salute.Salute'])
        self.assertEqual(p['states'][0]['id'],'mm_State1')
        self.assertFalse(any(i['severity']=='error' for i in p['issues']))
        self.assertTrue(review_errors(p))

    def test_confirmation_and_recompile_are_bound_to_ir_graph_and_resources(self):
        p=compile_unified(ir(),REQUEST,catalog(),'/Game/Test')
        p['model_info']['unified_review']=dict(confirmed=True,reviewed_ir=copy.deepcopy(ir()),request=REQUEST)
        self.assertTrue(review_errors(p))
        p['model_info']['unified_review']['compiled_signature']=compiled_signature(p)
        self.assertEqual(validate(p,catalog()),[])
        p['behavior_graph']['transitions'][0]['all']=[]
        self.assertTrue(validate(p,catalog()))

    def test_untrained_action_without_asset_stays_missing_not_attack(self):
        data=ir();data['states'][1]['content']['queries']=['missing_salute']
        p=compile_unified(data,REQUEST,catalog(),'/Game/Test')
        self.assertEqual(p['behavior_graph']['states'][1]['resources'],[])
        self.assertTrue(any(i['code']=='unified_binding_missing' for i in p['issues']))
        self.assertNotIn('attack',json.dumps(p['states']))
        self.assertTrue(validate(p,catalog()))

    def test_wrong_skeleton_invented_path_and_ambiguous_single_clip_block(self):
        for path in ['/Game/Fake.Fake','/Game/Other.Other']:
            data=ir();data['states'][1]['content']['resources']=[path]
            c=catalog();c['assets'].append(dict(id='/Game/Other.Other',name='Meteor_Salute',kind='sequence',skeleton='Other',loop=False))
            p=compile_unified(data,REQUEST,c,'/Game/Test')
            self.assertTrue(any(i['severity']=='error' for i in p['issues']))
        c=catalog();c['assets'].append(dict(c['assets'][-1],id='/Game/Salute2.Salute2'))
        p=compile_unified(ir(),REQUEST,c,'/Game/Test')
        self.assertTrue(any('多个同分' in i['message'] for i in p['issues']))

    def test_external_conditions_keep_initial_value_and_explicit_scope(self):
        data=ir();data['variables']=[dict(id='bHit',initial=False,scope='external',source='game hit detection calls SetBoolVariable')]
        data['transitions'][0]['all']=[dict(var='bHit',op='eq',value=True)]
        p=compile_unified(data,REQUEST,catalog(),'/Game/Test')
        self.assertFalse(p['behavior_graph']['variables']['bHit'])
        self.assertEqual(p['behavior_graph']['variable_sources']['bHit']['scope'],'external')

    def test_unsupported_execution_primitive_and_fake_quote_are_rejected(self):
        data=ir();data['states'][1]['on_entry']=[dict(op='invent_damage_system')]
        with self.assertRaisesRegex(ValueError,'未知动作'):compile_unified(data,REQUEST,catalog(),'/Game/Test')
        data=ir();data['transitions'][0]['source_quote']='not in request'
        with self.assertRaisesRegex(ValueError,'原文依据'):compile_unified(data,REQUEST,catalog(),'/Game/Test')

    def test_compiler_is_independent_of_action_taxonomy_and_supports_internal_handlers(self):
        data=ir();data['variables']=[dict(id='Rounds',initial=0,scope='internal',source='entry count')]
        data['states'][1]['on_entry']=[dict(op='add',var='Rounds',value=1)]
        data['handlers']=[dict({'from':'State2','event':'Again','condition':dict(var='Rounds',op='lt',value=3),'actions':[dict(op='add',var='Rounds',value=1)],'priority':10,'source_quote':'自定义礼仪动作'})]
        p=compile_unified(data,REQUEST,catalog(),'/Game/Test')
        self.assertEqual(p['behavior_graph']['handlers'][0]['condition']['value'],3)

    def test_staged_generator_does_not_call_template_generator(self):
        data=ir();layout=dict(entry='State1',states=[dict(id=n['id'],action_name=n['label'],node_type='leaf') for n in data['states']])
        responses=[layout,dict(variables=[],inputs=[],unresolved=[])]+[{k:n[k] for k in n if k not in ('id','label','source_quote','parent','initial')} for n in data['states']]+[
            dict(transitions=[{k:v for k,v in data['transitions'][0].items() if k!='source_quote'}|dict(source_line=0)],handlers=[],unresolved=[]),dict(transitions=[{k:v for k,v in data['transitions'][1].items() if k!='source_quote'}|dict(source_line=0)],handlers=[],unresolved=[]),dict(transitions=[],handlers=[],unresolved=[])]
        class Runtime:
            last_prediction_raw=None
            def predict(self,*args):
                supplied=json.loads(args[1][-1]['content'])
                if supplied['output_schema']!=self.behavior_schema:
                    raise AssertionError('模型必须收到与约束解码相同的Schema')
                if supplied['request']!=REQUEST:
                    raise AssertionError('每阶段必须保留原始用户需求')
                out=responses.pop(0);self.last_prediction_raw=dict(text=json.dumps(out));return out
        with tempfile.TemporaryDirectory() as folder:
            p,_,_=generate(Runtime(),catalog(),REQUEST,'/Game/Test',{},folder)
            self.assertEqual(p['model_info']['behavior_generation']['mode'],PROTOCOL)
            self.assertFalse(responses)

    def test_hierarchy_requires_a_relation_for_each_node(self):
        data=ir();group=node('Container','容器组','group',[]);group.update(initial='State1',content=None)
        for child in data['states']:child['parent']='Container'
        nodes=[group]+data['states']
        responses=[dict(entry='Container',states=[dict(id=n['id'],action_name=n['label'],node_type='group' if n['id']=='Container' else 'leaf') for n in nodes]),
            dict(groups=dict(Container=dict(children=['State1','State2'],initial_child='State1'))),dict(variables=[],inputs=[],unresolved=[])]
        responses += [{k:n[k] for k in n if k not in ('id','label','source_quote','parent','initial')} for n in nodes]
        responses += [dict(transitions=[],handlers=[],unresolved=[])]
        responses += [dict(transitions=[{k:v for k,v in e.items() if k!='source_quote'}|dict(source_line=0)],handlers=[],unresolved=[]) for e in data['transitions']]
        responses += [dict(transitions=[],handlers=[],unresolved=[])]
        class Runtime:
            last_prediction_raw=None
            def predict(self,*args):
                payload=json.loads(args[1][-1]['content'])
                if payload['stage']=='hierarchy':
                    assert set(payload['output_schema']['properties']['groups']['required'])=={'Container'}
                out=responses.pop(0);self.last_prediction_raw=dict(text=json.dumps(out));return out
        with tempfile.TemporaryDirectory() as folder:
            plan,_,_=generate(Runtime(),catalog(),REQUEST+'容器组', '/Game/Test',{},folder)
        self.assertEqual(plan['behavior_graph']['states'][1]['parent'],'Container')
        self.assertFalse(responses)

if __name__=='__main__':unittest.main()
