import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai/configuration/training'))
from assistant_loss import assistant_loss


class AssistantLossTests(unittest.TestCase):
    def test_suffix_loss_and_every_gradient_match_standard_masked_causal_loss(self):
        import torch
        from transformers import Qwen3Config,Qwen3ForCausalLM
        torch.manual_seed(9)
        model=Qwen3ForCausalLM(Qwen3Config(vocab_size=37,hidden_size=16,intermediate_size=32,num_hidden_layers=1,num_attention_heads=2,num_key_value_heads=1,head_dim=8,tie_word_embeddings=True,attention_dropout=0))
        ids=torch.tensor([[2,3,4,5,6,7,8,9]]);labels=ids.clone();labels[:,:5]=-100
        standard=model(input_ids=ids,attention_mask=torch.ones_like(ids),labels=labels).loss
        standard.backward();expected={n:p.grad.clone() for n,p in model.named_parameters()}
        model.zero_grad(set_to_none=True);suffix=assistant_loss(model,ids,labels);suffix.backward()
        torch.testing.assert_close(suffix,standard)
        for name,p in model.named_parameters():torch.testing.assert_close(p.grad,expected[name],rtol=1e-5,atol=1e-6)
    def test_noncontiguous_or_missing_assistant_labels_fail_before_forward(self):
        import torch
        from unittest.mock import Mock
        model=Mock();ids=torch.tensor([[1,2,3,4]])
        for labels in (torch.tensor([[-100,2,-100,4]]),torch.full_like(ids,-100),ids):
            with self.assertRaises(ValueError):assistant_loss(model,ids,labels)
        model.assert_not_called()


if __name__=='__main__':unittest.main()
