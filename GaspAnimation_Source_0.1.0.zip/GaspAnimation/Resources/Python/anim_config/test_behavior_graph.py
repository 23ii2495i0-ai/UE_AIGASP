import unittest,copy
from behavior_graph import default_graph,validate_graph

class BehaviorTests(unittest.TestCase):
    def setUp(self):
        self.catalog={'assets':[dict(id='mesh',kind='mesh',skeleton='s'),dict(id='clip',kind='sequence',skeleton='s',loop=False),dict(id='db',kind='database',skeleton='s')]}
        self.g=default_graph()
    def errors(self):return validate_graph(self.g,self.catalog,'mesh',['idle','run'])
    def add_state(self):
        self.g['states'].append(dict(id='CustomGuard',player='sequence',resources=['clip'],loop=False,allow_movement=False,lock_until_finished=True,min_duration=.1,blend_seconds=.2))
        self.g['transitions'].append(dict(from_='unused'))
        self.g['transitions'][-1]=dict({'from':'Locomotion','to':'CustomGuard','event':'Guard','all':[],'priority':10,'interrupt':False})
    def test_default_preserves_mm(self):self.assertEqual(self.errors(),[])
    def test_custom_names_are_supported(self):self.add_state();self.assertEqual(self.errors(),[])
    def test_missing_resource_is_blocked(self):self.add_state();self.g['states'][-1]['resources']=['invented'];self.assertTrue(self.errors())
    def test_rig_mismatch_is_blocked(self):self.add_state();self.catalog['assets'][1]['skeleton']='other';self.assertTrue(self.errors())
    def test_loop_cannot_wait_for_completion(self):self.add_state();self.g['states'][-1]['loop']=True;self.assertTrue(self.errors())
    def test_mm_role_must_exist(self):self.g['states'][0].update(player='mm',database_role='run');self.assertEqual(self.errors(),[]);self.g['states'][0]['database_role']='missing';self.assertTrue(self.errors())
    def test_auto_transition_requires_condition(self):self.add_state();self.g['transitions'][0]['event']='';self.assertTrue(self.errors())
    def test_undefined_condition_is_blocked(self):self.add_state();self.g['transitions'][0]['all']=[dict(var='health',op='gt',value=0)];self.assertTrue(self.errors())
    def test_held_input_and_predicate(self):
        self.add_state();self.g['variables']={'Held':False};self.g['inputs']=[dict(key='RightMouseButton',phase='pressed',event='Guard',set={'Held':True})]
        self.g['transitions'][0]['all']=[dict(var='Held',op='eq',value=True)];self.assertEqual(self.errors(),[])
    def test_duplicate_keys_and_state_case(self):
        self.g['inputs']=[dict(key='H',phase='pressed',event='Hit',set={})]*2;self.assertTrue(self.errors())
        self.g=default_graph();self.g['states'].append(dict(self.g['states'][0],id='locomotion'));self.assertTrue(self.errors())
    def test_nan_is_blocked(self):self.g['variables']={'X':float('nan')};self.assertTrue(self.errors())
    def test_unreachable_state_is_blocked(self):self.g['states'].append(dict(self.g['states'][0],id='Orphan'));self.assertTrue(self.errors())
    def test_unknown_player_is_blocked(self):self.g['states'][0]['player']='execute_python';self.assertTrue(self.errors())
    def test_malformed_types_fail_closed(self):
        for key,value in [('states',[[]]),('entry',{}),('inputs',[None]),('variables',{'X':{}}),('transitions',[42])]:
            self.g=default_graph();self.g[key]=value;self.assertTrue(self.errors())

class HierarchicalBehaviorTests(unittest.TestCase):
    def setUp(self):
        self.catalog={'assets':[dict(id='mesh',kind='mesh',skeleton='s'),dict(id='clip',kind='sequence',skeleton='s',loop=False),dict(id='db',kind='database',skeleton='s'),dict(id='montage',kind='montage',skeleton='s')]}
        self.g=default_graph();self.g['version']=2
        self.g['variables']={'Count':0,'bHit':False}
    def errors(self):return validate_graph(self.g,self.catalog,'mesh',['idle','run','jump'])
    def edge(self,a,b,event='',conditions=(),**extra):
        value={'from':a,'to':b,'event':event,'all':list(conditions),'priority':0,'interrupt':False};value.update(extra);self.g['transitions'].append(value);return value
    def state(self,name,player='sequence',**extra):
        value=dict(id=name,player=player,resources=['clip'] if player=='sequence' else [],loop=False,allow_movement=True,lock_until_finished=False,min_duration=0,blend_seconds=.2);value.update(extra);self.g['states'].append(value);return value
    def group(self):
        self.state('Combat','group',initial='Attack1')
        self.state('Attack1',parent='Combat',on_complete=[dict(op='add',var='Count',value=1)])
        self.state('Attack2',parent='Combat')
        self.edge('Locomotion','Combat','Attack')
        self.edge('Attack1','Attack2',condition={'all':[dict(var='finished',op='eq',value=True),{'any':[dict(var='Count',op='ge',value=2),dict(var='bHit',op='eq',value=True)]}]})
        self.edge('Combat','Locomotion','Cancel')
    def test_nested_combo_and_external_hit(self):self.group();self.assertEqual(self.errors(),[])
    def test_parent_edge_reaches_from_nested_initial(self):
        self.group();self.state('Recovery');self.edge('Combat','Recovery','Hit');self.assertEqual(self.errors(),[])
    def test_direct_child_entry_activates_parent(self):self.group();self.g['entry']='Attack1';self.assertEqual(self.errors(),[])
    def test_self_reentry_with_count(self):
        self.group();self.edge('Attack1','Attack1',conditions=[dict(var='finished',op='eq',value=True),dict(var='Count',op='lt',value=2)]);self.assertEqual(self.errors(),[])
    def test_multi_jump_uses_explicit_velocity(self):
        self.state('Jump1','mm',database_role='jump',on_entry=[dict(op='jump',velocity=500)])
        self.state('Jump2','mm',database_role='jump',on_entry=[dict(op='jump',velocity=600)])
        self.edge('Locomotion','Jump1','Jump');self.edge('Jump1','Jump2','Jump',interrupt=True)
        self.g['inputs']=[dict(key='SpaceBar',phase='pressed',event='Jump',set={},actions=[dict(op='add',var='Count',value=1)])]
        self.assertEqual(self.errors(),[])
    def test_parent_cycle(self):self.group();self.g['states'][1]['parent']='Combat';self.assertTrue(self.errors())
    def test_parent_must_be_group(self):self.group();self.g['states'][2]['parent']='Locomotion';self.assertTrue(self.errors())
    def test_initial_must_be_direct_child(self):self.group();self.g['states'][1]['initial']='Locomotion';self.assertTrue(self.errors())
    def test_leaf_initial_rejected(self):self.g['states'][0]['initial']='Locomotion';self.assertTrue(self.errors())
    def test_orphan_sibling_rejected(self):self.group();self.state('Orphan',parent='Combat');self.assertTrue(self.errors())
    def test_parent_ninth_level_rejected(self):
        self.g['entry']='G0';self.g['states']=[]
        for i in range(8):self.state('G'+str(i),'group',initial='G'+str(i+1),**({'parent':'G'+str(i-1)} if i else {}))
        self.state('G8',parent='G7');self.assertTrue(self.errors())
    def test_condition_depth_and_budget(self):
        self.group();condition=dict(var='bHit',op='eq',value=True)
        for i in range(8):condition={'not':condition}
        self.g['transitions'][1]['condition']=condition;self.assertTrue(self.errors())
        self.g['transitions'][1]['condition']={'all':[dict(var='bHit',op='eq',value=True)]*128};self.assertTrue(self.errors())
    def test_condition_empty_ambiguous_or_undeclared(self):
        self.group()
        for condition in ({'all':[]},{'any':[]},{'any':[dict(var='Missing',op='eq',value=True)]},{'not':{},'all':[]}):
            self.g['transitions'][1]['condition']=condition;self.assertTrue(self.errors())
    def test_completion_on_group_or_loop_rejected(self):
        self.group();self.g['states'][1]['on_complete']=[dict(op='set',var='Count',value=0)];self.assertTrue(self.errors())
        self.g['states'][1].pop('on_complete');self.g['states'][2]['loop']=True;self.assertTrue(self.errors())
    def test_builtin_mutations_and_bad_actions_rejected(self):
        for action in (dict(op='add',var='speed',value=1),dict(op='set',var='bHit',value=float('inf')),dict(op='python',code='x'),dict(op='jump',velocity=0),dict(op='jump',velocity=True),dict(op='jump',velocity=2001)):
            self.g['states'][0]['on_entry']=[action];self.assertTrue(self.errors())
    def test_action_array_bound(self):self.g['states'][0]['on_entry']=[dict(op='set',var='Count',value=0)]*33;self.assertTrue(self.errors())
    def test_reserved_builtin_case(self):self.g['variables']['Finished']=False;self.assertTrue(self.errors())
    def test_v1_cannot_silently_accept_v2(self):self.group();self.g['version']=1;self.assertTrue(self.errors())
    def test_interruption_condition_supported(self):self.edge('Locomotion','Locomotion',conditions=[dict(var='interrupted',op='eq',value=True)]);self.assertEqual(self.errors(),[])
    def test_montage_loop_blocked(self):self.state('Montage','montage',resources=['montage'],loop=True);self.edge('Locomotion','Montage','Play');self.assertTrue(self.errors())
    def test_wrong_types_rejected_without_exception(self):
        for path,value in [('parent',[]),('player',{}),('initial',{}),('resources',[{}]),('on_entry',{})]:
            self.g=default_graph();self.g['version']=2;self.g['states'][0][path]=value;self.assertTrue(self.errors())

if __name__=='__main__':unittest.main()
