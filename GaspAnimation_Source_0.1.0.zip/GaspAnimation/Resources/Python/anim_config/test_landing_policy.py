import copy
import unittest
from behavior_requirements import compile_requirements,validate_extracted_stage,extraction_messages
from behavior_graph import validate_graph
from landing_policy import add_landing_resources,STAGE_ROLES
from prepare_behavior_v3_smoke import IR
from config_tool import generate,validate,signature

REQUEST='Ground 是父组，包含 Idle、Walk、Run。\nAir 是空中父组，包含 JumpRise、JumpFall。\nRecovery 是落地恢复父组，包含 Land、LandRun。\n二段跳 JumpCount 最多2次。'

def fixture():
    ir=copy.deepcopy(IR)
    ir.update(topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run'],initial='Idle',source_lines=[0]),dict(id='Air',children=['JumpRise','JumpFall'],initial='JumpRise',source_lines=[1]),dict(id='Recovery',children=['Land','LandRun'],initial='Land',source_lines=[2])],standalone=[]),
        locomotion=dict(group='Ground',idle='Idle',walk='Walk',run='Run'),
        jump=dict(group='Air',rise='JumpRise',fall='JumpFall',counter='JumpCount',max_jumps=2,landing=dict(group='Recovery',land='Land',land_run='LandRun',land_seconds=.35,run_seconds=.7)),combo=None)
    return ir

class LandingTests(unittest.TestCase):
    def test_all_four_stages_have_independent_mm_roles(self):
        ir=fixture();graph,roles=compile_requirements(ir,REQUEST)
        mapped={s['id']:s.get('database_role') for s in graph['states']}
        self.assertEqual([mapped[n] for n in ['JumpRise','JumpFall','Land','LandRun']],list(STAGE_ROLES))
        self.assertEqual(validate_graph(graph,dict(assets=[]),None,roles),[])
        self.assertTrue(all(s['player']=='mm' for s in graph['states'] if s['id'] in mapped and mapped[s['id']]))

    def test_real_landed_routes_running_and_static_then_resets_count(self):
        graph,_=compile_requirements(fixture(),REQUEST)
        landed=[e for e in graph['transitions'] if e['event']=='Landed']
        self.assertEqual({e['to'] for e in landed},{'Land','LandRun'})
        run=next(e for e in landed if e['to']=='LandRun');stand=next(e for e in landed if e['to']=='Land')
        self.assertGreater(run['priority'],stand['priority'])
        self.assertIn(dict(var='JumpWasRunning',op='eq',value=True),run['all'])
        self.assertIn(dict(var='crouched',op='eq',value=False),run['all'])
        self.assertEqual(run['actions'],[dict(op='set',var='JumpCount',value=0)])
        self.assertFalse(any(e['to']=='Ground' for e in landed))

    def test_running_takeoff_is_latched_and_recovery_exit_is_not_clip_end(self):
        graph,_=compile_requirements(fixture(),REQUEST)
        takeoff=next(e for e in graph['transitions'] if e['from']=='Run' and e['event']=='Jump')
        self.assertEqual(takeoff['actions'][-1],dict(op='set',var='JumpWasRunning',value=True))
        exits=[e for e in graph['transitions'] if e['from']=='LandRun']
        self.assertTrue(exits)
        self.assertTrue(all(dict(var='state_time',op='ge',value=.7) in e['all'] for e in exits))
        self.assertFalse(any(p['var']=='finished' for e in exits for p in e['all']))

    def test_recovery_is_not_attack_or_air_group(self):
        ir=fixture()
        with self.assertRaisesRegex(ValueError,'不能复用'):
            validate_extracted_stage('combo',dict(policy=dict(attacks=['LandRun'],hit='Land',buffer='Queued')),ir,REQUEST)
        ir['jump']['landing']['group']='Air'
        with self.assertRaisesRegex(ValueError,'独立父组'):compile_requirements(ir,REQUEST)

    def test_recovery_schema_cannot_drop_declared_stage(self):
        schema,_=extraction_messages('jump',REQUEST,fixture())
        p=schema['properties']['policy']['anyOf'][0]['properties']
        self.assertEqual(p['group']['enum'],['Air'])
        self.assertEqual(p['landing']['properties']['group']['enum'],['Recovery'])

    def test_stage_resources_are_separate_and_nonloop_allowed_only_for_behavior(self):
        catalog=dict(assets=[dict(id='M',kind='mesh',skeleton='S',bones=['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03'])])
        for name,loop in [('Idle',True),('Walk',True),('Run',True),('M_Jump_F_Start',False),('M_Jump_Loop_Fall',True),('M_Jump_F_Land_Stand_Light',False),('M_Jump_F_Land_Run_Heavy',False)]:
            catalog['assets'].append(dict(id='/Game/'+name+'.'+name,name=name,kind='sequence',skeleton='S',loop=loop))
        graph,roles=compile_requirements(fixture(),REQUEST)
        plan=generate(dict(assets=catalog['assets'][:4]),'idle walk run','/Game/Test')
        plan['catalog_signature']=signature(catalog)
        plan['issues']=[];plan['behavior_graph']=graph
        add_landing_resources(plan,catalog,roles,'')
        plan['request']=' '.join(roles)
        self.assertEqual(validate(plan,catalog),[])
        stage=[s for s in plan['states'] if s['id'] in STAGE_ROLES]
        self.assertEqual(len(stage),4)
        self.assertTrue(all(s['behavior_only'] and s['when']=={} for s in stage))
        self.assertEqual(len({p for s in stage for p in s['resources']}),4)
        stage[0]['behavior_only']=False
        self.assertTrue(validate(plan,catalog))

    def test_missing_stage_is_never_filled_with_another_stage(self):
        plan=dict(states=[],issues=[],model_info={},target_mesh='M')
        add_landing_resources(plan,dict(assets=[dict(id='M',kind='mesh',skeleton='S')]),STAGE_ROLES,'')
        self.assertEqual(len([i for i in plan['issues'] if i['severity']=='error']),4)

if __name__=='__main__':unittest.main()
