import unittest
from candidate_policy import selection_policy,semantic_exclusion,direction

class CandidatePolicyTests(unittest.TestCase):
    def test_explicit_text_limits(self):
        for text,n in [('每类动作只选一段',1),('每类动画保留4段',4),('每个插槽最多两条',2),('每类四段，支持 WASD',4)]:
            self.assertEqual(selection_policy(text)['max_candidates_per_role'],n,text)
        self.assertIsNone(selection_policy('每类保留多段，不要只选一段')['max_candidates_per_role'])
        with self.assertRaises(ValueError):selection_policy('每类最多0段')
        self.assertEqual(selection_policy('每类保留4段；下蹲保留5段')['max_candidates_by_role'],{'crouch':5})
    def test_exclude_wrong_animation_domains(self):
        for name in ('M_Neutral_AO_Stand_X90','Run_Lean_Pose_Base','LookAtPOI_test_relaxed_idle_loop','Traversal_Climb_Run','Jump_Traversal_Catch'):
            self.assertTrue(semantic_exclusion(dict(name=name)),name)
        self.assertIsNone(semantic_exclusion(dict(name='M_Neutral_Run_Loop_F')))
    def test_grouped_role_limits(self):
        policy=selection_policy('待机只保留1段；行走、跑步各最多4段；下蹲最多5段；跳跃最多4段')
        self.assertEqual(policy['max_candidates_by_role'],dict(idle=1,walk=4,run=4,crouch=5,jump=4))
        self.assertEqual(selection_policy('行走和跑步各保留两段')['max_candidates_by_role'],dict(walk=2,run=2))
    def test_direction_and_authoring_target(self):
        self.assertEqual([direction(dict(name='Run_Loop_'+suffix)) for suffix in ('F','B','LL','RL')],['forward','back','left','right'])
        policy=selection_policy('Motion Matching 数据库，需要前后左右，无法确认的待人工检查')
        self.assertTrue(policy['index_jump']);self.assertTrue(policy['review_uncertain']);self.assertTrue(policy['require_cardinal_directions'])

if __name__=='__main__':unittest.main()
