"""Build an isolated candidate serialization fixture. Jump stand-ins test timing, not semantics."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import json,sys
from pathlib import Path
ROOT=_gasp_workspace;sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from split_protocol import compile_split
from config_tool import validate
folder=ROOT/'artifacts/anim_config/verification/hybrid_ue'
catalog=json.loads((folder/'catalog.json').read_text());old=json.loads((ROOT/'unreal/Saved/AnimationConfigurator/ActionFlow/catalog.json').read_text(encoding='utf-8-sig'))
actions=[a for a in old['assets'] if a['kind']=='sequence'];catalog['assets'].extend(actions)
aliases={a['id']:f'a{i}' for i,a in enumerate(catalog['assets'])}
attack=next(a['id'] for a in actions if 'attack' in a['id']);hit=next(a['id'] for a in actions if 'hit' in a['id']);run=catalog['assets'][1]['id']
g=dict(roles=['run'],slots={'run':'locomotion','hit':'action','attack':'action'},filters={},policy={'hit_interrupts':'all','attack_exit':'finished','after_hit':'previous'},blend_seconds=.15,reject=None)
s=dict(bindings={'run':aliases[run],'hit':aliases[hit],'attack':aliases[attack]},issues={})
plan=compile_split(catalog,'配置跑步、攻击和受击；受击打断并恢复上一动作，攻击必须播放完成。','/Game/Native/Generated/HybridActionProbe_20261021',g,s,{})
plan['states'][0]['resources']=[a['id'] for a in catalog['assets'][1:4]]
plan['runtime_flow']['action_candidates']={'attack':[attack,hit],'hit':[hit,attack]}
plan['issues'].append(dict(severity='warning',code='timing_fixture_only',message='专用序列化测试：两个跳跃片段仅作为动作时序替身，非真实攻击/受击。'))
assert not validate(plan,catalog),validate(plan,catalog)
(folder/'actions_catalog.json').write_text(json.dumps(catalog),encoding='utf-8')
(folder/'actions_plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
print('ACTION_CANDIDATES_FIXTURE_READY')
