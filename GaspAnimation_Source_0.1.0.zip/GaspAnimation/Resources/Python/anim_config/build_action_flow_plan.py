"""Create deterministic playback-test plan, independent of trained model quality."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from split_protocol import compile_split
from protocol import compact_catalog
root=_gasp_workspace
out=root/'unreal/Saved/AnimationConfigurator/ActionFlow'
catalog=json.loads((out/'catalog.json').read_text(encoding='utf-8-sig'))
_,ids=compact_catalog(catalog);reverse={v:k for k,v in ids.items()}
byname={a['name']:a['id'] for a in catalog['assets']}
g={'roles':['idle','run'],'slots':{'idle':'locomotion','run':'locomotion','hit':'action','attack':'action'},'blend_seconds':.15,'filters':{},'policy':{'hit_interrupts':'all','attack_exit':'finished','after_hit':'previous','sprint_aim':'block'},'reject':None}
s={'bindings':{r:reverse[next(a['id'] for a in catalog['assets'] if (r in ('idle','run') and a['kind']=='database' and (('Idle' if r=='idle' else 'Run_Loops') in a['name'])) or a['name']==f'A_{r}_PlaybackTest')] for r in g['slots']},'issues':{}}
destination='/Game/Native/Generated/ActionFlowConfig_'+sys.argv[1]
plan=compile_split(catalog,'配置待机和跑步；受击打断所有当前动作；攻击必须播完才能退出；受击结束恢复上一个动作；冲刺时禁止瞄准；混合时间0.15秒',destination,g,s,{'verification_fixture':True})
(out/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
print(destination)
