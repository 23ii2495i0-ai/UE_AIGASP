import unittest
from unified_content_rules import content_constraints
from unified_behavior import resolve_content

class ContentRulesTests(unittest.TestCase):
    def test_limits_and_aliases_use_arbitrary_ids_and_shared_budget(self):
        text='L（站立行走）、R（站立跑步）、C（蹲姿移动）、S（站立待机）、Z（蹲姿待机）、U（起跳与上升）、D（空中下降）。\nL、R、C 每类最多选8段。S、Z 各最多1段；U 和 D 合计最多4段。'
        self.assertEqual([content_constraints(text,n)['max_candidates'] for n in ['L','R','C','S','Z','U','D']],[8,8,8,1,1,2,2])
        self.assertEqual(content_constraints(text,'C')['role'],'crouch_move')
        self.assertIsNone(content_constraints('自定义礼仪动作 Stellar','Stellar')['role'])

    def test_role_filter_keeps_crouch_and_air_phases_separate(self):
        catalog=dict(assets=[dict(id='M',kind='mesh',skeleton='S')])
        for name in ['Stand_Idle_Loop','Crouch_Idle_Loop','Walk_Loop_F','Crouch_Walk_Loop_F','Jump_F_Start','Jump_Fall_Loop','Jump_F_Land_Run','AO_Walk_Loop']:
            catalog['assets'].append(dict(id=name,name=name,kind='sequence',skeleton='S',num_frames=60))
        for role,query,expected in [('idle','idle loop',['Stand_Idle_Loop']),('walk','walk loop',['Walk_Loop_F']),('crouch_move','crouch walk loop',['Crouch_Walk_Loop_F']),('jump_start','jump',['Jump_F_Start']),('jump_fall','jump',['Jump_Fall_Loop'])]:
            found,issue=resolve_content(dict(queries=[query],resources=[],max_candidates=8),catalog,'M','mm',role)
            self.assertEqual(found,expected);self.assertIsNone(issue)
        found,issue=resolve_content(dict(queries=[],resources=['Crouch_Idle_Loop'],max_candidates=1),catalog,'M','mm','walk')
        self.assertEqual(found,[]);self.assertTrue(issue)

    def test_directional_candidates_before_repeated_forward_variants(self):
        catalog=dict(assets=[dict(id='M',kind='mesh',skeleton='S')])
        for name in ['Run_Loop_F_A','Run_Loop_F_B','Run_Loop_L','Run_Loop_R','Run_Loop_B']:
            catalog['assets'].append(dict(id=name,name=name,kind='sequence',skeleton='S',num_frames=60))
        found,_=resolve_content(dict(queries=['run loop'],resources=[],max_candidates=4),catalog,'M','mm','run')
        self.assertIn('Run_Loop_L',found);self.assertIn('Run_Loop_R',found);self.assertIn('Run_Loop_B',found)

if __name__=='__main__':unittest.main()
