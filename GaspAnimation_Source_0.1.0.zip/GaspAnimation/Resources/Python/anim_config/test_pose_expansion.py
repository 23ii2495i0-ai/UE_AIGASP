import io,pickle,sys,unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from fetch_humanact12 import load_numeric
from train_pose_expanded import resample_motion,SMPL_BONES


class NotNumeric:
    def __reduce__(self):return eval,('40+2',)


class ExpansionTests(unittest.TestCase):
    def test_short_motion_resampled_with_real_endpoints(self):
        x=np.arange(9*24*3,dtype=np.float32).reshape(9,24,3)
        p,t=resample_motion(x)
        self.assertEqual(p.shape,(16,11,3));np.testing.assert_array_equal(p[0],x[0,list(SMPL_BONES)])
        np.testing.assert_array_equal(p[-1],x[-1,list(SMPL_BONES)])
        self.assertEqual(t[-1],8);self.assertTrue(np.all(np.diff(t)>0))

    def test_invalid_geometry_rejected(self):
        for x in (np.zeros((1,24,3)),np.zeros((16,22,3)),np.full((16,24,3),np.nan)):
            with self.assertRaises(ValueError):resample_motion(x)

    def test_numeric_pickle_only(self):
        a={'joints3D':[np.arange(12,dtype=np.float32).reshape(2,2,3)],'y':[1]}
        b=load_numeric(pickle.dumps(a,protocol=4));np.testing.assert_array_equal(a['joints3D'][0],b['joints3D'][0])
        with self.assertRaisesRegex(ValueError,'Blocked pickle global'):load_numeric(pickle.dumps(NotNumeric()))


if __name__=='__main__':unittest.main()
