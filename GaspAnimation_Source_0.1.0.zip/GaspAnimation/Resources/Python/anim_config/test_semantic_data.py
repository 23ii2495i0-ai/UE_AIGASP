import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from build_semantic_split import example
from split_protocol import generator_messages,merge

class SemanticDataTests(unittest.TestCase):
    def test_guided_resource_free_generator(self):
        for i in range(100):
            g,s=example(1200000+i,'train')
            self.assertEqual(g['prompt_version'],2)
            self.assertEqual(g['messages'][:-1],generator_messages(g['request'],2))
            self.assertNotIn('catalog',g)
            self.assertEqual(g['target'],s['configuration'])
            merge(s['catalog'],g['target'],s['target'])
    def test_prompt_version_is_explicit(self):
        self.assertNotEqual(generator_messages('配置跑步',1),generator_messages('配置跑步',2))
        with self.assertRaises(ValueError):generator_messages('配置跑步',99)
if __name__=='__main__':unittest.main()
