"""Regression checks for failed staged generation; no GPU required."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
import split_runtime
import config_tool
from behavior_graph import default_graph, explicit_layout_errors, validate_graph, generation_schema,explicit_parent_groups


class GenerationRecoveryTests(unittest.TestCase):
    def test_parent_guard_does_not_treat_entry_or_mm_clauses_as_children(self):
        for suffix in ('；初始子状态 Idle，入口 Ground。','，均使用 MM；入口 Ground。','；initial Idle; entry Ground.'):
            self.assertEqual(explicit_parent_groups('Ground 为父状态，包含 Idle、Walk'+suffix),{'Ground':['Idle','Walk']})
        graph=default_graph();graph['states']=[dict(graph['states'][0],id='Ground',player='group',initial='Idle'),dict(graph['states'][0],id='Idle',parent='Ground'),dict(graph['states'][0],id='Walk')]
        self.assertEqual(explicit_layout_errors('Ground 为父状态，包含 Idle、Walk；入口 Ground。',graph),['Walk 必须存在并设置 parent=Ground'])
    def test_mm_cache_isolated_from_graph_destination_and_mutations(self):
        runtime=split_runtime.SplitRuntime.__new__(split_runtime.SplitRuntime);calls=[]
        def generate(catalog,request,destination,info):
            calls.append(request);return dict(destination=destination,model_info={},issues=[]),{},{}
        runtime.generate=generate;catalog={'assets':[]}
        first,_,_=runtime.behavior_mm_resources(catalog,'idle','/Game/First',{})
        first['model_info']['changed']=True
        second,_,_=runtime.behavior_mm_resources(catalog,'idle','/Game/Second',{})
        self.assertEqual(len(calls),1);self.assertEqual(second['destination'],'/Game/Second');self.assertNotIn('changed',second['model_info'])
        self.assertTrue(second['model_info']['behavior_mm_resource_cache']['hit'])
        runtime.behavior_mm_resources(catalog,'run','/Game/Third',{});self.assertEqual(len(calls),2)
    def test_failed_mm_selection_is_never_cached(self):
        runtime=split_runtime.SplitRuntime.__new__(split_runtime.SplitRuntime);calls=[]
        def generate(*args):
            calls.append(True);return dict(model_info={},issues=[dict(severity='error')]),{},{}
        runtime.generate=generate
        for _ in range(2):runtime.behavior_mm_resources({'assets':[]},'idle','/Game/Test',{})
        self.assertEqual(len(calls),2)
    def test_empty_or_failed_draft_keeps_original_diagnostic(self):
        for contents,expected in [('', '没有有效草案'),('{"error":"原始生成失败"}', '原始生成失败')]:
            with tempfile.TemporaryDirectory() as folder:
                root=Path(folder);catalog=root/'catalog.json';plan=root/'plan.json'
                catalog.write_text('{"assets":[]}',encoding='utf-8');plan.write_text(contents,encoding='utf-8')
                args=['config_tool','validate','--catalog',str(catalog),'--plan',str(plan),'--output',str(root/'result.json')]
                with patch.object(sys,'argv',args),self.assertRaisesRegex(ValueError,expected):config_tool.main()
                self.assertEqual(plan.read_text(encoding='utf-8'),contents)

    def test_decoder_accepts_real_json_group_booleans(self):
        try:from lmformatenforcer import JsonSchemaParser
        except ImportError:self.skipTest('model decoder dependency not installed')
        state=default_graph()['states'][0]
        group=dict(state,id='Ground',player='group',loop=False,initial='Idle')
        child=dict(state,id='Idle',parent='Ground')
        layout=dict(locomotion_roles=['idle'],entry='Ground',variables={},inputs=[],states=[group,child])
        parser=JsonSchemaParser(generation_schema(['a1'],stage='layout'))
        for character in json.dumps(layout,separators=(',',':')):
            self.assertIn(character,parser.get_allowed_characters())
            parser=parser.add_character(character)
        self.assertTrue(parser.can_end())

    def test_empty_model_output_has_actionable_error_and_raw_record(self):
        runtime=split_runtime.SplitRuntime.__new__(split_runtime.SplitRuntime)
        runtime.predict_batch=lambda *args:['']
        with tempfile.TemporaryDirectory() as folder,patch.object(split_runtime,'_LAYOUT_REPO',Path(folder)):
            path=Path(folder)/'artifacts/anim_config/models/configuration/logs'
            path.mkdir(parents=True)
            with self.assertRaisesRegex(ValueError,'空输出'):runtime.predict('behavior',[])
            self.assertTrue((path/'latest_behavior_output.txt').exists())

    def test_explicit_groups_cannot_silently_become_flat_states(self):
        graph=default_graph()
        graph['states']=[dict(graph['states'][0],id=n) for n in ('Ground','Idle','Walk','Run')]
        request='Ground 为父状态，包含 Idle、Walk、Run。'
        self.assertEqual(len(explicit_layout_errors(request,graph)),4)
        graph['states'][0].update(player='group',loop=False,initial='Idle')
        for state in graph['states'][1:]:state['parent']='Ground'
        self.assertEqual(explicit_layout_errors(request,graph),[])

    def test_reachability_reports_actual_state_names(self):
        graph=default_graph();graph['states'].append(dict(graph['states'][0],id='Orphan'))
        self.assertIn('状态机：存在从入口不可达的状态：Orphan',validate_graph(graph,{'assets':[]},None))

    def run_generation(self,repair_valid=True):
        runtime=split_runtime.SplitRuntime.__new__(split_runtime.SplitRuntime)
        graph=default_graph();graph['version']=2
        graph['states'].append(dict(graph['states'][0],id='Other'))
        layout={k:copy.deepcopy(graph[k]) for k in ('entry','variables','inputs','states')}
        layout['locomotion_roles']=['idle']
        calls=[]
        def predict(task,messages):
            # Initial stage prompt precedes any retry feedback.
            prompt=next(json.loads(m['content']) for m in messages if m['role']=='user' and m['content'].startswith('{'))
            calls.append(prompt['stage'])
            if prompt['stage']=='layout':return copy.deepcopy(layout)
            if prompt['stage']=='transitions':return {'transitions':[]}
            repaired=copy.deepcopy(graph)
            if repair_valid:repaired['transitions']=[dict({'from':'Locomotion','to':'Other','event':'Go','all':[],'priority':0,'interrupt':False})]
            return dict(transitions=repaired['transitions'])
        runtime.predict=predict
        runtime.generate=lambda *args:({'model_info':{},'issues':[]},{},{})
        catalog={'assets':[dict(id='mesh',kind='mesh',skeleton='s'),dict(id='clip',kind='sequence',skeleton='s',name='Idle',loop=True)]}
        with tempfile.TemporaryDirectory() as folder,patch.object(split_runtime,'_LAYOUT_REPO',Path(folder)):
            if repair_valid:
                plan,_,_=runtime.generate_behavior_legacy(catalog,'配置待机','/Game/Test',{})
                self.assertEqual(plan['behavior_graph']['transitions'][0]['to'],'Other')
                log=json.loads((Path(folder)/'artifacts/anim_config/models/configuration/logs/latest_behavior_stages.json').read_text(encoding='utf-8'))
                self.assertEqual(log['errors'],[])
                self.assertTrue(any(f['stage']=='whole_graph' for f in log['failures']))
            else:
                with self.assertRaisesRegex(ValueError,'Other'):runtime.generate_behavior_legacy(catalog,'配置待机','/Game/Test',{})
                self.assertEqual(calls.count('repair_transitions'),3)
        return calls

    def test_whole_graph_failure_is_repaired_and_logged(self):self.assertIn('repair_transitions',self.run_generation())
    def test_exhausted_repair_is_rejected(self):self.run_generation(False)

if __name__=='__main__':unittest.main()
