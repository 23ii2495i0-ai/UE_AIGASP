import sys,unittest,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from split_protocol import compile_split
from protocol import compact_catalog
from config_tool import validate

class MMAuthoringTests(unittest.TestCase):
    def fixture(self,jump_loop=False):
        roles=['idle','walk','run','crouch']
        mesh=dict(id='/Game/M',name='Mesh',kind='mesh',skeleton='s',bones=['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03'])
        catalog=dict(version=1,assets=[mesh]+[dict(id='/Game/'+r,name=r+'_Loop_F',kind='sequence',skeleton='s',loop=r!='jump') for r in roles+['jump']])
        if jump_loop:catalog['assets'][-1]['loop']=True
        _,ids=compact_catalog(catalog);reverse={v:k for k,v in ids.items()}
        g=dict(roles=roles,slots={**{r:'locomotion' for r in roles},'jump':'action'},blend_seconds=.2,filters={},policy={},reject=None)
        s=dict(bindings={r:reverse['/Game/'+r] for r in g['slots']},issues={})
        plan=compile_split(catalog,'待机、行走、跑步、下蹲、跳跃，每类动作只选一段，加入 Motion Matching 数据库','/Game/Test',g,s,{})
        return catalog,plan
    def test_jump_is_indexed_in_air_and_not_a_montage(self):
        catalog,plan=self.fixture()
        self.assertEqual(validate(plan,catalog),[])
        self.assertNotIn('jump',plan['runtime_flow']['actions'])
        self.assertEqual(next(s['when'] for s in plan['states'] if s['id']=='jump'),{'MovementMode':1})
        self.assertIn('jump',plan['model_info']['flow_ir']['bindings'])
    def test_crouch_stopped_and_airborne_coverage(self):
        _,plan=self.fixture()
        for mode,state,stance,gait,expected in [(0,0,1,1,'crouch'),(0,1,1,0,'crouch'),(0,0,0,1,'idle'),(0,1,0,0,'walk'),(0,1,0,1,'run'),(1,0,0,1,'jump'),(1,1,1,2,'jump')]:
            context=dict(MovementMode=mode,MovementState=state,Stance=stance,Gait=gait)
            matches=[s['id'] for s in plan['states'] if all(context[k]==v for k,v in s['when'].items())]
            self.assertEqual(matches,[expected],context)
    def test_text_limit_is_checked_after_manual_edits(self):
        catalog,plan=self.fixture()
        run=next(s for s in plan['states'] if s['id']=='run')
        run['resources']=['/Game/run','/Game/walk']
        self.assertTrue(any('text limit' in e for e in validate(plan,catalog)))
    def test_indexed_jump_accepts_airborne_loop(self):
        catalog,plan=self.fixture(jump_loop=True)
        self.assertEqual(validate(plan,catalog),[])
    def test_additive_and_crouch_idle_cannot_be_standing_idle(self):
        catalog,plan=self.fixture()
        next(a for a in catalog['assets'] if a['id']=='/Game/idle')['name']='Crouch_Idle_Loop'
        from config_tool import signature
        plan['catalog_signature']=signature(catalog)
        self.assertTrue(any('conflicting' in e for e in validate(plan,catalog)))

if __name__=='__main__':unittest.main()
