"""Run inside UE Python: sparse numerical poses only, never infer labels from names."""
import hashlib
import json
import os
import time
import sys
from pathlib import Path
import unreal
sys.path.insert(0,str(Path(__file__).resolve().parent/'ai'))
from project_paths import configure_imports
configure_imports()
from motion_window_policy import sparse_windows,POLICY

ROOT=Path(os.environ.get('GASP_REPO','.')).resolve()
SOURCE=Path(os.environ['GASP_MOTION_CATALOG'])
OUTPUT=Path(os.environ.get('GASP_MOTION_OUTPUT',str(ROOT/'artifacts/anim_config/models/pose/samples/sparse_v1/catalog_motion.json')))
COUNT=int(os.environ.get('GASP_MOTION_SAMPLES','16'))
WINDOWED=os.environ.get('GASP_MOTION_WINDOWED')=='1'
LIMIT=int(os.environ.get('GASP_MOTION_LIMIT','0'))
if not 8<=COUNT<=64:raise ValueError('GASP_MOTION_SAMPLES must be 8..64')
OUTPUT.parent.mkdir(parents=True,exist_ok=True)
CACHE=OUTPUT.parent/'sample_cache';CACHE.mkdir(exist_ok=True)
ALIASES={
 'root':('root',),'pelvis':('pelvis','Hips'),'spine':('spine_03','Spine2'),
 'head':('head','Head'),'hand_l':('hand_l','LeftHand'),'hand_r':('hand_r','RightHand'),
 'foot_l':('foot_l','LeftFoot'),'foot_r':('foot_r','RightFoot'),
 'knee_l':('calf_l','LeftLeg'),'knee_r':('calf_r','RightLeg'),
 'elbow_l':('lowerarm_l','LeftForeArm'),'elbow_r':('lowerarm_r','RightForeArm')}
AP=unreal.AnimPoseExtensions
OPTIONS=unreal.AnimPoseEvaluationOptions()
OPTIONS.set_editor_property('extract_root_motion',False)
OPTIONS.set_editor_property('incorporate_root_motion_into_pose',True)
OPTIONS.set_editor_property('evaluate_curves',False)
OPTIONS.set_editor_property('evaluation_type',unreal.AnimDataEvalType.RAW)


def fingerprint(obj):
    package=obj.get_path_name().split('.')[0]
    # A package hash includes changes to keyframes; skeleton reference pose is hashed too.
    filename=Path(unreal.Paths.convert_relative_path_to_full(unreal.PackageTools.find_package_file_without_extension(package))) if hasattr(unreal.PackageTools,'find_package_file_without_extension') else None
    if not filename or not filename.is_file():
        if not package.startswith('/Game/'):
            raise ValueError('Cannot fingerprint non-project package: '+package)
        filename=ROOT/'unreal/Content'/(package[len('/Game/'):]+'.uasset')
    h=hashlib.sha256()
    for suffix in ('.uasset','.uexp','.ubulk'):
        part=filename.with_suffix(suffix)
        if part.exists():h.update(part.read_bytes())
    if not filename.exists():raise ValueError('Cannot fingerprint asset: '+str(filename))
    return h.hexdigest()


def vec(p):return [round(float(p.x),5),round(float(p.y),5),round(float(p.z),5)]
def quat(q):
    sign=-1 if q.w<0 else 1
    return [round(sign*float(v),7) for v in (q.x,q.y,q.z,q.w)]


def sample(row):
    if row['kind']!='sequence':
        return dict(status='unknown',reason='database_requires_member_sampling',schema=1)
    anim=unreal.load_asset(row['id'])
    if not isinstance(anim,unreal.AnimSequence):raise ValueError('Selected sequence cannot load')
    skeleton=anim.get_editor_property('skeleton')
    if not skeleton or skeleton.get_path_name()!=row.get('skeleton'):raise ValueError('Catalog skeleton changed')
    key_data=dict(schema=1,samples=COUNT,asset_sha256=fingerprint(anim),skeleton_sha256=fingerprint(skeleton),aliases=ALIASES)
    if WINDOWED:key_data['window_policy']=POLICY
    key=hashlib.sha256(json.dumps(key_data,sort_keys=True).encode()).hexdigest()
    cache=CACHE/(key+'.json')
    if cache.exists():return json.loads(cache.read_text(encoding='utf-8')),True
    length=float(anim.get_play_length())
    if length<=0:raise ValueError('Animation has zero duration')
    first=AP.get_anim_pose_at_time(anim,0.,OPTIONS)
    available=[str(n) for n in AP.get_bone_names(first)]
    bones={}
    for role,aliases in ALIASES.items():
        matches=[n for n in available if any(n==alias or n.endswith(':'+alias) for alias in aliases)]
        if len(matches)==1:bones[role]=matches[0]
    missing=sorted(set(ALIASES)-set(bones))
    if missing:return dict(status='unknown',reason='missing_required_bones',missing=missing,schema=1),False
    ref=AP.get_reference_pose(skeleton)
    head=AP.get_ref_bone_pose(ref,bones['head'],unreal.AnimPoseSpaces.WORLD).translation
    foot=AP.get_ref_bone_pose(ref,bones['foot_l'],unreal.AnimPoseSpaces.WORLD).translation
    height=sum((float(a)-float(b))**2 for a,b in zip(vec(head),vec(foot)))**.5
    if height<=1:raise ValueError('Invalid reference skeleton scale')
    windows=sparse_windows(0.,length) if WINDOWED else None
    times=sorted(set(t for window in windows for t in window)) if windows else [length*i/(COUNT-1) for i in range(COUNT)]
    frames=[]
    for i,t in enumerate(times):
        pose=first if i==0 else AP.get_anim_pose_at_time(anim,t,OPTIONS)
        root=AP.get_bone_pose(pose,bones['root'],unreal.AnimPoseSpaces.WORLD)
        positions={};rotations={}
        for role,bone in bones.items():
            world=AP.get_bone_pose(pose,bone,unreal.AnimPoseSpaces.WORLD)
            positions[role]=vec(root.inverse_transform_location(world.translation))
            rotations[role]=quat(AP.get_bone_pose(pose,bone,unreal.AnimPoseSpaces.LOCAL).rotation)
        frames.append(dict(time=t,root_position_cm=vec(root.translation),root_rotation=quat(root.rotation),positions_root_cm=positions,rotations_local=rotations))
    result=dict(status='sampled',schema=1,space='UE_cm_root_relative',sample_count=len(frames),duration=length,
                fingerprint=key_data,bones=bones,reference_height_cm=height,frames=frames)
    if windows:result.update(window_policy=POLICY,window_times=windows)
    cache.write_text(json.dumps(result,separators=(',',':')),encoding='utf-8')
    return result,False


def main():
    started=time.perf_counter();catalog=json.loads(SOURCE.read_text(encoding='utf-8-sig'))
    summary=dict(sampled=0,cached=0,unknown=0,errors=0,sequence_limit=LIMIT)
    processed=0
    for row in catalog['assets']:
        if row['kind']=='mesh':continue
        if row['kind']=='sequence' and LIMIT and processed>=LIMIT:
            row['motion_samples']=dict(status='unknown',reason='not_sampled_limit',schema=1);summary['unknown']+=1;continue
        try:
            if row['kind']!='sequence':result,cached=sample(row),False
            else:
                result,cached=sample(row);processed+=1
            row['motion_samples']=result
            summary['sampled' if result['status']=='sampled' else 'unknown']+=1
            summary['cached']+=int(cached)
        except Exception as exc:
            row['motion_samples']=dict(status='unknown',reason='sampling_failed',detail=str(exc),schema=1)
            summary['errors']+=1
        if processed and processed%50==0:unreal.log('MOTION_SAMPLES '+str(processed))
    summary['seconds']=round(time.perf_counter()-started,3)
    catalog['motion_sampling']=dict(schema=1,samples_per_sequence=COUNT,semantics_trained=False,summary=summary)
    OUTPUT.write_text(json.dumps(catalog,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    OUTPUT.with_suffix('.summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    unreal.log('MOTION_SAMPLES_COMPLETE '+json.dumps(summary))


main()
