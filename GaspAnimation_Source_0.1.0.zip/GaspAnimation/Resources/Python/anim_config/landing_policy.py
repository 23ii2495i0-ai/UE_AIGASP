"""Optional staged MM jump/landing policy. Recovery uses explicit reviewed time,
not sequence-completion semantics for a continuously searching MM database.
"""
import math
import re

STAGE_ROLES=('jump_start','jump_fall','jump_land','jump_land_run')

def landing_nodes(jump):
    p=(jump or {}).get('landing') or {}
    return {p[k] for k in ('group','land','land_run') if p.get(k)}

def durations(policy):
    return (policy.get('land_seconds') if policy.get('land_seconds') is not None else .35,
            policy.get('run_seconds') if policy.get('run_seconds') is not None else .7)

def validate_landing(jump,groups,ground):
    p=jump.get('landing')
    if p is None:return set()
    if not isinstance(p,dict) or not {'group','land','land_run'}<=set(p) or set(p)-{'group','land','land_run','land_seconds','run_seconds'}:raise ValueError('无效落地恢复策略')
    children=[p['land']]+([p['land_run']] if p['land_run'] else [])
    if p['group'] not in groups or p['group'] in (ground['group'],jump['group']) or len(set(children))!=len(children) or set(groups[p['group']]['children'])!=set(children) or groups[p['group']]['initial']!=p['land']:
        raise ValueError('落地恢复必须使用独立父组，完整声明Land及可选LandRun子状态，initial为Land')
    if p['land_run'] and not ground.get('run'):raise ValueError('跑步落地恢复需要已声明Run状态')
    for value in durations(p):
        if type(value) not in (int,float) or not math.isfinite(value) or not .05<=value<=5:raise ValueError('落地恢复时间必须为0.05～5秒')
    return set(children)

def phase_asset_matches(asset,role):
    words=set(re.findall(r'[a-z]+',asset.get('name','').lower()))
    if not words&{'jump','jumping'}:return False
    if role=='jump_start':return bool(words&{'start','off'}) and 'land' not in words
    if role=='jump_fall':return 'fall' in words and 'loop' in words
    if role=='jump_land':return 'land' in words and 'stand' in words
    if role=='jump_land_run':return 'land' in words and 'run' in words
    return False

def add_landing_resources(plan,catalog,roles,request):
    from candidate_policy import semantic_exclusion,selection_policy,direction
    assets=catalog['assets'];mesh=next(a for a in assets if a['id']==plan['target_mesh'])
    limits=selection_policy(request)
    plan['states']=[s for s in plan['states'] if s['id']!='jump' and s['id'] not in STAGE_ROLES]
    for role in STAGE_ROLES:
        if role not in roles:continue
        choices=[a for a in assets if a['kind']=='sequence' and a.get('skeleton')==mesh.get('skeleton') and
                 not semantic_exclusion(a) and phase_asset_matches(a,role) and
                 '/actionflowfixture/' not in a['id'].lower() and 'playbacktest' not in a['id'].lower()]
        # Prefer light stationary landings, heavier running recovery; neither
        # label proves a "stumble". The actual motion remains reviewable.
        choices.sort(key=lambda a:(0 if direction(a)=='forward' else 1,
                       0 if ('heavy' if role=='jump_land_run' else 'light') in a.get('name','').lower() else 1,a['id']))
        limit=limits['max_candidates_by_role'].get(role,limits['max_candidates_by_role'].get('jump',limits['max_candidates_per_role'] or 4))
        selected=[a['id'] for a in choices[:limit]]
        plan['states'].append(dict(id=role,resource=selected[0] if selected else None,resources=selected,when={},behavior_only=True))
        if not selected:plan['issues'].append(dict(severity='error',code='jump_phase_missing',role=role,message=role+' 缺少选中的同骨架真实阶段动画，禁止拿其他阶段补足。'))
    ids=[s['id'] for s in plan['states']];plan['intent_roles']=ids
    plan['transitions']=[dict({'from':a,'to':b,'blend_seconds':.2}) for a in ids for b in ids if a!=b]
    plan['issues'].append(dict(severity='warning',code='landing_review',message='跳跃阶段使用独立MM库；落地由真实Landed触发，恢复按IR中的秒数退出，并非MM动画播放完成。Land_Run_Heavy只是跑步落地候选，不能凭名称认定为踉跄，请审阅实际动作。'))
    return plan
