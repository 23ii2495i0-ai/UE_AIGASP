"""Deployment must reject stale paired metrics and failing task-specific evaluation."""
import contextlib,hashlib,io,json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
import promote_split

class PromotionTests(unittest.TestCase):
    def fixture(self,root):
        hashes={}
        for task in ('generator','selector'):
            p=root/task/'adapter';p.mkdir(parents=True)
            (p/'adapter_model.safetensors').write_bytes(task.encode());(p/'adapter_config.json').write_text('{}')
            hashes[task]=hashlib.sha256(task.encode()).hexdigest()
            (p.parent/'test_metrics.json').write_text(json.dumps({'task':task,'n':192,'metrics':{'json_valid':1,'protocol_valid':1,'exact':.9}}))
        (root/'pipeline_metrics.json').write_text(json.dumps({'n':192,'adapter_sha256':hashes,'metrics':{'exact':.8,'protocol_valid':1}}))
        required=['flow_native_graph','flow_saved_policy','flow_attack_locked','flow_montage_slot_active','flow_hit_interrupt','flow_previous_resumed','flow_natural_completion','flow_mm_recovered','flow_sprint_blocks_aim','flow_hit_returns_mm']
        (root/'native.json').write_text(json.dumps({'failures':0,'checks':[{'name':k,'passed':True} for k in required]}))
    def promote(self,root):
        args=['promote','--run',str(root),'--native-report',str(root/'native.json'),'--base',str(root)]
        with patch.object(sys,'argv',args),contextlib.redirect_stdout(io.StringIO()):promote_split.main()
    def test_stale_weights_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Path(tmp);self.fixture(r);(r/'selector/adapter/adapter_model.safetensors').write_bytes(b'changed')
            with self.assertRaises(ValueError):self.promote(r)
            self.assertFalse((r/'split_deployment.json').exists())
    def test_one_task_failure_blocks_pair(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Path(tmp);self.fixture(r);p=r/'generator/test_metrics.json';data=json.loads(p.read_text());data['metrics']['exact']=.84;p.write_text(json.dumps(data))
            with self.assertRaises(ValueError):self.promote(r)
    def test_complete_gate_publishes_pair(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Path(tmp);self.fixture(r);self.promote(r)
            self.assertEqual(set(json.loads((r/'split_deployment.json').read_text())['adapter_sha256']),{'generator','selector'})
if __name__=='__main__':unittest.main()
