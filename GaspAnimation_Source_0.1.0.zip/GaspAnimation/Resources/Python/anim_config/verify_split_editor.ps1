param([int]$Port=8766,[string]$UERoot='C:/Program Files/Epic Games/UE_5.8')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'FindSampleRoot.ps1')
$repo=Get-GaspSampleRoot
Push-Location $repo
try {
 $health=Invoke-RestMethod "http://127.0.0.1:$Port/health" -TimeoutSec 3
 if ($health.task_protocol -ne 'generator_selector_v1') {throw 'Not an independent generator/selector endpoint'}
 $session=Join-Path $repo ('unreal/Saved/AnimationConfigurator/SplitEditor_'+[guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory $session|Out-Null
 $py=Join-Path $repo '.anim_model_env/Scripts/python.exe'
 $ue=Join-Path $UERoot 'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'
 $project=Join-Path $repo 'unreal/GaspNative.uproject'
 Copy-Item unreal/Saved/AnimationConfigurator/ActionFlow/catalog.json "$session/catalog.json"
 '配置待机和跑步；受击打断所有当前动作；攻击必须播完才能退出；受击结束恢复上一个动作；冲刺时禁止瞄准；混合时间0.15秒'|Set-Content "$session/request.txt" -Encoding utf8
 $dest='/Game/Native/Generated/SplitModel_'+[guid]::NewGuid().ToString('N')
 & $py tools/anim_config/config_tool.py generate --provider local --endpoint "http://127.0.0.1:$Port/generate" --catalog "$session/catalog.json" --request "$session/request.txt" --destination $dest --output "$session/plan.json"
 if ($LASTEXITCODE) {throw 'Real paired-model generation failed'}
 & $py tools/anim_config/config_tool.py validate --catalog "$session/catalog.json" --plan "$session/plan.json" --output "$session/validation.json"
 if ($LASTEXITCODE) {throw 'Real paired-model plan failed validation'}
 function RunUE([string]$Name,[string[]]$Extra) {
  & $ue $project @Extra -unattended -nop4 -nosplash -NullRHI *> "$session/$Name.log"
  if ($LASTEXITCODE) {throw "UE verification failed: $Name"}
 }
 RunUE 'apply' @('-run=GaspConfigure','-Action=Apply',"-Catalog=$session/catalog.json","-Plan=$session/plan.json",'-TargetBlueprint=/Game/Native/Generated/ActionFlowFixture/BP_FlowTarget.BP_FlowTarget')
 RunUE 'verify' @('-run=GaspConfigure','-Action=Verify',"-Plan=$session/plan.json")
 $oldRepo=$env:GASP_REPO;$oldMode=$env:GASP_FLOW_MODE
 try {
  $env:GASP_REPO=$repo;$env:GASP_FLOW_MODE='verify'
  RunUE 'reload' @('-run=pythonscript',"-script=$repo/tools/ue/setup_action_flow_fixture.py")
 } finally {$env:GASP_REPO=$oldRepo;$env:GASP_FLOW_MODE=$oldMode}
 # No AnimationSet override: this proves the saved class blueprint binding is used.
 RunUE 'runtime' @('/Game/Native/Generated/ActionFlowFixture/L_ActionFlowRun','-game','-FlowSmoke','-benchmark','-fps=60')
 Copy-Item unreal/Saved/flow_smoke.json "$session/runtime.json"
 $runtime=Get-Content "$session/runtime.json" -Raw|ConvertFrom-Json
 if ($runtime.failures -ne 0) {throw 'Paired-model blueprint runtime failed'}
 # Also prove the original two-FBX Marker workflow with reference idle still works.
 & (Join-Path $repo 'tools/anim_config/verify_flow_model.ps1') -Port $Port -UERoot $UERoot
 if ($LASTEXITCODE) {throw 'Paired-model Marker workflow failed'}
 $run=(Resolve-Path -LiteralPath $health.run).Path
 if (!$run.StartsWith((Join-Path $repo 'artifacts/anim_config/models/configuration/runs'),[StringComparison]::OrdinalIgnoreCase)) {throw 'Unexpected model run directory'}
 @{passed=$true;session=$session;destination=$dest;checks=$runtime.checks.Count;marker_checks=9;deployment_sha256=$health.deployment_sha256}|ConvertTo-Json|Set-Content (Join-Path $run 'editor_verify.json') -Encoding utf8
 Write-Host "SPLIT_EDITOR_VERIFIED $session"
} finally {Pop-Location}
