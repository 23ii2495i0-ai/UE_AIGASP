"""Restricted animation configuration DSL, deterministic generator and dataset capture.
No external dependencies. Rule mode does not claim learned semantic understanding.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import urllib.request
from flow_schema import validate_runtime
from candidate_policy import semantic_exclusion,selection_policy,category_conflict
from behavior_graph import validate_graph,_id
from landing_policy import STAGE_ROLES

VERSION = 1
ROLES = {'idle': ('idle','idling','待机','站立'), 'walk': ('walk','walking','行走','走路','慢走'),
         'run': ('run','running','jog','jogging','跑步','奔跑','跑动'), 'sprint': ('sprint','sprinting','冲刺'), 'crouch': ('crouch','crouching','蹲伏','蹲下'),
         'crouch_idle':('crouch_idle','CrouchIdle','蹲姿待机'), 'crouch_move':('crouch_move','CrouchMove','蹲姿移动'), 'jump': ('jump','jumping','跳跃')}
UNSUPPORTED = ('翻越','跳跃','急停','持枪','瞄准','侧移','转身','vault','mantle','jump','strafe','pivot','rifle','aim')
CONDITIONS = {'MovementMode':{0,1}, 'MovementState': {0,1}, 'Gait': {0,1,2}, 'Stance': {0,1}}
ROLES.update({r:(r,) for r in STAGE_ROLES})

def mentioned(text, term):
    return term in text if any(ord(c)>127 for c in term) else re.search(r'\b'+re.escape(term)+r'\b',text) is not None

def requested_roles(text):
    return [r for r,names in ROLES.items() if any(mentioned(text.lower(),n) for n in names)]

def signature(catalog):
    return hashlib.sha256(json.dumps(catalog,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def tokens(text):
    return set(re.findall(r'[a-z]+', re.sub(r'([a-z])([A-Z])',r'\1 \2',text).lower()))

def classified(asset, role):
    if role in ('crouch_idle','crouch_move'):
        return not category_conflict(asset,role)
    words=tokens(asset.get('name',asset['id'])) | set(asset.get('tags',[]))
    aliases={'idle':{'idle','idles'},'walk':{'walk','walks','walking'},'run':{'run','runs','running','jog'},'sprint':{'sprint','sprints','sprinting'},'crouch':{'crouch','crouched','crouches'},'jump':{'jump','jumping'}}
    return bool(words & aliases[role])

def generate(catalog, request, destination):
    assets=catalog['assets']; meshes=[a for a in assets if a['kind']=='mesh']
    issues=[{'severity':'warning','code':'rule_scope','message':'Rule mode recognizes action keywords only. Review the full request for additional semantics before applying.'}]
    if len(meshes)!=1:issues.append({'severity':'error','code':'target_mesh','message':'Select exactly one skeletal mesh.'})
    mesh=meshes[0] if len(meshes)==1 else None
    roles=requested_roles(request)
    if not roles:issues.append({'severity':'error','code':'unknown_intent','message':'Specify idle/walk/run/sprint/crouch; no action is guessed.'})
    for word in UNSUPPORTED:
        if mentioned(request.lower(),word):issues.append({'severity':'error','code':'unsupported_intent','message':f'v1 cannot implement this requested behavior: {word}'})
    states=[]
    for role in roles:
        candidates=[a for a in assets if a['kind'] in ('sequence','database') and classified(a,role) and mesh and a.get('skeleton')==mesh['skeleton']]
        candidates.sort(key=lambda a:a['id'])
        if len(candidates)!=1:
            issues.append({'severity':'error','code':'missing_resource' if not candidates else 'ambiguous_resource','role':role,
                'message':f'{role}: expected one compatible resource, found {len(candidates)}. Edit the draft to choose explicitly.',
                'candidates':[a['id'] for a in candidates]})
        when={'Stance':1} if role=='crouch' else {'MovementState':0 if role in ('idle','crouch_idle') else 1,'Stance':1 if role.startswith('crouch_') else 0}
        when['MovementMode']=0
        if role in ('walk','run','sprint') and len(set(roles)&{'walk','run','sprint'})>1:when['Gait']={'walk':0,'run':1,'sprint':2}[role]
        states.append({'id':role,'resource':candidates[0]['id'] if len(candidates)==1 else None,'when':when})
    # Static reference pose is an explicit gap, never presented as a generated idle animation.
    if 'idle' not in roles:issues.append({'severity':'warning','code':'reference_idle','message':'No idle requested: stopped pose uses the mesh reference pose.'})
    plan={'version':VERSION,'provider':'rules','request':request,'catalog_signature':signature(catalog),
        'destination':destination,'target_mesh':mesh['id'] if mesh else None,'states':states,
        'transitions':[{'from':a['id'],'to':b['id'],'blend_seconds':.2} for a in states for b in states if a!=b],
        'parameters':{'mesh_yaw':-90.,'reference_idle':'idle' not in roles,'play_rate':1.},'issues':issues}
    return plan

def validate(plan,catalog):
    errors=[]
    def need(ok,msg):
        if not ok:errors.append(msg)
    need(isinstance(plan,dict),'Plan must be an object')
    if not isinstance(plan,dict):return errors
    need(set(plan)<= {'version','provider','request','catalog_signature','destination','target_mesh','states','transitions','parameters','issues','intent_roles','model_info','runtime_flow','behavior_graph'},'Unknown plan field')
    unified=plan.get('model_info',{}).get('unified_requirements')
    custom_roles={s.get('database_role') for s in plan.get('behavior_graph',{}).get('states',[]) if s.get('player')=='mm' and s.get('database_role')}
    if unified:
        from unified_behavior import compile_unified,review_errors
        errors.extend(review_errors(plan))
        try:
            expected=compile_unified(unified,plan['request'],catalog,plan['destination'],plan['provider'])
            for key in ('behavior_graph','states','transitions','parameters','target_mesh','catalog_signature'):
                need(plan.get(key)==expected[key],'统一IR与编译结果不一致：'+key)
            need(not any(i['severity']=='error' for i in expected['issues']),'统一IR仍有资源或能力未解决项')
        except (ValueError,TypeError,KeyError) as error:errors.append('统一IR编译失败：'+str(error))
    if 'behavior_graph' in plan:
        errors.extend(validate_graph(plan['behavior_graph'],catalog,plan.get('target_mesh'),[s.get('id') for s in plan.get('states',[]) if isinstance(s,dict)]))
        metadata=plan.get('model_info',{})
        requirements=metadata.get('behavior_requirements') if isinstance(metadata,dict) else None
        provenance=metadata.get('behavior_generation',{}) if isinstance(metadata,dict) else {}
        if isinstance(provenance,dict) and provenance.get('mode')=='requirement_ir_compiler_v1':need(bool(requirements),'需求编译草案缺少IR，不能跳过语义审阅')
        if requirements:
            if 'behavior_manual_creation' in metadata:
                from manual_leaf_form import validate_creation
                errors.extend(validate_creation(requirements,metadata['behavior_manual_creation']))
            if 'behavior_human_review' in metadata:
                from behavior_human_review import validate_human_review
                errors.extend(validate_human_review(requirements,plan.get('request',''),metadata['behavior_human_review'],require_compiled=True))
            from behavior_requirements import semantic_audit
            try:
                errors.extend(semantic_audit(requirements,plan.get('request',''),plan['behavior_graph']))
                combo=requirements.get('combo')
                if combo:
                    attack_paths=[]
                    for state in plan['behavior_graph']['states']:
                        if state['id'] in combo['attacks']+[combo['hit']]:
                            need(not any('/actionflowfixture/' in p.lower() or 'playbacktest' in p.lower() for p in state.get('resources',[])),'真实动作需求不能使用PlaybackTest/ActionFlowFixture作为战斗资源')
                            if state['id'] in combo['attacks']:attack_paths.extend(state.get('resources',[]))
                    need(len(attack_paths)==len(set(attack_paths)),'多段攻击不能静默复用同一资源来冒充缺失的独立攻击素材')
            except (ValueError,TypeError,KeyError) as error:errors.append('需求IR或语义审阅记录无效，必须重新生成或审阅：'+str(error))
    runtime=plan.get('runtime_flow')
    if runtime is not None:errors.extend(validate_runtime(runtime,catalog,plan.get('target_mesh'),plan.get('states')))
    info=plan.get('model_info')
    if plan.get('provider')=='manual_review':
        need('behavior_graph' in plan and isinstance(info,dict) and bool(info.get('behavior_requirements')) and 'behavior_human_review' in info,'人工草案必须包含需求IR、状态图和人工确认记录')
    if isinstance(info,dict):need(not info.get('evaluation_only'),'Evaluation-only checkpoint cannot be applied')
    if isinstance(info,dict) and info.get('flow_protocol')==2:
        flow=info.get('flow_ir')
        need(isinstance(flow,dict),'V2 flow IR is required')
        if isinstance(flow,dict):
            for field in ('filters','actions','policy'):
                need(isinstance(flow.get(field),dict),'Invalid V2 '+field)
                if runtime is None:need(not flow.get(field),'V2 complex flow requires C++ runtime integration: '+field)
            if isinstance(runtime,dict):
                for field in ('filters','policy','blend_seconds'):need(runtime.get(field)==flow.get(field),'Runtime/model flow disagreement: '+field)
                ids={f'a{i}':a['id'] for i,a in enumerate(catalog['assets'])}
                if isinstance(flow.get('actions'),dict):need(runtime.get('actions')=={k:ids.get(v) for k,v in flow['actions'].items()},'Runtime/model action bindings disagree')
    need(type(plan.get('version')) is int and plan['version']==VERSION,'Unsupported plan version')
    need(plan.get('catalog_signature')==signature(catalog),'Catalog changed; regenerate or revalidate against the original selection')
    need(isinstance(plan.get('request'),str) and bool(plan['request'].strip()),'Request is required')
    if isinstance(plan.get('request'),str) and plan.get('provider') not in ('local_model','manual_review'):
        need(not any(mentioned(plan['request'].lower(),word) for word in UNSUPPORTED),'Request contains behavior outside v1 capabilities')
    destination=plan.get('destination','')
    need(isinstance(destination,str) and re.fullmatch(r'/Game/(?:[A-Za-z_][A-Za-z0-9_]*/)*[A-Za-z_][A-Za-z0-9_]*',destination) is not None,'Invalid destination package directory')
    assets={a['id']:a for a in catalog['assets']}
    mesh=assets.get(plan.get('target_mesh'))
    need(mesh is not None and mesh['kind']=='mesh','Target mesh must be in the selected catalog')
    if mesh:
        bones=mesh.get('bones',[])
        for aliases in [('pelvis','Hips'),('foot_l','LeftFoot'),('foot_r','RightFoot'),('thigh_l','LeftUpLeg'),('thigh_r','RightUpLeg'),('spine_03','Spine2')]:
            need(any(b==aliases[0] or b.endswith(aliases[1]) for b in bones),'Unsupported rig: missing bone alias '+str(aliases))
    states=plan.get('states',[]);need(isinstance(states,list) and (0 if 'behavior_graph' in plan else 1)<=len(states)<=32,'Invalid resource category count')
    if not isinstance(states,list):return errors
    ids=[];conditions=[]
    for state in states:
        if not isinstance(state,dict):errors.append('Invalid state');continue
        need(set(state)<= {'id','resource','resources','when','behavior_only'},'Unknown state field')
        if 'resources' in state:
            candidates=state['resources']
            valid=isinstance(candidates,list) and bool(candidates) and all(isinstance(p,str) for p in candidates)
            need(valid,'Invalid locomotion candidates')
            if valid:
                need(len(set(candidates))==len(candidates) and candidates[0]==state.get('resource'),'Invalid locomotion candidate primary')
                for path in candidates:
                    a=assets.get(path,{})
                    need(a.get('kind') in ('sequence','database') and mesh and a.get('skeleton')==mesh.get('skeleton'),'Incompatible locomotion candidate')
                    need(not semantic_exclusion(a),'Non-locomotion asset in movement candidates: '+str(path))
                    need(not category_conflict(a,state.get('id')),'Movement candidate has conflicting action/stance: '+str(path))
                need(len(candidates)==1 or all(assets.get(p,{}).get('kind')=='sequence' for p in candidates),'Mixed database/sequence candidates unsupported')
        role=state.get('id');custom=bool(role not in ROLES and role in custom_roles and _id(role))
        need((role in ROLES or custom) and role not in ids,'Invalid or duplicate state id');ids.append(role)
        resource=assets.get(state.get('resource'))
        need(resource is not None and resource['kind'] in ('sequence','database'),'State resource must be a selected sequence/database')
        if resource and mesh:need(resource.get('skeleton')==mesh.get('skeleton'),'Skeleton mismatch')
        if resource and resource['kind']=='sequence' and role!='jump' and role not in STAGE_ROLES and not custom:need(resource.get('loop') is True,'Locomotion sequence must be marked Loop before applying')
        if resource:need(not semantic_exclusion(resource),'Non-locomotion primary resource')
        if resource:need(not category_conflict(resource,role),'Primary resource has conflicting action/stance')
        when=state.get('when')
        need((role in STAGE_ROLES or custom)==(state.get('behavior_only') is True),'Explicit behavior databases must be behavior-only')
        if state.get('behavior_only') is True:
            need(when=={},'Behavior-only databases must not enter the native chooser')
            need(any(s.get('player')=='mm' and s.get('database_role')==role for s in plan.get('behavior_graph',{}).get('states',[])),'Behavior-only database needs an explicit MM state')
            continue
        need(isinstance(when,dict) and bool(when),'State conditions required')
        if isinstance(when,dict):
            need(all(k in CONDITIONS and type(v) is int and v in CONDITIONS[k] for k,v in when.items()),'Unknown condition or invalid value')
            if role=='jump':need(when=={'MovementMode':1},'Jump database must be selected only while airborne')
            else:
                need(when.get('MovementMode',0)==0,'Ground state cannot match airborne movement')
                need((role=='crouch' and 'MovementState' not in when) or when.get('MovementState')==(0 if role in ('idle','crouch_idle') else 1),'State MovementState must match role')
                need(when.get('Stance')==(1 if role in ('crouch','crouch_idle','crouch_move') else 0),'State Stance must match role')
            # Multi-result chooser must not activate two incompatible role groups simultaneously.
            for previous in conditions:need(any(k in previous and previous[k]!=v for k,v in when.items()),'Overlapping state conditions')
            conditions.append(when)
    parameters=plan.get('parameters',{});need(isinstance(parameters,dict),'Invalid parameters')
    if isinstance(plan.get('request'),str):
        requested=set(requested_roles(plan['request']))
        if plan.get('provider')=='local_model':
            intent=plan.get('intent_roles');need(isinstance(intent,list) and (bool(intent) or bool(unified)) and all(r in ROLES or (r in custom_roles and _id(r)) for r in intent),'Invalid learned intent')
            requested=set(intent) if isinstance(intent,list) else set()
        if 'behavior_graph' in plan and isinstance(plan.get('intent_roles'),list):requested=set(plan['intent_roles'])
        if plan.get('provider')=='manual_review' and not unified:
            try:
                from behavior_requirements import compile_requirements
                requested=set(compile_requirements(plan['model_info']['behavior_requirements'],plan['request'])[1])
            except (KeyError,TypeError,ValueError):
                requested=set();need(False,'人工需求IR无效，无法确定资源类别')
        need(set(ids)==requested,'States must cover exactly the requested supported roles')
    if isinstance(parameters,dict):
        need(set(parameters)=={'mesh_yaw','play_rate','reference_idle'},'Unknown or missing parameter')
        yaw=parameters.get('mesh_yaw');rate=parameters.get('play_rate')
        need(type(yaw) in (int,float) and math.isfinite(yaw) and -360<=yaw<=360,'Invalid mesh yaw')
        need(type(rate) in (int,float) and math.isfinite(rate) and .1<=rate<=3,'Invalid fixed play rate')
        need(type(parameters.get('reference_idle')) is bool,'reference_idle must be boolean')
        need(parameters.get('reference_idle')==((not bool(states)) if unified or any(s.get('behavior_only') for s in states) else 'idle' not in ids),'Reference idle must match resource configuration')
    transitions=plan.get('transitions');need(isinstance(transitions,list),'Transitions required')
    if isinstance(transitions,list):
        seen=set()
        for edge in transitions:
            if not isinstance(edge,dict):errors.append('Invalid transition');continue
            need(set(edge)=={'from','to','blend_seconds'},'Unknown or missing transition field')
            pair=(edge.get('from'),edge.get('to'));need(pair[0] in ids and pair[1] in ids and pair[0]!=pair[1] and pair not in seen,'Invalid or duplicate edge');seen.add(pair)
            value=edge.get('blend_seconds');need(type(value) in (int,float) and math.isfinite(value) and 0<=value<=2,'Blend seconds must be in [0,2]')
        need(seen=={(a,b) for a in ids for b in ids if a!=b},'Every state pair needs an explicit transition')
    issues=plan.get('issues');need(isinstance(issues,list),'Issues must be a list')
    if isinstance(plan.get('request'),str):
        try:constraints=selection_policy(plan['request']);limit=constraints['max_candidates_per_role'];overrides=constraints['max_candidates_by_role']
        except ValueError as error:errors.append(str(error));limit=None;overrides={}
        if limit or overrides:
            for state in states:
                if isinstance(state,dict):
                    paths=state.get('resources',[state.get('resource')])
                    role_limit=overrides.get(state.get('id'),limit)
                    if isinstance(paths,list) and role_limit:need(len(paths)<=role_limit,'Movement candidates exceed text limit: '+str(state.get('id')))
            if isinstance(runtime,dict) and isinstance(runtime.get('action_candidates'),dict):
                for role,paths in runtime['action_candidates'].items():
                    role_limit=overrides.get(role,limit)
                    if isinstance(paths,list) and role_limit:need(len(paths)<=role_limit,'Action candidates exceed text limit: '+role)
    if isinstance(issues,list):
        for issue in issues:
            if not isinstance(issue,dict) or issue.get('severity') not in ('warning','error'):errors.append('Invalid issue');continue
            if issue['severity']=='error':errors.append('Unresolved: '+str(issue.get('message','')))
    return errors

def model_generate(catalog,request,destination,endpoint,model):
    # Opt-in future adapter. Model output passes exactly the same deterministic validator.
    if not endpoint.startswith(('http://127.0.0.1:','http://localhost:')):raise ValueError('Only local endpoints are supported')
    example=generate(catalog,request,destination)
    prompt='Produce only JSON editable fields: target_mesh,states,transitions,parameters,issues. Metadata is assigned by the tool. Use this restricted animation config format. Never invent resource IDs. Resolve issues only when supported by the catalog. Supported state roles: idle,walk,run,sprint,crouch.\n'+json.dumps({'catalog':catalog,'draft':example},ensure_ascii=False)
    payload=json.dumps({'model':model,'prompt':prompt,'stream':False,'format':'json'}).encode()
    with urllib.request.urlopen(urllib.request.Request(endpoint,payload,{'Content-Type':'application/json'}),timeout=120) as response:result=json.load(response)
    plan=json.loads(result['response'])
    plan.update(version=VERSION, provider='ollama', request=request, destination=destination, catalog_signature=signature(catalog))
    return plan

def local_model_generate(catalog,request,destination,endpoint,behavior_mode=False,unified_mode=False,progress_file=None):
    from urllib.parse import urlparse
    parsed=urlparse(endpoint)
    if parsed.scheme!='http' or parsed.hostname not in ('127.0.0.1','localhost'):raise ValueError('Only a local model service is supported')
    payload={'catalog':catalog,'request':request,'destination':destination}
    import threading,time,uuid
    request_id=uuid.uuid4().hex;payload['request_id']=request_id
    stopped=threading.Event()
    def poll_progress():
        while not stopped.wait(1):
            try:
                with urllib.request.urlopen(endpoint.rsplit('/',1)[0]+'/progress',timeout=2) as response:status=json.load(response)
                if status.get('request_id')==request_id:
                    status['elapsed']=round(time.time()-status['started'],1)
                    target=Path(progress_file);temp=target.with_suffix('.tmp')
                    temp.write_text(json.dumps(status,ensure_ascii=False),encoding='utf-8');temp.replace(target)
            except (OSError,ValueError,KeyError):pass
    if progress_file:threading.Thread(target=poll_progress,daemon=True).start()
    if behavior_mode:payload['behavior_mode']=True
    if unified_mode:payload.update(behavior_mode=True,behavior_protocol='unified_state_v1')
    body=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request(endpoint,body,{'Content-Type':'application/json'}),timeout=1800 if behavior_mode or unified_mode else 600) as response:result=json.load(response)
    except urllib.error.HTTPError as e:
        text=e.read().decode('utf-8',errors='replace')
        try:text=json.loads(text).get('error',text)
        except (ValueError,TypeError):pass
        raise ValueError(text) from e
    finally:stopped.set()
    plan=result['plan']
    if plan.get('provider')!='local_model' or plan.get('catalog_signature')!=signature(catalog) or plan.get('request')!=request or plan.get('destination')!=destination:raise ValueError('Local service returned mismatched metadata')
    return plan

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['generate','validate','record','dataset','compile-behavior','review-draft','create-leaf']);p.add_argument('--catalog');p.add_argument('--plan');p.add_argument('--ir-file');p.add_argument('--form-file');p.add_argument('--request');p.add_argument('--destination',default='/Game/Native/Generated/AnimationSetup');p.add_argument('--output',required=True);p.add_argument('--provider',default='rules',choices=['rules','ollama','local']);p.add_argument('--model',default='');p.add_argument('--endpoint',default=None);p.add_argument('--samples');p.add_argument('--applied-manifest');p.add_argument('--behavior',action='store_true');p.add_argument('--unified-behavior',action='store_true');a=p.parse_args()
    out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
    if a.action=='dataset':
        examples=[json.loads(x) for x in Path(a.samples).read_text(encoding='utf-8').splitlines() if x.strip()]
        with out.open('w',encoding='utf-8') as f:
            for e in examples:
                f.write(json.dumps({'messages':[{'role':'user','content':json.dumps(e['input'],ensure_ascii=False)},{'role':'assistant','content':json.dumps({k:v for k,v in e['output'].items() if k not in ('version','provider','request','destination','catalog_signature','model_info')},ensure_ascii=False)}]},ensure_ascii=False)+'\n')
        return 0
    catalog=json.loads(Path(a.catalog).read_text(encoding='utf-8-sig'))
    if a.action=='create-leaf':
        from manual_leaf_form import create_leaf_plan
        import uuid
        if out.exists():Path(str(out)+'.before_manual_'+uuid.uuid4().hex+'.json').write_bytes(out.read_bytes())
        form=json.loads(Path(a.form_file).read_text(encoding='utf-8-sig'))
        plan=create_leaf_plan(form,catalog,a.destination)
        out.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8');return 0
    if a.action=='review-draft':
        from behavior_human_review import create_review_draft
        import uuid
        if out.exists():Path(str(out)+'.before_manual_'+uuid.uuid4().hex+'.json').write_bytes(out.read_bytes())
        ir=json.loads(Path(a.ir_file).read_text(encoding='utf-8-sig'))
        request=Path(a.request).read_text(encoding='utf-8-sig')
        if ir.get('protocol')=='unified_state_v1':
            from unified_behavior import compile_unified
            plan=compile_unified(ir,request,catalog,a.destination,provider='rules')
        else:plan=create_review_draft(ir,request,a.destination,catalog)
        out.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8');return 0
    if a.action=='generate':
        request=Path(a.request).read_text(encoding='utf-8-sig')
        if a.behavior and a.provider!='local':raise ValueError('状态机生成需选择本地模型模式')
        plan=generate(catalog,request,a.destination) if a.provider=='rules' else local_model_generate(catalog,request,a.destination,a.endpoint or 'http://127.0.0.1:8765/generate',a.behavior,a.unified_behavior,str(Path(a.output).with_name('progress.json'))) if a.provider=='local' else model_generate(catalog,request,a.destination,a.endpoint or 'http://127.0.0.1:11434/api/generate',a.model)
        out.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8');return 0
    plan_text=Path(a.plan).read_text(encoding='utf-8-sig')
    if not plan_text.strip():raise ValueError('没有有效草案：上次生成未成功。请先重新生成，不能检查或应用空白草案。')
    plan=json.loads(plan_text)
    if isinstance(plan,dict) and 'error' in plan:raise ValueError('上次生成失败：'+str(plan['error']))
    if a.action=='compile-behavior':
        if plan.get('model_info',{}).get('unified_requirements'):
            from unified_behavior import compile_unified,review_errors,compiled_signature
            import copy,uuid
            pending=review_errors(plan,require_compiled=False)
            if pending:raise ValueError('；'.join(pending))
            rebuilt=compile_unified(plan['model_info']['unified_requirements'],plan['request'],catalog,plan['destination'],plan['provider'])
            rebuilt['model_info']['unified_review']=copy.deepcopy(plan['model_info']['unified_review'])
            rebuilt['model_info']['behavior_generation'].update(requirements_edited_manually=True,previous_generation=plan['model_info'].get('behavior_generation'))
            rebuilt['model_info']['unified_review']['compiled_signature']=compiled_signature(rebuilt)
            Path(str(a.plan)+'.before_compile_'+uuid.uuid4().hex+'.json').write_text(plan_text,encoding='utf-8')
            out.write_text(json.dumps(rebuilt,ensure_ascii=False,indent=2),encoding='utf-8');return 0
        from behavior_requirements import compile_requirements,resource_bindings
        import uuid
        ir=plan.get('model_info',{}).get('behavior_requirements')
        if not ir:raise ValueError('缺少可审阅的需求IR；不能把自由图编辑冒充需求重新编译')
        review=plan['model_info'].get('behavior_human_review')
        if review is not None:
            from behavior_human_review import finalize_human_review
            finalize_human_review(ir,plan['request'],review)
        existing={s['id']:s.get('resources',[]) for s in plan.get('behavior_graph',{}).get('states',[])}
        bindings,issues=resource_bindings(ir,catalog)
        for name,paths in existing.items():
            if paths:bindings[name]=paths
        graph,roles=compile_requirements(ir,plan['request'],bindings)
        if set(roles)-{s['id'] for s in plan['states']}:raise ValueError('修改后的需求需要新的MM类别资源；请重新生成资源草案')
        # Persist the precompile draft even when input and output are the same.
        Path(str(a.plan)+'.before_compile_'+uuid.uuid4().hex+'.json').write_text(plan_text,encoding='utf-8')
        plan['behavior_graph']=graph
        provenance=plan['model_info'].setdefault('behavior_generation',{})
        provenance.update(requirements_edited_manually=True,assumptions={})
        plan['issues']=[i for i in plan['issues'] if i.get('code') not in ('behavior_resource_missing','behavior_content_review','behavior_external_unbound','behavior_unsupported','behavior_defaults_review')]
        for issue in issues:
            if issue['code']=='behavior_resource_missing' and any(issue['message'].startswith(name+' ') and paths for name,paths in bindings.items()):continue
            plan['issues'].append(issue)
        for variable in ir['external_variables']:plan['issues'].append(dict(severity='error',code='behavior_external_unbound',message=variable['id']+' 等待接入：'+variable['source']))
        for unsupported in ir['unsupported']:plan['issues'].append(dict(severity='error',code='behavior_unsupported',message=unsupported))
        plan['issues'].append(dict(severity='warning',code='behavior_manual_review',message='此需求IR经人工修改后重新编译，不能计为原始模型端到端生成成功。'))
        out.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8');return 0
    errors=validate(plan,catalog)
    if a.action=='record' and not errors:
        manifest=json.loads(Path(a.applied_manifest).read_text(encoding='utf-8-sig'))
        if json.loads(manifest.get('plan_text','null'))!=plan:errors.append('Apply manifest does not match the approved plan')
        else:
            sample={'input':{'request':plan['request'],'catalog':catalog,'destination':plan['destination']},'output':plan,'applied_assets':manifest['assets']}
            samples=Path(a.samples); previous=[json.loads(x) for x in samples.read_text(encoding='utf-8').splitlines() if x.strip()] if samples.exists() else []
            if not any(e['input']==sample['input'] and e['output']==sample['output'] for e in previous):
                samples.parent.mkdir(parents=True,exist_ok=True)
                with samples.open('a',encoding='utf-8') as f:f.write(json.dumps(sample,ensure_ascii=False)+'\n')
    out.write_text(json.dumps({'valid':not errors,'errors':errors},ensure_ascii=False,indent=2),encoding='utf-8');return int(bool(errors))

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        # Return a readable failure to the editor; never silently fall back from a model.
        if '--output' in sys.argv:Path(sys.argv[sys.argv.index('--output')+1]).write_text(json.dumps({'error':str(e)},ensure_ascii=False),encoding='utf-8')
        print(str(e),file=sys.stderr);sys.exit(2)


