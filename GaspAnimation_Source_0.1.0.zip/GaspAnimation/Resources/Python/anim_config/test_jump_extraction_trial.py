import copy
import unittest

from jump_extraction_trial import extract_jump, validate_evidence


class JumpEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.request = '\n'.join([
            'shell包含leftLeaf和rightLeaf，leftLeaf向上，rightLeaf向下。',
            '内部计数budget初始0，按键时budget < 2才实际起跳，成功后加1。',
            '落地时budget清零，禁止超过两次后继续起跳。'])
        self.reviewed = dict(topology=dict(entry='shell', groups=[dict(id='shell', children=['leftLeaf', 'rightLeaf'], initial='leftLeaf')], standalone=[]))
        def citation(line, **extra):
            return dict(line=line, quote=self.request.splitlines()[line], **extra)
        self.evidence = dict(status='required', trigger=citation(1), launch=citation(1),
            successful_count=citation(1), landing_reset=citation(2), limit=citation(1, value=2),
            counter=citation(1, id='budget'), states=[citation(0, id=name, role=role) for name, role in
            [('shell', 'air_group'), ('leftLeaf', 'rising'), ('rightLeaf', 'falling')]], negative_constraints=[citation(2)])
        self.policy = dict(group='shell', rise='leftLeaf', fall='rightLeaf', counter='budget', max_jumps=2)

    def run_outputs(self, outputs):
        calls = []
        def extract(stage, override=None):
            calls.append((stage, override))
            return copy.deepcopy(outputs[len(calls)-1])
        return calls, extract

    def test_required_evidence_and_policy_are_model_outputs(self):
        calls, extract = self.run_outputs([self.evidence, dict(policy=self.policy)])
        self.assertEqual(extract_jump('A', self.request, self.reviewed, extract), self.policy)
        self.assertEqual([c[0] for c in calls], ['jump_evidence', 'jump'])

    def test_null_with_positive_evidence_has_one_targeted_repair(self):
        calls, extract = self.run_outputs([self.evidence, dict(policy=None), dict(policy=self.policy)])
        self.assertEqual(extract_jump('B', self.request, self.reviewed, extract), self.policy)
        self.assertEqual([c[0] for c in calls], ['jump_evidence', 'jump', 'jump_repair'])
        self.assertIn('consistency_error', calls[-1][1][1][-1]['content'])

    def test_second_null_fails_instead_of_default_policy(self):
        calls, extract = self.run_outputs([self.evidence, dict(policy=None), dict(policy=None)])
        with self.assertRaisesRegex(ValueError, 'after one'):
            extract_jump('A', self.request, self.reviewed, extract)
        self.assertEqual(len(calls), 3)

    def test_nonnull_disagreement_is_not_overwritten(self):
        wrong = dict(self.policy, max_jumps=3)
        calls, extract = self.run_outputs([self.evidence, dict(policy=wrong), dict(policy=wrong)])
        with self.assertRaisesRegex(ValueError, 'disagree'):
            extract_jump('A', self.request, self.reviewed, extract)
        self.assertEqual(len(calls), 3)

    def test_fabricated_citation_stops_before_policy(self):
        evidence = copy.deepcopy(self.evidence); evidence['launch']['quote'] = 'invented launch'
        calls, extract = self.run_outputs([evidence])
        with self.assertRaisesRegex(ValueError, 'exact source'):
            extract_jump('A', self.request, self.reviewed, extract)
        self.assertEqual(len(calls), 1)

    def test_missing_counter_is_not_invented(self):
        evidence = copy.deepcopy(self.evidence); evidence['counter'] = None
        calls, extract = self.run_outputs([evidence])
        with self.assertRaisesRegex(ValueError, 'incomplete'):
            extract_jump('A', self.request, self.reviewed, extract)
        self.assertEqual(len(calls), 1)

    def test_no_jump_stays_null_despite_state_names(self):
        request = 'Air为地面组，Rise为待机；禁止所有跳跃。'
        evidence = dict(status='forbidden', trigger=None, launch=None, successful_count=None,
            landing_reset=None, limit=None, counter=None, states=[],
            negative_constraints=[dict(line=0, quote=request)])
        calls, extract = self.run_outputs([evidence, dict(policy=None)])
        self.assertIsNone(extract_jump('A', request, self.reviewed, extract))
        self.assertEqual(len(calls), 2)

    def test_prohibition_after_limit_does_not_invalidate_positive_evidence(self):
        validate_evidence(self.evidence, self.request, self.reviewed)

    def test_unclear_or_conflicting_evidence_rejected(self):
        for status in ('unclear', 'absent'):
            evidence = dict(self.evidence, status=status)
            with self.assertRaises(ValueError):validate_evidence(evidence, self.request, self.reviewed)

    def test_semantic_role_refs_must_match_reviewed_hierarchy(self):
        evidence = copy.deepcopy(self.evidence); evidence['states'][1]['id'] = 'shell'
        with self.assertRaisesRegex(ValueError, 'parent/child'):
            validate_evidence(evidence, self.request, self.reviewed)


if __name__ == '__main__':unittest.main()
