import copy
import unittest
from behavior_requirements import anchor_topology,compile_requirements,validate_extracted_stage,extraction_messages
from behavior_graph import validate_graph
from prepare_behavior_v3_smoke import IR
from candidate_policy import category_conflict,selection_policy
from split_crouch_resources import add_split_crouch_resources

SOURCE='入口 Ground。\nGround 是地面移动父组，包含以下五个直接子状态：\n1. Idle。\n2. Walk。\n3. Run。\n4. CrouchIdle。\n5. CrouchMove。\nGround 初始子状态为 Idle。'

def fixture():
    ir=copy.deepcopy(IR)
    topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run','CrouchIdle','CrouchMove'],initial='Idle',source_lines=[])])
    topology=anchor_topology(topology,SOURCE);topology['standalone']=[]
    ir.update(topology=topology,locomotion=dict(group='Ground',idle='Idle',walk='Walk',run='Run',crouch=None,crouch_idle='CrouchIdle',crouch_move='CrouchMove'),jump=None,combo=None)
    return ir

class SplitCrouchTests(unittest.TestCase):
    def test_multiline_source_and_distinct_roles_compile(self):
        ir=fixture();self.assertTrue(validate_extracted_stage('locomotion',dict(policy=ir['locomotion']),ir,SOURCE))
        schema,_=extraction_messages('locomotion',SOURCE,ir)
        fields=schema['properties']['policy']['anyOf'][0]['properties']
        self.assertEqual(fields['crouch_idle'],dict(type='string',enum=['CrouchIdle']))
        self.assertEqual(fields['crouch_move'],dict(type='string',enum=['CrouchMove']))
        self.assertEqual(fields['crouch'],dict(type='null'))
        graph,roles=compile_requirements(ir,SOURCE)
        self.assertEqual(roles,['idle','walk','run','crouch_idle','crouch_move'])
        self.assertEqual(validate_graph(graph,dict(assets=[]),None,roles),[])
        mapped={s['id']:s.get('database_role') for s in graph['states']}
        self.assertEqual(mapped['CrouchIdle'],'crouch_idle');self.assertEqual(mapped['CrouchMove'],'crouch_move')

    def test_next_parent_declaration_cannot_anchor_previous_group(self):
        source=SOURCE+'\nAir 是空中父组，包含 JumpRise、JumpFall。'
        topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run','CrouchIdle','CrouchMove'],initial='Idle',source_lines=[])])
        anchored=anchor_topology(topology,source)
        self.assertEqual(anchored['groups'][0]['source_lines'],list(range(1,7)))

    def test_every_source_selects_correct_crouch_or_standing_target(self):
        graph,_=compile_requirements(fixture(),SOURCE)
        for source in ['Idle','Walk','Run','CrouchIdle','CrouchMove']:
            for crouched in [True,False]:
                for moving in [False,True]:
                    for gait in [0,1,2]:
                        expected=('CrouchMove' if moving else 'CrouchIdle') if crouched else ('Idle' if not moving else 'Walk' if gait==0 else 'Run')
                        values=dict(crouched=crouched,move_input=1 if moving else 0,gait=gait)
                        def matches(p):
                            a=values[p['var']];b=p['value']
                            return {'eq':lambda:a==b,'gt':lambda:a>b,'ge':lambda:a>=b,'le':lambda:a<=b}[p['op']]()
                        targets={e['to'] for e in graph['transitions'] if e['from']==source and all(matches(p) for p in e['all'])}
                        self.assertEqual(targets,set() if source==expected else {expected},(source,values))

    def test_separate_resource_lists_limits_and_no_idle_in_moving(self):
        assets=[dict(id='/Game/M.M',kind='mesh',skeleton='S')]
        for name in ['M_Crouch_Idle_Loop','M_Crouch_Loop_F','M_Crouch_Loop_B','M_Crouch_Idle_Turn_L','M_Stand_Idle_Loop']:
            assets.append(dict(id='/Game/'+name+'.'+name,name=name,kind='sequence',skeleton='S',loop=True))
        assets.append(dict(id='/Game/Other.Other',name='M_Crouch_Idle_Loop',kind='sequence',skeleton='Other',loop=True))
        plan=dict(target_mesh='/Game/M.M',states=[],issues=[])
        add_split_crouch_resources(plan,dict(assets=assets),['crouch_idle','crouch_move'],'CrouchIdle：最多1段；CrouchMove：最多2段')
        idle,move=plan['states'];self.assertEqual(len(idle['resources']),1);self.assertEqual(len(move['resources']),2)
        self.assertFalse(set(idle['resources'])&set(move['resources']))
        self.assertTrue(all('Idle' not in p for p in move['resources']))
        self.assertFalse(any(i['severity']=='error' for i in plan['issues']))
        self.assertEqual(selection_policy('CrouchIdle：最多1段；CrouchMove：最多8段')['max_candidates_by_role']['crouch_move'],8)

    def test_missing_or_ambiguous_crouch_content_does_not_fill(self):
        for name in ['M_Stand_Idle','M_Crouch_Turn','M_Crouch_Jump']:
            self.assertTrue(category_conflict(dict(name=name),'crouch_move'))
        plan=dict(target_mesh='M',states=[],issues=[])
        add_split_crouch_resources(plan,dict(assets=[dict(id='M',kind='mesh',skeleton='S')]),['crouch_idle','crouch_move'],'')
        self.assertEqual(len([i for i in plan['issues'] if i['severity']=='error']),2)

    def test_partial_or_combined_split_roles_are_rejected(self):
        ir=fixture();ir['locomotion']['crouch_move']=None
        with self.assertRaisesRegex(ValueError,'同时声明'):compile_requirements(ir,SOURCE)
        ir=fixture();ir['locomotion']['crouch']='CrouchIdle'
        with self.assertRaisesRegex(ValueError,'不能同时'):compile_requirements(ir,SOURCE)

    def test_builtin_movement_is_not_an_unimplemented_external_dependency(self):
        ir=fixture()
        schema,_=extraction_messages('dependencies',SOURCE,ir)
        self.assertIn('character_movement',schema['properties']['unsupported']['items']['not']['enum'])
        with self.assertRaisesRegex(ValueError,'unsupported'):
            validate_extracted_stage('dependencies',dict(external_variables=[],unsupported=['character_movement']),ir,SOURCE)

    def test_crouch_leaves_cannot_be_reclassified_as_attack_and_hit(self):
        ir=fixture();bad=dict(attacks=['CrouchMove'],hit='CrouchIdle',buffer='Queued')
        with self.assertRaisesRegex(ValueError,'不能复用'):
            validate_extracted_stage('combo',dict(policy=bad),ir,SOURCE)
        ir['combo']=bad
        with self.assertRaisesRegex(ValueError,'不能复用'):compile_requirements(ir,SOURCE)

    def test_combo_decoder_excludes_all_movement_leaves_and_groups(self):
        ir=fixture();schema,_=extraction_messages('combo',SOURCE+'\nStrike Hurt',ir)
        props=schema['properties']['policy']['anyOf'][0]['properties']
        allowed=props['attacks']['items']['enum']
        for n in ['Ground','Idle','Walk','Run','CrouchIdle','CrouchMove']:self.assertNotIn(n,allowed)
        self.assertIn('Strike',allowed);self.assertIn('Hurt',allowed)
        closed=SOURCE+'\n除上述父组和子状态外，不创建其他行为状态。'
        schema,_=extraction_messages('combo',closed,ir)
        self.assertEqual(schema['properties']['policy'],dict(type='null'))

    def test_air_states_and_groups_cannot_be_action_players(self):
        ir=fixture();ir['jump']=dict(group='Air',rise='JumpRise',fall='JumpFall',counter='JumpCount',max_jumps=2)
        for n in ['Ground','Air','JumpRise','JumpFall']:
            with self.assertRaisesRegex(ValueError,'不能复用'):
                validate_extracted_stage('combo',dict(policy=dict(attacks=[n],hit='Hurt',buffer='Queued')),ir,SOURCE)

    def test_distinct_explicit_combat_children_remain_allowed_in_closed_layout(self):
        ir=fixture()
        ir['topology']['groups'].append(dict(id='Combat',children=['Strike','Hurt'],initial='Strike',source_lines=[8]))
        source=SOURCE+'\nCombat 是父组，包含 Strike、Hurt。\n除上述父组和子状态外，不创建其他行为状态。'
        schema,_=extraction_messages('combo',source,ir)
        props=schema['properties']['policy']['anyOf'][0]['properties']
        self.assertEqual(set(props['attacks']['items']['enum']),{'Strike','Hurt'})
        policy=dict(attacks=['Strike'],hit='Hurt',buffer='Queued')
        self.assertTrue(validate_extracted_stage('combo',dict(policy=policy),ir,source))
        ir['combo']=policy
        graph,_=compile_requirements(ir,source,dict(Strike=['/Game/Strike.Strike'],Hurt=['/Game/Hurt.Hurt']))
        self.assertEqual(next(s['player'] for s in graph['states'] if s['id']=='CrouchMove'),'mm')
        self.assertEqual(next(s['player'] for s in graph['states'] if s['id']=='Strike'),'sequence')

if __name__=='__main__':unittest.main()
