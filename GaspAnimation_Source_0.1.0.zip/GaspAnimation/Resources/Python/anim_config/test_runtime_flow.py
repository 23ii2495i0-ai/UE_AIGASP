import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from build_flow_data import make
from build_split_data import convert
from split_protocol import compile_split
import config_tool

class RuntimeFlowTests(unittest.TestCase):
    def fixture(self):
        for i in range(100):
            row=make(i,'train')
            if row['target']['reject'] is None and row['target']['actions']:
                g,s=convert(row)
                return row,compile_split(row['catalog'],row['request'],'/Game/Native/Generated/Test',g['target'],s['target'],{})
    def test_supported_flow(self):
        r,p=self.fixture();self.assertEqual([],config_tool.validate(p,r['catalog']))
    def test_invented_action_rejected(self):
        r,p=self.fixture();p['runtime_flow']['actions']['hit']='/Game/NotSelected.A'
        self.assertTrue(config_tool.validate(p,r['catalog']))
    def test_policy_mismatch(self):
        r,p=self.fixture();p['runtime_flow']['policy']['attack_exit']='invalid'
        self.assertTrue(config_tool.validate(p,r['catalog']))
    def test_no_capability_bypass(self):
        r,p=self.fixture();del p['runtime_flow'];p['issues']=[]
        self.assertTrue(config_tool.validate(p,r['catalog']))
    def test_evaluation_only_blocked(self):
        r,p=self.fixture();p['model_info']['evaluation_only']=True
        self.assertTrue(config_tool.validate(p,r['catalog']))
    def test_loop_action_blocked(self):
        r,p=self.fixture();c=copy.deepcopy(r['catalog']);path=next(iter(p['runtime_flow']['actions'].values()))
        next(a for a in c['assets'] if a['id']==path)['loop']=True
        p['catalog_signature']=config_tool.signature(c)
        self.assertTrue(config_tool.validate(p,c))
if __name__=='__main__':unittest.main()
