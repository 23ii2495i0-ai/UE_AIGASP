import unittest,sys,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'ai'))
from project_paths import configure_imports
configure_imports()
from flow_protocol import validate_ir,compile_flow,simulate_policy
from build_flow_data import make
import config_tool
class FlowTests(unittest.TestCase):
 def sample(self):
  return next(r for i in range(100) if (r:=make(i,'train'))['target']['policy'].get('attack_exit')=='finished' and r['target']['policy'].get('hit_interrupts')=='all' and not r['target']['reject'])
 def test_domain_oracle_all_cases(self):
  for i in range(240):
   r=make(i,'test');validate_ir(r['catalog'],r['target'])
 def test_complex_never_silently_applies(self):
  r=self.sample();p=compile_flow(r['catalog'],r['request'],'/Game/FlowTest',r['target'],{})
  self.assertTrue(config_tool.validate(p,r['catalog']))
  self.assertTrue(any(x['code']=='flow_runtime_unavailable' for x in p['issues']))
 def test_basic_still_compiles(self):
  r=next(r for i in range(200) if not (r:=make(i,'train'))['target']['filters'] and not r['target']['policy'] and not r['target']['actions'] and not r['target']['reject'])
  p=compile_flow(r['catalog'],r['request'],'/Game/FlowTest',r['target'],{})
  self.assertEqual(config_tool.validate(p,r['catalog']),[])
 def test_deleting_error_text_cannot_bypass_capability(self):
  r=self.sample();p=compile_flow(r['catalog'],r['request'],'/Game/FlowTest',r['target'],{})
  p['issues']=[]
  self.assertTrue(any('runtime integration' in e for e in config_tool.validate(p,r['catalog'])))
 def test_hit_priority_over_attack_lock(self):
  p=self.sample()['target'];self.assertEqual(simulate_policy(p,'attack','hit'),'hit')
 def test_unpromoted_diagnostic_cannot_apply(self):
  r=self.sample();p=compile_flow(r['catalog'],r['request'],'/Game/FlowTest',r['target'],{'evaluation_only':True})
  self.assertIn('Evaluation-only checkpoint cannot be applied',config_tool.validate(p,r['catalog']))
 def test_lock_requires_finish(self):
  p=self.sample()['target'];self.assertEqual(simulate_policy(p,'attack','run'),'attack');self.assertEqual(simulate_policy(p,'attack','run',True),'run')
 def test_restore_previous(self):
  p=self.sample()['target'];p['policy']['after_hit']='previous';self.assertEqual(simulate_policy(p,'hit','run',True,'attack'),'attack')
 def test_sprint_aim_mutual_exclusion(self):
  p=self.sample()['target'];p['policy']['sprint_aim']='block';self.assertEqual(simulate_policy(p,'sprint','aim'),'sprint')
 def test_reject_invented_id(self):
  r=self.sample();p=copy.deepcopy(r['target']);p['bindings'][p['roles'][0]]='a1000'
  with self.assertRaises(ValueError):validate_ir(r['catalog'],p)
 def test_no_code_or_unknown_policy(self):
  r=self.sample();p=copy.deepcopy(r['target']);p['policy']['execute']='print(1)'
  with self.assertRaises(ValueError):validate_ir(r['catalog'],p)
if __name__=='__main__':unittest.main()
