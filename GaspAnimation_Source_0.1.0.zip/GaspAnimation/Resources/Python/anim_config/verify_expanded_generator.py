"""Probe expanded slots with the installed adapters; never promote weights."""
import json
import argparse
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import REPO,configure_imports
configure_imports()
from split_runtime import SplitRuntime
from split_protocol import generator_messages,validate_generator

def main():
    root=REPO/'artifacts/anim_config/models/configuration'
    parser=argparse.ArgumentParser();parser.add_argument('--run',default='formal_split_release_v1');args=parser.parse_args()
    run=root/'runs'/args.run
    selector=run/'selector/adapter'
    if not selector.exists():selector=root/'runs/formal_split_release_v1/selector/adapter'
    runtime=SplitRuntime(root/'base_model',run/'generator/adapter',selector)
    requests=[
        ('配置待机、走路、跑步、冲刺、蹲伏、跳跃、攻击、受击、闪避翻滚。',
         {'idle','walk','run','sprint','crouch','jump','attack','hit','dodge'}),
        ('走跑跳蹲攻击受击，特殊状态选择闪避。受击打断所有动作，结束返回移动。',
         {'walk','run','crouch','jump','attack','hit','dodge'}),
    ]
    results=[]
    for request,expected in requests:
        try:
            prediction=runtime.predict('generator',generator_messages(request,3))
            validate_generator(prediction)
            passed=set(prediction['slots'])==expected and prediction['reject'] is None
            results.append(dict(request=request,prediction=prediction,passed=passed))
        except (ValueError,TypeError,KeyError) as error:
            results.append(dict(request=request,error=str(error),passed=False))
    output=REPO/'artifacts/anim_config/expanded_generator_probe.json'
    output.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(results,ensure_ascii=False,indent=2))
    return 0 if all(r['passed'] for r in results) else 1

if __name__=='__main__':sys.exit(main())
