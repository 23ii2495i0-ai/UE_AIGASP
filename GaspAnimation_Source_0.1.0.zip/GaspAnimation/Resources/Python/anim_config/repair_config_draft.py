"""Rebuild a reviewable draft from its recorded selected catalog and pose evidence.

Never modifies or applies a UE asset. Reuses numeric evidence, not synthetic pose scores.
"""
import argparse,copy,json,sys,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import REPO,configure_imports
configure_imports()
from split_protocol import compile_split
from hybrid_selection import PoseAssistant
from candidate_policy import selection_policy,direction
from config_tool import validate

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--session',type=Path,required=True);parser.add_argument('--request-file',type=Path);args=parser.parse_args()
    old=json.loads((args.session/'plan.json').read_text(encoding='utf-8-sig'))
    catalog=json.loads((args.session/'catalog.json').read_text(encoding='utf-8-sig'))
    evidence=old['model_info']['hybrid_selection']['evidence'];scores={e['id']:e.get('pose_scores',{}) for e in evidence}
    assistant=PoseAssistant.__new__(PoseAssistant)
    assistant.scores=lambda asset:(scores.get(asset['id'],{}),'recorded_previous_inference')
    ir=old['model_info']['flow_ir']
    g={k:copy.deepcopy(ir[k]) for k in ('roles','filters','policy','blend_seconds')}
    g.update(slots={**{r:'locomotion' for r in ir['roles']},**{r:'action' for r in ir['actions']}},reject=None)
    original=dict(bindings={**ir['bindings'],**ir['actions']},issues={})
    request_text=old['request']
    if args.request_file:
        from split_runtime import SplitRuntime
        from split_protocol import generator_messages,validate_generator,validate_action_coverage
        active=json.loads((REPO/'artifacts/anim_config/active_model.json').read_text(encoding='utf-8'))
        deployment=json.loads(Path(active['deployment']).read_text(encoding='utf-8'))
        run=Path(deployment['run']);runtime=SplitRuntime(deployment['base'],run/'generator/adapter',run/'selector/adapter')
        request_text=args.request_file.read_text(encoding='utf-8')
        g=runtime.predict('generator',generator_messages(request_text,runtime.generator_prompt_version));validate_generator(g);validate_action_coverage(request_text,g)
        original=dict(bindings={r:original['bindings'].get(r) for r in g['slots']},issues={r:'missing' for r in g['slots'] if not original['bindings'].get(r)})
    out=REPO/'artifacts/anim_config/verification/config_quality';out.mkdir(parents=True,exist_ok=True)
    (out/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False),encoding='utf-8')
    bp=REPO/'unreal/Content/Blueprints/Character/BP_CusGaspNativeCharacter.uasset'
    backup=out/'BP_CusGaspNativeCharacter.before_mm_repair.uasset'
    if bp.exists() and not backup.exists():shutil.copy2(bp,backup)
    summaries=[]
    for count in (1,4,5):
        complete_wasd=count==5
        limit=4 if complete_wasd else count
        request=request_text.replace('每类动作只选一段',f'每类动作最多保留{limit}段')+'\n支持 WASD 前后左右方向。'
        if complete_wasd:request+='\n下蹲保留5段，覆盖四向蹲行和蹲停。'
        constraints=selection_policy(request)
        selection,candidates,review=assistant.select(catalog,g,original,constraints)
        suffix='_MMRepairWASD' if complete_wasd else f'_MMRepair{count}'
        plan=compile_split(catalog,request,old['destination']+suffix,g,selection,dict(generator_reject=None,repair_source=str(args.session),selection_constraints=constraints))
        for state in plan['states']:
            if state['id'] in candidates:state['resources']=candidates[state['id']]
        plan['runtime_flow']['action_candidates']={r:candidates[r] for r in plan['runtime_flow']['actions'] if r in candidates}
        plan['model_info']['hybrid_selection']=dict(experimental=True,evidence=review,pose_evidence_source='previous_recorded_inference')
        assets={a['id']:a for a in catalog['assets']}
        coverage={r:sorted({direction(assets[p]) for p in paths}-{None}) for r,paths in candidates.items()}
        for role in ('walk','run','crouch'):
            missing={'forward','back','left','right'}-set(coverage.get(role,[]))
            if missing:plan['issues'].append(dict(severity='warning',code='direction_coverage',role=role,message='缺少方向：'+', '.join(sorted(missing))))
        for role,reason in selection['issues'].items():plan['issues'].append(dict(severity='error',code='selector_unresolved',role=role,message='仍未确认兼容资源：'+reason))
        errors=validate(plan,catalog)
        filename='plan_wasd_complete.json' if complete_wasd else f'plan_{count}_per_role.json'
        (out/filename).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
        summaries.append(dict(count=count,validation_errors=errors,resources=candidates,directions=coverage,unbound_review=sum(bool(r.get('review_reason')) for r in review)))
    (out/'draft_summary.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summaries,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
