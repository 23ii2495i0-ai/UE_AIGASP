"""Scoped compatibility for lm-format-enforcer's zero-length array bug.

0.11.3 pushes a first item parser even when maxItems is zero. Use a literal
empty-array parser instead. No installed dependency files are modified. The
service serializes generation; this lock also serializes local users here.
"""
from contextlib import contextmanager
from threading import RLock

_LOCK=RLock()

@contextmanager
def strict_empty_arrays():
    import lmformatenforcer.jsonschemaparser as module
    from lmformatenforcer.characterlevelparser import StringParser
    with _LOCK:
        original=module.get_parser
        def get_parser(root,schema):
            if schema is not None and schema.type=='boolean' and schema.enum is not None and len(schema.enum)==1 and type(schema.enum[0]) is bool:
                return StringParser('true' if schema.enum[0] else 'false')
            if schema is not None and schema.type=='array' and schema.maxItems==0:
                if schema.minItems and schema.minItems>0:
                    raise ValueError('Conflicting minItems/maxItems for empty array')
                return StringParser('[]')
            return original(root,schema)
        module.get_parser=get_parser
        try:yield
        finally:module.get_parser=original
