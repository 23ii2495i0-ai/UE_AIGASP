import unittest
from lmformatenforcer import JsonSchemaParser
from schema_decode_compat import strict_empty_arrays

class DecodeTests(unittest.TestCase):
    def test_fixed_boolean_uses_json_literal(self):
        self.assertTrue(self.accept(dict(type='boolean',enum=[False]),'false'))
        self.assertFalse(self.accept(dict(type='boolean',enum=[False]),'true'))
        self.assertFalse(self.accept(dict(type='boolean',enum=[False]),'False'))
    def accept(self,schema,text):
        with strict_empty_arrays():
            parser=JsonSchemaParser(schema)
            for char in text:
                if char not in parser.get_allowed_characters():return False
                parser=parser.add_character(char)
            return parser.can_end()

    def test_zero_array_rejects_first_item(self):
        schema=dict(type='object',properties=dict(transitions=dict(type='array',items=dict(type='object'),maxItems=0)),required=['transitions'],additionalProperties=False)
        self.assertTrue(self.accept(schema,'{"transitions":[]}'))
        self.assertFalse(self.accept(schema,'{"transitions":[{}]}'))

    def test_positive_limits_keep_items(self):
        schema=dict(type='array',items=dict(type='string'),maxItems=1)
        self.assertTrue(self.accept(schema,'["one"]'))
        self.assertFalse(self.accept(schema,'["one","two"]'))

    def test_factory_is_restored_after_error(self):
        import lmformatenforcer.jsonschemaparser as module
        old=module.get_parser
        with self.assertRaises(RuntimeError):
            with strict_empty_arrays():raise RuntimeError('probe')
        self.assertIs(module.get_parser,old)

if __name__=='__main__':unittest.main()
