"""Runtime configuration validation, independent of model adapters and deployment metadata."""
import math
import re

POLICIES={'sprint_aim':('block',),'hit_interrupts':('all',),'attack_exit':('finished',),'after_hit':('previous','locomotion')}
def validate_runtime(flow,catalog,mesh_path,states=None):
    errors=[]
    if not isinstance(flow,dict) or set(flow)-{'version','filters','actions','policy','blend_seconds','action_candidates'} or not {'version','filters','actions','policy','blend_seconds'}<=set(flow):
        return ['Invalid runtime_flow fields']
    if type(flow['version']) is not int or flow['version']!=1:errors.append('Unknown runtime flow version')
    filters=flow['filters'];actions=flow['actions'];policy=flow['policy'];blend=flow['blend_seconds']
    if not isinstance(filters,dict) or set(filters)-{'weapon','injured','aim'} or any(v!='rifle' if k=='weapon' else v is not True for k,v in filters.items()):errors.append('Invalid runtime filters')
    if not isinstance(policy,dict) or any(k not in POLICIES or v not in POLICIES[k] for k,v in policy.items()):errors.append('Invalid runtime policy')
    if type(blend) not in (int,float) or not math.isfinite(blend) or not 0<=blend<=2:errors.append('Invalid action blend')
    if not isinstance(actions,dict) or set(actions)-{'hit','attack','jump','dodge'}:return errors+['Invalid runtime actions']
    assets={a['id']:a for a in catalog['assets']};mesh=assets.get(mesh_path,{})
    for role,path in actions.items():
        a=assets.get(path) if isinstance(path,str) else None
        if not a or a['kind']!='sequence' or a.get('loop') is not False or a.get('skeleton')!=mesh.get('skeleton'):errors.append('Action must be selected compatible nonloop sequence: '+role)
    candidates=flow.get('action_candidates',{})
    if not isinstance(candidates,dict) or set(candidates)-set(actions):errors.append('Invalid action candidates')
    else:
        for role,paths in candidates.items():
            if not isinstance(paths,list) or not paths or any(not isinstance(p,str) for p in paths) or len(set(paths))!=len(paths) or paths[0]!=actions[role]:errors.append('Invalid action candidate primary: '+role);continue
            for path in paths:
                a=assets.get(path,{})
                if a.get('kind')!='sequence' or a.get('loop') is not False or a.get('skeleton')!=mesh.get('skeleton'):errors.append('Invalid action candidate: '+role)
    if isinstance(policy,dict):
        if 'attack_exit' in policy and 'attack' not in actions:errors.append('Attack policy needs attack slot')
        if any(k in policy for k in ('hit_interrupts','after_hit')) and 'hit' not in actions:errors.append('Hit policy needs hit slot')
    if isinstance(filters,dict) and isinstance(states,list):
        required=({'rifle'} if filters.get('weapon')=='rifle' else set())|{k for k in ('injured','aim') if filters.get(k)}
        expanded=[]
        for state in states:
            if isinstance(state,dict):
                paths=state.get('resources',[state.get('resource')])
                if isinstance(paths,list):expanded.extend(dict(state,resource=p) for p in paths)
        for state in expanded:
            a=assets.get(state.get('resource'),{}) if isinstance(state,dict) else {}
            name=re.sub(r'([a-z])([A-Z])',r'\1 \2',a.get('name','')).lower()
            words=set(re.findall('[a-z]+',name))|{str(t).lower() for t in a.get('tags',[])}
            variants=words&{'plain','neutral','rifle','injured','aim'}
            if variants and ((required and not required<=variants) or (not required and variants&{'rifle','injured','aim'})):
                errors.append('Locomotion resource contradicts requested variant: '+str(state.get('id')))
    return errors
