"""One frozen supervised evidence protocol; policy compilation is deterministic.

No model policy call, repair loop, name heuristic, or missing-fact default.
Citation provenance is checked in code; interpreting prose remains a model task.
"""
import copy
import hashlib
import json
import re
from pathlib import Path

from jump_extraction_trial import evidence_messages as old_messages, validate_evidence

SYSTEM = 'Extract source-grounded facts, not a state graph. Return only the evidence JSON. State identifiers are opaque references. Never guess behavior from a name. Use exact nonempty substrings from the numbered original source lines. Missing facts stay null. A prohibition on EXTRA jumps does not cancel allowed jumps.'
INSTRUCTION = '''判断实际起跳是required、absent、forbidden还是unclear，并摘录证据。required表示明确需要实际起跳；absent表示没有请求跳跃；forbidden只表示全部跳跃被明确禁止，允许N次但禁止额外跳跃仍为required。unclear用于矛盾或无法确定的要求。用line和连续原文quote引用触发、实际起跳、成功时计数、落地重置、次数上限、计数变量与初值，以及父组/上升/下降三个角色。关联ID必须在引用中出现。trigger.event填Jump或unspecified；launch.kind填jump或animation_only；successful_count提取增量value及timing(successful_launch_only/every_input/unspecified)；landing_reset提取value和event(landed/other/unspecified)；counter提取id和initial；limit.value是一个落地周期内成功起跳总次数。不要从初值、加一或动作名猜上限。negative_constraints的scope区分all_jumps、beyond_limit和other。absent/forbidden的正向事实为null、states为空；forbidden须引用禁止原文。只有明确出现的事实才能写入，缺字段不得编造默认值。不要输出policy，策略由宿主从这些字段确定性编译。'''
PROTOCOL = 'jump_cited_evidence_deterministic_v1'


def evidence_messages(request, reviewed):
    schema, messages = old_messages('B', request, reviewed)
    props = schema['properties']
    additions = {
        'trigger': {'event': {'type':'string','enum':['Jump','unspecified']}},
        'launch': {'kind': {'type':'string','enum':['jump','animation_only']}},
        'successful_count': {'value':{'type':'integer','minimum':0,'maximum':8}, 'timing':{'type':'string','enum':['successful_launch_only','every_input','unspecified']}},
        'landing_reset': {'value':{'type':'integer','minimum':-10,'maximum':10}, 'event':{'type':'string','enum':['landed','other','unspecified']}},
        'counter': {'initial':{'type':'integer','minimum':-10,'maximum':10}},
    }
    for key, fields in additions.items():
        # The old schema intentionally shares a citation-properties dictionary.
        # Typed facts need independent dictionaries (trigger.event != reset.event).
        props[key] = copy.deepcopy(props[key])
        fact = props[key]['anyOf'][0]
        fact['properties'].update(fields); fact['required'].extend(fields)
    negative = props['negative_constraints']['items']
    negative['properties']['scope'] = {'type':'string','enum':['all_jumps','beyond_limit','other']}
    negative['required'].append('scope')
    prompt = json.loads(messages[-1]['content'])
    prompt.update(stage='jump_evidence', protocol=PROTOCOL, instruction=INSTRUCTION)
    return schema, [dict(role='system',content=SYSTEM),dict(role='user',content=json.dumps(prompt,ensure_ascii=False))]


def protocol_fingerprint():
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def compile_evidence(evidence, request, reviewed):
    validate_evidence(evidence, request, reviewed)
    scopes = {fact['scope'] for fact in evidence['negative_constraints']}
    if evidence['status'] == 'required':
        if 'all_jumps' in scopes: raise ValueError('Required jump evidence conflicts with an all-jumps prohibition')
        if evidence['trigger']['event'] != 'Jump' or evidence['launch']['kind'] != 'jump':
            raise ValueError('Jump evidence does not specify a supported actual-launch trigger/action')
        count = evidence['successful_count']; reset = evidence['landing_reset']; counter = evidence['counter']
        if count['value'] != 1 or count['timing'] != 'successful_launch_only':
            raise ValueError('Unsupported/conflicting jump count update; only successful launches may increment by one')
        if reset['value'] != 0 or reset['event'] != 'landed' or counter['initial'] != 0:
            raise ValueError('Unsupported/conflicting jump initialization or landing reset')
        # Reject recognizable contradictory numeric statements; never use these
        # matches to create evidence or to fill any missing policy field.
        bounds = {int(n) for n in re.findall(r'(?<![A-Za-z0-9_])'+re.escape(counter['id'])+r'\s*(?:<|小于)\s*([0-9]+)',request)}
        if bounds and bounds != {evidence['limit']['value']}:
            raise ValueError('Cited jump limit conflicts with explicit counter bounds')
        for fact, key in ((count,'value'),(reset,'value'),(counter,'initial')):
            numbers={int(n) for n in re.findall(r'-?\d+',fact['quote'])}
            numbers.update(i for i, char in enumerate('零一二三四五六七八',0) if char in fact['quote'])
            if fact[key] not in numbers: raise ValueError('Jump numeric fact is absent from its quoted source')
        roles={fact['role']:fact['id'] for fact in evidence['states']}
        return dict(group=roles['air_group'],rise=roles['rising'],fall=roles['falling'],counter=counter['id'],max_jumps=evidence['limit']['value'])
    if 'beyond_limit' in scopes: raise ValueError('No-jump evidence contradicts a beyond-limit-only prohibition')
    if evidence['status']=='forbidden' and 'all_jumps' not in scopes:
        raise ValueError('Forbidden jump requires an explicit all-jumps prohibition')
    return None


def extract_jump(request, reviewed, extract):
    evidence=extract('jump_evidence',override=evidence_messages(request,copy.deepcopy(reviewed)))
    return compile_evidence(evidence,request,reviewed)
