"""Opt-in, untrained jump evidence experiment. Never supplies a policy itself.

Two fixed prompt variants share the same source/consistency guards. A model
policy is accepted only after cited evidence agrees with it. No name heuristic,
counter limit default, or silent repair is implemented here.
"""
import copy
import json
import re

from behavior_requirements import obj, arr, ident, optional, string, extraction_messages, source_identifiers, identifier_in

SYSTEM = 'Extract facts from the supplied request. Return only the requested JSON. Identifiers are opaque references, never evidence of behavior. Do not infer semantics from names. Cite exact nonempty substrings of original request lines. Do not create missing facts or defaults.'

INSTRUCTIONS = {
    'A': {
        'evidence': 'First decide whether actual jumping is required, absent, forbidden, or unclear. A ban on EXTRA jumps after an allowed limit does NOT forbid the allowed jumps. Extract cited trigger, successful-launch action, successful count increment, landing reset, integer jump limit, counter ID, and explicitly associated group/rising/falling states. Use role air_group/rising/falling according to behavior described in text, never names. For absent/forbidden jumping leave all positive facts null and states empty; cite prohibitions in negative_constraints. Missing or ambiguous required facts must stay null, not guessed. Each fact citation uses the original line index and exact quote; include referenced IDs in the quote. Limit value must be explicitly expressed in the quote.',
        'policy': 'Generate ONLY the jump policy from the reviewed jump evidence and full original request. Copy references according to cited roles, not name meaning. The maximum is the cited number of successful launches per landing cycle. A ban on extra jumps after that maximum does not mean no jump. If evidence says required, null contradicts it; do not invent missing facts. For absent/forbidden evidence use null. Return the ordinary policy object; do not emit evidence or transitions.'
    },
    'B': {
        'evidence': '先判断实际起跳是 required（有明确要求）、absent（未要求）、forbidden（整个起跳功能被禁止）还是 unclear。严格区分“禁止全部跳跃”和“允许N次、禁止更多次”；后者仍为required。逐项摘录原文证据：触发方式、次数上限、起跳动作、仅成功才计数、落地重置、内部计数名、关联父组及上升/下降子状态。状态名仅作不透明引用，不能根据拼写猜用途。证据用原文行号line与连续原文quote，涉及ID必须包含该ID。无法找到的事实写null，不补默认值。absent/forbidden的正向事实均为null、states为空，禁止条款摘到negative_constraints。',
        'policy': '仅根据jump_evidence中已引用的事实生成普通jump策略，原文保留用于核对。按证据role定位父组、上升、下降状态，不按状态名猜测。max_jumps是一次落地周期允许的成功起跳总次数。“允许N次但禁止额外跳跃”不能输出null。如果evidence状态为required，则policy=null属于前后矛盾；缺失事实不得编造。absent/forbidden才返回null。只输出policy对象，不输出证据或转换。'
    }
}


def _lines(request):
    return [line.strip() for line in request.splitlines() if line.strip()]


def evidence_messages(scheme, request, reviewed):
    lines = _lines(request)
    citation = dict(line=dict(type='integer', minimum=0, maximum=max(0, len(lines)-1)), quote=string())
    topology = reviewed['topology']
    names = sorted({n for group in topology['groups'] for n in [group['id']]+group['children']} | set(topology.get('standalone', [])))
    schema = obj(dict(
        status=dict(type='string', enum=['required', 'absent', 'forbidden', 'unclear']),
        trigger=optional(obj(citation)), launch=optional(obj(citation)),
        successful_count=optional(obj(citation)), landing_reset=optional(obj(citation)),
        limit=optional(obj(dict(citation, value=dict(type='integer', minimum=1, maximum=8)))),
        counter=optional(obj(dict(citation, id=ident(source_identifiers(request))))),
        states=arr(obj(dict(citation, id=ident(names), role=dict(type='string', enum=['air_group', 'rising', 'falling']))), 3),
        negative_constraints=arr(obj(citation), 16)))
    prompt = dict(stage='jump_evidence', instruction=INSTRUCTIONS[scheme]['evidence'],
                  request_lines=[dict(index=i, text=line) for i, line in enumerate(lines)],
                  reviewed_topology=copy.deepcopy(topology))
    return schema, [dict(role='system', content=SYSTEM), dict(role='user', content=json.dumps(prompt, ensure_ascii=False))]


def validate_evidence(evidence, request, reviewed):
    """Verify provenance and completeness, not the truth of model interpretation."""
    lines = _lines(request)
    def cite(fact):
        if not isinstance(fact, dict) or type(fact.get('line')) is not int or not 0 <= fact['line'] < len(lines):
            raise ValueError('Invalid jump evidence source line')
        if not isinstance(fact.get('quote'), str) or not fact['quote'].strip() or fact['quote'] not in lines[fact['line']]:
            raise ValueError('Jump evidence quote is not an exact source substring')
        if 'id' in fact and not identifier_in(fact['id'], fact['quote']):
            raise ValueError('Jump evidence identifier is absent from its cited quote')
    positive = ('trigger', 'launch', 'successful_count', 'landing_reset', 'limit', 'counter')
    for key in positive:
        if evidence.get(key) is not None: cite(evidence[key])
    for fact in evidence['states'] + evidence['negative_constraints']: cite(fact)
    if evidence['status'] == 'unclear': raise ValueError('Jump evidence is unclear; no policy may be invented')
    if evidence['status'] in ('absent', 'forbidden'):
        if any(evidence.get(key) is not None for key in positive) or evidence['states']:
            raise ValueError('No-jump evidence contradicts its positive jump facts')
        if evidence['status'] == 'forbidden' and not evidence['negative_constraints']:
            raise ValueError('Forbidden jump evidence requires a source citation')
        return
    if evidence['status'] != 'required' or any(evidence.get(key) is None for key in positive):
        raise ValueError('Required jump evidence is incomplete; missing facts cannot become defaults')
    limit = evidence['limit']
    # This only verifies a numeral occurs in the citation. Its semantic role is
    # still a model claim assessed by independent expected-label evaluation.
    numbers = {int(n) for n in re.findall(r'(?<![0-9])[0-9]+(?![0-9])', limit['quote'])}
    numbers.update(i for i, character in enumerate('一二三四五六七八', 1) if character in limit['quote'])
    if type(limit['value']) is not int or not 1 <= limit['value'] <= 8 or limit['value'] not in numbers:
        raise ValueError('Jump limit lacks an explicit cited numeral')
    roles = {fact['role']:fact['id'] for fact in evidence['states']}
    if len(evidence['states']) != 3 or set(roles) != {'air_group', 'rising', 'falling'}:
        raise ValueError('Required jump evidence needs three distinct state roles')
    groups = {group['id']:group for group in reviewed['topology']['groups']}
    if roles['air_group'] not in groups or set(groups[roles['air_group']]['children']) != {roles['rising'], roles['falling']} or roles['rising'] == roles['falling']:
        raise ValueError('Jump evidence roles contradict reviewed parent/child references')


def policy_messages(scheme, request, reviewed, evidence, previous=None, error=None):
    schema, messages = extraction_messages('jump', request, reviewed)
    prompt = json.loads(messages[-1]['content'])
    prompt.update(instruction=INSTRUCTIONS[scheme]['policy'], jump_evidence=copy.deepcopy(evidence))
    if error is not None:
        prompt.update(consistency_error=error, rejected_policy=previous,
                      repair_instruction='One repair only. Resolve this contradiction using cited source facts. No invented defaults, new states or omitted requirements.')
    return schema, [dict(role='system', content=SYSTEM), dict(role='user', content=json.dumps(prompt, ensure_ascii=False))]


def consistency_error(policy, evidence):
    if evidence['status'] in ('absent', 'forbidden'):
        return None if policy is None else 'Policy creates jumping although evidence says absent/forbidden'
    if policy is None: return 'Explicit required jump evidence was extracted, but the policy is null'
    roles = {fact['role']:fact['id'] for fact in evidence['states']}
    expected = dict(group=roles['air_group'], rise=roles['rising'], fall=roles['falling'],
                    counter=evidence['counter']['id'], max_jumps=evidence['limit']['value'])
    return None if policy == expected else 'Policy fields disagree with the cited state roles, counter or limit'


def extract_jump(scheme, request, reviewed, extract):
    if scheme not in INSTRUCTIONS: raise ValueError('Unknown fixed jump evidence scheme')
    evidence = extract('jump_evidence', override=evidence_messages(scheme, request, reviewed))
    validate_evidence(evidence, request, reviewed)
    policy = extract('jump', override=policy_messages(scheme, request, reviewed, evidence))['policy']
    error = consistency_error(policy, evidence)
    if error:
        policy = extract('jump_repair', override=policy_messages(scheme, request, reviewed, evidence, policy, error))['policy']
        remaining = consistency_error(policy, evidence)
        if remaining: raise ValueError('Jump extraction failed after one evidence-guided repair: '+remaining)
    return policy
