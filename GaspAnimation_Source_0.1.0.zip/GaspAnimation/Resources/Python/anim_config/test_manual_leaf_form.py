import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import config_tool
from manual_leaf_form import create_leaf_plan,check_form,validate_creation
from behavior_requirements import semantic_audit,validate_topology


CAT=dict(version=1,assets=[dict(id='/Game/M.M',name='M',kind='mesh',skeleton='/Game/S.S',bones=['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03'])]+[
    dict(id=f'/Game/{role}.{role}',name=role,kind='sequence',skeleton='/Game/S.S',loop=True,num_frames=20)
    for role in ('idle','walk','run')])


def form(name='Hub_7'):
    return dict(state_name=name,selection='native_ground',confirmed=True)


class ManualLeafTests(unittest.TestCase):
    def test_user_names_compile_to_one_native_leaf_without_generated_logic(self):
        for name in ('Hub_7','Travel','s0','AttackLabel','_Root'):
            with self.subTest(name=name):
                plan=create_leaf_plan(form(name),copy.deepcopy(CAT),'/Game/IsolatedManual')
                ir=plan['model_info']['behavior_requirements'];g=plan['behavior_graph']
                self.assertEqual(ir['topology'],dict(entry=name,groups=[],standalone=[name]))
                self.assertEqual(g['entry'],name);self.assertEqual(len(g['states']),1)
                leaf=g['states'][0];self.assertEqual(leaf['id'],name);self.assertEqual(leaf['player'],'locomotion')
                self.assertNotIn('database_role',leaf);self.assertNotIn('parent',leaf);self.assertNotIn('initial',leaf)
                for k in ('transitions','handlers','inputs'):self.assertEqual(g[k],[])
                self.assertEqual(g['variables'],{})
                self.assertEqual(config_tool.validate(plan,CAT),[])
                self.assertEqual(semantic_audit(ir,plan['request'],g),[])
                self.assertEqual({s['id'] for s in plan['states']},{'idle','walk','run'})
                self.assertFalse(plan['model_info']['behavior_generation']['model_called'])

    def test_invalid_unconfirmed_or_other_modes_never_create_a_default_state(self):
        for name in ('',None,True,'9bad','two states','../x','状态','a'*65):
            with self.subTest(name=name),self.assertRaises(ValueError):check_form(form(name))
        for delta in (dict(confirmed=False),dict(confirmed=1),dict(selection='infer'),dict(extra='Move')):
            f=form();f.update(delta)
            with self.subTest(delta=delta),self.assertRaises(ValueError):check_form(f)

    def test_missing_and_ambiguous_resources_remain_blocking(self):
        for catalog in (dict(assets=[]),dict(assets=[CAT['assets'][0]])):
            plan=create_leaf_plan(form(),catalog,'/Game/Manual')
            self.assertEqual(len(plan['behavior_graph']['states']),1)
            self.assertEqual(sum(i['code']=='missing_resource' for i in plan['issues']),3)
            self.assertTrue(config_tool.validate(plan,catalog))
            self.assertTrue(all(s['resource'] is None for s in plan['states']))
        c=copy.deepcopy(CAT);second=copy.deepcopy(c['assets'][1]);second['id']='/Game/idle2.idle2';c['assets'].append(second)
        plan=create_leaf_plan(form(),c,'/Game/Manual')
        self.assertIsNone(next(s for s in plan['states'] if s['id']=='idle')['resource'])
        self.assertTrue(any(i['code']=='ambiguous_resource' for i in plan['issues']))
        self.assertTrue(config_tool.validate(plan,c))

    def test_incompatible_and_pose_resources_are_not_substituted(self):
        for delta in (dict(skeleton='/Game/Other.Other'),dict(loop=False),dict(additive=True),dict(num_frames=1)):
            c=copy.deepcopy(CAT);c['assets'][1].update(delta)
            plan=create_leaf_plan(form(),c,'/Game/Manual')
            self.assertIsNone(next(s for s in plan['states'] if s['id']=='idle')['resource'])
            self.assertTrue(config_tool.validate(plan,c))

    def test_failed_or_absent_draft_cli_uses_no_models_and_keeps_backup(self):
        for previous in (None,'',json.dumps({'error':'model failed'}),'invalid json'):
            with self.subTest(previous=previous),tempfile.TemporaryDirectory() as folder:
                p=Path(folder);cp=p/'catalog.json';fp=p/'form.json';out=p/'plan.json'
                cp.write_text(json.dumps(CAT),encoding='utf-8');fp.write_text(json.dumps(form('Custom_Leaf')),encoding='utf-8')
                if previous is not None:out.write_text(previous,encoding='utf-8')
                args=['config_tool.py','create-leaf','--catalog',str(cp),'--form-file',str(fp),'--output',str(out)]
                with patch('sys.argv',args),patch('config_tool.local_model_generate',side_effect=AssertionError('model called')),patch('config_tool.model_generate',side_effect=AssertionError('model called')),patch('urllib.request.urlopen',side_effect=AssertionError('network called')):
                    self.assertEqual(config_tool.main(),0)
                plan=json.loads(out.read_text(encoding='utf-8'));self.assertEqual(config_tool.validate(plan,CAT),[])
                backups=list(p.glob('plan.json.before_manual_*.json'))
                self.assertEqual(len(backups),int(previous is not None))
                if backups:self.assertEqual(backups[0].read_text(encoding='utf-8'),previous)

    def test_edits_are_rejected_and_invalid_model_group_is_not_repaired(self):
        plan=create_leaf_plan(form(),copy.deepcopy(CAT),'/Game/Manual')
        ir=plan['model_info']['behavior_requirements'];ir['topology']['entry']='Other'
        self.assertTrue(validate_creation(ir,plan['model_info']['behavior_manual_creation']))
        self.assertTrue(config_tool.validate(plan,CAT))
        invalid=dict(entry='AnyName',groups=[dict(id='AnyName',children=[],initial='AnyName',source_lines=[0])],standalone=[])
        before=copy.deepcopy(invalid)
        with self.assertRaises(ValueError):validate_topology(invalid,'AnyName')
        self.assertEqual(invalid,before)


if __name__=='__main__':unittest.main()
