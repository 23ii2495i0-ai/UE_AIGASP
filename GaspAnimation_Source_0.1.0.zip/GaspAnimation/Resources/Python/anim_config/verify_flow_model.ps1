param([string]$UERoot='C:\Program Files\Epic Games\UE_5.8',[int]$Port=8766)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'FindSampleRoot.ps1')
$repo=Get-GaspSampleRoot
Push-Location $repo
try {
 $py=Join-Path $repo '.anim_model_env/Scripts/python.exe'
 $project=Join-Path $repo 'unreal/GaspNative.uproject'
 $editor=Join-Path $UERoot 'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'
 $health=Invoke-RestMethod "http://127.0.0.1:$Port/health" -TimeoutSec 3
 if ($health.flow_protocol -ne 2) {throw 'Not a V2 model endpoint'}
 $session=Join-Path $repo ('unreal/Saved/AnimationConfigurator/FlowV2_'+[guid]::NewGuid().ToString('N'))
 New-Item -ItemType Directory $session|Out-Null
 $destination='/Game/Native/Generated/FlowV2_'+[guid]::NewGuid().ToString('N')
 Copy-Item 'unreal/Saved/AnimationConfigurator/ModelIntegration/catalog.json' "$session/catalog.json"
 '配置跑步，停止移动时使用参考姿势'|Set-Content "$session/request.txt" -Encoding utf8
 & $py tools/anim_config/config_tool.py generate --provider local --endpoint "http://127.0.0.1:$Port/generate" --catalog "$session/catalog.json" --request "$session/request.txt" --destination $destination --output "$session/plan.json"
 if ($LASTEXITCODE) {throw 'Trained V2 generation failed'}
 & $py tools/anim_config/config_tool.py validate --catalog "$session/catalog.json" --plan "$session/plan.json" --output "$session/validation.json"
 if ($LASTEXITCODE) {throw 'Trained V2 basic plan is not applicable'}
 function RunUE([string]$Name,[string[]]$Extra) {
  & $editor $project @Extra -unattended -nop4 -nosplash -NullRHI *> "$session/$Name.log"
  if ($LASTEXITCODE) {Get-Content "$session/$Name.log" -Tail 15;throw "UE step failed: $Name"}
 }
 $oldRepo=$env:GASP_REPO;$oldMode=$env:GASP_BP_CHECK
 try {
  $env:GASP_REPO=$repo;$env:GASP_BP_CHECK='fixture'
  $fixture=Join-Path $repo 'tools/ue/verify_config_blueprint.py'
  RunUE 'fixture' @('-run=pythonscript',"-script=$fixture")
  RunUE 'apply' @('-run=GaspConfigure','-Action=Apply',"-Catalog=$session/catalog.json","-Plan=$session/plan.json",'-TargetBlueprint=/Game/Native/Generated/BlueprintWorkflowCheck/BP_ConfigTarget.BP_ConfigTarget')
  RunUE 'verify' @('-run=GaspConfigure','-Action=Verify',"-Plan=$session/plan.json")
  $env:GASP_BP_CHECK='verify'
  RunUE 'reload' @('-run=pythonscript',"-script=$fixture")
  RunUE 'runtime' @('/Game/Native/Generated/BlueprintWorkflowCheck/L_ConfigBlueprintRun','-game','-ConfigSmoke','-benchmark','-fps=60')
  Copy-Item unreal/Saved/config_smoke.json "$session/runtime.json"
  $runtime=Get-Content "$session/runtime.json" -Raw|ConvertFrom-Json
  if ($runtime.failures -ne 0) {throw 'V2 blueprint runtime smoke failed'}
 } finally {$env:GASP_REPO=$oldRepo;$env:GASP_BP_CHECK=$oldMode}
 Write-Output "FLOW_V2_UE_PASS session=$session generated=$destination"
} finally {Pop-Location}
