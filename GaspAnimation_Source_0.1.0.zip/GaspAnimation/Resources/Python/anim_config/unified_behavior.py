"""Uniform state/transition/content IR. No jump/combo/action-class templates.

Custom labels and content queries are data; a resource absent from the selected
catalog is an unresolved binding, never a silently substituted trained class.
"""
import copy
import hashlib
import json
import re
from behavior_graph import validate_graph,_id

PROTOCOL='unified_state_v1'

def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'))

def content_role(state_id):
    return 'mm_'+state_id if len(state_id)<=61 else 'mm_'+state_id[:44]+'_'+hashlib.sha256(state_id.encode()).hexdigest()[:10]

def words(value):
    return set(re.findall(r'[a-z0-9]+',re.sub(r'([a-z])([A-Z])',r'\1 \2',value).lower()))

def resolve_content(content,catalog,mesh,player,semantic_role=None):
    """Only exact selected IDs or explicit query tokens, over the entire catalog."""
    assets={a['id']:a for a in catalog['assets']};skeleton=assets[mesh].get('skeleton')
    explicit=content.get('resources',[])
    expected={'mm':('sequence','database'),'sequence':('sequence',),'montage':('montage',)}.get(player,())
    def compatible(a):
        from unified_content_rules import matches_role
        return a.get('kind') in expected and a.get('skeleton')==skeleton and not a.get('additive') and a.get('num_frames',2)>1 and '/actionflowfixture/' not in a['id'].lower() and 'playbacktest' not in a['id'].lower() and matches_role(a,semantic_role)
    if explicit:
        if len(explicit)!=len(set(explicit)) or any(p not in assets or not compatible(assets[p]) for p in explicit):
            return [],'资源未选中、重复、类型错误或骨架不兼容'
        if player!='mm' and len(explicit)!=1:return [],'单段播放器只能绑定一个资源'
        if len(explicit)>content.get('max_candidates',8):return [],'显式资源超过本状态候选上限'
        if len(explicit)>1 and any(assets[p]['kind']!='sequence' for p in explicit):return [],'MM多候选必须全部为动画序列'
        return explicit,None
    queries=[q.strip() for q in content.get('queries',[]) if q.strip()]
    if not queries:return [],'没有明确资源或可匹配的自定义动作查询'
    ranked=[]
    for a in assets.values():
        if not compatible(a):continue
        name=a.get('name','');tokens=words(name)
        score=0
        for query in queries:
            terms=words(query)
            if name.casefold()==query.casefold():score=max(score,1000)
            elif terms and terms<=tokens:score=max(score,len(terms))
            elif not terms and query in name:score=max(score,len(query))
        if score:ranked.append((score,a['id']))
    ranked.sort(key=lambda item:(-item[0],item[1]))
    if semantic_role in ('walk','run','crouch_move'):
        from candidate_policy import direction
        covered=set();directional=[];remaining=[]
        for item in ranked:
            label=direction(assets[item[1]])
            if label and label not in covered:
                covered.add(label);directional.append(item)
            else:remaining.append(item)
        ranked=directional+remaining
    if not ranked:return [],'已选同骨架资源中没有匹配内容；训练类别之外的动作可以保留，但仍需真实动画素材'
    if player!='mm':
        winners=[p for score,p in ranked if score==ranked[0][0]]
        if len(winners)!=1:return [],'多个同分资源，无法确定唯一单段动画，请指定资源名'
        return winners,None
    # Prefer sequences when constructing a new custom MM database. Existing
    # database candidates require an explicit unique selected ID.
    selected=[p for _,p in ranked if assets[p]['kind']=='sequence'][:content.get('max_candidates',8)]
    if not selected:
        winners=[p for score,p in ranked if score==ranked[0][0]]
        return (winners,None) if len(winners)==1 else ([], '数据库匹配有歧义，请明确指定一个已选数据库')
    return selected,None

def compile_unified(ir,request,catalog,destination,provider='local_model'):
    from config_tool import signature
    if not isinstance(ir,dict) or set(ir)!={'protocol','entry','states','variables','inputs','transitions','handlers','unresolved'} or ir['protocol']!=PROTOCOL:raise ValueError('统一需求IR字段或版本无效')
    meshes=[a for a in catalog['assets'] if a['kind']=='mesh']
    if len(meshes)!=1:raise ValueError('统一状态机需要恰好一个选中网格')
    mesh=meshes[0]['id'];nodes=ir['states']
    if not isinstance(nodes,list) or not 1<=len(nodes)<=32:raise ValueError('统一状态机需要1～32个节点')
    graph=dict(version=3,entry=ir['entry'],states=[],variables={},variable_sources={},inputs=copy.deepcopy(ir['inputs']),transitions=[],handlers=[])
    for field in ('transitions','handlers'):
        for edge in ir[field]:
            quote=edge.get('source_quote')
            if not isinstance(quote,str) or not quote.strip() or quote not in request:raise ValueError('转换或内部事件缺少精确原文依据')
            graph[field].append({k:copy.deepcopy(v) for k,v in edge.items() if k!='source_quote'})
    issues=[];slots=[];labels={}
    for variable in ir['variables']:
        if set(variable)!={'id','initial','scope','source'} or variable['id'] in graph['variables']:raise ValueError('变量声明重复或字段无效')
        graph['variables'][variable['id']]=variable['initial']
        graph['variable_sources'][variable['id']]=dict(scope=variable['scope'],source=variable['source'])
        if variable['scope']=='external':issues.append(dict(severity='warning',code='unified_external',message=variable['id']+' 初始值保留，等待外部SetVariable/SetBoolVariable接入；未绑定条件运行时保持关闭。'))
    for node in nodes:
        if set(node)!={'id','label','source_quote','parent','initial','player','loop','allow_movement','lock_until_finished','min_duration','blend_seconds','on_entry','on_exit','on_complete','content'}:raise ValueError('统一节点字段无效')
        if not _id(node['id']) or not isinstance(node['label'],str) or not node['label'].strip():raise ValueError('状态ID或动作名无效')
        if not node['source_quote'] or node['source_quote'] not in request or node['label'] not in node['source_quote']:raise ValueError('状态名缺少可定位原文依据：'+node['id'])
        labels[node['id']]=node['label']
        if node['player']=='locomotion':raise ValueError('统一节点请使用显式MM内容绑定，不能使用未配置资源的旧原生选择器')
        state={k:copy.deepcopy(node[k]) for k in ('id','player','loop','allow_movement','lock_until_finished','min_duration','blend_seconds','on_entry','on_exit','on_complete')}
        if node['parent'] is not None:state['parent']=node['parent']
        if node['initial'] is not None:state['initial']=node['initial']
        state['resources']=[]
        if node['player'] in ('mm','sequence','montage'):
            content=node['content']
            if not isinstance(content,dict) or set(content)!={'action_name','queries','resources','max_candidates'} or not isinstance(content['action_name'],str) or not content['action_name'].strip() or not isinstance(content['queries'],list) or not all(isinstance(q,str) for q in content['queries']) or not isinstance(content['resources'],list) or not all(isinstance(p,str) for p in content['resources']) or type(content['max_candidates']) is not int or not 1<=content['max_candidates']<=32:raise ValueError('自定义动作内容声明无效：'+node['id'])
            from unified_content_rules import content_constraints
            semantic_role=content_constraints(request,node['id'])['role']
            paths,missing=resolve_content(content,catalog,mesh,node['player'],semantic_role)
            if missing:issues.append(dict(severity='error',code='unified_binding_missing',state=node['id'],message=node['label']+'：'+missing))
            if node['player']=='mm':
                role=content_role(node['id']);state['database_role']=role
                slots.append(dict(id=role,resource=paths[0] if paths else None,resources=paths,when={},behavior_only=True))
            else:state['resources']=paths
        elif node['content'] is not None:raise ValueError('父组/原生移动选择器不能直接绑定动作内容')
        graph['states'].append(state)
    # Missing resources leave an editable graph but cannot bypass structural checks.
    errors=validate_graph(graph,catalog,mesh,[s['id'] for s in slots])
    structural=[e for e in errors if not (any(i.get('code')=='unified_binding_missing' for i in issues) and 'sequence/montage需要且只能绑定一个资源' in e)]
    if structural:raise ValueError('统一状态图编译失败：'+'；'.join(structural))
    if not isinstance(ir['unresolved'],list) or not all(isinstance(s,str) for s in ir['unresolved']):raise ValueError('未解决项必须是文本数组')
    issues.extend(dict(severity='error',code='unified_unresolved',message=s) for s in ir['unresolved'])
    issues.append(dict(severity='warning',code='unified_review',message='统一草案需审阅；自动生成可包含模型抽取和确定性规则编译。自定义动作不受旧训练类别限制。名称查询只提供候选，需审阅动作语义、条件和外部接入。'))
    return dict(version=1,provider=provider,request=request,catalog_signature=signature(catalog),destination=destination,target_mesh=mesh,states=slots,
        transitions=[dict({'from':a['id'],'to':b['id'],'blend_seconds':.2}) for a in slots for b in slots if a!=b],
        parameters=dict(mesh_yaw=-90.,play_rate=1.,reference_idle=not bool(slots)),issues=issues,intent_roles=[s['id'] for s in slots],behavior_graph=graph,
        model_info=dict(unified_requirements=copy.deepcopy(ir),unified_review=dict(confirmed=False),state_labels=labels,behavior_generation=dict(mode=PROTOCOL,origin='model' if provider=='local_model' else 'explicit_ir_import')))

def compiled_signature(plan):
    # UE's JSON writer emits integral doubles as integers. Fingerprint JSON
    # numeric values, not the spelling Python happened to use before UI save.
    # Keep bool distinct and never round fractional values or float32 edits.
    def numeric_values(value):
        if isinstance(value,float) and value.is_integer():return int(value)
        if isinstance(value,dict):return {k:numeric_values(v) for k,v in value.items()}
        if isinstance(value,list):return [numeric_values(v) for v in value]
        return value
    payload={k:plan[k] for k in ('request','catalog_signature','target_mesh','destination','states','transitions','parameters','behavior_graph')}|dict(ir=plan['model_info']['unified_requirements'])
    return hashlib.sha256(canonical(numeric_values(payload)).encode()).hexdigest()

def review_errors(plan,require_compiled=True):
    info=plan['model_info'];r=info.get('unified_review',{});errors=[]
    if r.get('uncommitted'):errors.append('统一需求IR有未提交修改')
    if r.get('confirmed') is not True or r.get('reviewed_ir')!=info['unified_requirements'] or r.get('request')!=plan['request']:errors.append('统一状态、条件和自定义动作尚未确认或已改变')
    if require_compiled and r.get('compiled_signature')!=compiled_signature(plan):errors.append('统一需求尚未重新编译，或图/资源已改变')
    return errors
