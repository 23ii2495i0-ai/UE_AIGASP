import copy
import unittest
from unified_runtime_rules import compile_runtime_rules,control_rule_lines,merge_selection_edges,authored_node_settings

REQUEST='''创建父组 Floor，初始子状态为 Rest。
Floor 下有五个直接叶子状态：Rest（站立待机）、Stride（站立行走）、Dash（站立跑步）、LowRest（蹲姿待机）、LowMove（蹲姿移动）。
创建父组 Sky，初始子状态为 Rise。
Sky 下有两个直接叶子状态：Rise（起跳与上升）、Fall（空中下降）。
Rest → Stride：move_input > 0.01 且 gait == 0。
蹲姿移动停止后进入 LowRest；蹲姿期间有移动输入进入 LowMove。下蹲状态优先于站立行走或跑步。
使用内部整数 Leaps，初始值为0。
只有成功执行真实起跳才将 Leaps 加1。
每次真实落地前最多成功起跳2次。
空中再次按下 Space 且 Leaps < 2 时执行第二次真实起跳并加1。
达到2次后拒绝后续起跳；按住 Space 不得重复计数。
真实落地时将 Leaps 清零。
如果当前运行时不能准确实现这些规则，将具体缺口列入未解决项并阻止应用。
'''

def fixture(request=REQUEST):
    states=[dict(id=n,player='mm',parent='Floor') for n in ['Rest','Stride','Dash','LowRest','LowMove']]
    states += [dict(id=n,player='mm',parent='Sky') for n in ['Rise','Fall']]
    states += [dict(id=n,player='group',parent=None) for n in ['Floor','Sky']]
    variables=[dict(id='Leaps',initial=0,scope='internal',source='internal jump count')]
    return compile_runtime_rules(request,states,variables,[])

def passes(conditions,values):
    ops={'eq':lambda a,b:a==b,'lt':lambda a,b:a<b,'le':lambda a,b:a<=b,'gt':lambda a,b:a>b,'ge':lambda a,b:a>=b}
    return all(ops[c['op']](values[c['var']],c['value']) for c in conditions)

class RuntimeRulesTests(unittest.TestCase):
    def test_unspecified_group_residence_is_zero_and_blend_follows_request(self):
        self.assertEqual(authored_node_settings('创建父组 Floor。混合时间使用0.2秒。','Floor'),dict(min_duration=0.,blend_seconds=.2))
        self.assertEqual(authored_node_settings('Ritual 最短停留1.5秒。混合时间为0.4秒。','Ritual'),dict(min_duration=1.5,blend_seconds=.4))
        with self.assertRaises(ValueError):authored_node_settings('混合时间为0.2秒。\n混合时间为0.4秒。','Floor')

    def test_selection_matrix_and_no_self_reentry(self):
        rules=fixture()
        for crouched,movement,gait,target in [(False,0,0,'Rest'),(False,1,0,'Stride'),(False,1,1,'Dash'),(True,0,1,'LowRest'),(True,1,1,'LowMove')]:
            values=dict(crouched=crouched,move_input=movement,gait=gait,falling=False)
            for source in rules['selector_nodes']:
                winners=[e for e in rules['transitions'] if e['from']==source and passes(e['all'],values)]
                self.assertEqual([e['to'] for e in winners],[] if source==target else [target])
        self.assertTrue(all((e['all'] or e['event']) and e['from']!=e['to'] for e in rules['transitions']))
        self.assertFalse(any(not e['event'] and passes(e['all'],dict(crouched=True,move_input=1,gait=1,falling=True)) for e in rules['transitions']))

    def test_selection_evidence_does_not_misquote_a_landing_arrow(self):
        rules=fixture('Fall → Floor：根据当前移动输入、步态和下蹲状态选择正确子状态。\n'+REQUEST)
        self.assertTrue(all('→' not in e['source_quote'] for e in rules['transitions']))

    def test_press_count_cap_and_real_landing_reset(self):
        rules=fixture();count=0
        press=rules['handlers'][0];land=rules['handlers'][1]
        self.assertEqual(rules['inputs'],[dict(key='SpaceBar',phase='pressed',event=press['event'],set={})])
        accepted=[]
        for _ in range(3):
            c=press['condition'];allowed=passes([c],{'Leaps':count});accepted.append(allowed)
            if allowed:
                self.assertEqual([a['op'] for a in press['actions']],['jump','add'])
                count+=press['actions'][1]['value']
        self.assertEqual(accepted,[True,True,False]);self.assertEqual(count,2)
        self.assertEqual(land['event'],'Landed');self.assertEqual(land['actions'],[dict(op='set',var='Leaps',value=0)])
        landed=[e for e in rules['transitions'] if e['event']=='Landed']
        self.assertEqual([(e['from'],e['to']) for e in landed],[('Sky','Floor')])
        self.assertTrue(landed[0]['interrupt'])
        self.assertFalse(any(h['event']=='Attack' for h in rules['handlers']))

    def test_handled_rules_do_not_leave_headers_or_definitions_as_events(self):
        rules=fixture()
        lines=[dict(index=i,text=l) for i,l in enumerate(REQUEST.splitlines()) if l.strip() and '→' not in l]
        self.assertEqual(control_rule_lines(lines,rules['handled_lines']),[])
        unknown=dict(index=100,text='进入 Mystery 时 Rounds 加1。')
        self.assertEqual(control_rule_lines([unknown],rules['handled_lines']),[unknown])

    def test_no_rules_from_unrelated_custom_animation_name(self):
        rules=fixture('创建自定义礼仪状态 Ritual。Ritual 使用MM。')
        self.assertEqual(rules['transitions'],[]);self.assertEqual(rules['handlers'],[])

    def test_unknown_compound_rules_and_conflicting_jump_guard_are_not_consumed(self):
        text=REQUEST.replace('真实落地时将 Leaps 清零。','真实落地时将 Leaps 清零；进入 Mystery 时 Extra 加1。')
        rules=fixture(text)
        remaining=control_rule_lines([dict(index=i,text=l) for i,l in enumerate(text.splitlines())],rules['handled_lines'])
        self.assertTrue(any('Mystery' in i['text'] for i in remaining))
        rules=fixture(REQUEST.replace('Leaps < 2','Leaps < 3'))
        self.assertEqual(rules['handlers'],[]);self.assertTrue(rules['unresolved'])

    def test_global_stance_refines_explicit_arithmetic_but_conflicts_block(self):
        rules=fixture()
        original={'from':'Rest','to':'Stride','event':'','all':[dict(var='move_input',op='gt',value=.01),dict(var='gait',op='eq',value=0)],'priority':0,'interrupt':False,'actions':[],'source_quote':REQUEST.splitlines()[4]}
        merged=merge_selection_edges([original],rules)
        chosen=[e for e in merged if e['from']=='Rest' and e['to']=='Stride']
        self.assertEqual(len(chosen),1)
        self.assertIn(dict(var='crouched',op='eq',value=False),chosen[0]['all'])
        self.assertEqual(rules['unresolved'],[])
        conflict=copy.deepcopy(original);conflict['all'].append(dict(var='Leaps',op='eq',value=1))
        rules=fixture();merge_selection_edges([conflict],rules)
        self.assertTrue(rules['unresolved'])

    def test_ambiguous_input_threshold_does_not_guess(self):
        rules=fixture(REQUEST+'\nDash → Rest：move_input <= 0.2。')
        self.assertFalse(any(not e['event'] for e in rules['transitions']));self.assertTrue(rules['unresolved'])

if __name__=='__main__':unittest.main()
