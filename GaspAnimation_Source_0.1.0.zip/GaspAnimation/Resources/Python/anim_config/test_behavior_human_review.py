import copy
import unittest
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
from behavior_human_review import review_values, validate_human_review, finalize_human_review, suggest_review_quotes, prefill_review_quotes


class HumanReviewTests(unittest.TestCase):
    def test_explicit_long_form_jump_quotes_are_prefilled_without_confirmation(self):
        ir={'jump':dict(group='Air',rise='JumpRise',fall='JumpFall',counter='JumpCount',max_jumps=2)}
        request=('Air 是空中父组，包含两个直接子状态。\nAir 的初始子状态为 JumpRise。\n'
                 '按项目现有 Space 跳跃输入触发 Jump 事件。\n每次真实落地前，最多允许成功起跳2次。\n'
                 '使用内部整数变量 JumpCount，初始值为0。\n地面第一次成功起跳时进入 Air，并将 JumpCount 加1。\n'
                 '第二次实际起跳，并将 JumpCount 加1。\n只有成功执行实际起跳才增加计数，拒绝的输入不增加计数。\n'
                 '角色真实落地时，将 JumpCount 重置为0并返回 Ground。\nJumpRise 在垂直速度转为下降时进入 JumpFall。')
        suggestions=suggest_review_quotes(ir,request)
        self.assertEqual(set(suggestions),set(review_values(ir)))
        for item in suggestions.values():self.assertIn(item['quote'],request)
        self.assertEqual(suggestions['increment']['quote'],'将 JumpCount 加1')
        self.assertNotIn('increment',suggest_review_quotes(ir,'失败时不将 JumpCount 加1。'))
    def test_autofill_exact_quotes_do_not_attest_or_change_policy(self):
        ir={'jump':dict(group='Air',rise='JumpRise',fall='JumpFall',counter='JumpCount',max_jumps=2)}
        request=('Air 是空中父组，包含 JumpRise 和 JumpFall，初始子状态为 JumpRise。'
                 '按 Space 从 Ground 进入 Air 并执行实际起跳。最多连续成功起跳 2 次。'
                 '使用内部整数变量 JumpCount，初始值为 0。只有成功起跳时才加 1；真实落地后重置为 0。'
                 '垂直速度由正转负时从 JumpRise 进入 JumpFall。')
        before=copy.deepcopy(ir)
        suggestions=suggest_review_quotes(ir,request)
        self.assertEqual(set(suggestions),set(review_values(ir)))
        self.assertEqual(ir,before)
        for item in suggestions.values():
            self.assertIn(item['quote'],request)
            self.assertNotIn('confirmed',item)
        self.assertEqual(suggestions['reset_value']['quote'],'真实落地后重置为 0')

    def test_autofill_leaves_ambiguous_negated_and_mismatched_rules_empty(self):
        ir={'jump':dict(group='Air',rise='JumpRise',fall='JumpFall',counter='n',max_jumps=2)}
        suggestions=suggest_review_quotes(ir,'最多连续成功起跳 3 次。不得按 Space 执行实际起跳。落地清零；真实落地后重置为0。')
        self.assertNotIn('max_jumps',suggestions)
        self.assertNotIn('jump_enabled',suggestions)
        self.assertNotIn('reset_value',suggestions)
        self.assertEqual(suggest_review_quotes({'jump':None},'禁止跳跃'),{})

    def test_prefill_preserves_manual_edits_and_cannot_confirm_or_apply(self):
        ir={'jump':dict(group='Air',rise='JumpRise',fall='JumpFall',counter='n',max_jumps=2)}
        request='真实落地后重置为0。'
        info=dict(behavior_requirements=ir)
        review=prefill_review_quotes(info,request)
        self.assertEqual(review['fields']['reset_when']['quote'],'真实落地后重置为0')
        self.assertFalse(review['fields']['reset_when']['confirmed'])
        self.assertTrue(validate_human_review(ir,request,review,require_compiled=True))
        review['fields']['reset_value'].update(quote='',quote_edited_by_human=True)
        review['fields']['reset_when'].update(quote='手动内容',confirmed=True)
        prefill_review_quotes(info,request)
        self.assertEqual(review['fields']['reset_value']['quote'],'')
        self.assertEqual(review['fields']['reset_when']['quote'],'手动内容')
        self.assertTrue(review['fields']['reset_when']['confirmed'])

    def setUp(self):
        self.ir = {'jump': dict(group='x', rise='y', fall='z', counter='n', max_jumps=3)}
        self.request = '允许跳三次。落地清零。落地清零。'
        self.review = dict(version=1, request=self.request, reviewed_ir=copy.deepcopy(self.ir),
                           all_ir_confirmed=True, fields={
                               k: dict(value=v, confirmed=True, quote='落地清零')
                               for k, v in review_values(self.ir).items()})

    def test_program_resolves_all_exact_positions_without_model_offsets(self):
        self.assertTrue(validate_human_review(self.ir, self.request, self.review, require_compiled=True))
        finalize_human_review(self.ir, self.request, self.review)
        self.assertEqual(self.review['fields']['reset_value']['source_spans'], [[6, 10], [11, 15]])
        self.assertEqual(validate_human_review(self.ir, self.request, self.review, require_compiled=True), [])
        self.review['fields']['reset_value']['quote'] = '清零'
        self.assertTrue(validate_human_review(self.ir, self.request, self.review, require_compiled=True))

    def test_ir_request_and_field_edits_invalidate_confirmation(self):
        for mutation in ('ir', 'request', 'field', 'unconfirmed'):
            with self.subTest(mutation=mutation):
                ir, r = copy.deepcopy(self.ir), copy.deepcopy(self.review)
                request = self.request
                if mutation == 'ir': ir['jump']['max_jumps'] = 4
                if mutation == 'request': request += '新需求'
                if mutation == 'field': r['fields']['max_jumps']['value'] = 4
                if mutation == 'unconfirmed': r['fields']['reset_value']['confirmed'] = False
                self.assertTrue(validate_human_review(ir, request, r))

    def test_empty_nonexistent_quote_and_boolean_integer_are_rejected(self):
        for quote in ('', ' ', '实际不存在'):
            r = copy.deepcopy(self.review); r['fields']['initial']['quote'] = quote
            self.assertTrue(validate_human_review(self.ir, self.request, r))
        self.review['fields']['initial']['value'] = False
        self.assertTrue(validate_human_review(self.ir, self.request, self.review))

    def test_no_jump_requires_explicit_review_not_default_strategy(self):
        ir = {'jump': None}
        self.assertEqual(review_values(ir), {'jump_enabled': False})
        self.assertTrue(validate_human_review(ir, '完全禁止跳跃', self.review))

    def test_uncommitted_edits_cannot_reuse_previously_compiled_confirmation(self):
        finalize_human_review(self.ir,self.request,self.review)
        for pending in ('field','ir'):
            with self.subTest(pending=pending):
                r=copy.deepcopy(self.review)
                if pending=='field':r['fields']['max_jumps'].update(uncommitted=True,pending_text='4')
                else:r['ir_edit_uncommitted']=True
                self.assertTrue(any('未提交' in e for e in validate_human_review(self.ir,self.request,r,require_compiled=True)))
                with self.assertRaisesRegex(ValueError,'未提交'):finalize_human_review(self.ir,self.request,r)

    def test_saved_reopened_confirmation_is_bound_to_exact_ir_and_quotes(self):
        finalize_human_review(self.ir,self.request,self.review)
        reopened=json.loads(json.dumps(self.review,ensure_ascii=False))
        self.assertEqual(validate_human_review(self.ir,self.request,reopened,require_compiled=True),[])
        reopened['fields']['max_jumps']['quote']='清零'
        self.assertTrue(validate_human_review(self.ir,self.request,reopened,require_compiled=True))

    def test_manual_import_compile_and_apply_validation_pipeline(self):
        import config_tool
        from behavior_human_review import create_review_draft
        from prepare_behavior_v3_smoke import IR
        ir = copy.deepcopy(IR)
        ir.update(topology=dict(entry='Move', groups=[], standalone=['Move']),
                  locomotion=dict(group='Move', idle='Move', walk=None, run=None), jump=None, combo=None)
        request = '只有 Move 状态用于待机，完全禁止跳跃。'
        catalog = dict(assets=[dict(id='/Game/M.M', kind='mesh', skeleton='/Game/S.S', bones=['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03']),
                               dict(id='/Game/Idle.Idle', name='Idle', kind='sequence', skeleton='/Game/S.S', loop=True)])
        plan = create_review_draft(ir, request, '/Game/ManualReview', catalog)
        self.assertEqual(plan['provider'], 'manual_review')
        self.assertTrue(config_tool.validate(plan, catalog))  # Unconfirmed cannot apply.
        review = plan['model_info']['behavior_human_review']
        review.update(request=request, reviewed_ir=copy.deepcopy(ir), all_ir_confirmed=True,
                      fields=dict(jump_enabled=dict(value=False, quote='完全禁止跳跃', confirmed=True)))
        self.assertTrue(config_tool.validate(plan, catalog))  # Confirmed but not compiled.
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder); cp=folder/'catalog.json'; pp=folder/'plan.json'; ip=folder/'ir.json'; rp=folder/'request.txt'
            cp.write_text(json.dumps(catalog),encoding='utf-8'); pp.write_text(json.dumps(plan),encoding='utf-8')
            args=['config_tool.py','compile-behavior','--catalog',str(cp),'--plan',str(pp),'--output',str(pp)]
            with patch('sys.argv',args): self.assertEqual(config_tool.main(),0)
            compiled=json.loads(pp.read_text(encoding='utf-8'))
            self.assertEqual(config_tool.validate(compiled,catalog),[])
            self.assertEqual(len(list(folder.glob('plan.json.before_compile_*.json'))),1)
            compiled['model_info']['behavior_requirements']['settings']['jump_velocity']=600
            self.assertTrue(config_tool.validate(compiled,catalog))
            ip.write_text(json.dumps(ir),encoding='utf-8');rp.write_text(request,encoding='utf-8')
            args=['config_tool.py','review-draft','--catalog',str(cp),'--ir-file',str(ip),'--request',str(rp),'--output',str(pp)]
            with patch('sys.argv',args): self.assertEqual(config_tool.main(),0)
            self.assertEqual(len(list(folder.glob('plan.json.before_manual_*.json'))),1)
            self.assertTrue(config_tool.validate(json.loads(pp.read_text(encoding='utf-8')),catalog))


if __name__ == '__main__': unittest.main()
