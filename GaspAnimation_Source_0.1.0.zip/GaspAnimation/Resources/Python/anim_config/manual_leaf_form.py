"""User-confirmed blank-form compiler. No model, NL repair or inferred structure."""
import copy
import datetime
from behavior_graph import _id


def leaf_ir(name):
    if not _id(name):
        raise ValueError('状态名须以英文字母或下划线开头，仅含英文、数字、下划线，最多64字符')
    return dict(version=1, topology=dict(entry=name,groups=[],standalone=[name]),
        locomotion=dict(group=name,idle=name,walk=None,run=None,selection='native_ground'),
        jump=None,combo=None,external_variables=[],unsupported=[],
        settings=dict(move_blend=.2,attack_blend=.1,hit_blend=.05,window_start=.25,window_end=.65,jump_velocity=500))


def check_form(form):
    if not isinstance(form,dict) or set(form)!={'state_name','selection','confirmed'}:
        raise ValueError('人工创建表单字段无效')
    if form['selection']!='native_ground':
        raise ValueError('请选择使用现有地面Motion Matching选择逻辑')
    if form['confirmed'] is not True:
        raise ValueError('请确认：只创建一个入口叶子状态，无父组、子状态或转换')
    return leaf_ir(form['state_name'])


def validate_creation(ir, creation):
    try:
        if not isinstance(creation,dict) or creation.get('origin')!='human_leaf_form_v1':raise ValueError('人工创建来源无效')
        expected=check_form(creation['form'])
        if ir!=expected:raise ValueError('需求已偏离已确认的人工创建表单，请重新创建或审阅')
        return []
    except (KeyError,TypeError,ValueError) as error:
        return [str(error)]


def create_leaf_plan(form,catalog,destination):
    from behavior_human_review import create_review_draft,finalize_human_review
    from config_tool import classified
    from candidate_policy import semantic_exclusion,category_conflict
    ir=check_form(form);name=form['state_name']
    request=f'人工创建：入口为 {name}，只有这一个叶子状态；无父组、无子状态、无状态转换。使用现有地面Motion Matching选择逻辑。不添加跳跃、攻击、连招或受击。'
    plan=create_review_draft(ir,request,destination,catalog)
    assets=catalog['assets'];meshes=[a for a in assets if a['kind']=='mesh'];mesh=meshes[0] if len(meshes)==1 else None
    # Only unique compatible selected resources can be bound without another
    # user choice. Missing/ambiguous roles remain blocking and expose candidates.
    plan['issues']=[i for i in plan['issues'] if i['code'] not in ('ambiguous_resource','missing_resource','behavior_manual_review')]
    for state in plan['states']:
        role=state['id']
        candidates=sorted([a['id'] for a in assets if mesh and a['kind'] in ('sequence','database')
            and a.get('skeleton')==mesh['skeleton'] and classified(a,role)
            and not semantic_exclusion(a) and not category_conflict(a,role)
            and (a['kind']=='database' or (a.get('loop') is True and not a.get('additive') and a.get('num_frames',2)>1))])
        state['resource']=candidates[0] if len(candidates)==1 else None
        if len(candidates)!=1:
            plan['issues'].append(dict(severity='error',code='missing_resource' if not candidates else 'ambiguous_resource',role=role,
                message=role+(' 缺少兼容资源，请选择已有资源' if not candidates else ' 存在多个候选，请明确选择'),candidates=candidates))
    info=plan['model_info'];generation=info['behavior_generation']
    generation.update(origin='human_leaf_form_v1',requirements_created_manually=True,model_called=False,
        assumptions=dict(move_blend=.2,unused_jump_combo_settings='inactive: no jump/combo states'))
    info['behavior_manual_creation']=dict(origin='human_leaf_form_v1',form=copy.deepcopy(form),confirmed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    review=info['behavior_human_review']
    review.update(request=request,reviewed_ir=copy.deepcopy(ir),all_ir_confirmed=True,
        fields=dict(jump_enabled=dict(value=False,quote='不添加跳跃',confirmed=True,confirmed_by='explicit_single_leaf_form_confirmation')))
    finalize_human_review(ir,request,review)
    plan['issues'].append(dict(severity='warning',code='behavior_manual_review',message='由用户确认表单人工创建并确定性编译；未调用模型，不计为模型生成成功。'))
    return plan
