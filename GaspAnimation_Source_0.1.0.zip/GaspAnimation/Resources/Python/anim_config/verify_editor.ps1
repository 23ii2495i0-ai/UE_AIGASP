param([string]$UERoot='C:\Program Files\Epic Games\UE_5.8',[string]$Python='D:\Python3.11\python.exe',[switch]$SkipBuild)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'FindSampleRoot.ps1')
$repo=Get-GaspSampleRoot
$project=Join-Path $repo 'unreal/GaspNative.uproject'
$editor=Join-Path $UERoot 'Engine/Binaries/Win64/UnrealEditor-Cmd.exe'
$backend=Join-Path $PSScriptRoot 'config_tool.py'
$session=Join-Path $repo ('unreal/Saved/AnimationConfigurator/Check_'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $session -Force | Out-Null
function RunEditor([string]$Name,[string[]]$Extra,[switch]$ExpectedFailure) {
 $log=Join-Path $session "$Name.log"
 & $editor $project @Extra '-unattended' '-nop4' '-nosplash' '-NullRHI' '-stdout' *> $log
 $code=$LASTEXITCODE
 if ((!$ExpectedFailure -and $code -ne 0) -or ($ExpectedFailure -and $code -eq 0)) { Get-Content $log -Tail 20; throw "Unexpected $Name exit: $code" }
}
if (!$SkipBuild) {
 & (Join-Path $UERoot 'Engine/Build/BatchFiles/Build.bat') GaspNativeEditor Win64 Development "-Project=$project" -WaitMutex -NoHotReloadFromIDE *> (Join-Path $session 'build.log')
 if ($LASTEXITCODE) { throw "Build failed: $session/build.log" }
}
& $Python -m unittest discover -s $PSScriptRoot -p test_config_tool.py
if ($LASTEXITCODE) { throw 'Contract tests failed' }
$catalog=Join-Path $session 'catalog.json'; $plan=Join-Path $session 'plan.json';$request=Join-Path $session 'request.txt'
RunEditor 'scan' @('-run=GaspConfigure','-Action=Scan',"-Catalog=$catalog",'-Selection=/Game/Native/MarkerExample/SK_Marker.SK_Marker+/Game/Native/MarkerExample/A_FastRun.A_FastRun')
'配置跑步，停止移动时使用参考姿势' | Set-Content $request -Encoding utf8
$destination='/Game/Native/Generated/ToolCheck_'+[guid]::NewGuid().ToString('N')
& $Python $backend generate --catalog $catalog --request $request --destination $destination --output $plan
if ($LASTEXITCODE) { throw 'Generation failed' }
RunEditor 'apply' @('-run=GaspConfigure','-Action=Apply',"-Catalog=$catalog","-Plan=$plan")
RunEditor 'verify' @('-run=GaspConfigure','-Action=Verify',"-Plan=$plan")
RunEditor 'prevent_overwrite' @('-run=GaspConfigure','-Action=Apply',"-Catalog=$catalog","-Plan=$plan") -ExpectedFailure
if (!(Select-String -Path (Join-Path $session 'prevent_overwrite.log') -Pattern 'Destination already exists' -SimpleMatch -Quiet)) { throw 'Overwrite rejection had the wrong cause' }
RunEditor 'runtime' @('/Game/Native/MarkerExample/L_MarkerExample','-game','-ConfigSmoke',"-AnimationSet=$destination/DA_Config.DA_Config",'-benchmark','-fps=60')
RunEditor 'gasp_regression' @('/Game/Native/L_NativeSandbox','-game','-NativeSmoke','-benchmark','-fps=60')
$samples=Join-Path $session 'samples.jsonl';$result=Join-Path $session 'record.json'
& $Python $backend record --catalog $catalog --plan $plan --applied-manifest "$plan.applied.json" --samples $samples --output $result
if ($LASTEXITCODE) { throw 'Approved sample capture failed' }
& $Python $backend dataset --samples $samples --output (Join-Path $session 'training_messages.jsonl')
if ($LASTEXITCODE) { throw 'Dataset export failed' }
Write-Host "CONFIG_TOOL_CHECKS_PASS session=$session generated=$destination"
