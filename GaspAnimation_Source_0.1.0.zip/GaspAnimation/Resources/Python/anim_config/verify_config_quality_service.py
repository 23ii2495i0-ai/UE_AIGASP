"""Exercise text counts, indexed jumping and four-way candidates through the live service."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import json,urllib.request
from pathlib import Path
from config_tool import validate
from candidate_policy import direction

root=_gasp_workspace
folder=root/'artifacts/anim_config/verification/config_quality'
catalog=json.loads((folder/'catalog.json').read_text(encoding='utf-8'))
reference=json.loads((folder/'plan_wasd_complete.json').read_text(encoding='utf-8'))
paths={p for s in reference['states'] for p in s['resources']}
for asset in catalog['assets']:
    if any(text in asset.get('name','') for text in ('Run_Lean_Pose_Base','Traversal_Catch_Vault')):paths.add(asset['id'])
selected=dict(version=1,assets=[a for a in catalog['assets'] if a['kind']=='mesh' or a['id'] in paths])
assets={a['id']:a for a in selected['assets']};results=[]
for count in (1,4):
    text=f'配置待机、行走、跑步、跳跃、下蹲，加入 Motion Matching 数据库。每类动作最多保留{count}段。支持 WASD 四向。无法确认类别的待人工检查，不强行绑定。'
    if count==4:text+='下蹲保留5段，覆盖四向蹲行和蹲停。'
    data=dict(catalog=selected,request=text,destination='/Game/Native/Generated/ServiceQualityProbe'+str(count))
    request=urllib.request.Request('http://127.0.0.1:8765/generate',json.dumps(data,ensure_ascii=False).encode(),{'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=180) as response:result=json.load(response)
    plan=result['plan'];errors=validate(plan,selected)
    assert not errors,errors
    assert {s['id'] for s in plan['states']}=={'idle','walk','run','crouch','jump'}
    assert 'jump' not in plan['runtime_flow']['actions']
    for state in plan['states']:
        limit=5 if count==4 and state['id']=='crouch' else count
        assert len(state['resources'])<=limit
        if count==4 and state['id'] in ('walk','run','crouch'):
            assert {'forward','back','left','right'}<={direction(assets[p]) for p in state['resources']}
    results.append(result)
(folder/'live_service_verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('LIVE_CONFIG_QUALITY_PASS: text limits, per-role override, four directions, airborne MM; no UE assets modified')
