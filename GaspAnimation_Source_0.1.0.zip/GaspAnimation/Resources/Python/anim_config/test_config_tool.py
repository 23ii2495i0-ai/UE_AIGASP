import copy
import unittest
from config_tool import generate,validate,signature

M='/Game/M.M';S='/Game/S.S';R='/Game/Run.Run'
CAT={'version':1,'assets':[{'id':M,'name':'M','kind':'mesh','skeleton':S,'bones':['root','pelvis','foot_l','foot_r','thigh_l','thigh_r','spine_03']},{'id':R,'name':'A_FastRun','kind':'sequence','skeleton':S,'loop':True}]}
class ContractTests(unittest.TestCase):
 def draft(self):return generate(copy.deepcopy(CAT),'配置跑步','/Game/Generated/Demo')
 def test_valid_single_clip_and_explicit_gap(self):
  p=self.draft();self.assertEqual(validate(p,CAT),[]);self.assertTrue(p['parameters']['reference_idle']);self.assertEqual(p['states'][0]['resource'],R)
 def test_hallucinated_resource_rejected(self):
  p=self.draft();p['states'][0]['resource']='/Game/Fake.Fake';self.assertTrue(validate(p,CAT))
 def test_missing_idle_not_invented(self):
  p=generate(CAT,'待机和跑步','/Game/X');self.assertIsNone(next(s for s in p['states'] if s['id']=='idle')['resource']);self.assertTrue(validate(p,CAT))
 def test_ambiguous_choice_requires_review(self):
  c=copy.deepcopy(CAT);r=copy.deepcopy(c['assets'][1]);r['id']='/Game/Run2.Run2';c['assets'].append(r)
  p=generate(c,'跑步','/Game/X');self.assertTrue(validate(p,c));self.assertIsNone(p['states'][0]['resource'])
 def test_foreign_skeleton_and_stale_catalog(self):
  p=self.draft();c=copy.deepcopy(CAT);c['assets'][1]['skeleton']='/Game/Other.Other';p['catalog_signature']=signature(c);self.assertTrue(validate(p,c));self.assertTrue(validate(self.draft(),c))
 def test_overlap_rejected(self):
  p=self.draft();p['states'].append({'id':'sprint','resource':R,'when':{'MovementState':1,'Stance':0}});self.assertTrue(validate(p,CAT))
 def test_invalid_numeric_and_unknown_condition(self):
  for value in [-1,float('nan'),4]:
   p=self.draft();p['parameters']['play_rate']=value;self.assertTrue(validate(p,CAT))
  p=self.draft();p['states'][0]['when']['InventedInput']=1;self.assertTrue(validate(p,CAT))
 def test_unsupported_semantics_block(self):
  self.assertTrue(validate(generate(CAT,'跑步和翻越','/Game/X'),CAT))
 def test_missing_or_bad_transition_rejected(self):
  c=copy.deepcopy(CAT);c['assets'].append({'id':'/Game/Walk.Walk','name':'Walk','kind':'sequence','skeleton':S,'loop':True})
  p=generate(c,'行走和跑步','/Game/X');self.assertEqual(validate(p,c),[]);p['transitions'][0]['blend_seconds']=10;self.assertTrue(validate(p,c))
 def test_path_escape(self):
  p=self.draft();p['destination']='/Game/../Outside';self.assertTrue(validate(p,CAT))
 def test_removing_issue_does_not_bypass_capability_check(self):
  p=generate(CAT,'跑步和翻越','/Game/X');p['issues']=[];self.assertTrue(validate(p,CAT))
 def test_non_loop_clip_rejected(self):
  c=copy.deepcopy(CAT);c['assets'][1]['loop']=False;self.assertTrue(validate(generate(c,'跑步','/Game/X'),c))
 def test_english_keywords_do_not_match_inside_other_words(self):
  self.assertTrue(validate(generate(CAT,'configure runtime parameters','/Game/X'),CAT))
  self.assertEqual(validate(generate(CAT,'configure running','/Game/X'),CAT),[])
 def test_unknown_parameter_rejected(self):
  p=self.draft();p['parameters']['pretend_traversal']=True;self.assertTrue(validate(p,CAT))
if __name__=='__main__':unittest.main()
