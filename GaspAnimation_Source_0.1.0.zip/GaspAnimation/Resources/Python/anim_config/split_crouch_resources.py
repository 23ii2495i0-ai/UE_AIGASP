"""Independent crouched-idle/moving MM categories from the selected catalog.

This is conservative name/metadata filtering, not a newly trained selector.
Ambiguous resources remain excluded and missing categories block application.
"""
from candidate_policy import category_conflict,semantic_exclusion,selection_policy,direction


def add_split_crouch_resources(plan,catalog,roles,request):
    assets=catalog['assets'];mesh=next((a for a in assets if a['id']==plan['target_mesh']),{})
    policy=selection_policy(request)
    plan['states']=[s for s in plan['states'] if s['id'] not in ('crouch','crouch_idle','crouch_move')]
    for role in ('crouch_idle','crouch_move'):
        if role not in roles:continue
        candidates=[a for a in assets if a['kind']=='sequence' and a.get('skeleton')==mesh.get('skeleton') and a.get('loop') is True
                    and not semantic_exclusion(a) and not category_conflict(a,role)
                    and '/actionflowfixture/' not in a['id'].lower() and 'playbacktest' not in a['id'].lower()]
        candidates.sort(key=lambda a:a['id'])
        ordered=[]
        if role=='crouch_move':
            for label in ('forward','back','left','right','forward_left','forward_right','back_left','back_right'):
                match=next((a for a in candidates if direction(a)==label),None)
                if match:ordered.append(match)
        ordered.extend(a for a in candidates if a not in ordered)
        limit=policy['max_candidates_by_role'].get(role,policy['max_candidates_per_role'] or (1 if role=='crouch_idle' else 8))
        paths=[a['id'] for a in ordered[:limit]]
        if role=='crouch_move':
            coverage=sorted({direction(a) for a in ordered[:limit]}-{None})
            expected=['forward','back','left','right']
            if '八个方向' in request or '八方向' in request:expected+=['forward_left','forward_right','back_left','back_right']
            missing=[d for d in expected if d not in coverage]
            plan.setdefault('model_info',{})['split_crouch_direction_coverage']=dict(available=coverage,missing=missing,source='selected resource name tags, not verified motion semantics')
            if missing:plan['issues'].append(dict(severity='warning',code='split_crouch_direction_gap',role=role,message='蹲姿移动候选缺少以下方向标签：'+', '.join(missing)+'；候选数量不代表完整方向覆盖，请检查实际素材。'))
        plan['states'].append(dict(id=role,resource=paths[0] if paths else None,resources=paths,
                                  when=dict(MovementMode=0,MovementState=0 if role=='crouch_idle' else 1,Stance=1)))
        if not paths:plan['issues'].append(dict(severity='error',code='split_crouch_missing',role=role,message=role+'：没有选中的同骨架循环动画满足独立蹲姿类别，禁止共用未筛选数据库。'))
    ids=[s['id'] for s in plan['states']]
    plan['intent_roles']=ids
    plan['transitions']=[dict({'from':a,'to':b,'blend_seconds':.2}) for a in ids for b in ids if a!=b]
    plan['issues'].append(dict(severity='warning',code='split_crouch_review',message='蹲姿待机与移动已分别按名称和元数据筛选为独立数据库类别；该筛选不是模型动作语义保证，请检查候选与方向覆盖。'))
    return plan
