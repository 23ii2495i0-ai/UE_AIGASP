import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from catalog_batches import partition,combine
from protocol import compact_catalog
from split_protocol import compile_split
import config_tool


class CatalogBatchTests(unittest.TestCase):
    def setUp(self):
        self.catalog={'version':1,'assets':[{'id':'/mesh','name':'mesh','kind':'mesh','skeleton':'rig','bones':[]}]+[
            {'id':f'/run{i}','name':f'run{i}','kind':'sequence','skeleton':'rig','loop':True} for i in range(300)]}
        self.g=dict(roles=['run'],slots={'run':'locomotion'},blend_seconds=.2,filters={},policy={},reject=None)
        self.chunks=partition(self.catalog,'run',self.g,lambda msg:len(msg[1]['content']),budget=2200)

    def missing(self):
        return [dict(bindings={'run':None},issues={'run':'missing'}) for _ in self.chunks]

    def test_full_coverage_and_budget(self):
        assets=[a['id'] for c in self.chunks for a in c['assets'] if a['kind']!='mesh']
        self.assertEqual(assets,[a['id'] for a in self.catalog['assets'][1:]])
        self.assertTrue(all(len(c['assets'])<=128 for c in self.chunks))
        from split_protocol import selector_messages
        self.assertTrue(all(len(selector_messages(c,'run',self.g)[1]['content'])<=2200 for c in self.chunks))

    def test_last_batch_binding_remapped_and_full_signature(self):
        results=self.missing();results[-1]=dict(bindings={'run':'a1'},issues={})
        selection=combine(self.catalog,self.g,self.chunks,results)
        _,full=compact_catalog(self.catalog)
        self.assertEqual(full[selection['bindings']['run']],self.chunks[-1]['assets'][1]['id'])
        plan=compile_split(self.catalog,'run','/Game/Test',self.g,selection,{})
        self.assertEqual(plan['catalog_signature'],config_tool.signature(self.catalog))

    def test_cross_batch_matches_are_ambiguous(self):
        results=self.missing()
        results[0]=results[-1]=dict(bindings={'run':'a1'},issues={})
        self.assertEqual(combine(self.catalog,self.g,self.chunks,results),dict(bindings={'run':None},issues={'run':'ambiguous'}))

    def test_local_ambiguity_not_hidden(self):
        results=self.missing();results[0]=dict(bindings={'run':'a1'},issues={})
        results[-1]=dict(bindings={'run':None},issues={'run':'ambiguous'})
        self.assertEqual(combine(self.catalog,self.g,self.chunks,results)['issues']['run'],'ambiguous')

    def test_invented_alias_and_partial_results_rejected(self):
        results=self.missing();results[0]=dict(bindings={'run':'a9999'},issues={})
        with self.assertRaises(ValueError):combine(self.catalog,self.g,self.chunks,results)
        with self.assertRaises(ValueError):combine(self.catalog,self.g,self.chunks,results[:-1])

    def test_single_asset_too_large_rejected(self):
        with self.assertRaises(ValueError):partition(self.catalog,'run',self.g,lambda msg:99999)

    def test_nonlooping_prediction_stays_unresolved(self):
        self.chunks[0]['assets'][1]['loop']=False
        results=self.missing();results[0]=dict(bindings={'run':'a1'},issues={})
        self.assertEqual(combine(self.catalog,self.g,self.chunks,results),dict(bindings={'run':None},issues={'run':'unsupported'}))


if __name__=='__main__':unittest.main()
