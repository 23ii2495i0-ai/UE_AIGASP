"""One pass over frozen field-repair cases, retaining every model draft."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import argparse,hashlib,json,time
from pathlib import Path
from config_tool import local_model_generate

ROOT=_gasp_workspace
OUT=ROOT/'artifacts/anim_config/verification/unified_field_repair'
args=argparse.ArgumentParser();args.add_argument('--cases',default='frozen_cases.json');args.add_argument('--prefix',default='frozen');args=args.parse_args()
frozen=OUT/args.cases
catalog=json.loads((ROOT/'unreal/Saved/AnimationConfigurator/BDDE9D4545098AC2B70C159188A256C6/catalog.json').read_text(encoding='utf-8-sig'))
results=[]
for case in json.loads(frozen.read_text(encoding='utf-8')):
    started=time.monotonic();result=dict(name=case['name'],passed=False)
    try:
        plan=local_model_generate(catalog,case['request'],'/Game/Native/Generated/UnifiedField_'+case['name'],'http://127.0.0.1:8765/generate',unified_mode=True)
        (OUT/(args.prefix+'_'+case['name']+'_plan.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
        ir=plan['model_info']['unified_requirements'];graph=plan['behavior_graph']
        checks=dict(ids={n['id'] for n in graph['states']}==set(case['ids']) and len(graph['states'])==len(case['ids']),edges=len(graph['transitions'])==case['edges'],no_extra_logic=not graph['variables'] and not graph['inputs'] and not graph['handlers'] and not any(n['on_entry'] or n['on_exit'] or n['on_complete'] for n in graph['states']))
        if case.get('labels'):checks['labels']={n['id']:n['label'] for n in ir['states']}==dict(zip(case['ids'],case['labels']))
        if case.get('expected_edges'):
            actual=[{k:e[k] for k in ('from','to','event','all')} for e in graph['transitions']]
            checks['conditions']=actual==case['expected_edges']
        if case['name']=='novel_nested':
            by_id={n['id']:n for n in graph['states']}
            checks['hierarchy']=graph['entry']=='WatchGroup' and by_id['WatchGroup'].get('initial')=='Watch' and by_id['Watch'].get('parent')=='WatchGroup' and ir['states'][next(i for i,n in enumerate(ir['states']) if n['id']=='Watch')]['label']=='静候'
        errors=[i for i in plan['issues'] if i['severity']=='error']
        checks['resource_status']=any(i['code']=='unified_binding_missing' for i in errors) if case.get('missing') else not errors
        result.update(checks=checks,passed=all(checks.values()))
    except Exception as error:result['error']=str(error)
    result['seconds']=round(time.monotonic()-started,2);results.append(result)
    (OUT/(args.prefix+'_results.json')).write_text(json.dumps(dict(cases_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),results=results),ensure_ascii=False,indent=2),encoding='utf-8')
    print(case['name'],result['passed'],flush=True)
