"""Evidence gate for the experimental bounded extractor, never combat approval."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import hashlib,json
from pathlib import Path
from behavior_requirements import prompt_fingerprint

ROOT=_gasp_workspace
TARGET_CLASS='/Game/Blueprints/Character/BP_CusGaspNativeCharacter.BP_CusGaspNativeCharacter_C'
REQUIRED_RUNTIME_CHECKS={'generated_actual_target_class','generated_actual_blueprint_native_mm','generated_independent_initial_state','generated_walk_from_actual_input_gait','generated_run_from_actual_input_gait','generated_stop_returns_idle','generated_real_launch_1','generated_real_launch_2','generated_jump_over_limit_rejected','generated_actual_landing_reset'}


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def check_reports(stages,pipeline,runtime,adapter_sha,animation_set,schema_sha=None,runtime_sha=None):
    cases=stages.get('cases',[])
    if stages.get('kind')!='teacher_forced_extraction_stages_not_end_to_end' or len(cases)<96 or stages.get('n')!=len(cases) or stages.get('exact')!=len(cases) or not all(c.get('exact') for c in cases) or len({c['id'] for c in cases})!=len(cases):raise ValueError('Incomplete or failing extraction test evidence')
    if any(sum(c.get('stage')==stage for c in cases)<16 for stage in ('topology','locomotion','jump','combo','dependencies','settings')):raise ValueError('Missing extraction stage coverage')
    generated=pipeline.get('cases',[]);heldout=[c for c in generated if c.get('split')=='heldout']
    if not pipeline.get('completed') or pipeline.get('planned_n')!=len(generated) or pipeline.get('n')!=len(generated) or len(heldout)<16:raise ValueError('Incomplete full-pipeline evidence')
    if not all(c.get('requirements_exact') and c.get('compiled_equivalence') and not c.get('manually_edited') and not c.get('fixture_bound') and c.get('model',{}).get('behavior_adapter_sha256')==adapter_sha for c in generated):raise ValueError('Pipeline contains mismatches, edits, fixtures or different weights')
    if schema_sha and (stages.get('schema_source')!='current_runtime_extraction_messages' or stages.get('runtime_schema_source_sha256')!=schema_sha or not all(c['model'].get('behavior_schema_source_sha256')==schema_sha for c in generated)):raise ValueError('Stage/runtime schema evidence is stale')
    if runtime_sha and not all(c['model'].get('behavior_runtime_source_sha256')==runtime_sha for c in generated):raise ValueError('Pipeline runtime evidence is stale')
    by_id={c['id']:c for c in generated}
    if not {'original_user_request','original_movement_jump','minimal_single_mm','counterfactual_numeric','short_ids_fresh_v3'}<=set(by_id):raise ValueError('Missing required probe coverage')
    if not by_id['original_user_request'].get('requirements_exact') or not all(by_id[name].get('application_accepted') for name in ('original_movement_jump','minimal_single_mm')):raise ValueError('Original requirement or real movement probe failed')
    if runtime.get('animation_set')!=animation_set or runtime.get('character_class')!=TARGET_CLASS or runtime.get('failures')!=0 or len(runtime.get('checks',[]))<14 or not all(c.get('passed') for c in runtime['checks']):raise ValueError('Real target-class game-loop evidence failed or mismatched')
    if not REQUIRED_RUNTIME_CHECKS<={c.get('name') for c in runtime['checks']}:raise ValueError('Missing real-input/physics runtime coverage')
    return dict(scope='bounded_requirement_extraction_and_compilation_only',stages=len(cases),heldout_requests=len(heldout),pipeline_requests=len(generated),real_movement_jump_checks=len(runtime['checks']),combat_playback_validated=False,requires_human_review=True)


def create_manifest(base,adapter,stage_file,pipeline_file,runtime_file):
    base,adapter=Path(base).resolve(),Path(adapter).resolve()
    metadata=json.loads((adapter/'behavior_prompt_config.json').read_text(encoding='utf-8'))
    if metadata.get('prompt_sha256')!=prompt_fingerprint() or metadata.get('base_config_sha256')!=sha(base/'config.json'):raise ValueError('Adapter base/prompt mismatch')
    stage_file,pipeline_file,runtime_file=map(lambda p:Path(p).resolve(),(stage_file,pipeline_file,runtime_file))
    if stage_file.parent!=adapter.parent:raise ValueError('Stage report must belong to the adapter run')
    pipeline=json.loads(pipeline_file.read_text(encoding='utf-8'))
    movement=json.loads((pipeline_file.parent/'original_movement_jump_plan.json').read_text(encoding='utf-8'))
    adapter_sha=sha(adapter/'adapter_model.safetensors')
    if movement['model_info'].get('behavior_adapter_sha256')!=adapter_sha:raise ValueError('Game-loop plan belongs to different weights')
    summary=check_reports(json.loads(stage_file.read_text(encoding='utf-8')),pipeline,json.loads(runtime_file.read_text(encoding='utf-8-sig')),adapter_sha,movement['destination']+'/DA_Config.DA_Config',sha(Path(__file__).resolve().parent/'behavior_requirements.py'),sha(Path(__file__).resolve().parent/'ai/configuration/runtime/split_runtime.py'))
    proof_files=[stage_file,pipeline_file,runtime_file,pipeline_file.parent/'original_movement_jump_plan.json']
    source_files=[Path(__file__).resolve().parent/p for p in ('behavior_requirements.py','behavior_graph.py','config_tool.py','behavior_model_deployment.py','ai/configuration/runtime/split_runtime.py','ai/configuration/runtime/serve_split.py')]
    model_files=[adapter/p for p in ('adapter_model.safetensors','adapter_config.json','behavior_prompt_config.json')]+[base/'config.json',base/'modelscope_sources.json']
    sources=json.loads((base/'modelscope_sources.json').read_text(encoding='utf-8'))
    base_files={str((base/f['Path']).resolve()):f['Sha256'] for f in sources['files']}
    result=dict(protocol='experimental_behavior_extractor_v1',base=str(base),adapter=str(adapter),prompt_sha256=prompt_fingerprint(),summary=summary,checked_files={str(Path(p).resolve()):sha(p) for p in proof_files+source_files+model_files},base_files=base_files,activation_scope='experimental graph checkbox only; material/external/unsupported blockers remain')
    return result


def load_manifest(path):
    m=json.loads(Path(path).read_text(encoding='utf-8'))
    if m.get('protocol')!='experimental_behavior_extractor_v1' or m.get('prompt_sha256')!=prompt_fingerprint() or m.get('summary',{}).get('combat_playback_validated') is not False or not m.get('summary',{}).get('requires_human_review'):raise ValueError('Invalid experimental extractor manifest')
    for filename,expected in (m['checked_files']|m['base_files']).items():
        if sha(filename)!=expected:raise ValueError('Extractor evidence/weights/source changed: '+filename)
    # Recompute acceptance from hash-checked reports, not a hand-edited summary.
    files=[Path(p) for p in m['checked_files']]
    stage=next(p for p in files if p.name=='test_stages.json')
    pipeline=next(p for p in files if p.name=='report.json')
    runtime=next(p for p in files if p.name.endswith('runtime_report.json'))
    current=create_manifest(m['base'],m['adapter'],stage,pipeline,runtime)
    if current!=m:raise ValueError('Extractor manifest differs from checked evidence')
    return m


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--adapter',required=True);p.add_argument('--stages',required=True);p.add_argument('--pipeline',required=True);p.add_argument('--runtime',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    m=create_manifest(a.base,a.adapter,a.stages,a.pipeline,a.runtime)
    # Validate file contents, including pinned base weights, before writing.
    for filename,expected in m['base_files'].items():
        if sha(filename)!=expected:raise ValueError('Pinned base changed: '+filename)
    Path(a.output).write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(m['summary']))
