"""Check the local expanded model against real selected assets; never apply a plan."""
import argparse,json,urllib.request
from pathlib import Path
from config_tool import validate

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--catalog',type=Path,required=True);args=parser.parse_args()
    catalog=json.loads(args.catalog.read_text(encoding='utf-8-sig'))
    mesh=next(a for a in catalog['assets'] if a['kind']=='mesh')
    run=next(a for a in catalog['assets'] if a['kind']=='sequence' and a.get('loop') and a.get('name')=='M_Neutral_Run_Loop_F' and a['skeleton']==mesh['skeleton'])
    jump=next(a for a in catalog['assets'] if a['kind']=='sequence' and not a.get('loop') and a.get('name')=='M_Neutral_Jump_F_Start_Run_Lfoot' and a['skeleton']==mesh['skeleton'])
    selected=dict(version=1,assets=[mesh,run,jump])
    payload=dict(catalog=selected,request='配置跑步和跳跃，混合时间0.2秒',destination='/Game/Native/Generated/ExpandedServiceProbe')
    request=urllib.request.Request('http://127.0.0.1:8765/generate',json.dumps(payload,ensure_ascii=False).encode(),{'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=120) as response:result=json.load(response)
    plan=result['plan'];errors=validate(plan,selected)
    assert not errors,errors
    assert set(result['configuration']['slots'])=={'run','jump'},result['configuration']
    assert plan['runtime_flow']['actions']['jump']==jump['id']
    assert plan['states'][0].get('resources')==[run['id']],plan['states']
    output=Path(__file__).resolve().parents[2]/'artifacts/anim_config/expanded_service_probe.json'
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('EXPANDED_SERVICE_PASS: real run + jump assets, complete slots, valid plan; no assets applied')

if __name__=='__main__':main()
