import sys,unittest,tempfile,json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
sys.path.insert(0,str(Path(__file__).parent/'ai/configuration/runtime'))
from split_runtime import SplitRuntime
import split_runtime


class BackendRoutingTests(unittest.TestCase):
    def test_enforcer_vocabulary_reused_between_schemas_not_tokenizers(self):
        rt=SplitRuntime.__new__(SplitRuntime)
        first,second=object(),object();build=Mock(side_effect=lambda _:object())
        data=split_runtime.cached_tokenizer_data(rt,first,build)
        self.assertIs(data,split_runtime.cached_tokenizer_data(rt,first,build))
        self.assertIsNot(data,split_runtime.cached_tokenizer_data(rt,second,build))
        self.assertEqual(build.call_count,2)

    def test_timeout_reports_cause_and_retains_partial_output(self):
        rt=SplitRuntime.__new__(SplitRuntime);rt.last_decode_timeout={'seconds':121,'tokens':1}
        rt.predict_batch=lambda *args:['{"']
        with tempfile.TemporaryDirectory() as folder,patch.object(split_runtime,'_LAYOUT_REPO',Path(folder)):
            with self.assertRaisesRegex(ValueError,'121'):
                rt.predict('behavior',[])
            self.assertEqual((Path(folder)/'artifacts/anim_config/models/configuration/logs/latest_behavior_output.txt').read_text(encoding='utf-8'),'{"')

    def test_invalid_json_is_persisted_in_unique_failure_record_before_next_request(self):
        rt=SplitRuntime.__new__(SplitRuntime)
        def fail(*args):
            rt.last_prediction_raw={'task':'behavior','text':'{"entry": unfinished'}
            raise ValueError('Invalid JSON')
        rt.predict=fail
        with tempfile.TemporaryDirectory() as folder,patch.object(split_runtime,'_LAYOUT_REPO',Path(folder)):
            with self.assertRaisesRegex(ValueError,'Invalid JSON'):rt.generate_behavior_templates({'assets':[]},'状态 Move','/Game/Test',{})
            records=list((Path(folder)/'artifacts/anim_config/models/configuration/logs').glob('requirements_*.json'))
            self.assertEqual(len(records),1)
            record=json.loads(records[0].read_text(encoding='utf-8'))
            rt.last_prediction_raw={'task':'behavior','text':'new output'}
            self.assertEqual(record['stages'][-1]['raw']['text'],'{"entry": unfinished')
            self.assertEqual(record['stages'][-1]['stage'],'topology_validation')
            self.assertEqual(len(record['stages']),3)
            self.assertIsNone(record['graph'])
            self.assertNotIn('topology',record['requirements'])
    def test_quantized_extractor_keeps_packed_weights_on_gpu(self):
        rt=SplitRuntime.__new__(SplitRuntime);rt.model=Mock();rt.behavior_model=Mock();rt.tokenizer=object();rt.behavior_tokenizer=object();rt.behavior_quantized=True
        self.assertEqual(rt.prediction_backend('behavior'),(rt.behavior_model,rt.behavior_tokenizer))
        self.assertEqual(rt.prediction_backend('selector'),(rt.model,rt.tokenizer))
        rt.model.to.assert_not_called();rt.behavior_model.to.assert_not_called()
    def test_independent_extractor_parks_legacy_before_gpu_load_and_restores_on_selection(self):
        events=[]
        class Model:
            def __init__(self,name,device):self.name=name;self.device=device
            def parameters(self):yield SimpleNamespace(device=SimpleNamespace(type=self.device))
            def to(self,device):events.append((self.name,device));self.device=device;return self
        rt=SplitRuntime.__new__(SplitRuntime);rt.model=Model('legacy','cuda');rt.behavior_model=Model('extractor','cpu')
        rt.tokenizer=object();rt.behavior_tokenizer=object();rt.torch=SimpleNamespace(cuda=SimpleNamespace(empty_cache=lambda:events.append('cache')))
        self.assertEqual(rt.prediction_backend('behavior'),(rt.behavior_model,rt.behavior_tokenizer))
        self.assertEqual(events,[('legacy','cpu'),'cache',('extractor','cuda')])
        rt.prediction_backend('behavior');self.assertEqual(len(events),3)
        self.assertEqual(rt.prediction_backend('selector'),(rt.model,rt.tokenizer))
        self.assertEqual(events[3:],[('extractor','cpu'),'cache',('legacy','cuda')])
    def test_original_adapter_service_does_not_move_models(self):
        rt=SplitRuntime.__new__(SplitRuntime);rt.model=Mock();rt.tokenizer=object()
        # Use None explicitly: a Mock's auto-created attributes are not a model.
        rt.behavior_model=None
        self.assertEqual(rt.prediction_backend('behavior'),(rt.model,rt.tokenizer))
        self.assertEqual(rt.prediction_backend('generator'),(rt.model,rt.tokenizer))
        rt.model.to.assert_not_called()


if __name__=='__main__':unittest.main()
