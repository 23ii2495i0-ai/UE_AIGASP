import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai/configuration/datasets'))
sys.path.insert(0,str(Path(__file__).parent/'ai/configuration/training'))
from build_jump_evidence_once import make_case
from jump_evidence_protocol import compile_evidence,extract_jump


class DeterministicEvidenceTests(unittest.TestCase):
    def test_compiles_cited_fields_without_a_model_policy_call(self):
        row=make_case(7,'limited_extra',3);calls=[]
        def extract(stage,override=None):calls.append(stage);return row['target']
        self.assertEqual(extract_jump(row['request'],row['reviewed'],extract),row['expected_policy'])
        self.assertEqual(calls,['jump_evidence'])

    def test_absent_and_forbidden_stay_null_with_no_state_name_inference(self):
        for kind in ('absent','forbidden'):
            row=make_case(12,kind)
            self.assertIsNone(compile_evidence(row['target'],row['request'],row['reviewed']))

    def test_incomplete_conflicting_and_unsupported_facts_reject(self):
        for kind in ('missing_reset','conflict','unsupported_count'):
            row=make_case(25,kind,2)
            with self.assertRaises(ValueError):compile_evidence(row['target'],row['request'],row['reviewed'])

    def test_initial_and_reset_are_never_filled(self):
        row=make_case(16,'required',4)
        for key,field in [('counter','initial'),('landing_reset','value')]:
            evidence=copy.deepcopy(row['target']);evidence[key][field]=3
            with self.assertRaises(ValueError):compile_evidence(evidence,row['request'],row['reviewed'])

    def test_schema_allows_actual_unsupported_values_for_truthful_rejection(self):
        import jsonschema
        row=make_case(28,'unsupported_count',2)
        jsonschema.validate(row['target'],row['schema'])
        with self.assertRaises(ValueError):compile_evidence(row['target'],row['request'],row['reviewed'])

    def test_chunked_loss_matches_loss_and_all_lora_gradients(self):
        import torch
        from transformers import Qwen3Config,Qwen3ForCausalLM
        from peft import LoraConfig,get_peft_model
        from chunked_assistant_loss import chunked_assistant_loss
        torch.manual_seed(17)
        model=get_peft_model(Qwen3ForCausalLM(Qwen3Config(vocab_size=41,hidden_size=16,intermediate_size=32,num_hidden_layers=1,num_attention_heads=2,num_key_value_heads=1,head_dim=8,tie_word_embeddings=True,attention_dropout=0)),LoraConfig(r=2,lora_alpha=4,lora_dropout=0,target_modules=['q_proj','v_proj'],task_type='CAUSAL_LM'))
        ids=torch.tensor([[2,3,4,5,6,7,8,9,10]]);labels=ids.clone();labels[:,:4]=-100
        expected=model(input_ids=ids,attention_mask=torch.ones_like(ids),labels=labels).loss;expected.backward()
        gradients={n:p.grad.clone() for n,p in model.named_parameters() if p.requires_grad}
        model.zero_grad(set_to_none=True)
        actual=chunked_assistant_loss(model,ids,labels,chunk_size=2);actual.backward()
        torch.testing.assert_close(actual,expected)
        for name,p in model.named_parameters():
            if p.requires_grad:torch.testing.assert_close(p.grad,gradients[name],rtol=1e-5,atol=1e-6)


if __name__=='__main__':unittest.main()
