"""Ground explicit action descriptions in a small resource-name vocabulary.

State IDs remain arbitrary. Unknown descriptions retain free custom queries.
No paths are invented and missing matches remain blocking issues.
"""
import re

VOCABULARY={
    '站立待机':('idle',['stand idle loop']),
    '站立行走':('walk',['walk loop']),
    '站立跑步':('run',['run loop']),
    '蹲姿待机':('crouch_idle',['crouch idle loop']),
    '蹲姿移动':('crouch_move',['crouch walk loop','crouch locomotion loop','crouch loop']),
    '起跳与上升':('jump_start',['jump start','jump off']),
    '空中下降':('jump_fall',['jump fall loop']),
}

def content_constraints(request,node_id):
    role=None;queries=None;limit=None
    for name,description in re.findall(r'([A-Za-z_][A-Za-z0-9_]*)[（(]([^）)]+)[）)]',request):
        if name==node_id and description in VOCABULARY:
            role,queries=VOCABULARY[description]
    for line in re.split(r'[；;。\n]',request):
        match=re.search(r'(?:最多|至多)(?:选)?\s*(\d+)\s*段',line)
        if not match:continue
        prefix=line[:match.start()]
        names=re.findall(r'[A-Za-z_][A-Za-z0-9_]*',prefix)
        if node_id not in names:continue
        count=int(match[1])
        if '合计' in prefix:
            names=list(dict.fromkeys(names))
            if count<len(names):raise ValueError('合计片段预算不足以分别配置各声明阶段：'+line)
            count//=len(names)
        if not 1<=count<=32:raise ValueError('统一状态候选上限必须为1～32：'+line)
        limit=count
    return dict(role=role,queries=queries,max_candidates=limit)

def matches_role(asset,role):
    if role is None:return True
    from candidate_policy import semantic_exclusion,category_conflict
    return not semantic_exclusion(asset) and not category_conflict(asset,role)
