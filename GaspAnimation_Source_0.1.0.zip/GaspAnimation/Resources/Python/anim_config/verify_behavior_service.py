"""Generate a real graph using selected UE clips as explicit timing-test stand-ins."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
import json,urllib.request
from pathlib import Path
from config_tool import validate

root=_gasp_workspace;folder=root/'artifacts/anim_config/verification/behavior_v1';folder.mkdir(parents=True,exist_ok=True)
full=json.loads((root/'artifacts/anim_config/verification/config_quality/catalog.json').read_text(encoding='utf-8'))
names={'M_Neutral_Stand_Idle_Loop','M_Neutral_Crouch_Idle_Loop','M_Neutral_Jump_F_Start_Stand_Lfoot','M_Neutral_Jump_B_Start_Lfoot'}
for a in full['assets']:
    if a.get('loop') and any(t in a.get('name','') for t in ('Walk_Loop','Run_Loop','Crouch_Walk_Loop')) and a.get('name','').endswith(('_F','_B','_LL','_RL')):names.add(a['name'])
catalog=dict(version=1,assets=[a for a in full['assets'] if a['kind']=='mesh' or a.get('name') in names])
request='''生成可编辑状态机。移动类别仅待机、行走、跑步和下蹲，使用Motion Matching数据库。每类最多保留5段，支持WASD四向。
明确使用这些状态ID：Move、Guard、Strike、Hurt。入口Move使用locomotion播放器。变量Held初始false。
RightMouseButton按下设置Held=true并发送GuardPressed，松开设置Held=false并发送GuardReleased。LeftMouseButton按下发送Attack。H按下发送Hit。
Move收到GuardPressed进入Guard；Guard收到GuardReleased返回Move。Guard允许移动，循环播放选中的M_Neutral_Crouch_Idle_Loop，只把它当作测试姿势，不是真实格挡。
Move收到Attack进入Strike，播放选中的M_Neutral_Jump_F_Start_Stand_Lfoot作为时序测试占位，非循环、禁止移动、锁定至结束；结束返回Move。Guard不允许攻击。
任意状态收到Hit优先级100并interrupt=true，进入Hurt，播放选中的M_Neutral_Jump_B_Start_Lfoot作为时序测试占位，非循环、禁止移动、锁定至结束。
Hurt结束时如果Held=true则返回Guard，否则返回Move。除Hit外其他连接interrupt=false。没有真实战斗资源，不能宣称占位动画是攻击、受击或格挡。'''
(folder/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False),encoding='utf-8');(folder/'request.txt').write_text(request,encoding='utf-8')
payload=dict(catalog=catalog,request=request,destination='/Game/Native/Generated/BehaviorV1_ModelProbe',behavior_mode=True)
req=urllib.request.Request('http://127.0.0.1:8765/generate',json.dumps(payload,ensure_ascii=False).encode(),{'Content-Type':'application/json'})
try:
    with urllib.request.urlopen(req,timeout=600) as response:result=json.load(response)
except urllib.error.HTTPError as e:
    print(e.read().decode('utf-8'));raise
(folder/'service_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
plan=result['plan'];errors=validate(plan,catalog)
(folder/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
assert not errors,errors
print('BEHAVIOR_SERVICE_PASS',[(s['id'],s['player']) for s in plan['behavior_graph']['states']],flush=True)
