"""Explicit human attestation, never model-generation success or entailment proof."""
import datetime
import hashlib
import json
import re


def suggest_review_quotes(ir, request):
    """Conservative exact-source suggestions; never confirms a rule or edits IR."""
    jump = ir.get('jump')
    if not jump:
        return {}
    clauses = [s.strip() for s in re.split(r'[。；;\n]', request) if s.strip()]
    def unique(predicate):
        matches = list(dict.fromkeys(s for s in clauses if predicate(s)))
        return matches[0] if len(matches) == 1 else None
    def contains_id(s, name):
        return re.search(r'(?<![A-Za-z0-9_])' + re.escape(name) + r'(?![A-Za-z0-9_])', s) is not None
    rules = {
        'jump_enabled': lambda s: bool(re.search(r'按\s*(?:Space|空格).*起跳|地面第一次成功起跳时进入', s)),
        'group': lambda s: contains_id(s, jump['group']) and '空中父组' in s,
        'rise': lambda s: contains_id(s, jump['rise']) and contains_id(s,jump['group']) and '初始子状态' in s,
        'fall': lambda s: contains_id(s, jump['fall']) and bool(re.search(r'垂直速度(?:由正转负|转为下降)',s)),
        'counter': lambda s: contains_id(s, jump['counter']) and '内部整数变量' in s,
        'max_jumps': lambda s: bool(re.search(r'最多(?:允许)?(?:连续)?(?:成功)?起跳\s*' + str(jump['max_jumps']) + r'\s*次', s)),
        'trigger': lambda s: bool(re.search(r'按(?:项目现有)?\s*(?:Space|空格).*(?:起跳|触发\s*Jump\s*事件)', s)),
        'initial': lambda s: contains_id(s, jump['counter']) and bool(re.search(r'初始值为\s*0', s)),
        'count_when': lambda s: '只有成功起跳时才加' in s or '仅当成功起跳' in s or '只有成功执行实际起跳才增加计数' in s,
        'increment': lambda s: bool(re.search(r'(?:成功起跳时才|成功起跳后)加\s*1(?!\d)', s)),
        'reset_when': lambda s: bool(re.search(r'(?:真实)?落地后?(?:重置为\s*0|清零)|真实落地时.*重置为\s*0', s)),
        'reset_value': lambda s: bool(re.search(r'(?:真实)?落地后?(?:重置为\s*0|清零)|真实落地时.*重置为\s*0', s)),
    }
    result = {}
    for key, predicate in rules.items():
        quote = unique(lambda s: not re.search(r'禁止|不得|不要|不允许|不支持', s) and predicate(s))
        if quote:
            result[key] = dict(value=review_values(ir)[key], quote=quote, origin='exact_source_suggestion')
    if 'increment' not in result:
        matches=set()
        for s in clauses:
            if re.search(r'禁止|不得|不要|不允许|不支持|不(?:将|给|让)?\s*'+re.escape(jump['counter']),s):continue
            matches.update(re.findall(r'(?<![A-Za-z0-9_])(?:将\s*)?'+re.escape(jump['counter'])+r'(?![A-Za-z0-9_])\s*加\s*1(?!\d)',s))
        if len(matches)==1:
            result['increment']=dict(value=1,quote=matches.pop(),origin='exact_source_suggestion')
    return result


def review_values(ir):
    jump = ir.get('jump')
    if jump is None:
        return {'jump_enabled': False}
    return dict(jump_enabled=True, **{k:jump[k] for k in ('group','rise','fall','counter','max_jumps')}, trigger='Jump', initial=0,
                count_when='successful_launch_only', increment=1,
                reset_when='Landed', reset_value=0)


def prefill_review_quotes(info, request):
    """Populate the existing UI fields without changing confirmations or IR values."""
    ir=info['behavior_requirements']
    suggestions=suggest_review_quotes(ir,request)
    info['behavior_review_suggestions']=suggestions
    review=info.setdefault('behavior_human_review',dict(version=1,fields={},all_ir_confirmed=False))
    fields=review.setdefault('fields',{})
    for key,item in suggestions.items():
        field=fields.setdefault(key,dict(value=item['value'],original_value=item['value'],quote='',confirmed=False,value_edited_by_human=False))
        if field.get('quote') or field.get('quote_edited_by_human') or field.get('uncommitted') or field.get('value_edited_by_human'):
            continue
        if type(field.get('value')) is not type(item['value']) or field.get('value')!=item['value']:
            continue
        field.update(quote=item['quote'],quote_origin=item['origin'],confirmed=False)
        review['all_ir_confirmed']=False
        review.pop('compiled_signature',None)
    return review


def review_signature(ir, request, review):
    payload = dict(ir=ir, request=request, fields={k: {f: review['fields'][k].get(f)
                   for f in ('value', 'quote', 'confirmed')} for k in review_values(ir)})
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def validate_human_review(ir, request, review, require_compiled=False):
    errors = []
    if not isinstance(review, dict) or review.get('version') != 1:
        return ['人工确认记录无效']
    if review.get('ir_edit_uncommitted'):
        errors.append('需求IR存在未提交修改，请先提交并重新确认')
    if review.get('request') != request or review.get('reviewed_ir') != ir or review.get('all_ir_confirmed') is not True:
        errors.append('需求或IR已变化，必须重新审阅并确认全部需求')
    fields = review.get('fields', {})
    for key, value in review_values(ir).items():
        field = fields.get(key, {}) if isinstance(fields, dict) else {}
        if not isinstance(field, dict):
            errors.append(key + ' 人工确认字段格式无效')
            continue
        if field.get('input_error'):
            errors.append(key + ' 输入值无效')
        if field.get('uncommitted'):
            errors.append(key + ' 存在未提交修改，不能编译或应用')
        quote = field.get('quote', '')
        if field.get('confirmed') is not True or type(field.get('value')) is not type(value) or field.get('value') != value:
            errors.append(key + ' 尚未确认或确认值已过期')
        if not isinstance(quote, str) or not quote.strip() or quote not in request:
            errors.append(key + ' 缺少可在原文精确找到的依据')
    if require_compiled and not errors and review.get('compiled_signature') != review_signature(ir, request, review):
        errors.append('人工确认尚未重新编译，或确认记录已改变；请重新编译审阅需求')
    return errors


def finalize_human_review(ir, request, review):
    errors = validate_human_review(ir, request, review)
    if errors:
        raise ValueError('；'.join(errors))
    # Python code-point offsets, not model-supplied line/character positions.
    for key in review_values(ir):
        field = review['fields'][key]
        quote = field['quote']
        starts, offset = [], 0
        while (offset := request.find(quote, offset)) >= 0:
            starts.append(offset)
            offset += 1
        field['source_spans'] = [[start, start + len(quote)] for start in starts]
    review['compiled_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    review['compiled_signature'] = review_signature(ir, request, review)
    review['attestation'] = 'human-confirmed semantics; exact-source positions resolved by program'


def create_review_draft(ir, request, destination, catalog):
    from behavior_requirements import compile_requirements, resource_bindings
    from config_tool import generate
    bindings, issues = resource_bindings(ir, catalog)
    graph, roles = compile_requirements(ir, request, bindings)
    # Reuse category resource selection, not natural-language rule extraction.
    plan = generate(catalog, ' '.join(roles), destination)
    plan['issues'] = [i for i in plan['issues'] if i['code'] not in ('unsupported_intent', 'rule_scope')]
    plan.update(provider='manual_review', request=request, behavior_graph=graph)
    plan['issues'].extend(issues)
    for var in ir['external_variables']:
        plan['issues'].append(dict(severity='error', code='behavior_external_unbound', message=var['id']+' 等待接入：'+var['source']))
    for item in ir['unsupported']:
        plan['issues'].append(dict(severity='error', code='behavior_unsupported', message=item))
    plan['model_info'] = dict(behavior_requirements=ir, behavior_review_suggestions=suggest_review_quotes(ir, request), behavior_human_review=dict(version=1, fields={}, all_ir_confirmed=False),
        behavior_generation=dict(mode='requirement_ir_compiler_v1', requirements_edited_manually=True,
                                 origin='explicit_human_ir_import', graph_construction='deterministic_feature_compiler'))
    plan['issues'].append(dict(severity='warning', code='behavior_manual_review', message='人工导入IR的待确认草案，不是模型端到端生成成功。'))
    prefill_review_quotes(plan['model_info'],request)
    return plan
