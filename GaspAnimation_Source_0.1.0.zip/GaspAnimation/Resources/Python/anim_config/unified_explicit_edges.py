"""Compile explicitly written A -> B: boolean expressions, without eval.

This is a syntax compiler, not model semantic extraction or an action template.
Natural-language transitions continue through the model path. A mixed request
must not silently drop an unparsed transition clause.
"""
import ast,re

OPS={ast.Eq:'eq',ast.NotEq:'ne',ast.Lt:'lt',ast.LtE:'le',ast.Gt:'gt',ast.GtE:'ge'}

def condition(text,readable):
    text=re.sub(r'\btrue\b','True',text,flags=re.I)
    text=re.sub(r'\bfalse\b','False',text,flags=re.I)
    text=text.replace('并且',' and ').replace('且',' and ').replace('或',' or ').replace('&&',' and ').replace('||',' or ')
    tree=ast.parse(text.strip(),mode='eval').body
    def scalar(n):
        if isinstance(n,ast.Constant) and type(n.value) in (int,float,bool):return n.value
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub) and isinstance(n.operand,ast.Constant) and type(n.operand.value) in (int,float):return -n.operand.value
        raise ValueError('条件只允许数字/布尔常量，不执行代码')
    def convert(n):
        if isinstance(n,ast.BoolOp) and isinstance(n.op,(ast.And,ast.Or)):
            return {'all' if isinstance(n.op,ast.And) else 'any':[convert(x) for x in n.values]}
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.Not):return {'not':convert(n.operand)}
        if isinstance(n,ast.Compare) and len(n.ops)==1 and type(n.ops[0]) in OPS and isinstance(n.left,ast.Name) and n.left.id in readable:
            return dict(var=n.left.id,op=OPS[type(n.ops[0])],value=scalar(n.comparators[0]))
        raise ValueError('显式条件包含未知变量或不支持的表达式')
    return convert(tree)

def compile_edges(request,state_ids,readable):
    names='(?:'+'|'.join(re.escape(n) for n in sorted(state_ids,key=len,reverse=True))+')'
    pattern=re.compile(r'^\s*('+names+r')\s*(?:到|->|→)\s*('+names+r')\s*[:：]\s*(.+?)\s*[。.]?\s*$')
    edges=[];unparsed=False
    for line in request.splitlines():
        match=pattern.fullmatch(line)
        if match:
            expression=match[3].rstrip('。')
            try:tree=condition(expression,readable)
            except (SyntaxError,ValueError) as error:raise ValueError('显式转换条件编译失败：'+line+'；'+str(error)) from error
            edge=dict({'from':match[1],'to':match[2],'event':'','all':[],'priority':0,'interrupt':False,'source_quote':line})
            if 'all' in tree and all('var' in x for x in tree['all']):edge['all']=tree['all']
            elif 'var' in tree:edge['all']=[tree]
            else:edge['condition']=tree
            edges.append(edge)
        elif re.search(r'(?:切换|返回|转入|转到|跳转|进入|->|→|\b'+names+r'\s*到\s*'+names+r')',line):
            unparsed=True
    return edges if edges and not unparsed else None
