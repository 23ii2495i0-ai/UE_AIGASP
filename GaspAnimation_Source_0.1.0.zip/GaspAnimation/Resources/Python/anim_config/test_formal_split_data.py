import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from build_formal_split import example
from split_protocol import merge

class FormalDataTests(unittest.TestCase):
    def test_catalog_diversity_and_contracts(self):
        databases=untagged=missing=ambiguous=0
        for split,offset in [('train',300000),('validation',600000),('test',900000)]:
            for i in range(100):
                g,s=example(offset+i,split)
                p=merge(s['catalog'],g['target'],s['target'])
                self.assertEqual(g['messages'][1]['content'],g['request'])
                self.assertNotIn('catalog',g)
                self.assertNotIn('bindings',g['target'])
                databases+=sum(a['kind']=='database' for a in s['catalog']['assets'])
                untagged+=sum(a['kind']!='mesh' and 'tags' not in a for a in s['catalog']['assets'])
                missing+=p['reject']=='missing';ambiguous+=p['reject']=='ambiguous'
        self.assertGreater(databases,0);self.assertGreater(untagged,0)
        self.assertGreater(missing,0);self.assertGreater(ambiguous,0)
if __name__=='__main__':unittest.main()
