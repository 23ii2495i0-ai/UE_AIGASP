"""Build an isolated deterministic behavior fixture; never edits the user's BP.

Run with UE -run=pythonscript after rebuilding. The two existing jump clips are
timing stand-ins, not combat content and not a successful model-generation sample.
The saved map uses the actual requested character class. Pass the emitted config
as -AnimationSet when running -BehaviorQualitySmoke.
"""
import json
import os
from pathlib import Path

FOLDER = '/Game/Native/Generated/BehaviorV2QualityFixture'
BLUEPRINT = '/Game/Blueprints/Character/BP_CusGaspNativeCharacter'
STABLE = '/Game/Native/Generated/Directional_20261021_222945/DA_Config'
CLIPS = {
    'action': '/Game/Characters/UEFN_Mannequin/Animations/Jump/M_Neutral_Jump_F_Start_Stand_Lfoot',
    'hurt': '/Game/Characters/UEFN_Mannequin/Animations/Jump/M_Neutral_Jump_B_Start_Lfoot',
    'guard': '/Game/Characters/UEFN_Mannequin/Animations/Idle/M_Neutral_Crouch_Idle_Loop',
}


def definition(paths):
    def add(var, value=1): return {'op': 'add', 'var': var, 'value': value}
    def assign(var, value): return {'op': 'set', 'var': var, 'value': value}
    def pred(var, op, value): return {'var': var, 'op': op, 'value': value}
    def state(name, player='locomotion', parent='Root', **kw):
        value = dict(id=name, player=player, resources=[], loop=player in ('locomotion', 'mm'),
                     allow_movement=True, lock_until_finished=False, min_duration=0, blend_seconds=.12)
        if parent: value['parent'] = parent
        value.update(kw)
        return value
    def action(name, parent, clip='action', **kw):
        return state(name, 'sequence', parent, resources=[paths[clip]], allow_movement=False,
                     lock_until_finished=True, **kw)
    def edge(source, target, event='', conditions=(), priority=0, interrupt=False, **kw):
        value = {'from': source, 'to': target, 'event': event, 'all': list(conditions),
                 'priority': priority, 'interrupt': interrupt}
        value.update(kw)
        return value

    variables = {name: 0 for name in (
        'RootEntries', 'RootExits', 'CombatEntries', 'CombatExits', 'ComboEntries', 'ComboExits',
        'Attack1Entries', 'Attack2Entries', 'Attack3Entries', 'Attack1Done', 'Attack2Done',
        'Attack3Done', 'HurtDone', 'Repeats', 'RootHit', 'CombatHit', 'LeafProbe', 'ParentProbe',
        'JumpEntries', 'JumpExits', 'JumpCount', 'Jump1Entries', 'Jump2Entries', 'HoldDone')}
    variables.update(bHit=False, Held=False, Queued=False)
    states = [
        state('Root', 'group', '', initial='Move', on_entry=[add('RootEntries')], on_exit=[add('RootExits')]),
        state('Move'),
        state('Combat', 'group', initial='Combo', on_entry=[add('CombatEntries'), assign('Repeats', 0)], on_exit=[add('CombatExits')]),
        state('Combo', 'group', 'Combat', initial='Attack1', on_entry=[add('ComboEntries')], on_exit=[add('ComboExits')]),
        action('Attack1', 'Combo', on_entry=[add('Attack1Entries')], on_complete=[add('Repeats'), add('Attack1Done')]),
        action('Attack2', 'Combo', on_entry=[add('Attack2Entries'), assign('Queued', False)], on_complete=[add('Attack2Done')]),
        action('Attack3', 'Combo', on_entry=[add('Attack3Entries')], on_complete=[add('Attack3Done')]),
        state('Guard', 'sequence', resources=[paths['guard']], loop=True),
        action('Hurt', 'Root', clip='hurt', on_complete=[add('HurtDone')]),
        state('JumpGroup', 'group', initial='Jump1', on_entry=[add('JumpEntries'), assign('JumpCount', 0)], on_exit=[add('JumpExits'), assign('JumpCount', 0)]),
        state('Jump1', 'mm', 'JumpGroup', database_role='jump', on_entry=[add('Jump1Entries'), add('JumpCount'), {'op': 'jump', 'velocity': 500}]),
        state('Jump2', 'mm', 'JumpGroup', database_role='jump', on_entry=[add('Jump2Entries'), add('JumpCount'), {'op': 'jump', 'velocity': 800}]),
        state('MMRole', 'mm', database_role='walk'),
        action('CompleteHold', 'Root', on_complete=[add('HoldDone')]),
    ]
    finished = pred('finished', 'eq', True)
    transitions = [
        edge('Move', 'Combat', 'Attack', actions=[assign('Queued', False)]),
        edge('Attack1', 'Attack1', conditions=[finished, pred('Repeats', 'lt', 3)]),
        edge('Attack1', 'Attack2', conditions=[finished, pred('Repeats', 'ge', 3)], priority=10,
             condition={'all': [pred('bHit', 'eq', True), {'any': [pred('Attack1Done', 'gt', 0), pred('speed', 'gt', 1000)]}]}),
        edge('Attack1', 'Move', conditions=[finished, pred('Repeats', 'ge', 3)], condition={'not': pred('bHit', 'eq', True)}),
        edge('Attack2', 'Attack3', conditions=[finished, pred('Queued', 'eq', True)], priority=10, actions=[assign('Queued', False)]),
        edge('Attack2', 'Move', conditions=[finished, pred('Queued', 'eq', False)]),
        edge('Attack3', 'Move', conditions=[finished]),
        edge('Root', 'Hurt', 'Hit', priority=100, interrupt=True, actions=[add('RootHit')]),
        edge('Combat', 'Hurt', 'Hit', priority=100, interrupt=True, actions=[add('CombatHit')]),
        edge('Combat', 'Move', 'Probe', priority=50, interrupt=True, actions=[add('ParentProbe')]),
        edge('Attack1', 'Guard', 'Probe', priority=50, interrupt=True, actions=[add('LeafProbe')]),
        edge('Move', 'Guard', 'GuardPressed'), edge('Guard', 'Move', 'GuardReleased'),
        edge('Hurt', 'Guard', conditions=[finished, pred('Held', 'eq', True)], priority=1),
        edge('Hurt', 'Move', conditions=[finished, pred('Held', 'eq', False)]),
        edge('Move', 'JumpGroup', 'JumpPressed'),
        edge('Jump1', 'Jump1', 'JumpPressed', [pred('JumpCount', 'lt', 2)], interrupt=True),
        edge('Jump1', 'Jump2', 'JumpPressed', [pred('JumpCount', 'ge', 2)], priority=10, interrupt=True),
        edge('JumpGroup', 'Move', 'Landed', interrupt=True),
        edge('Move', 'MMRole', 'RoleToggle'), edge('MMRole', 'Move', 'RoleToggle'),
        edge('Move', 'CompleteHold', 'HoldTest'), edge('CompleteHold', 'Move', 'Acknowledge'),
        edge('CompleteHold', 'Move', conditions=[pred('interrupted', 'eq', True)], interrupt=True),
        edge('Root', 'Move', 'Cancel', interrupt=False),
    ]
    inputs = [
        dict(key='LeftMouseButton', phase='pressed', event='Attack', set={'Queued': True}),
        dict(key='RightMouseButton', phase='pressed', event='GuardPressed', set={'Held': True}),
        dict(key='RightMouseButton', phase='released', event='GuardReleased', set={'Held': False}),
        dict(key='H', phase='pressed', event='Hit', set={}),
        dict(key='SpaceBar', phase='pressed', event='JumpPressed', set={}),
    ]
    return dict(version=2, entry='Root', variables=variables, inputs=inputs, states=states, transitions=transitions)


def prepare(output_subdir='behavior_v2'):
    import unreal
    root = Path(os.environ['GASP_REPO']).resolve()
    output = root / 'artifacts/anim_config/verification' / output_subdir
    output.mkdir(parents=True, exist_ok=True)
    paths, references = {}, []
    for role, source_path in CLIPS.items():
        source = unreal.load_asset(source_path)
        assert source, source_path
        references.append(source)
        paths[role] = source.get_path_name()
    graph = definition(paths)
    config_path = FOLDER + '/DA_BehaviorQuality'
    config = unreal.load_asset(config_path)
    if not config:
        config = unreal.EditorAssetLibrary.duplicate_asset(STABLE, config_path)
    assert config, 'Stable configuration is required to build the isolated fixture'
    config.set_editor_property('behavior_graph_json', json.dumps(graph, ensure_ascii=False))
    config.set_editor_property('behavior_resources', references)
    assert unreal.EditorAssetLibrary.save_loaded_asset(config, False)

    # Use the user's actual class while overriding only the test game's config.
    # The character Blueprint CDO is never changed or saved here.
    target = unreal.load_asset(BLUEPRINT)
    assert target and target.generated_class()
    original_config = unreal.get_default_object(target.generated_class()).get_editor_property('animation_set_override')
    assets = unreal.AssetToolsHelpers.get_asset_tools()
    factory = unreal.BlueprintFactory()
    factory.set_editor_property('parent_class', unreal.GaspNativeGameMode)
    game = unreal.load_asset(FOLDER + '/BP_BehaviorQualityGameMode') or assets.create_asset('BP_BehaviorQualityGameMode', FOLDER, unreal.Blueprint, factory)
    unreal.get_default_object(game.generated_class()).set_editor_property('default_pawn_class', target.generated_class())
    unreal.BlueprintEditorLibrary.compile_blueprint(game)
    assert unreal.EditorAssetLibrary.save_loaded_asset(game, False)
    assert unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).load_level('/Game/Native/L_NativeSandbox')
    actors = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    for actor in actors.get_all_level_actors():
        if isinstance(actor, unreal.GaspNativeCharacter): actors.destroy_actor(actor)
    world = unreal.EditorLevelLibrary.get_editor_world()
    world.get_world_settings().set_editor_property('default_game_mode', game.generated_class())
    map_path = FOLDER + '/L_BehaviorQuality'
    assert unreal.EditorLoadingAndSavingUtils.save_map(world, map_path)
    manifest = dict(config=config.get_path_name(), map=map_path, character_class=target.generated_class().get_path_name(),
                    original_character_config=original_config.get_path_name(),
                    note='Deterministic runtime fixture; existing jump clips are timing substitutes, not combat content or a model-generated plan.')
    (output / 'graph.json').write_text(json.dumps(graph, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / 'fixture.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    unreal.log('BEHAVIOR_QUALITY_FIXTURE_READY ' + json.dumps(manifest))


if __name__ == '__main__':
    prepare()
