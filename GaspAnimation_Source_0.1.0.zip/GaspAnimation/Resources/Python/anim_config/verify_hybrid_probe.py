"""Exercise the deployed hybrid service using real UE sparse samples; no blueprint changes."""
from pathlib import Path as _gasp_path
import sys as _gasp_sys
_gasp_ai = next((p if (p / "project_paths.py").is_file() else p / "ai") for p in _gasp_path(__file__).resolve().parents if (p / "project_paths.py").is_file() or (p / "ai/project_paths.py").is_file())
_gasp_sys.path.insert(0, str(_gasp_ai))
from project_paths import REPO as _gasp_workspace, configure_imports as _gasp_imports
_gasp_imports()
from pathlib import Path
import json,sys,urllib.request
ROOT=_gasp_workspace;sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
import config_tool
source=ROOT/'artifacts/anim_config/models/pose/samples/temporal_v2/catalog_motion.json'
catalog=json.loads(source.read_text());mesh=next(a for a in catalog['assets'] if a['kind']=='mesh')
sequences=[a for a in catalog['assets'] if a['kind']=='sequence' and a.get('skeleton')==mesh['skeleton'] and 'run' in a.get('name','').lower() and 'loop' in a.get('name','').lower() and a.get('loop')]
catalog=dict(version=1,assets=[mesh]+sequences[:3])
out=ROOT/'artifacts/anim_config/verification/hybrid_ue';out.mkdir(parents=True,exist_ok=True)
(out/'catalog.json').write_text(json.dumps(catalog),encoding='utf-8')
body=json.dumps(dict(catalog=catalog,request='配置普通跑步，停止时用参考姿势。',destination='/Game/Native/Generated/HybridProbe_20261021'),ensure_ascii=False).encode()
with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8765/generate',body,{'Content-Type':'application/json'}),timeout=600) as response:result=json.load(response)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
plan=result['plan'];(out/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
errors=config_tool.validate(plan,catalog)
print('HYBRID_PROBE',json.dumps(dict(errors=errors,states=plan['states'],pose_evidence=plan['model_info']['hybrid_selection']),ensure_ascii=False))
if errors:raise ValueError(errors)
if len(plan['states'][0].get('resources',[]))<2:raise ValueError('Multiple real UE candidates were not retained')
