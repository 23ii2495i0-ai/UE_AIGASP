function Get-GaspSampleRoot {
    if ($env:GASP_REPO -and (Test-Path -LiteralPath (Join-Path $env:GASP_REPO 'unreal/GaspNative.uproject'))) { return [IO.Path]::GetFullPath($env:GASP_REPO) }
    $candidate = [IO.Path]::GetFullPath($PSScriptRoot)
    while ($candidate) {
        if (Test-Path -LiteralPath (Join-Path $candidate 'unreal/GaspNative.uproject')) { return $candidate }
        $candidate = Split-Path -Parent $candidate
    }
    throw 'This legacy regression requires the GaspNative sample project. Set GASP_REPO to its repository root.'
}
