import copy
import unittest
import tempfile,json,sys
from pathlib import Path
from unittest.mock import patch
import config_tool
from behavior_graph import validate_graph
from behavior_requirements import compile_requirements, validate_topology, semantic_audit, resource_bindings, anchor_topology,validate_generated_symbols,extraction_messages,source_identifiers,identifier_in,validate_extracted_stage
from prepare_behavior_v3_smoke import IR, REQUEST, definition


class RequirementCompilerTests(unittest.TestCase):
    def test_empty_or_self_parent_is_rejected_before_source_ambiguity(self):
        source='入口 Move。\nMove 是叶子状态，没有父组，也没有子状态。'
        for children in ([],['Move']):
            with self.assertRaisesRegex(ValueError,'无效父组'):
                anchor_topology(dict(entry='Move',groups=[dict(id='Move',children=children,initial='Move',source_lines=[0])]),source)

    def test_single_leaf_selection_is_model_field_and_compiles_without_extra_states(self):
        for name in ('Move','Travel_9','u0'):
            source=f'入口 {name}。{name} 是叶子状态。根据移动输入和步态选择地面动画。'
            ir=copy.deepcopy(IR)
            ir.update(topology=dict(entry=name,groups=[],standalone=[name]),locomotion=dict(group=name,idle=name,walk=None,run=None,selection='native_ground'),jump=None,combo=None)
            schema,_=extraction_messages('locomotion',source,ir)
            self.assertIn('selection',schema['properties']['policy']['anyOf'][0]['required'])
            graph,roles=compile_requirements(ir,source)
            self.assertEqual(roles,['idle','walk','run'])
            self.assertEqual(len(graph['states']),1)
            self.assertEqual(graph['states'][0]['player'],'locomotion')
            self.assertNotIn('database_role',graph['states'][0])
            self.assertEqual(graph['transitions'],[])
            self.assertEqual(graph['variables'],{})
            ir['locomotion']['selection']='idle_only'
            graph,roles=compile_requirements(ir,source)
            self.assertEqual(roles,['idle'])
            self.assertEqual(graph['states'][0]['database_role'],'idle')

    def test_schema_rejects_empty_group_and_zero_jump_limit(self):
        import jsonschema
        schema,_=extraction_messages('topology','Move Motion Matching',{'version':1})
        with self.assertRaises(jsonschema.ValidationError):
            jsonschema.validate(dict(entry='Move',groups=[dict(id='Move',children=[],initial='Move',source_lines=[0])]),schema)
        schema,_=extraction_messages('jump',REQUEST+' Count',IR)
        bad=dict(IR['jump'],max_jumps=0)
        with self.assertRaises(jsonschema.ValidationError):jsonschema.validate(dict(policy=bad),schema)

    def test_parent_source_mapping_ignores_later_ground_recap(self):
        source='入口 Ground。\nGround 是父组，包含 Idle、Walk、Run、Crouch。\n落地后返回 Ground，从 Idle、Walk、Run、Crouch 中按输入选择。'
        topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run','Crouch'],initial='Idle',source_lines=[])])
        self.assertEqual(anchor_topology(topology,source)['groups'][0]['source_lines'],[1])

    def test_ground_policy_requires_complete_direct_children_and_idle_initial(self):
        request='Ground Ground为父组，包含Idle、Walk、Run、Crouch。Air包含JumpRise、JumpFall。JumpCount最多二段跳。'
        ir=copy.deepcopy(IR);ir.update(topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run','Crouch'],initial='Idle',source_lines=[0]),dict(id='Air',children=['JumpRise','JumpFall'],initial='JumpRise',source_lines=[0])],standalone=[]),jump=None)
        with self.assertRaisesRegex(ValueError,'每个直接子状态'):
            validate_extracted_stage('locomotion',dict(policy=dict(group='Ground',idle='Idle',walk=None,run=None,crouch=None)),ir,request)
        good=dict(policy=dict(group='Ground',idle='Idle',walk='Walk',run='Run',crouch='Crouch'))
        self.assertTrue(validate_extracted_stage('locomotion',good,ir,request))

    def test_requested_double_jump_cannot_be_dropped_or_use_ground_as_air(self):
        request='Ground Air JumpRise JumpFall JumpCount，最多连续成功起跳二段跳'
        ir=copy.deepcopy(IR);ir['topology']=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run','Crouch'],initial='Idle',source_lines=[0]),dict(id='Air',children=['JumpRise','JumpFall'],initial='JumpRise',source_lines=[0])],standalone=[])
        with self.assertRaisesRegex(ValueError,'不能输出null'):
            validate_extracted_stage('jump',dict(policy=None),ir,request)
        with self.assertRaisesRegex(ValueError,'空中父组'):
            validate_extracted_stage('jump',dict(policy=dict(group='Ground',rise='JumpRise',fall='JumpFall',counter='JumpCount',max_jumps=2)),ir,request)
        schema,_=extraction_messages('jump',request,ir)
        policy=schema['properties']['policy']['anyOf'][0]['properties']
        self.assertEqual(policy['group']['enum'],['Air'])
        self.assertEqual(policy['rise']['enum'],['JumpRise'])
        self.assertEqual(policy['fall']['enum'],['JumpFall'])

    def test_dependencies_schema_reserves_state_ids_and_internal_counters(self):
        request='为Ground Idle Walk Run Crouch Air JumpRise JumpFall JumpCount配置Motion Matching，外部变量bHit由蓝图传入。'
        reviewed=copy.deepcopy(IR)
        reviewed['topology']=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run','Crouch'],initial='Idle',source_lines=[0]),dict(id='Air',children=['JumpRise','JumpFall'],initial='JumpRise',source_lines=[0])],standalone=[])
        reviewed['jump']=dict(group='Air',rise='JumpRise',fall='JumpFall',counter='JumpCount',max_jumps=2)
        schema,_=extraction_messages('dependencies',request,reviewed)
        props=schema['properties']
        allowed=props['external_variables']['items']['properties']['id']['enum']
        self.assertIn('bHit',allowed)
        self.assertNotIn('Motion',allowed)
        for name in ('Crouch','JumpCount','JumpRise','JumpFall'):self.assertNotIn(name,allowed)
        unsupported=props['unsupported']['items']['not']['enum']
        for name in ('Crouch','JumpCount','JumpRise','JumpFall'):self.assertIn(name,unsupported)

    def test_dependencies_rejects_unmentioned_feature_terms_as_variables(self):
        request='Use Motion Matching for Ground Idle Walk Run.'
        schema,_=extraction_messages('dependencies',request,copy.deepcopy(IR))
        external=schema['properties']['external_variables']
        self.assertEqual(external['maxItems'],0)


    def test_english_ids_adjacent_to_chinese_are_preserved_without_matching_prefixes(self):
        source='请让Ground为父状态，包含Idle、Walk和Run；入口Ground。计数JumpCount<2。'
        self.assertEqual(set(source_identifiers(source)),{'Ground','Idle','Walk','Run','JumpCount'})
        self.assertFalse(identifier_in('Run','RunFast'));self.assertTrue(identifier_in('Run','使用Run状态'))
        topology=dict(entry='Ground',groups=[dict(id='Ground',children=['Idle','Walk','Run'],initial='Idle',source_lines=[])])
        validate_topology(dict(anchor_topology(topology,source),standalone=[]),source)
        schema,_=extraction_messages('topology',source,{'version':1})
        self.assertIn('Ground',schema['properties']['entry']['enum'])
    def test_optional_walk_and_run_are_covered_without_extra_states(self):
        for has_walk,has_run in ((False,False),(True,False),(False,True)):
            ir=copy.deepcopy(IR);ir.update(jump=None,combo=None)
            children=['Rest']+(['Stroll'] if has_walk else [])+(['Jog'] if has_run else [])
            ir['topology']=dict(entry='Travel',groups=[dict(id='Travel',children=children,initial='Rest',source_lines=[0])],standalone=[])
            ir['locomotion'].update(walk='Stroll' if has_walk else None,run='Jog' if has_run else None)
            source='Travel 为父状态，包含 '+','.join(children)
            graph,roles=compile_requirements(ir,source)
            self.assertEqual({s['id'] for s in graph['states']},set(children)|{'Travel'})
            self.assertEqual(set(roles),{'idle'}|({'walk'} if has_walk else set())|({'run'} if has_run else set()))
            self.assertEqual(validate_graph(graph,{'assets':[]},None,roles),[])
    def test_decode_variable_ids_are_source_grounded_with_visible_internal_defaults(self):
        request='Ground Idle Air Rise Fall JumpCount Buffered'
        jump,_=extraction_messages('jump',request,IR)
        combo,_=extraction_messages('combo',request,IR)
        dependencies,_=extraction_messages('dependencies',request,IR)
        self.assertIn('JumpCount',jump['properties']['policy']['anyOf'][0]['properties']['counter']['enum'])
        allowed=combo['properties']['policy']['anyOf'][0]['properties']['buffer']['enum']
        self.assertIn('Buffered',allowed);self.assertIn('Queued',allowed);self.assertNotIn('Buffer',allowed);self.assertNotIn('CachedAttack',allowed)
        self.assertEqual(dependencies['properties']['external_variables']['maxItems'],0)
    def test_model_variable_typo_is_rejected_without_changing_ir(self):
        ir=copy.deepcopy(IR);source=REQUEST+' Count Buffered'
        self.assertEqual(validate_generated_symbols(ir,source),{})
        ir['combo']['buffer']='Buffer'
        with self.assertRaisesRegex(ValueError,'Buffer'):validate_generated_symbols(ir,source)
        self.assertEqual(ir['combo']['buffer'],'Buffer')
        ir['combo']['buffer']='Queued'
        self.assertEqual(validate_generated_symbols(ir,source),{'combo.buffer':'Queued'})
    def test_source_mapping_does_not_change_semantics_or_accept_ambiguity(self):
        topology=copy.deepcopy(IR['topology']);topology['groups'][0]['source_lines']=[99]
        anchored=anchor_topology(topology,REQUEST)
        self.assertEqual(anchored['groups'][0]['source_lines'],[0])
        self.assertEqual(anchored['groups'][0]['children'],topology['groups'][0]['children'])
        self.assertEqual(anchored['groups'][0]['initial'],topology['groups'][0]['initial'])
        with self.assertRaises(ValueError):anchor_topology(topology,REQUEST+'\n'+REQUEST)
        topology['groups'][0]['initial']='Travel'
        with self.assertRaises(ValueError):validate_topology(anchor_topology(topology,REQUEST),REQUEST)
    def setUp(self):
        self.ir=copy.deepcopy(IR)
        self.catalog={'assets':[dict(id='mesh',kind='mesh',skeleton='s'),dict(id='clip',kind='sequence',skeleton='s',name='Attack',loop=False),dict(id='hurt',kind='sequence',skeleton='s',name='Hit',loop=False)]}
        self.bindings=dict(SwingA=['clip'],SwingB=['clip'],Flinch=['hurt'])
    def compile(self):return compile_requirements(self.ir,REQUEST,self.bindings)[0]
    def test_compiled_named_hierarchy_and_real_bindings_are_structurally_valid(self):
        graph=self.compile()
        self.assertEqual(validate_graph(graph,self.catalog,'mesh',['idle','walk','run','jump']),[])
        self.assertEqual(semantic_audit(self.ir,REQUEST,graph),[])
        self.assertEqual({s['id']:s.get('parent') for s in graph['states']}['Ascend'],'Sky')
    def test_missing_material_is_not_replaced_with_fixture(self):
        catalog={'assets':[self.catalog['assets'][0],dict(self.catalog['assets'][1],id='/Game/Native/Generated/ActionFlowFixture/A_attack_PlaybackTest.A_attack_PlaybackTest',name='A_attack_PlaybackTest')]}
        bindings,issues=resource_bindings(self.ir,catalog)
        self.assertEqual(bindings,{})
        self.assertEqual(len([i for i in issues if i['severity']=='error']),3)
    def test_foreign_skeleton_is_not_selected(self):
        self.catalog['assets'][1]['skeleton']='foreign'
        bindings,issues=resource_bindings(self.ir,self.catalog)
        self.assertNotIn('SwingA',bindings)
    def test_unrequested_entry_is_rejected(self):
        self.ir['topology']['entry']='RestFromExample'
        with self.assertRaisesRegex(ValueError,'Entry'):self.compile()
    def test_fabricated_parent_or_child_cannot_pass_grounding(self):
        self.ir['topology']['groups'][0]['id']='FakeParent'
        with self.assertRaises(ValueError):self.compile()
    def test_no_unconditional_buffer_assignment(self):
        graph=self.compile()
        self.assertTrue(all(not i['set'] and not i.get('actions') for i in graph['inputs']))
        handler=next(h for h in graph['handlers'] if h['from']=='SwingA')
        self.assertEqual([c['var'] for c in handler['condition']['all']],['animation_phase','animation_phase','Buffered'])
        self.assertFalse(any(e['from']==e['to'] for e in graph['transitions']))
    def test_launch_and_increment_share_same_guarded_actions(self):
        graph=self.compile()
        handler=next(h for h in graph['handlers'] if h['event']=='Jump')
        self.assertEqual(handler['condition'],dict(var='Count',op='lt',value=2))
        self.assertEqual([a['op'] for a in handler['actions']],['jump','add'])
        landing=next(e for e in graph['transitions'] if e['from']=='Sky' and e['event']=='Landed')
        self.assertEqual(landing['actions'],[dict(op='set',var='Count',value=0)])
    def test_jump_limit_is_parameterized(self):
        self.ir['jump']['max_jumps']=4
        graph=self.compile()
        self.assertEqual(next(h for h in graph['handlers'] if h['event']=='Jump')['condition']['value'],4)
    def test_explicit_numeric_fact_is_rejected_not_silently_repaired(self):
        self.ir['jump']['max_jumps']=3
        with self.assertRaisesRegex(ValueError,'上限'):compile_requirements(self.ir,REQUEST+'\nCount < 2',self.bindings)
        self.ir['jump']['max_jumps']=2
        with self.assertRaisesRegex(ValueError,'move_blend'):compile_requirements(self.ir,REQUEST+'\n普通移动混合0.31秒',self.bindings)
        self.ir['settings']['move_blend']=True
        with self.assertRaisesRegex(ValueError,'finite numbers'):self.compile()
    def test_single_ungrouped_mm_state_is_representable(self):
        ir=copy.deepcopy(self.ir)
        ir.update(topology=dict(entry='Move',groups=[],standalone=['Move']),locomotion=dict(group='Move',idle='Move',walk=None,run=None),jump=None,combo=None)
        graph,roles=compile_requirements(ir,'只有一个状态 Move，使用待机MM。')
        self.assertEqual(roles,['idle'])
        self.assertEqual(validate_graph(graph,self.catalog,'mesh',['idle']),[])
    def test_no_air_policy_does_not_leave_finished_hit_stuck_while_falling(self):
        self.ir['jump']=None
        self.ir['topology']['groups']=[g for g in self.ir['topology']['groups'] if g['id']!='Sky']
        graph=compile_requirements(self.ir,'\n'.join(line for line in REQUEST.splitlines() if not line.startswith('Sky ')),self.bindings)[0]
        edges=[e for e in graph['transitions'] if e['from']=='Flinch' and not e['event']]
        self.assertEqual(len(edges),1)
        self.assertEqual(edges[0]['all'],[dict(var='finished',op='eq',value=True)])
    def test_removed_reset_or_window_is_caught_by_semantic_audit(self):
        for mutate in (lambda g:g['handlers'][0].update(condition=dict(var='Buffered',op='eq',value=False)),lambda g:next(s for s in g['states'] if s['id']=='SwingA').update(on_exit=[]),lambda g:g['transitions'][0].update(all=[])):
            graph=self.compile();mutate(graph)
            self.assertTrue(semantic_audit(self.ir,REQUEST,graph))
    def test_internal_handler_has_no_destination_and_nonempty_event(self):
        graph=self.compile();graph['handlers'][0]['to']='Rest'
        self.assertTrue(validate_graph(graph,self.catalog,'mesh',['idle','walk','run','jump']))
        graph=self.compile();graph['handlers'][0]['event']=''
        self.assertTrue(validate_graph(graph,self.catalog,'mesh',['idle','walk','run','jump']))
    def test_external_source_is_explicit(self):
        graph=definition(dict(action='clip',hurt='hurt'))
        self.assertEqual(graph['variable_sources']['ExternalReady']['scope'],'external')
        self.assertEqual(validate_graph(graph,self.catalog,'mesh',['idle','walk','run','jump']),[])
        del graph['variable_sources']['ExternalReady']
        self.assertTrue(validate_graph(graph,self.catalog,'mesh',['idle','walk','run','jump']))
    def test_v2_does_not_silently_accept_v3_semantics(self):
        graph=self.compile();graph['version']=2
        self.assertTrue(validate_graph(graph,self.catalog,'mesh',['idle','walk','run','jump']))
    def test_reviewed_recompile_has_backup_and_distinct_manual_provenance(self):
        graph=self.compile()
        plan=dict(request=REQUEST,behavior_graph=graph,states=[dict(id=r) for r in ('idle','walk','run','jump')],issues=[],model_info=dict(behavior_requirements=copy.deepcopy(self.ir),behavior_generation=dict(mode='requirement_ir_compiler_v1')))
        plan['model_info']['behavior_requirements']['jump']['max_jumps']=3
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);catalog=root/'catalog.json';source=root/'plan.json';output=root/'compiled.json'
            catalog.write_text(json.dumps(self.catalog),encoding='utf-8');source.write_text(json.dumps(plan),encoding='utf-8')
            args=['config_tool','compile-behavior','--catalog',str(catalog),'--plan',str(source),'--output',str(output)]
            with patch.object(sys,'argv',args):self.assertEqual(config_tool.main(),0)
            result=json.loads(output.read_text(encoding='utf-8'))
            self.assertTrue(result['model_info']['behavior_generation']['requirements_edited_manually'])
            self.assertEqual(next(h for h in result['behavior_graph']['handlers'] if h['event']=='Jump')['condition']['value'],3)
            self.assertEqual(len(list(root.glob('plan.json.before_compile_*.json'))),1)
            self.assertEqual(json.loads(source.read_text(encoding='utf-8')),plan)

if __name__=='__main__':unittest.main()
