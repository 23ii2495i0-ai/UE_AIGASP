"""Numerical motion descriptors and an explicit unknown gate; no name-based labels."""
import argparse
import json
import math
from pathlib import Path

BONES=('pelvis','spine','head','hand_l','hand_r','foot_l','foot_r','knee_l','knee_r','elbow_l','elbow_r')


def describe(samples):
    if not isinstance(samples,dict) or samples.get('status')!='sampled':
        raise ValueError(samples.get('reason','not_sampled') if isinstance(samples,dict) else 'not_sampled')
    frames=samples['frames'];height=float(samples['reference_height_cm'])
    if len(frames)<8 or not math.isfinite(height) or height<=1:raise ValueError('insufficient_or_invalid_samples')
    times=[float(f['time']) for f in frames]
    if not all(math.isfinite(t) for t in times) or any(b<=a for a,b in zip(times,times[1:])):raise ValueError('invalid_sample_times')
    features={}
    for bone in BONES:
        positions=[[float(v)/height for v in f['positions_root_cm'][bone]] for f in frames]
        if any(len(p)!=3 or not all(math.isfinite(v) for v in p) for p in positions):raise ValueError('invalid_bone_positions')
        for axis in range(3):
            values=[p[axis] for p in positions];mean=sum(values)/len(values)
            features[f'{bone}.mean.{axis}']=mean
            features[f'{bone}.std.{axis}']=(sum((v-mean)**2 for v in values)/len(values))**.5
            features[f'{bone}.range.{axis}']=max(values)-min(values)
        speeds=[sum(((b[j]-a[j])/(tb-ta))**2 for j in range(3))**.5 for a,b,ta,tb in zip(positions,positions[1:],times,times[1:])]
        features[bone+'.speed_mean']=sum(speeds)/len(speeds)
        features[bone+'.speed_max']=max(speeds)
    roots=[[float(v)/height for v in f['root_position_cm']] for f in frames]
    if any(len(p)!=3 or not all(math.isfinite(v) for v in p) for p in roots):raise ValueError('invalid_root_positions')
    features['root.travel']=sum(sum((b[j]-a[j])**2 for j in range(3))**.5 for a,b in zip(roots,roots[1:]))
    features['root.speed_mean']=features['root.travel']/(times[-1]-times[0])
    features['duration_seconds']=times[-1]-times[0]
    return {k:round(v,7) for k,v in features.items()}


def inspect_asset(asset):
    result={'id':asset['id'],'semantic_role':'unknown','confidence':None,'usable_for_auto_binding':False}
    try:
        result['features']=describe(asset.get('motion_samples'))
        result['reason']='semantic_classifier_not_trained'
    except (ValueError,TypeError,KeyError,ZeroDivisionError) as exc:
        result['reason']=str(exc)
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--catalog',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();catalog=json.loads(args.catalog.read_text(encoding='utf-8-sig'))
    results=[inspect_asset(a) for a in catalog['assets'] if a['kind']!='mesh']
    report={'schema':1,'classification_enabled':False,'uses_asset_names_for_semantics':False,'assets':results,
            'summary':{'total':len(results),'descriptors':sum('features' in r for r in results),'unknown':len(results)}}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report['summary']))


if __name__=='__main__':main()
