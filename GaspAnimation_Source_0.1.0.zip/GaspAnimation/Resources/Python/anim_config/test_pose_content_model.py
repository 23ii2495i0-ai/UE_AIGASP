import sys,unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).parent/'ai'))
from project_paths import configure_imports
configure_imports()
from pose_content_model import BONES,PAIRS,encode,bvh_positions,parse_bvh


class PoseContentTests(unittest.TestCase):
    def positions(self):
        p=np.zeros((16,len(BONES),3))
        offsets=[[0,1,0],[0,1.5,0],[0,2,0],[-1,1.5,0],[1,1.5,0],[-.2,0,0],[.2,0,0],[-.2,.5,0],[.2,.5,0],[-.5,1.5,0],[.5,1.5,0]]
        p[:]=offsets
        for i in range(16):p[i,3,2]=.1*np.sin(i)
        return p,np.linspace(0,1,16)

    def test_units_translation_and_facing_invariance(self):
        p,t=self.positions();rotation=np.array([[0,-1,0],[1,0,0],[0,0,1]])
        np.testing.assert_allclose(encode(p,t),encode((p@rotation)*100+987,t),rtol=1e-5,atol=1e-5)

    def test_real_timing_changes_speed_not_shape(self):
        p,t=self.positions();a,b=encode(p,t),encode(p,t*2)
        np.testing.assert_allclose(a[:,:len(PAIRS)],b[:,:len(PAIRS)])
        np.testing.assert_allclose(a[:,len(PAIRS):-1]/2,b[:,len(PAIRS):-1])

    def test_invalid_and_degenerate_samples_rejected(self):
        p,t=self.positions();t[1]=t[0]
        with self.assertRaises(ValueError):encode(p,t)
        with self.assertRaises(ValueError):encode(np.zeros_like(p),np.linspace(0,1,16))

    def test_duplicate_content_merges_subject_aliases_transitively(self):
        from train_pose_content import clean_rows
        rows=[dict(id=str(i),subject=s,role='walk',download={'sha256':h}) for i,(s,h) in enumerate([('01','a'),('02','a'),('02','b'),('03','b'),('04','c')])]
        clean,aliases,removed=clean_rows(rows)
        self.assertEqual(removed,2);self.assertEqual(len(clean),3)
        self.assertEqual(aliases['01'],aliases['03']);self.assertNotEqual(aliases['01'],aliases['04'])
        bad=[dict(rows[0]),dict(rows[1],role='attack')]
        with self.assertRaises(ValueError):clean_rows(bad)

    def test_bvh_parser_header_and_intrinsic_rotation(self):
        text='HIERARCHY ROOT Hips { OFFSET 0 0 0 CHANNELS 6 Xposition Yposition Zposition Zrotation Yrotation Xrotation JOINT Spine1 { OFFSET 1 0 0 CHANNELS 3 Zrotation Yrotation Xrotation End Site { OFFSET 0 1 0 } } } MOTION Frames: 1 Frame Time: 0.01\n0 0 0 90 0 0 0 0 0'
        nodes,data,dt=parse_bvh(text)
        from pose_content_model import BVH_BONES
        # Add passive joints to test the root's 90 degree world rotation independently.
        nodes.extend(dict(name=b,parent=0,offset=np.array([1.,0,0]),channels=[],start=9) for b in BVH_BONES if b not in ('Hips','Spine1'))
        positions=bvh_positions(nodes,data,[0]);np.testing.assert_allclose(positions[0,1],[0,1,0],atol=1e-7)
        self.assertEqual(dt,.01)
        with self.assertRaises(ValueError):parse_bvh(text+' 12')


if __name__=='__main__':unittest.main()
