# GASP AI interfaces

Install this directory using your **training Python**, for example `python -m pip install -e .`.
The core SDK has no heavyweight imports. Install `[training,constrained]` extras when you need local model inference/training; the project's existing training environment can be reused.

`gasp-ai init --workspace <external-data-directory> --deployment <existing-split_deployment.json> --dataset-root <data-root>` creates an editable `gasp_ai.json`. `data-root` contains separate `generator/` and `selector/` folders, each with train/validation/test JSONL files.

- `gasp-ai doctor --config <json>` checks paths and dependencies without loading weights.
- `gasp-ai check --config <json> --task generator` validates isolated generator data; repeat for selector.
- `gasp-ai train --config <json> --task generator --dry-run` prints the exact training plan. Remove `--dry-run` to train. Selector training uses its own adapter/output and `--task selector`.
- `gasp-ai infer --config <json> --task generator --request "..." --output configuration.json` runs resource-free planning. Pass the output file directly to selector inference with `--catalog` and `--configuration`; a raw prediction object is also accepted.
- `gasp-ai serve --config <json> --port 8767` runs the editor-compatible pipeline on an isolated review port. Set the UE plugin endpoint to `http://127.0.0.1:8767/generate`.

Generator means classification/semantic configuration planning, not resource binding. Selector binds immutable generated slots to selected resources. Pose classification is an optional auxiliary model under `anim_config/ai/pose`, not a replacement for either model. Training does not promote or replace the active model service.

## Extend independently

Implement `Predictor.predict_batch(messages, *, stage)` and return one JSON string/object per input. Register generator factories in `gasp_ai.generator_providers`, selector factories in `gasp_ai.selector_providers`, or set a trusted `package.module:factory` in that role's `provider`. Factories receive `ModelSpec`. Stages may be `generator`/`behavior` for a generator, and `selector` for a selector; crossing this boundary is rejected. Existing runtime protocol validation still applies.

Built-in `builtin` preserves the evaluated shared-base/two-adapter backend. `huggingface_lora` loads a role's own base and adapter lazily, allowing separate architectures/checkpoints per role. Provider overrides on the pipeline service use a review port; old evaluated metrics do not certify new providers. Custom trainers implement `Trainer.train(spec, *, dry_run, check_only)` and register in `gasp_ai.trainers` or use `package.module:factory` as the trainer ID.

Model weights, datasets, checkpoints and logs live in the external workspace. `GASP_AI_WORKSPACE` overrides workspace discovery, and `GASP_AI_BACKEND` can explicitly locate a nonstandard backend installation. Legacy scripts remain private implementation details; use the SDK CLI/config/contracts for new integrations.
