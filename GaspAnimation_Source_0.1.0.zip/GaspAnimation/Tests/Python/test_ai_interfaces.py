import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import io
from contextlib import redirect_stdout

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "Resources/Python"))
from gasp_ai import Task, register_provider
from gasp_ai.config import load_config
from gasp_ai.runtime import attach_runtime, provider_batch


def profile(root):
    return {"version": 1, **{task: {"task": task, "provider": "builtin", "base_model": "base", "adapter": task + "/adapter", "output_dir": "runs/" + task} for task in ("generator", "selector")}}


class RecordingProvider:
    def __init__(self, label): self.label = label; self.calls = []
    def predict_batch(self, messages, *, stage):
        self.calls.append((stage, messages))
        return [{"provider": self.label, "stage": stage} for _ in messages]


class AIInterfaces(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.path = self.root / "gasp_ai.json"
        self.data = profile(self.root)
    def tearDown(self): self.tmp.cleanup()
    def save(self): self.path.write_text(json.dumps(self.data), encoding="utf-8")
    def test_relative_paths_follow_config_not_cwd(self):
        self.save(); _, specs = load_config(self.path)
        self.assertEqual(specs[Task.GENERATOR].adapter, self.root / "generator/adapter")
        self.assertNotEqual(specs[Task.GENERATOR].output_dir, specs[Task.SELECTOR].output_dir)
    def test_reject_shared_training_output(self):
        self.data["selector"]["output_dir"] = self.data["generator"]["output_dir"]
        self.save()
        with self.assertRaises(ValueError): load_config(self.path)
    def test_reject_swapped_role(self):
        self.data["selector"]["task"] = "generator"; self.save()
        with self.assertRaises(ValueError): load_config(self.path)
    def test_independent_provider_dispatch_in_real_pipeline_wrapper(self):
        generator, selector = RecordingProvider("generator"), RecordingProvider("selector")
        register_provider("generator", "record_generator", lambda spec: generator)
        register_provider("selector", "record_selector", lambda spec: selector)
        self.data["generator"]["provider"] = "record_generator"
        self.data["selector"]["provider"] = "record_selector"; self.save()
        runtime = types.SimpleNamespace(); attach_runtime(runtime, self.path)
        from gasp_ai.paths import configure_legacy
        configure_legacy()
        from split_runtime import SplitRuntime
        messages = [[{"role": "user", "content": "test"}]]
        self.assertEqual(json.loads(SplitRuntime.predict_batch(runtime, "generator", messages)[0])["provider"], "generator")
        self.assertEqual(json.loads(SplitRuntime.predict_batch(runtime, "selector", messages)[0])["provider"], "selector")
        self.assertEqual(len(generator.calls), 1);self.assertEqual(len(selector.calls), 1)
    def test_reject_provider_crossing_roles(self):
        register_provider("generator", "record_bad", lambda spec: RecordingProvider("bad"))
        self.data["generator"].update(provider="record_bad", options={"stages": ["selector"]});self.save()
        with self.assertRaises(ValueError):attach_runtime(types.SimpleNamespace(), self.path)
    def test_reject_provider_batch_shape(self):
        class Empty:
            def predict_batch(self, messages, *, stage):return []
        with self.assertRaises(ValueError):provider_batch(Empty(), "selector", [[{}]])

    def test_cli_uses_adapter_prompt_version(self):
        self.save()
        from gasp_ai.paths import configure_legacy
        configure_legacy()
        from gasp_ai.cli import main
        from split_protocol import generator_messages
        result = dict(roles=['walk'], blend_seconds=0.2, filters={}, policy={}, slots={'walk':'locomotion'}, reject=None)
        calls = []
        runtime = types.SimpleNamespace(generator_prompt_version=1, predict=lambda task, messages: calls.append((task, messages)) or result)
        with patch('gasp_ai.runtime.create_builtin_runtime', return_value=runtime), redirect_stdout(io.StringIO()):
            main(['infer', '--config', str(self.path), '--task', 'generator', '--request', 'walk'])
        self.assertEqual(calls, [('generator', generator_messages('walk', 1))])

    def test_selector_accepts_generator_output_wrapper(self):
        self.save()
        from gasp_ai.paths import configure_legacy
        configure_legacy()
        from gasp_ai.cli import main
        configuration = dict(roles=['walk'], blend_seconds=0.2, filters={}, policy={}, slots={'walk':'locomotion'}, reject=None)
        generated = self.root/'generated.json'
        generated.write_text(json.dumps(dict(task='generator', prediction=configuration, requires_human_review=True)), encoding='utf-8')
        catalog = self.root/'catalog.json'
        catalog.write_text(json.dumps(dict(version=1, assets=[])), encoding='utf-8')
        calls = []
        runtime = types.SimpleNamespace(generator_prompt_version=1, predict=lambda task, messages: calls.append(messages) or dict(bindings={'walk':None}, issues={'walk':'mesh'}))
        with patch('gasp_ai.runtime.create_builtin_runtime', return_value=runtime), redirect_stdout(io.StringIO()):
            main(['infer', '--config', str(self.path), '--task', 'selector', '--request', 'walk', '--catalog', str(catalog), '--configuration', str(generated)])
        self.assertEqual(json.loads(calls[0][1]['content'])['configuration'], configuration)


if __name__ == "__main__": unittest.main()
