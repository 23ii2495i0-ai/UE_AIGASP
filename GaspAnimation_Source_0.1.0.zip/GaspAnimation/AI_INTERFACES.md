# AI 用户入口与扩展

生成器 `generator` 负责分类、语义配置规划；选择器 `selector` 根据候选目录填充已确定的资源槽。两者分别配置 adapter、数据集、训练输出和 provider，不能共用 adapter 或输出目录。姿态模型仍是独立实验辅助，不承担这两个职责。

## 当前工程使用

在仓库根打开终端。`GaspAI.cmd` 优先使用 `GASP_CONFIG_PYTHON`，其次已有 `.anim_model_env`，最后系统 Python。模型数据不复制到插件。

```powershell
.\GaspAI.cmd init --workspace D:/GaspAI/MyTraining --deployment artifacts/anim_config/models/configuration/runs/expanded_slots_v3/split_deployment.json --dataset-root artifacts/anim_config/models/configuration/datasets/formal_split_v1/data
.\GaspAI.cmd doctor --config D:/GaspAI/MyTraining/gasp_ai.json
.\GaspAI.cmd check --config D:/GaspAI/MyTraining/gasp_ai.json --task generator
.\GaspAI.cmd train --config D:/GaspAI/MyTraining/gasp_ai.json --task generator --dry-run
.\GaspAI.cmd train --config D:/GaspAI/MyTraining/gasp_ai.json --task selector --dry-run
```

`check` 使用实际训练数据协议验证，`--dry-run` 保存完整计划而不加载模型；删除 `--dry-run` 开始该角色的训练。数据目录分别是 `generator/`、`selector/`，每个包含 train.jsonl、validation.jsonl、test.jsonl。数据行格式由现有 split_protocol/model_train 验证，不能把自然语言文本直接当训练样本。`training` 可修改 steps、学习率等已有训练器配置。训练输出独立，完成后需要评测与人工确认，再把配置中的 adapter 指向新输出；不会自动切换当前活动服务。

`lora_sft` 是分类/资源槽协议的训练器。需求抽取的多阶段实验训练器仍在 `anim_config/ai/configuration/training/train_behavior_requirements.py`，它使用另一套 requirement_ir_v1 数据，不能把它的权重直接当 selector；可按下述 Trainer 接口封装扩展。

## 脱离本仓库安装

```powershell
python -m pip install -e ./Resources/Python
# 需要训练或本地模型推理时：
python -m pip install -e './Resources/Python[training,constrained]'
gasp-ai init --workspace D:/GaspAI/MyTraining
```

编辑生成的 JSON，填入实际 base_model、adapter 和数据路径。相对路径以 JSON 所在目录为基准。`builtin` 使用原有共享基座/双 adapter CUDA 后端；独立基座可选 `huggingface_lora`，按各角色懒加载。CPU 推理可在该 provider 的 options.device 中设 cpu。SDK 本身不依赖 torch，doctor 和自定义轻量 provider 可独立使用。

```powershell
gasp-ai infer --config gasp_ai.json --task generator --request "四向走跑" --output generated.json
gasp-ai infer --config gasp_ai.json --task selector --request "四向走跑" --catalog catalog.json --configuration generated.json --output selected.json
gasp-ai serve --config gasp_ai.json --port 8767
```

infer 输出包含 task/prediction/requires_human_review；selector 可直接接收生成器输出文件。catalog 必须是实际资源目录协议。serve 保留编辑器兼容的完整管线，需要配置已有评测部署 deployment；修改模型 provider 使用独立审核端口，UE 服务地址设 `http://127.0.0.1:8767/generate`。新 provider 不继承旧模型的评测成绩。正式 8765 服务拒绝 provider 覆盖。

## 扩展推理与训练

契约位于 `gasp_ai/contracts.py`。自定义模块必须安装到运行 Python 可导入的位置；配置的 `provider` 可写 `your_package.models:create_generator` 或 `your_package.models:create_selector`。factory 接收 ModelSpec，返回实现以下方法的对象：

```python
class MyPredictor:
    def predict_batch(self, messages, *, stage):
        # 返回与输入数目一致的 JSON 对象或 JSON 字符串。
        return [self.generate_one(conversation, stage) for conversation in messages]

def create_generator(spec):
    return MyGenerator(spec)  # 用户自己的实现
```

生成器允许 generator/behavior 阶段，选择器只允许 selector 阶段；不能跨角色映射。返回结果仍接受现有协议、资源槽和目录校验。全局注册可用 `register_provider(Task.GENERATOR, name, factory)`，也可在自己的 pyproject 中声明 `gasp_ai.generator_providers` 或 `gasp_ai.selector_providers` entry point，分别配置角色。

自定义训练器实现 `train(spec, *, dry_run=False, check_only=False) -> dict`；将 `trainer` 设为 `your_package.training:create_trainer`，或声明 `gasp_ai.trainers` entry point。检查模式必须只校验，dry_run 必须只输出计划；训练结果写到 spec.output_dir，不自动部署。适配其他模型、远程推理、蒸馏或需求抽取训练时可复用这些入口。

## 原数据与兼容性

姿态辅助权重是可选项：外部工作目录中未安装时明确关闭该辅助，不阻止生成器/选择器启动；可用 `GASP_POSE_MODEL` 指定已有姿态 run 目录。已安装但文件不完整或哈希不符仍报错。builtin 服务必须匹配其 deployment 的基座和双 adapter，避免配置修改后服务仍悄悄使用旧模型。

`artifacts/anim_config/models` 保留现有权重、训练数据与评测；旧模型路径中的 junction 只作兼容，不复制或清理目标。仓库 `tools/anim_config` 也是到插件后端的兼容 junction，新集成应依赖公开 SDK。`GASP_AI_WORKSPACE` / 项目设置 AIWorkspace 决定数据根，`GASP_AI_BACKEND` 可指定特殊后端安装目录。旧需求实验中使用源码哈希锁定的部署在代码迁移后需要重新审核，不改写其已有合格标记。
